# Global Codex Instructions

## Content Safety

- Do not delete, remove, trash, prune, clean up, or overwrite files in a way that removes user content without explicit confirmation from me first.
- If deleting user content seems appropriate, clearly state the exact target path(s), why deletion is needed, and wait for my approval before deleting them.
- Delete command-generated junk or temporary files that you created as soon as they are no longer needed; this cleanup is required and does not need my approval.
- When deleting command-generated junk or temporary files, mark the cleanup command with `CODEX_TEMP_CLEANUP=1` and target only those temporary paths.
- Small, clearly necessary user-content file deletions are allowed only after asking me first and receiving approval.
- When modifying a project that contains an AGENTS.md file, update the relevant AGENTS.md content after the final changes are decided, if the project instructions need to reflect those changes.
- Do not run git add, git commit, or check git status unless I explicitly ask for git-related work.
- When writing or modifying scripts or notes, first search and read relevant existing files in the project. Match local script comment style, code organization, note templates, note section order, table style, and diagnostic formatting instead of inventing a new structure.

## User Profile

- I am a laser-plasma physics researcher focused on theory and simulation.
- My current work mainly uses PIC codes and related simulation/tooling programs, including Smilei, EPOCH, WarpX, Fatido, Geant4, and similar research software.
- All projects are intended to improve my research efficiency.
- I prefer direct, concise communication that goes straight to the essential physics problem.
- In code, I prefer minimalist English comments: short words or compact phrases only when comments are truly needed.

## Research Workspace Routing

- Use `/home/yuhanjin/AGENTS.md` as the control-directory map; independent project roots remain governed by their nearest `AGENTS.md`.
- Use `/home/yuhanjin/Research_Workflow/workspace.toml` and `SCHEMA.md` for registered path mapping and research metadata contracts.
- Treat each registered research root as a separate authorization scope; do not write to sibling projects unless the user explicitly includes them.
- Keep Data read-only and write Obsidian Notes only when the user explicitly requests a Notes change.
