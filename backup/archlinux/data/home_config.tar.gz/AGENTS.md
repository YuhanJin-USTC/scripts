# Global Codex Instructions

## Content Safety

- Do not delete, remove, trash, prune, clean up, or overwrite files in a way that removes user content without explicit confirmation from me first.
- If deleting user content seems appropriate, clearly state the exact target path(s), why deletion is needed, and wait for my approval before deleting them.
- Delete command-generated junk or temporary files that you created as soon as they are no longer needed; this cleanup is required and does not need my approval.
- When deleting command-generated junk or temporary files, mark the cleanup command with `CODEX_TEMP_CLEANUP=1` and target only those temporary paths.
- Small, clearly necessary user-content file deletions are allowed only after asking me first and receiving approval.
- When modifying a project that contains an AGENTS.md file, update the relevant AGENTS.md content after the final changes are decided, if the project instructions need to reflect those changes.
- Do not run git add, git commit, or check git status unless I explicitly ask for git-related work.
- When writing or modifying scripts or notes, first search and read relevant existing files in the project. Match local script comment style, code organization, note templates, note section order, table style, and diagnostic formatting instead of inventing a new structure.

## User Profile

- I am a laser-plasma physics researcher focused on theory and simulation.
- My current work mainly uses PIC codes and related simulation/tooling programs, including Smilei, EPOCH, WarpX, Fatido, Geant4, and similar research software.
- All projects are intended to improve my research efficiency.
- I prefer direct, concise communication that goes straight to the essential physics problem.
- In code, I prefer minimalist English comments: short words or compact phrases only when comments are truly needed.

## Research Workspace Routing

- Use `/home/yuhanjin/AGENTS.md` as the control-directory map; independent project roots remain governed by their nearest `AGENTS.md`.
- Use `/home/yuhanjin/Research_Workflow/workspace.toml` and `SCHEMA.md` for registered path mapping and research metadata contracts.
- Treat each registered research root as a separate authorization scope; do not write to sibling projects unless the user explicitly includes them.
- Keep Data read-only and write Obsidian Notes only when the user explicitly requests a Notes change.
- Restore compact Case, Study, Project, or exact registered root/path memory before substantive work; follow event IDs and evidence only as needed.
- Record one substantive result as an event at its exact owner. Ordinary work does not require a Case change or an empty research hierarchy.
- For explicit registration or simulation-definition changes, finish files/checks, show the saved preview, actually ask and await the user, then apply the accepted digest. A digest proves equality, not consent.
- Preserve purpose, actual result, accepted reasons, validation level and limits in existing event summary/evidence fields. Do not log ordinary discussion turn by turn.
- Treat the local SQLite index as disposable cache and the append-only metadata streams as portable authority.
<!-- research-workflow:policy:start -->
<!-- digest: 53b828bcd3473143cd53c8eb3790393d6fec47f065abe2b14e0e167f32b593b7 -->
## Managed Research Workflow Policy

- `case-confirmation`: "A Case target does not imply a Case edit. For explicit registration or simulation-definition changes, finish files/checks, show the saved preview, actually ask and await the user, then apply the exact plan. A digest is not consent; unchanged accepted definitions add no revision."
- `external-operations`: "Do not run cluster, simulation, MATLAB, network, sync, build, or Git mutations without explicit user authorization."
- `framework-authority`: "Use Research Workflow 0.2.3 and the unversioned researchctl CLI. Preserve journal-only Case authority, original Event fields, historical migrate/tombstone bindings, immutable streams, and fail-closed forks."
- `indexing`: "Treat SQLite and saved plans as device-local derived state. Queries may refresh the disposable index; never synchronize it or use it as authority."
- `multi-device`: "Synchronize and check portable authority before context or any portable write after switching devices, including event-only work. Keep local TOML/device/paths, upgrade devices sequentially, and stop old metadata writers until local acceptance. External sync remains separately authorized."
- `propagation`: "Preview pending policy semantics, exact targets and differences; obtain real user approval of the stable digest, record it through policy approve, then apply. Preserve cumulative device approvals and unmanaged AGENTS bytes; Data/Notes and body patches require exact separate scope."
- `recording`: "Restore bounded Case, Study, Project, or exact root/path memory. Record one substantive result as an event at the most specific owner; retain purpose, result, accepted reasons, validation level and limits in existing summary/evidence. Do not log ordinary Q&A or create empty membership or pending queues."
- `workspace-routing`: "Resolve local access through verified roots and explicit mappings. Logical memory may be queried without a local mapping, but new writes require local registration. Keep Data read-only and Notes access within exact authorized links/sections."

<!-- research-workflow:policy:end -->
