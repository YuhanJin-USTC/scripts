# Global Codex Instructions

## Content Safety

- Do not delete, remove, trash, prune, clean up, or overwrite files in a way that removes user content without explicit confirmation from me first.
- If deleting user content seems appropriate, clearly state the exact target path(s), why deletion is needed, and wait for my approval before deleting them.
- Delete command-generated junk or temporary files that you created as soon as they are no longer needed; this cleanup is required and does not need my approval.
- When deleting command-generated junk or temporary files, mark the cleanup command with `CODEX_TEMP_CLEANUP=1` and target only those temporary paths.
- Small, clearly necessary user-content file deletions are allowed only after asking me first and receiving approval.
- When modifying a project that contains an AGENTS.md file, update the relevant AGENTS.md content after the final changes are decided, if the project instructions need to reflect those changes.
- Do not run git add, git commit, or check git status unless I explicitly ask for git-related work.
- When writing or modifying scripts or notes, first search and read relevant existing files in the project. Match local script comment style, code organization, note templates, note section order, table style, and diagnostic formatting instead of inventing a new structure.

## User Profile

- I am a laser-plasma physics researcher focused on theory and simulation.
- My current work mainly uses PIC codes and related simulation/tooling programs, including Smilei, EPOCH, WarpX, Fatido, Geant4, and similar research software.
- All projects are intended to improve my research efficiency.
- I prefer direct, concise communication that goes straight to the essential physics problem.
- In code, I prefer minimalist English comments: short words or compact phrases only when comments are truly needed.

## WSL Tool Execution

- For WSL work, run Bash, Python, and Node through `exec_command` with Linux paths and Linux executables. Use `functions.exec` to call tools; its JavaScript environment has no local filesystem.
- In Codex desktop 26.1007.21434, the bundled `node_repl` MCP launches a Windows executable and rejects Linux `sandboxCwd` URIs. For local code, use native `/usr/bin/node` or `/usr/bin/python3` through `exec_command`. Retest this limitation after an app update; tools that specifically require the desktop REPL may still be unavailable.
- The app rewrites its bundled `node_repl` configuration at startup. Disabling that server in `config.toml` alone is not a persistent fix. Preserve sandbox permissions and do not rewrite sandbox metadata to hide the platform mismatch.
- WSL `npm` and `npx` are available in `/home/yuhanjin/.local/bin`, using Linux Node and npm 11.13.0 under `/home/yuhanjin/.local/share/codex-wsl/npm`. Check command resolution before using a Windows-mounted development tool.

## Research Workspace Routing

- Use `/home/yuhanjin/AGENTS.md` as the control-directory map; independent project roots remain governed by their nearest `AGENTS.md`.
- Use `/home/yuhanjin/Research_Workflow/workspace.toml` and `SCHEMA.md` for registered path mapping and research metadata contracts.
- `/home/yuhanjin/Tool_Project` groups independent tool repositories and is not a Git repository or research root. Read its routing instructions, then the selected child's nearest `AGENTS.md`: `Daily_Arxiv` owns the arXiv digest (`daily_arxiv`); `Figure_Browser` owns the local figure browser (`matlab_html`). Resolve each active path through the local registry before access.
- Portable Tool_Project onboarding and recreation of its local parent files belong in `Research_Workflow/GIT_PRIVATE_REMOTE.md`. Child clones do not deliver this home map, the parent README/AGENTS or device-local TOML. Preserve historical policy approvals through the control repository without reusing another device's authorization. Keep root IDs stable across verified directory moves and devices.
- Treat each registered research root as a separate authorization scope; do not write to sibling projects unless the user explicitly includes them.
- Keep Data read-only and write Obsidian Notes only when the user explicitly requests a Notes change.
- Restore compact Case, Study, Project, or exact registered root/path memory before substantive work; follow event IDs and evidence only as needed.
- Record one substantive result as an event at its exact owner. Ordinary work does not require a Case change or an empty research hierarchy.
- For explicit registration or simulation-definition changes, finish files/checks, show the saved preview, actually ask and await the user, then apply the accepted digest. A digest proves equality, not consent.
- Preserve purpose, actual result, accepted reasons, validation level and limits in existing event summary/evidence fields. Do not log ordinary discussion turn by turn.
- Treat the local SQLite index as disposable cache and the append-only metadata streams as portable authority.
<!-- research-workflow:policy:start -->
<!-- digest: 89d09a6994f49df8c13b524a2af6ad0acf361194fc848c001cb517be1ee3a44f -->
## Managed Research Workflow Policy

- `case-confirmation`: "A Case target does not imply a Case edit. For explicit registration or simulation-definition changes, finish files/checks, show the saved preview, actually ask and await the user, then apply the exact plan. A digest is not consent; unchanged accepted definitions add no revision."
- `external-operations`: "Do not run cluster, simulation, MATLAB, network, sync, build, or Git mutations without explicit user authorization."
- `framework-authority`: "Use Research Workflow 0.2.4 and the unversioned researchctl CLI. Preserve journal-only Case authority, original Event fields, historical migrate/tombstone bindings, immutable streams, and fail-closed forks."
- `indexing`: "Treat SQLite and saved plans as device-local derived state. Queries may refresh the disposable index; never synchronize it or use it as authority."
- `multi-device`: "Synchronize and check portable authority before context or any portable write after switching devices, including event-only work. Keep local TOML/device/paths, upgrade devices sequentially, and stop old metadata writers until local acceptance. External sync remains separately authorized."
- `propagation`: "Preview pending policy semantics, exact targets and differences; obtain real user approval of the stable digest, record it through policy approve, then apply. Preserve cumulative device approvals and unmanaged AGENTS bytes; Data/Notes and body patches require exact separate scope."
- `recording`: "Restore bounded Case, Study, Project, or exact root/path memory. Record one substantive result as an event at the most specific owner; retain purpose, result, accepted reasons, validation level and limits in existing summary/evidence. Do not log ordinary Q&A or create empty membership or pending queues."
- `workspace-routing`: "Resolve local access through verified roots and explicit mappings. Logical memory may be queried without a local mapping, but new writes require local registration. Keep Data read-only and Notes access within exact authorized links/sections."

<!-- research-workflow:policy:end -->
