#
# ~/.bash_profile
#

[[ -f ~/.bashrc ]] && . ~/.bashrc

# Codex WSL state
if [[ -n ${WSL_DISTRO_NAME:-} ]]; then
    export CODEX_HOME="/home/yuhanjin/.local/share/codex-wsl"
fi
