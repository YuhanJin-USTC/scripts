return {
  { -- Autoformat
    'stevearc/conform.nvim',
    event = { 'BufWritePre' },
    cmd = { 'ConformInfo' },
    keys = {
      {
        '<leader>f',
        function()
          require('conform').format { async = true, lsp_format = 'fallback' }
        end,
        mode = '',
        desc = '[F]ormat buffer',
      },
    },
    opts = {
      notify_on_error = false,
      -- disable format_on_save
      format_on_save = false,
      -- format_on_save = function(bufnr)
      --   -- Disable "format_on_save lsp_fallback" for languages that don't
      --   -- have a well standardized coding style. You can add additional
      --   -- languages here or re-enable it for the disabled ones.
      --   local disable_filetypes = { c = true, cpp = true }
      --   local lsp_format_opt
      --   if disable_filetypes[vim.bo[bufnr].filetype] then
      --     lsp_format_opt = 'never'
      --   else
      --     lsp_format_opt = 'fallback'
      --   end
      --   return {
      --     timeout_ms = 500,
      --     lsp_format = lsp_format_opt,
      --   }
      -- end,
      formatters_by_ft = {
        lua = { 'stylua' },
        c = { 'clang_format' },
        cpp = { 'clang_format' },
        python = { 'isort', 'black' },
        latex = { 'latexindent' },
        tex = { 'latexindent' },
        plaintex = { 'latexindent' },
        nu = { 'topiary' },
        def = { 'def_fmt' },
        sh = { 'shfmt_format' },
        singularity = { 'def_fmt' },
        -- Conform can also run multiple formatters sequentially
        -- python = { "isort", "black" },
        --
        -- You can use 'stop_after_first' to run the first available formatter from the list
        -- javascript = { "prettierd", "prettier", stop_after_first = true },
      },
      formatters = {
        clang_format = {
          command = 'clang-format',
          append_args = function()
            return { '--fallback-style=Microsoft' }
          end,
        },
        topiary = {
          command = 'topiary',
          args = { 'format', '--language', 'nu' },
          env = function()
            return {
              XDG_CACHE_HOME = vim.env.NVIM_EXTERNAL_CACHE_HOME
                or (not vim.env.NVIM_MANAGED_GENERATION and vim.env.XDG_CACHE_HOME)
                or vim.env.HOME .. '/.cache',
              TOPIARY_CONFIG_FILE = vim.env.TOPIARY_CONFIG_FILE or vim.env.HOME .. '/.config/topiary/languages.ncl',
              TOPIARY_LANGUAGE_DIR = vim.env.TOPIARY_LANGUAGE_DIR or vim.env.HOME .. '/.config/topiary/languages',
            }
          end,
          stdin = true,
        },
        shfmt_format = {
          command = 'shfmt',
          args = { '-i', '2' },
          stdin = true,
        },

        def_fmt = { command = 'singularity_def_fmt', args = {} },
      },
    },
  },
}
