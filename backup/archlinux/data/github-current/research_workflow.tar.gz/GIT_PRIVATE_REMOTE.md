# Research Workflow Private Git and Device Upgrade

## 0.2.4 activation order

Source implementation does not activate Store 3 or policy targets. Preserve
local work and stop old writers on every device. External publication/sync needs
separate authorization; no 0.2.4 release ref or remote acceptance is claimed.
Review/apply body changes first; preview and confirm the Store upgrade digest;
then prepare each exact device/path retirement separately and approve its current
plan before apply. Retain superseded rules and cumulative authorized paths.
Global 0.2.4 policy propagation follows with exact per-device scope; Data/Notes
and other projects require their own scope authorization. File deletion is a
separate final operation after retirement and a fresh exact deletion review.

Store 3 rejects 0.2.3 writers only after that copy receives the new Store; it
cannot stop an unsynchronized old copy. On each device, keep its identity/TOML
and independently verify mappings, explicit allowlists, installation, doctor,
event merge, validate and policy drift before resuming writes. Do not transplant
SQLite or confirmation/replay plans. Compatibility-only doctor checks archived
code/Store without a workspace, but does not replace this acceptance sequence.
The 0.2.3 publication commands below are historical procedure, not a chosen
0.2.4 branch. Fill the real reviewed release ref only after publication.

## Delivery state and boundaries

Delivery branch: `update_0.2.3`. Publication is **unpublished**; no release commit,
verified remote fetch, push or real laptop-1 deployment has occurred. Replace
this status with the actual published commit/ref only after those operations.
Local laptop-2 implementation, protected instruction deployment and independent
release acceptance completed on 2026-09-20 UTC: 199 tests passed and one existing
utility skip; structural, policy and installed-skill checks passed. Exact evidence
is in `FRAMEWORK_BASELINE.md`. A two-workspace fixture does not prove real
laptop-1 deployment.

Only this repository's source/tests/templates/skill/metadata/policy/instructions
and maintenance documentation are synchronized. Keep runtime `workspace.toml`,
`.research-workflow/`, SQLite, saved confirmation plans, credentials and external
scientific files out of Git. Every external `AGENTS.md` and skill symlink is
maintained on its own device. Preserve `.gitattributes` JSON/JSONL byte behavior.
Do not normalize or rewrite historical streams. Data remains read-only and
Data/Notes policy targets have `separate_approval=true`.

All commands below that use Git/network require explicit user authorization.
No CLI/skill executes them automatically; `sync plan` is always advisory.
Remote privacy must be verified by the user. Never copy private keys, force
push, reset, discard local work, or auto-resolve scientific journals.

## First-device publication, still pending

Local independent release acceptance and the protected policy/body apply are
complete. The single framework-root completion checkpoint precedes publication;
there are no per-stage duplicates. With authorization, inspect the actual branch
and exact candidates:

```bash
git status --short --branch
git branch --show-current
git diff --check
```

The delivery branch must be `update_0.2.3`; if a different branch is current,
resolve the intended branch with the user before publishing. Review exact files
and exclude local TOML/cache/plans/secrets. Once the exact candidate list is
reviewed, use `git add -- <exact-approved-paths>`, `git diff --cached --check`,
`git diff --cached --name-only`, and `git diff --cached`. Then:

```bash
git commit -m "Upgrade Research Workflow to 0.2.3"
git push -u origin update_0.2.3
git rev-parse HEAD
```

Record the resulting commit and confirmed `origin/update_0.2.3` publication.
Do not present placeholders or an unpushed commit as a usable remote release.
Merging to another branch remains a separate authorized operation.

## Second-device source and local configuration

1. Stop old Research Workflow metadata writers on laptop-1. Preserve all local
   work and identify unpublished changes; research computation/plotting/job
   submission is independent. No device resumes metadata writing until its own
   acceptance. Agent tasks/subagents do not create a new device identity.
2. After the actual commit above is published, with authorized Git/network work:

   ```bash
   git status --short --branch
   git fetch origin
   git show --no-patch --format=fuller origin/update_0.2.3
   git merge --ff-only origin/update_0.2.3
   git rev-parse HEAD
   ```

   Compare the fetched commit with the actual published value. If local work
   or divergence prevents fast-forward, preserve every byte and handle explicit
   integration separately. Never reset, overwrite or automatically merge JSONL.
3. Keep laptop-1's existing `workspace.toml` and identity. Compare fields with
   `workspace.example.toml`; do not copy laptop-2 TOML and do not re-onboard an
   existing device. Verify exact local absolute paths, explicit aliases, policy
   targets and Data/Notes guards. Keep stable root IDs across devices.
4. Add `matlab_theory`, kind `analysis`, mapping `none`, only if a real equivalent
   directory exists. Otherwise omit that local section, create nothing, and
   retain logical memory access. Do not register the Matlab parent or create
   empty Project/Study/Case records. The known precise owners are
   `root:matlab_theory/epoch_initial_distribution` (including photon-distribution
   generation) and `root:matlab_theory/tr_vortex_beam` (TR vortex fields).
   These are inspected code roles, not numerical/physical acceptance.

## daily-arxiv and HTML device onboarding

This section owns the portable Tool_Project layout and onboarding procedure.
The heading retains existing links; the source directories and GitHub names are
`Daily_Arxiv` and `Figure_Browser`. These instructions do not certify publication,
synchronization or acceptance on another device. Verify the actual published
commit before using this update; earlier release-state sections describe the
original 0.2.3 rollout, not this tool-project migration.

| Stable root ID | Independent repository | Local layout | Boundaries |
| --- | --- | --- | --- |
| `daily_arxiv` | `YuhanJin-USTC/Daily_Arxiv`, public | `Tool_Project/Daily_Arxiv` | Source on `main`, generated records on `data`; retain AI, email and publication gates |
| `matlab_html` | `YuhanJin-USTC/Figure_Browser`, private | `Tool_Project/Figure_Browser` | Local read-only figure browser; GitHub hosts source, not a remote browser service |

Both roots remain `source`, mapping `none`, access `project-policy`.
Tool_Project itself is neither a Git repository nor a new research root. Do not
use a monorepo, submodules or a second metadata authority for this layout.

### Source and local parent instructions

1. Preserve existing local work. Verify the account, existing Git/SSH settings
   and exact remotes before authorized fetch, clone or push. Reuse working
   authentication; do not install tools, replace keys or rewrite global Git
   settings for a directory move. A changed local path alone does not change
   `origin`; a GitHub repository rename does.
2. Verify the intended Tool_Project parent directory. Clone each authorized
   repository into its named child only when the destination is absent. Keep
   existing histories intact; never clone over a populated directory. On this
   device the parent is `/home/yuhanjin/Tool_Project`; use the other device's own
   verified path instead of copying that absolute path.
3. Recreate a short parent `README.md` with a two-row index linking each child's
   README and this guide. Its `AGENTS.md` must state: the parent is not a repo or
   research root; each child is an independent authorization scope; read the
   child's nearest instructions; resolve device paths through local
   `workspace.toml`; do not infer permission for siblings or data; keep Git and
   testing inside the selected child. Preserve any existing unrelated parent
   text. These local parent files are not synchronized by a child clone.
4. Use short task branches, such as `codex/<task>`, and reviewed PRs for source
   changes. Stage
   only reviewed task paths. Check existing work before switching; fetch and
   fast-forward `main` only when safe, and resolve divergence explicitly. Never
   reset, force-push, rename a feature branch to `main` or use the all-files
   direct-main `update_git` helper for this PR workflow.
5. Verify the private Figure_Browser repository and Issues through the intended
   agent connector after creation. Git SSH access does not prove connector
   access. If needed, ask the user to grant that repository to the existing
   GitHub App; do not expand access to all repositories automatically.

Figure_Browser starts through its WSL `start.sh` or the documented scripts
wrapper. Its own README owns dependency versions, source configuration, build
and local startup checks. Reuse available dependencies; installation or missing
environment repair requires a separate explicit request. Keep source IDs and
source-relative paths stable. Scientific figures stay in their existing roots
and use their established transfer procedures. Personal preferences, favorites,
collections, passwords and sessions stay independent on each device; no app
state synchronization is introduced. User-requested exports remain user data.
Do not copy `.local/`, `node_modules/`, `dist/`, credentials or runtime locks to
another device as a source synchronization method.

### Research memory and policy

After preserving local work and separately authorized synchronization of the
control repository, pass `doctor`, `event merge` and `validate` before restoring
context or writing portable authority on a switched device. Keep that device's
identity. Verify each equivalent checkout and its nearest instructions; names
alone do not establish identity. Enable only its commented root and exact
policy-target examples in `workspace.example.toml`, using independently checked
paths and times in the device's own `workspace.toml`. Do not register the
Tool_Project or Matlab parent, or the browser's Simulation/Theory/Archive
sources, as either source root. A missing checkout needs no placeholder root;
synchronized logical memory remains readable with `mappingAvailable: false`.

During a local move, change each root path and its current policy target only
after the new tree has been copied and verified. Preserve old directories until
any deletion has its own exact user approval. Keep stable root IDs and all
historical records; old evidence paths are not live routing instructions.

The child repositories deliver their own AGENTS and maintenance documents.
Keep the independent root owner, compact context, one event-only result and
control-repository authority in those instructions. The browser app must not
read or write research metadata or gain Python/SQLite dependencies. Registration
does not authorize a source push, application startup, data transfer or policy
apply. Resolve `CONTROL_ROOT` locally:

```text
python3 -B "<CONTROL_ROOT>/tools/researchctl.py" context root:daily_arxiv --view compact --json
python3 -B "<CONTROL_ROOT>/tools/researchctl.py" context root:matlab_html --view compact --json
```

Append an exact working directory for narrower ownership. Record one substantive
completed result through an event-only `checkpoint` at its exact owner, retaining
purpose, result, accepted reasons, checks and limits in existing summary/evidence
fields. Do not log planning, create empty research membership or duplicate a
cross-root result into every child. Metadata stays in the control repository;
SQLite, saved plans, device paths and application state remain local.

Preview exact AGENTS differences and the device-local policy plan after source
and mapping changes stabilize. Use the reauthorization procedure below with the
latest active rule revision, retaining earlier approved device paths and adding
verified new targets. Obtain real user approval of that exact difference/digest
before approval and apply. Reuse already-correct managed blocks; never edit them
by hand or reuse another device's approval. Remove obsolete paths from the local
allowlist only when that exact routing change was authorized; historical
approvals remain intact. Tool_Project's routing-only parent instructions do not
become a managed policy target merely by being created.

Run affected isolated regressions, local `doctor`, `event merge`, `validate`,
`policy check`, and both logical/absolute-path contexts. Verify the home control
map, each source mapping and its instructions agree. Record any old references
as active, historical, stable identifiers or separately handled external entry
points; no unexplained active old path may remain. Local or fixture acceptance
does not prove another computer was deployed. Report only the device actually
checked, and publish portable changes through separately authorized Git work.

## Skill and instruction replay on that device

Verify the actual local Codex home. Use it explicitly in every command below;
`CODEX_HOME` or the default `.codex` must not be guessed from laptop-2.

```bash
python3 -B skills/research-workflow/scripts/install.py --codex-home /actual/Codex/home --json
python3 -B skills/research-workflow/scripts/check_installation.py --codex-home /actual/Codex/home --json
```

If the installer previews `reuse`, no write is needed. If an ordinary old skill
directory exists, use `--backup-existing /actual/Codex/home/backups/EXACT-UNUSED`
outside `skills/`, inspect the preview, then repeat with `--write` after exact
path authorization. Never overwrite a backup. See `CODEX_SKILL_SYNC.md`.

Use the local TOML's exact target list, not laptop-2 paths. Prepare role-specific
body patches below, adapting `CONTROL_ROOT` to the verified local control root.
Retain all unrelated research rules and old bytes. Data/Notes are managed-only;
do not change their bodies or create a redundant Theory AGENTS file. The global
entry is the actual Codex home's AGENTS file; do not invent a managed target.
The repository AGENTS arrives through Git and already contains its current body.

| Role / existing section | Required body adjustment |
| --- | --- |
| Global and control-directory routing | Restore all-owner context; split ordinary event work from definition confirmation; keep device-switch synchronization before even event-only writes. |
| Simulation Required Workflow / Research Metadata | Read Case or exact root/path memory, record one result; finish files/checks then show preview, ask, await, apply for actual definition changes. |
| QED subtree Local Metadata Contract | Replace obsolete delta/current-spec lookup and forced metadata edits with journal-backed context and one evidenced comparison result; retain every physics/runner comparison rule. |
| Configuration and scripts Research Workflow Contract | Enable exact root/path context and transparent derived-cache refresh; replace forced Case or raw-event registration with one result checkpoint. Retain cross-root caller rules. |
| Matlab Research Workflow Metadata | Canonical explicit Simulation pairing, exact mapping-none Theory owners, event-only analysis, real definition confirmation, no parent registration or empty hierarchy. |
| Other scripts/source/build targets | Keep bodies unchanged; update only managed blocks. |

Apply these concise English paragraphs in the appropriate existing sections,
not as competing duplicate policy at the end of every file:

```text
Restore compact memory through CONTROL_ROOT/tools/researchctl.py context TARGET
--json for the exact Case, Study, Project, or registered root directory. Root
matching is exact unless --recursive is requested. Read direct evidence on demand.
Record one substantive result with an event-only checkpoint at its exact owner.
Retain purpose, result, accepted reasons, validation level, and limits in existing
summary/evidence fields when known. No empty research hierarchy or pending queue
is required; do not log ordinary discussion turn by turn.
For explicit registration or simulation-definition changes, finish files/checks,
show the saved preview, actually ask and await the user, then case apply --plan
DIGEST --write. Keep metadata correction distinct from physical/numerical input
changes. An accepted setting is not proof of physical correctness.
```

For scripts/configuration replace the obsolete cache prohibition with:

```text
Keep .research-workflow/index.sqlite3 local and non-authoritative; context queries
may transparently create or refresh it. Never synchronize SQLite or saved plans.
```

For Matlab add to its existing metadata section:

```text
Theory is the independent matlab_theory root, mapping none. Use the exact owner
root:matlab_theory/epoch_initial_distribution or root:matlab_theory/tr_vortex_beam
when that directory owns the work. Do not register the Matlab parent or create
empty Project/Study/Case records. A missing local Theory mapping still permits
logical memory reads, but local scientific access and new events require one.
```

For QED replace references to old Case delta/current spec files and mandatory
metadata edits with:

```text
Read stable facts through journal-backed materialized Case context and its
Project/Study/profiles. Record verified scan comparisons, active configuration
and source identities as one result event with direct evidence. Ordinary
comparison work does not force a Case revision. Keep unknowns explicit.
```

The final patch must include every actual removed/added line and an independent
body digest. User approval applies to those exact paths/differences. Compute its
expected input after managed policy application, or verify the managed/body
partitions separately with exact unchanged-byte checks. Never silently ignore
unrelated concurrent edits. Apply only after the reviewed scope and any required
filesystem permission are granted; policy apply itself never edits these bodies.

## Device-local policy reauthorization

After verifying the local target list, generate a pending same-behavior revision
from the released active rule. This deterministic preparation preserves all
previous device approvals and adds this device's explicit allowlist; it does not
claim approval and does not write policy authority:

```bash
python3 -B - <<'PYGEN'
import json
import tomllib
from pathlib import Path
root = Path.cwd()
rule_id = 'framework-v0-2-3-research-memory'
rule = json.loads((root / 'policy/rules' / (rule_id + '.json')).read_text())
config = tomllib.loads((root / 'workspace.toml').read_text())
targets = sorted(set(rule['approval']['authorized_targets']) |
                 {item['path'] for item in config['policy']['targets']})
proposal = {key: rule[key] for key in
            ('schema_version', 'scope', 'selector', 'supersedes', 'content', 'evidence')}
proposal.update(schema='research-workflow/policy-proposal', proposal_id=rule_id,
                revision=rule['revision'] + 1, status='open',
                approval={'status': 'pending'}, requested_targets=targets)
proposal['evidence'] = list(dict.fromkeys(
    list(proposal['evidence']) + ['device-upgrade:verified-local-instruction-targets']))
path = root / '.research-workflow' / 'device-policy-candidate.json'
path.parent.mkdir(exist_ok=True)
with path.open('x', encoding='utf-8') as stream:
    json.dump(proposal, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(path)
PYGEN
python3 -B tools/researchctl.py policy propose --proposal .research-workflow/device-policy-candidate.json --json
```

If that local candidate path already exists, inspect it and choose a new exact
unused name; do not overwrite it. Inspect the proposal preview, then save it:

```bash
python3 -B tools/researchctl.py policy propose --proposal .research-workflow/device-policy-candidate.json --write --json
python3 -B tools/researchctl.py policy plan framework-v0-2-3-research-memory --json
```

Review the exact local managed diff, cumulative authorized paths, old-rule
replacement/removals if any, and body patch. Obtain real user approval of this
plan digest and separate Data/Notes scope; the first device's old approval does
not authorize new local paths. Only after that response, substitute the actual
digest and UTC approval time:

```bash
python3 -B tools/researchctl.py policy approve framework-v0-2-3-research-memory \
  --expect-digest ACTUAL_DIGEST --actor user --decided-at ACTUAL_UTC --write --json
python3 -B tools/researchctl.py policy apply framework-v0-2-3-research-memory \
  --expect-digest ACTUAL_DIGEST --write --json
python3 -B tools/researchctl.py policy check --json
```

Approval bookkeeping does not change the reviewed digest. New content, targets
or front-state invalidates it. Active replay cannot repair drift; create a new
pending reauthorization. If an already approved open proposal is stale, use a
new unique proposal ID; same-ID higher revision is for an already active rule.
A pending/approved proposal remains policy workflow state, not a research-task
registration reminder. No approval JSON is edited by hand.

## Local acceptance, then resume writes

Check that no old framework process still writes metadata. Run:

```bash
python3 -B tools/researchctl.py doctor --json
python3 -B tools/researchctl.py event merge --json
python3 -B tools/researchctl.py validate --json
python3 -B tools/researchctl.py policy check --json
python3 -B skills/research-workflow/scripts/check_installation.py --codex-home /actual/Codex/home --full --json
python3 -B tools/researchctl.py case list --json
python3 -B tools/researchctl.py context case:ACTUAL_SIM_ID --json
python3 -B tools/researchctl.py context root:research_workflow --json
python3 -B tools/researchctl.py context root:matlab_theory/tr_vortex_beam --json
```

Require runtime `framework_version: 0.2.3`, valid authority/merge, policy agreement,
installed repository symlink, and successful full check with real Case discovery.
For absent Theory, the last query succeeds with `mappingAvailable: false`; it
need not fabricate events. New local Theory events/input access must refuse.
Full checks may refresh the derived index; ordinary installation checks do not.

Measure actual instruction discovery candidates after editing: global override
before AGENTS, then project-root-to-cwd override/AGENTS/fallback selection under
local root markers and configured size budget. Also retain a conservative
all-ancestor/reference total. Verify complete chains, not single-file size.
Official discovery rules are documented in
[AGENTS guidance](https://learn.chatgpt.com/docs/agent-configuration/agents-md).
Filesystem/config inference is not host-loaded telemetry; report that limit.
Restart the agent tasks that must use the upgraded instructions. Resume metadata
writes only on this accepted device. Record a separate deployment event only
after a real independent deployment result; do not copy the first-device event.

## Return portable approval and continue sequential work

With separate authorization, review/commit/publish laptop-1's portable policy
reauthorization and real acceptance event. Keep laptop-2's approved paths in the
record. Return them through the authorized Git procedure, preserving all streams.
On laptop-2, check clean/preserved local state, fetch and fast-forward the actual
published ref, then `doctor`, `event merge`, `validate`, and `policy check`.
If only approval metadata changed and managed blocks already agree, do not apply
or rewrite them. Report local implementation, publication, second-device acceptance
and return-policy consistency separately.

Before every later device switch: preserve local work, explicitly synchronize,
validate, then restore context and record one bounded result. This includes
event-only work. Device-local plans cannot be transplanted. Forks or event-ID
conflicts stop; never pick a winner based on clocks/mtime or rewrite JSONL.

## 0.2.2 portable cutover

当前 portable authority 是 journal-only：207 个 active migrate records、8 个
migrate-tombstone records、261 条原 Event lines；`metadata/cases` 不存在。另一台
设备拉取这些 bytes 后不得重复创建旧 Store upgrade 或 Case migration。历史 migrate
bindings 永久可读，但不是 public mutation leaves。

Project/Study schema versions 1 与 2 都是当前支持内容；不要在设备间只为统一版本号
批量重写 version-1 documents。SQLite index 不应提交；首次 context 会透明建立，或
显式运行 cache rebuild。

Active policy rules 可以随 Git 移动，但旧 approval 绑定首台设备的 absolute paths。
新设备需要用户重新批准本机 exact targets；Data/Notes 继续单独批准。不能复用另一
设备的 path approval 或自动修复 drift。

## Recovery

原文档中的 archive 参考为：

```text
/home/yuhanjin/Research_Workflow-pre-v0-reset-20260719.tar
expected sha256: 988a80543beb94b23ad06e7dde04a4347d5cbb7945a0e34091fb55792b3e7ade
```

该 exact path 当前不存在，availability 为 `unavailable / to-confirm`。不要搜索外部
roots 猜测其位置，不要声称 digest 已在当前设备核验。仓库仅有 minimal recovery
fixture。任何恢复都会写入或覆盖用户内容，必须单独批准 exact targets。
