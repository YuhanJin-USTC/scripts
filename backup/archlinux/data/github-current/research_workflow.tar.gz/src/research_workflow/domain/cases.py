"""Define compact Case deltas and in-memory views."""

from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Mapping, Sequence

from research_workflow.core.canonical import canonical_digest, require_fields, require_object, require_string
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.core.ids import validate_logical_id, validate_sim_id

from .profiles import Profile, ProfileReference, resolve_profiles
from .projects import Project
from .studies import Study


CASE_DELTA_SCHEMA = "research-workflow/case-delta"
CASE_VIEW_SCHEMA = "research-workflow/case-view"


def _revision(value: object, label: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise ValidationError(f"{label} must be a positive integer")
    return value


def _merge(base: dict[str, object], update: Mapping[str, object], path: str = "content") -> dict[str, object]:
    result = copy.deepcopy(base)
    for key, value in update.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, Mapping):
            result[key] = _merge(result[key], value, f"{path}.{key}")
        elif key in result and isinstance(result[key], dict) != isinstance(value, Mapping):
            raise ConflictError(f"profile/delta type conflict at {path}.{key}")
        else:
            result[key] = copy.deepcopy(value)
    return result


@dataclass(frozen=True, slots=True)
class CaseDelta:
    """Represent the compact current source for one Case spec."""

    sim_id: str
    project_id: str
    study_id: str
    revision: int
    profiles: tuple[ProfileReference, ...]
    content: dict[str, object]

    @classmethod
    def from_dict(cls, value: object) -> "CaseDelta":
        """Validate and construct a schema-version-1 Case delta."""

        item = require_object(value, "Case delta")
        require_fields(
            item,
            {"schema", "schema_version", "sim_id", "project_id", "study_id", "revision", "profiles", "content"},
            "Case delta",
        )
        if item["schema"] != CASE_DELTA_SCHEMA or item["schema_version"] != 1:
            raise ValidationError("Case delta must use research-workflow/case-delta schema version 1")
        raw_profiles = item["profiles"]
        if not isinstance(raw_profiles, list):
            raise ValidationError("Case delta profiles must be an ordered array")
        return cls(
            sim_id=validate_sim_id(item["sim_id"]),
            project_id=validate_logical_id(item["project_id"], "project_id"),
            study_id=validate_logical_id(item["study_id"], "study_id"),
            revision=_revision(item["revision"], "Case delta revision"),
            profiles=tuple(ProfileReference.from_dict(value) for value in raw_profiles),
            content=copy.deepcopy(require_object(item["content"], "Case delta content")),
        )

    def to_dict(self) -> dict[str, object]:
        """Return the compact portable Case delta document."""

        return {
            "schema": CASE_DELTA_SCHEMA,
            "schema_version": 1,
            "sim_id": self.sim_id,
            "project_id": self.project_id,
            "study_id": self.study_id,
            "revision": self.revision,
            "profiles": [reference.to_dict() for reference in self.profiles],
            "content": copy.deepcopy(self.content),
        }

    @property
    def digest(self) -> str:
        """Return the canonical digest used by the current spec pointer."""

        return canonical_digest(self.to_dict())


@dataclass(frozen=True, slots=True)
class CaseView:
    """Represent a generated, non-authoritative materialized Case view."""

    sim_id: str
    project_id: str
    study_id: str
    revision: int
    profiles: tuple[ProfileReference, ...]
    content: dict[str, object]

    def to_dict(self) -> dict[str, object]:
        """Return an output-only Case view document."""

        return {
            "schema": CASE_VIEW_SCHEMA,
            "schema_version": 1,
            "sim_id": self.sim_id,
            "project_id": self.project_id,
            "study_id": self.study_id,
            "revision": self.revision,
            "profiles": [reference.to_dict() for reference in self.profiles],
            "content": copy.deepcopy(self.content),
        }


def materialize_case(
    project: Project,
    study: Study,
    profiles: Mapping[tuple[str, str], Profile],
    delta: CaseDelta,
) -> CaseView:
    """Generate one current Case view in memory without persisting authority."""

    if project.project_id != study.project_id or project.project_id != delta.project_id:
        raise ConflictError("Project, Study, and Case delta project identities conflict")
    if study.study_id != delta.study_id:
        raise ConflictError("Study and Case delta identities conflict")
    if delta.sim_id == study.sim_prefix or not delta.sim_id.startswith(study.sim_prefix + "/"):
        raise ConflictError("Case sim_id is outside its Study sim_prefix")
    references = list(project.profiles + study.profiles + delta.profiles)
    ordered = resolve_profiles(references, profiles)
    content = copy.deepcopy(project.content)
    content = _merge(content, study.content)
    for profile in ordered:
        content = _merge(content, profile.content)
    content = _merge(content, delta.content)
    return CaseView(
        sim_id=delta.sim_id,
        project_id=delta.project_id,
        study_id=delta.study_id,
        revision=delta.revision,
        profiles=tuple(references),
        content=content,
    )


def validate_revision(previous: CaseDelta, revised: CaseDelta) -> None:
    """Require stable identity and a strictly increasing revision."""

    if (previous.sim_id, previous.project_id, previous.study_id) != (
        revised.sim_id,
        revised.project_id,
        revised.study_id,
    ):
        raise ConflictError("Case revision changes immutable identity")
    if revised.revision <= previous.revision:
        raise ConflictError("Case revision must increase")


def _decode_content_pointer(pointer: str) -> tuple[str, ...]:
    """Decode a document-root JSON Pointer restricted to a content member."""

    if not isinstance(pointer, str) or not pointer.startswith("/"):
        raise ValidationError("--remove-content-path must be an absolute JSON Pointer")
    raw_parts = pointer[1:].split("/")
    parts: list[str] = []
    for raw_part in raw_parts:
        part = ""
        index = 0
        while index < len(raw_part):
            character = raw_part[index]
            if character != "~":
                part += character
                index += 1
                continue
            if index + 1 >= len(raw_part) or raw_part[index + 1] not in {"0", "1"}:
                raise ValidationError(f"invalid JSON Pointer escape in --remove-content-path: {pointer}")
            part += "~" if raw_part[index + 1] == "0" else "/"
            index += 2
        parts.append(part)
    if len(parts) < 2 or parts[0] != "content":
        raise ValidationError("--remove-content-path may target only /content/... members")
    return tuple(parts[1:])


def _patch_paths(value: Mapping[str, object], prefix: tuple[str, ...] = ()) -> set[tuple[str, ...]]:
    """Return the effective leaf paths set by one recursive content patch."""

    result: set[tuple[str, ...]] = set()
    for key, item in value.items():
        path = prefix + (key,)
        if isinstance(item, Mapping) and item:
            result.update(_patch_paths(item, path))
        else:
            result.add(path)
    return result


def _paths_overlap(left: tuple[str, ...], right: tuple[str, ...]) -> bool:
    limit = min(len(left), len(right))
    return left[:limit] == right[:limit]


def _merge_revision_patch(base: Mapping[str, object], patch: Mapping[str, object]) -> dict[str, object]:
    """Recursively merge objects and replace every other value as a whole."""

    result = copy.deepcopy(dict(base))
    for key, value in patch.items():
        current = result.get(key)
        if isinstance(current, dict) and isinstance(value, Mapping):
            result[key] = _merge_revision_patch(current, value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def build_revised_case_delta(
    previous: CaseDelta,
    *,
    revision: int,
    content_patch: Mapping[str, object] | None = None,
    remove_content_paths: Sequence[str] = (),
    profiles: Sequence[ProfileReference] | None = None,
) -> CaseDelta:
    """Build one higher Case delta entirely in memory from explicit changes."""

    patch = require_object({} if content_patch is None else content_patch, "Case revision content patch")
    decoded_removals = [_decode_content_pointer(pointer) for pointer in remove_content_paths]
    if len(set(decoded_removals)) != len(decoded_removals):
        raise ValidationError("duplicate --remove-content-path is not allowed")
    for index, left in enumerate(decoded_removals):
        for right in decoded_removals[index + 1 :]:
            if _paths_overlap(left, right):
                raise ValidationError("overlapping --remove-content-path values are not allowed")
    for set_path in _patch_paths(patch):
        if any(_paths_overlap(set_path, removed_path) for removed_path in decoded_removals):
            raise ValidationError("content patch and removal paths overlap")

    content = _merge_revision_patch(previous.content, patch)
    for pointer, parts in zip(remove_content_paths, decoded_removals, strict=True):
        parent: dict[str, object] = content
        for part in parts[:-1]:
            child = parent.get(part)
            if not isinstance(child, dict):
                raise ValidationError(f"--remove-content-path does not resolve through objects: {pointer}")
            parent = child
        if parts[-1] not in parent:
            raise ValidationError(f"--remove-content-path target is missing: {pointer}")
        del parent[parts[-1]]

    revised = CaseDelta.from_dict(
        {
            "schema": CASE_DELTA_SCHEMA,
            "schema_version": 1,
            "sim_id": previous.sim_id,
            "project_id": previous.project_id,
            "study_id": previous.study_id,
            "revision": revision,
            "profiles": [reference.to_dict() for reference in (previous.profiles if profiles is None else profiles)],
            "content": content,
        }
    )
    validate_revision(previous, revised)
    return revised


__all__ = [
    "CASE_DELTA_SCHEMA",
    "CASE_VIEW_SCHEMA",
    "CaseDelta",
    "CaseView",
    "build_revised_case_delta",
    "materialize_case",
    "validate_revision",
]
