"""Define append-only Case journal records and deterministic heads."""

from __future__ import annotations

import copy
import heapq
from dataclasses import dataclass
from typing import Iterable

from research_workflow.core.canonical import (
    canonical_digest,
    require_fields,
    require_object,
)
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.core.ids import (
    validate_device_id,
    validate_digest,
    validate_event_id,
    validate_logical_id,
    validate_sim_id,
)
from research_workflow.core.time import validate_utc

from .cases import CaseDelta, validate_revision
from .profiles import ProfileReference


CASE_RECORD_SCHEMA = "research-workflow/case-record"
CASE_RECORD_ACTIONS = ("create", "revise", "migrate", "migrate-tombstone", "rename", "delete")
NO_PREVIOUS_DIGEST = "not-applicable"


def _positive_bytes(value: object, label: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise ValidationError(f"{label} must be a positive integer")
    return value


@dataclass(frozen=True, slots=True)
class LegacyCaseBinding:
    """Bind one migration to the exact legacy Case pair."""

    delta_digest: str
    current_spec_digest: str
    delta_raw_sha256: str
    delta_raw_bytes: int
    current_spec_raw_sha256: str
    current_spec_raw_bytes: int

    def __post_init__(self) -> None:
        for field in (
            "delta_digest",
            "current_spec_digest",
            "delta_raw_sha256",
            "current_spec_raw_sha256",
        ):
            object.__setattr__(self, field, validate_digest(getattr(self, field), field))
        object.__setattr__(
            self,
            "delta_raw_bytes",
            _positive_bytes(self.delta_raw_bytes, "delta_raw_bytes"),
        )
        object.__setattr__(
            self,
            "current_spec_raw_bytes",
            _positive_bytes(self.current_spec_raw_bytes, "current_spec_raw_bytes"),
        )

    @classmethod
    def from_dict(cls, value: object) -> "LegacyCaseBinding":
        item = require_object(value, "legacy Case binding")
        require_fields(
            item,
            {
                "delta_digest",
                "current_spec_digest",
                "delta_raw_sha256",
                "delta_raw_bytes",
                "current_spec_raw_sha256",
                "current_spec_raw_bytes",
            },
            "legacy Case binding",
        )
        return cls(**item)

    def to_dict(self) -> dict[str, object]:
        return {
            "delta_digest": self.delta_digest,
            "current_spec_digest": self.current_spec_digest,
            "delta_raw_sha256": self.delta_raw_sha256,
            "delta_raw_bytes": self.delta_raw_bytes,
            "current_spec_raw_sha256": self.current_spec_raw_sha256,
            "current_spec_raw_bytes": self.current_spec_raw_bytes,
        }


@dataclass(frozen=True, slots=True)
class LegacyDeletionBinding:
    """Bind one tombstone migration to an exact legacy deletion receipt."""

    sim_id: str
    project_id: str
    study_id: str
    revision: int
    source_delta_digest: str
    source_current_spec_digest: str
    source_delta_raw_sha256: str
    source_delta_raw_bytes: int
    source_current_spec_raw_sha256: str
    source_current_spec_raw_bytes: int
    receipt_digest: str
    receipt_raw_sha256: str
    receipt_raw_bytes: int

    def __post_init__(self) -> None:
        object.__setattr__(self, "sim_id", validate_sim_id(self.sim_id))
        object.__setattr__(self, "project_id", validate_logical_id(self.project_id, "project_id"))
        object.__setattr__(self, "study_id", validate_logical_id(self.study_id, "study_id"))
        object.__setattr__(self, "revision", _positive_revision(self.revision))
        for field in (
            "source_delta_digest",
            "source_current_spec_digest",
            "source_delta_raw_sha256",
            "source_current_spec_raw_sha256",
            "receipt_digest",
            "receipt_raw_sha256",
        ):
            object.__setattr__(self, field, validate_digest(getattr(self, field), field))
        for field in (
            "source_delta_raw_bytes",
            "source_current_spec_raw_bytes",
            "receipt_raw_bytes",
        ):
            object.__setattr__(self, field, _positive_bytes(getattr(self, field), field))

    @classmethod
    def from_dict(cls, value: object) -> "LegacyDeletionBinding":
        item = require_object(value, "legacy deletion binding")
        require_fields(
            item,
            {
                "sim_id",
                "project_id",
                "study_id",
                "revision",
                "source_delta_digest",
                "source_current_spec_digest",
                "source_delta_raw_sha256",
                "source_delta_raw_bytes",
                "source_current_spec_raw_sha256",
                "source_current_spec_raw_bytes",
                "receipt_digest",
                "receipt_raw_sha256",
                "receipt_raw_bytes",
            },
            "legacy deletion binding",
        )
        return cls(**item)

    def to_dict(self) -> dict[str, object]:
        return {
            "sim_id": self.sim_id,
            "project_id": self.project_id,
            "study_id": self.study_id,
            "revision": self.revision,
            "source_delta_digest": self.source_delta_digest,
            "source_current_spec_digest": self.source_current_spec_digest,
            "source_delta_raw_sha256": self.source_delta_raw_sha256,
            "source_delta_raw_bytes": self.source_delta_raw_bytes,
            "source_current_spec_raw_sha256": self.source_current_spec_raw_sha256,
            "source_current_spec_raw_bytes": self.source_current_spec_raw_bytes,
            "receipt_digest": self.receipt_digest,
            "receipt_raw_sha256": self.receipt_raw_sha256,
            "receipt_raw_bytes": self.receipt_raw_bytes,
        }


def _positive_revision(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise ValidationError("revision must be a positive integer")
    return value


@dataclass(frozen=True, slots=True)
class CaseRecord:
    """Represent one device-owned Case journal operation."""

    record_id: str
    device_id: str
    recorded_at: str
    action: str
    sim_id: str
    previous_digest: str
    delta: CaseDelta | None = None
    target_sim_id: str | None = None
    legacy_binding: LegacyCaseBinding | None = None
    legacy_deletion_binding: LegacyDeletionBinding | None = None

    def __post_init__(self) -> None:
        record_id = validate_event_id(self.record_id)
        device_id = validate_device_id(self.device_id)
        recorded_at = validate_utc(self.recorded_at, "Case record recorded_at")
        timestamp = recorded_at.replace("-", "").replace(":", "")
        bound_id = f"{timestamp}-{device_id}"
        if record_id != bound_id and not record_id.startswith(bound_id + "-"):
            raise ConflictError("Case record ID must bind recorded_at and device_id")
        if self.action not in CASE_RECORD_ACTIONS:
            raise ValidationError(f"unsupported Case record action: {self.action}")
        sim_id = validate_sim_id(self.sim_id)
        object.__setattr__(self, "record_id", record_id)
        object.__setattr__(self, "device_id", device_id)
        object.__setattr__(self, "recorded_at", recorded_at)
        object.__setattr__(self, "sim_id", sim_id)
        if self.action in {"create", "migrate", "migrate-tombstone"}:
            if self.previous_digest != NO_PREVIOUS_DIGEST:
                raise ConflictError(f"Case {self.action} must not name a previous digest")
        else:
            object.__setattr__(
                self,
                "previous_digest",
                validate_digest(self.previous_digest, "previous_digest"),
            )
        if self.action in {"create", "revise", "migrate"}:
            if self.delta is None or self.delta.sim_id != sim_id:
                raise ConflictError(f"Case {self.action} delta must match sim_id")
            if self.target_sim_id is not None:
                raise ValidationError(f"Case {self.action} cannot name target_sim_id")
        elif self.action == "rename":
            if self.delta is None or self.target_sim_id is None:
                raise ValidationError("Case rename requires a target delta and target_sim_id")
            target = validate_sim_id(self.target_sim_id)
            if target == sim_id or self.delta.sim_id != target:
                raise ConflictError("Case rename target delta must bind a distinct target_sim_id")
            object.__setattr__(self, "target_sim_id", target)
        elif self.action == "delete":
            if self.delta is None or self.delta.sim_id != sim_id:
                raise ConflictError("Case delete delta must match sim_id")
            if self.target_sim_id is not None:
                raise ValidationError("Case delete cannot contain target_sim_id")
            if self.previous_digest != self.delta.digest:
                raise ConflictError("Case delete delta must match previous_digest")
        else:
            if self.delta is not None or self.target_sim_id is not None:
                raise ValidationError("Case migrate-tombstone cannot contain delta or target_sim_id")
            if self.legacy_deletion_binding is None:
                raise ValidationError("Case migrate-tombstone requires a legacy deletion binding")
            if self.legacy_deletion_binding.sim_id != sim_id:
                raise ConflictError("Case migrate-tombstone binding must match sim_id")
        if self.action == "migrate":
            if self.legacy_binding is None or self.delta is None:
                raise ValidationError("Case migrate requires a legacy binding")
            if self.legacy_binding.delta_digest != self.delta.digest:
                raise ConflictError("Case migrate binding differs from its delta")
        elif self.legacy_binding is not None:
            raise ValidationError("legacy_binding is valid only for Case migrate")
        if self.action != "migrate-tombstone" and self.legacy_deletion_binding is not None:
            raise ValidationError("legacy_deletion_binding is valid only for Case migrate-tombstone")

    @property
    def project_id(self) -> str:
        if self.delta is not None:
            return self.delta.project_id
        assert self.legacy_deletion_binding is not None
        return self.legacy_deletion_binding.project_id

    @property
    def study_id(self) -> str:
        if self.delta is not None:
            return self.delta.study_id
        assert self.legacy_deletion_binding is not None
        return self.legacy_deletion_binding.study_id

    @property
    def revision(self) -> int:
        if self.delta is not None:
            return self.delta.revision
        assert self.legacy_deletion_binding is not None
        return self.legacy_deletion_binding.revision

    @classmethod
    def build_create(
        cls,
        delta: CaseDelta,
        *,
        record_id: str,
        device_id: str,
        recorded_at: str,
    ) -> "CaseRecord":
        return cls(record_id, device_id, recorded_at, "create", delta.sim_id, NO_PREVIOUS_DIGEST, delta)

    @classmethod
    def build_revise(
        cls,
        delta: CaseDelta,
        *,
        previous_digest: str,
        record_id: str,
        device_id: str,
        recorded_at: str,
    ) -> "CaseRecord":
        return cls(record_id, device_id, recorded_at, "revise", delta.sim_id, previous_digest, delta)

    @classmethod
    def build_rename(
        cls,
        source_sim_id: str,
        target_delta: CaseDelta,
        *,
        previous_digest: str,
        record_id: str,
        device_id: str,
        recorded_at: str,
    ) -> "CaseRecord":
        return cls(
            record_id,
            device_id,
            recorded_at,
            "rename",
            source_sim_id,
            previous_digest,
            target_delta,
            target_delta.sim_id,
        )

    @classmethod
    def build_delete(
        cls,
        source_delta: CaseDelta,
        *,
        previous_digest: str,
        record_id: str,
        device_id: str,
        recorded_at: str,
    ) -> "CaseRecord":
        return cls(
            record_id,
            device_id,
            recorded_at,
            "delete",
            source_delta.sim_id,
            previous_digest,
            source_delta,
        )

    @classmethod
    def from_dict(cls, value: object) -> "CaseRecord":
        item = require_object(value, "Case record")
        require_fields(
            item,
            {
                "schema",
                "schema_version",
                "record_id",
                "device_id",
                "recorded_at",
                "action",
                "sim_id",
                "previous_digest",
            },
            "Case record",
            {"delta", "target_sim_id", "legacy_binding", "legacy_deletion_binding"},
        )
        if item["schema"] != CASE_RECORD_SCHEMA or item["schema_version"] != 1:
            raise ValidationError("Case record must use research-workflow/case-record schema version 1")
        delta = CaseDelta.from_dict(item["delta"]) if "delta" in item else None
        binding = LegacyCaseBinding.from_dict(item["legacy_binding"]) if "legacy_binding" in item else None
        deletion_binding = (
            LegacyDeletionBinding.from_dict(item["legacy_deletion_binding"])
            if "legacy_deletion_binding" in item
            else None
        )
        return cls(
            record_id=item["record_id"],
            device_id=item["device_id"],
            recorded_at=item["recorded_at"],
            action=item["action"],
            sim_id=item["sim_id"],
            previous_digest=item["previous_digest"],
            delta=delta,
            target_sim_id=item.get("target_sim_id"),
            legacy_binding=binding,
            legacy_deletion_binding=deletion_binding,
        )

    def to_dict(self) -> dict[str, object]:
        result: dict[str, object] = {
            "schema": CASE_RECORD_SCHEMA,
            "schema_version": 1,
            "record_id": self.record_id,
            "device_id": self.device_id,
            "recorded_at": self.recorded_at,
            "action": self.action,
            "sim_id": self.sim_id,
            "previous_digest": self.previous_digest,
        }
        if self.delta is not None:
            result["delta"] = self.delta.to_dict()
        if self.target_sim_id is not None:
            result["target_sim_id"] = self.target_sim_id
        if self.legacy_binding is not None:
            result["legacy_binding"] = self.legacy_binding.to_dict()
        if self.legacy_deletion_binding is not None:
            result["legacy_deletion_binding"] = self.legacy_deletion_binding.to_dict()
        return result

    @property
    def digest(self) -> str:
        return canonical_digest(self.to_dict())


@dataclass(frozen=True, slots=True)
class CaseHead:
    """Expose one reduced current or reserved Case identity."""

    sim_id: str
    state: str
    project_id: str
    study_id: str
    revision: int
    delta_digest: str
    delta: CaseDelta | None
    target_sim_id: str | None = None

    @property
    def profiles(self) -> tuple[ProfileReference, ...]:
        if self.delta is None:
            raise ValidationError("deleted tombstone has no Case profiles")
        return self.delta.profiles

    @property
    def content(self) -> dict[str, object]:
        if self.delta is None:
            raise ValidationError("deleted tombstone has no Case content")
        return self.delta.content

    def to_dict(self) -> dict[str, object]:
        result: dict[str, object] = {
            "sim_id": self.sim_id,
            "state": self.state,
            "project_id": self.project_id,
            "study_id": self.study_id,
            "revision": self.revision,
            "delta_digest": self.delta_digest,
        }
        if self.delta is not None:
            result["delta"] = self.delta.to_dict()
        if self.target_sim_id is not None:
            result["target_sim_id"] = self.target_sim_id
        return result


def _active_head(delta: CaseDelta) -> CaseHead:
    return CaseHead(
        sim_id=delta.sim_id,
        state="active",
        project_id=validate_logical_id(delta.project_id, "project_id"),
        study_id=validate_logical_id(delta.study_id, "study_id"),
        revision=delta.revision,
        delta_digest=delta.digest,
        delta=delta,
    )


def _tombstone_head(binding: LegacyDeletionBinding) -> CaseHead:
    return CaseHead(
        sim_id=binding.sim_id,
        state="deleted",
        project_id=binding.project_id,
        study_id=binding.study_id,
        revision=binding.revision,
        delta_digest=binding.source_delta_digest,
        delta=None,
    )


def _rewrite_self_locators(value: object, source: str, target: str) -> object:
    if isinstance(value, list):
        return [_rewrite_self_locators(item, source, target) for item in value]
    if isinstance(value, dict):
        result = {key: _rewrite_self_locators(item, source, target) for key, item in value.items()}
        if result.get("kind") == "case" and result.get("sim_id") == source:
            result["sim_id"] = target
        return result
    return copy.deepcopy(value)


def _causal_records(records: list[CaseRecord]) -> list[CaseRecord]:
    """Order digest ancestry; clocks break ties only between independent nodes."""

    producers = {}
    children = {}
    indegree = {record.record_id: 0 for record in records}
    by_id = {record.record_id: record for record in records}
    for record in records:
        if record.action in {"delete", "migrate-tombstone"}:
            continue
        key = (record.delta.sim_id, record.delta.digest)
        if key in producers:
            raise ConflictError(f"Case identity or snapshot is already reserved: {record.sim_id}")
        producers[key] = record.record_id
    used_heads = set()
    for record in records:
        if record.action in {"create", "migrate", "migrate-tombstone"}:
            continue
        key = (record.sim_id, record.previous_digest)
        if key in used_heads:
            raise ConflictError(f"Case record fork or stale previous digest: {record.sim_id}")
        used_heads.add(key)
        parent = producers.get(key)
        if parent is None:
            raise ConflictError(f"Case record requires an active head for previous digest: {record.sim_id}")
        children.setdefault(parent, []).append(record.record_id)
        indegree[record.record_id] += 1
    ready = [(record.recorded_at, record.record_id) for record in records if not indegree[record.record_id]]
    heapq.heapify(ready)
    ordered = []
    while ready:
        _, record_id = heapq.heappop(ready)
        ordered.append(by_id[record_id])
        for child in children.get(record_id, []):
            indegree[child] -= 1
            if not indegree[child]:
                heapq.heappush(ready, (by_id[child].recorded_at, child))
    if len(ordered) != len(records):
        raise ConflictError("Case record ancestry contains a cycle")
    return ordered


def reduce_case_records(records: Iterable[CaseRecord]) -> dict[str, CaseHead]:
    """Reduce journal records and reject duplicate IDs, forks, or reuse."""

    ordered = sorted(records, key=lambda record: (record.recorded_at, record.record_id))
    by_record_id: dict[str, CaseRecord] = {}
    unique: list[CaseRecord] = []
    for record in ordered:
        existing = by_record_id.get(record.record_id)
        if existing is None:
            by_record_id[record.record_id] = record
            unique.append(record)
        elif existing.to_dict() != record.to_dict():
            raise ConflictError(f"conflicting duplicate Case record ID: {record.record_id}")
    heads: dict[str, CaseHead] = {}
    for record in _causal_records(unique):
        head = heads.get(record.sim_id)
        if record.action in {"create", "migrate", "migrate-tombstone"}:
            if head is not None:
                raise ConflictError(f"Case identity is already reserved: {record.sim_id}")
            if record.action == "migrate-tombstone":
                assert record.legacy_deletion_binding is not None
                heads[record.sim_id] = _tombstone_head(record.legacy_deletion_binding)
            else:
                assert record.delta is not None
                heads[record.sim_id] = _active_head(record.delta)
            continue
        if head is None or head.state != "active":
            raise ConflictError(f"Case {record.action} requires an active head: {record.sim_id}")
        if record.previous_digest != head.delta_digest:
            raise ConflictError(f"Case record fork or stale previous digest: {record.sim_id}")
        if record.action == "revise":
            assert record.delta is not None
            assert head.delta is not None
            validate_revision(head.delta, record.delta)
            heads[record.sim_id] = _active_head(record.delta)
        elif record.action == "rename":
            assert record.delta is not None and record.target_sim_id is not None
            assert head.delta is not None
            if record.target_sim_id in heads:
                raise ConflictError(f"Case rename target is already reserved: {record.target_sim_id}")
            if (record.delta.project_id, record.delta.study_id, record.delta.revision) != (
                head.project_id,
                head.study_id,
                head.revision,
            ):
                raise ConflictError("Case rename must preserve Project, Study, and revision")
            expected_target = CaseDelta.from_dict(
                {
                    **head.delta.to_dict(),
                    "sim_id": record.target_sim_id,
                    "content": _rewrite_self_locators(
                        head.delta.content,
                        record.sim_id,
                        record.target_sim_id,
                    ),
                }
            )
            if record.delta.to_dict() != expected_target.to_dict():
                raise ConflictError("Case rename must preserve semantic content")
            heads[record.sim_id] = CaseHead(
                record.sim_id,
                "renamed",
                head.project_id,
                head.study_id,
                head.revision,
                head.delta_digest,
                head.delta,
                record.target_sim_id,
            )
            heads[record.target_sim_id] = _active_head(record.delta)
        else:
            assert record.delta is not None
            assert head.delta is not None
            if record.delta.to_dict() != head.delta.to_dict():
                raise ConflictError("Case delete must preserve the current delta snapshot")
            heads[record.sim_id] = CaseHead(
                record.sim_id,
                "deleted",
                head.project_id,
                head.study_id,
                head.revision,
                head.delta_digest,
                head.delta,
            )
    return dict(sorted(heads.items()))


__all__ = [
    "CASE_RECORD_ACTIONS",
    "CASE_RECORD_SCHEMA",
    "NO_PREVIOUS_DIGEST",
    "CaseHead",
    "CaseRecord",
    "LegacyCaseBinding",
    "LegacyDeletionBinding",
    "reduce_case_records",
]
