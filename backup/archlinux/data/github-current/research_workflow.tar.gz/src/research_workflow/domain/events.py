"""Define portable append-only events and evidence."""

from __future__ import annotations

import copy
from dataclasses import dataclass

from research_workflow.core.canonical import canonical_json_bytes, require_fields, require_object, require_string
from research_workflow.core.errors import ValidationError
from research_workflow.core.ids import validate_device_id, validate_event_id
from research_workflow.core.time import validate_utc
from research_workflow.workspace.locators import LogicalLocator

from .corrections import Correction


EVENT_SCHEMA = "research-workflow/event"
EVENT_KINDS = {"modification", "validation", "decision", "status-change", "correction"}
EVIDENCE_KINDS = {
    "file",
    "checksum",
    "command-result",
    "scheduler",
    "transfer",
    "validation",
    "user-confirmation",
    "external-record",
}
STATUS_STATES = {
    "run": {"unknown", "planned", "ready", "submitted", "running", "completed", "failed"},
    "data": {"unknown", "not-synced", "partial", "synced", "stale"},
    "analysis": {"unknown", "not-started", "in-progress", "completed", "blocked"},
}


@dataclass(frozen=True, slots=True)
class Evidence:
    """Record one portable observation supporting an event or status."""

    evidence_id: str
    kind: str
    locator: LogicalLocator
    observation: str
    observed_at: str

    @classmethod
    def from_dict(cls, value: object) -> "Evidence":
        """Validate and construct one portable evidence item."""

        item = require_object(value, "evidence")
        require_fields(item, {"id", "kind", "locator", "observation", "observed_at"}, "evidence")
        evidence_id = require_string(item["id"], "evidence.id")
        if not evidence_id.startswith("E") or not evidence_id[1:].isdigit() or evidence_id == "E0":
            raise ValidationError("evidence id must use E1, E2, ...")
        kind = require_string(item["kind"], "evidence.kind")
        if kind not in EVIDENCE_KINDS:
            raise ValidationError(f"unsupported evidence kind: {kind}")
        return cls(
            evidence_id=evidence_id,
            kind=kind,
            locator=LogicalLocator.from_dict(item["locator"]),
            observation=require_string(item["observation"], "evidence.observation"),
            observed_at=validate_utc(item["observed_at"], "evidence.observed_at"),
        )

    def to_dict(self) -> dict[str, object]:
        """Return the portable evidence object."""

        return {
            "id": self.evidence_id,
            "kind": self.kind,
            "locator": self.locator.to_dict(),
            "observation": self.observation,
            "observed_at": self.observed_at,
        }


@dataclass(frozen=True, slots=True)
class StatusUpdate:
    """Update one independent Run, Data, or Analysis status track."""

    track: str
    state: str
    evidence_ids: tuple[str, ...]

    @classmethod
    def from_dict(cls, value: object) -> "StatusUpdate":
        """Validate one evidence-bound independent status update."""

        item = require_object(value, "status update")
        require_fields(item, {"track", "state", "evidence_ids"}, "status update")
        track = require_string(item["track"], "status track")
        state = require_string(item["state"], "status state")
        evidence_ids = item["evidence_ids"]
        if track not in STATUS_STATES or state not in STATUS_STATES[track]:
            raise ValidationError(f"invalid status update: {track}={state}")
        if not isinstance(evidence_ids, list) or any(not isinstance(item, str) for item in evidence_ids):
            raise ValidationError("status evidence_ids must be an array of strings")
        if state != "unknown" and not evidence_ids:
            raise ValidationError("non-unknown status requires evidence")
        if len(set(evidence_ids)) != len(evidence_ids):
            raise ValidationError("status evidence_ids must be unique")
        return cls(track, state, tuple(evidence_ids))

    def to_dict(self) -> dict[str, object]:
        """Return the portable status update object."""

        return {"track": self.track, "state": self.state, "evidence_ids": list(self.evidence_ids)}


@dataclass(frozen=True, slots=True)
class Event:
    """Represent one immutable event in a device-owned monthly stream."""

    event_id: str
    device_id: str
    recorded_at: str
    occurred_at: str
    owner: LogicalLocator
    kind: str
    summary: str
    evidence: tuple[Evidence, ...]
    status_updates: tuple[StatusUpdate, ...]
    correction: Correction | None = None

    @classmethod
    def from_dict(cls, value: object) -> "Event":
        """Validate and construct a schema-version-1 append-only event."""

        item = require_object(value, "Event")
        require_fields(
            item,
            {"schema", "schema_version", "event_id", "device_id", "recorded_at", "occurred_at", "owner", "kind", "summary", "evidence", "status_updates"},
            "Event",
            {"correction"},
        )
        if item["schema"] != EVENT_SCHEMA or item["schema_version"] != 1:
            raise ValidationError("Event must use research-workflow/event schema version 1")
        event_id = validate_event_id(item["event_id"])
        device_id = validate_device_id(item["device_id"])
        recorded_at = validate_utc(item["recorded_at"], "Event.recorded_at")
        occurred_at = validate_utc(item["occurred_at"], "Event.occurred_at")
        prefix = recorded_at.replace("-", "").replace(":", "")
        bound_id = prefix + "-" + device_id
        if event_id != bound_id and not event_id.startswith(bound_id + "-"):
            raise ValidationError("event_id must bind its recorded_at and device_id")
        raw_evidence = item["evidence"]
        raw_updates = item["status_updates"]
        if not isinstance(raw_evidence, list) or not isinstance(raw_updates, list):
            raise ValidationError("Event evidence and status_updates must be arrays")
        evidence = tuple(Evidence.from_dict(value) for value in raw_evidence)
        if tuple(item.evidence_id for item in evidence) != tuple(f"E{index}" for index in range(1, len(evidence) + 1)):
            raise ValidationError("evidence IDs must be consecutive E1, E2, ...")
        if any(item.observed_at > recorded_at for item in evidence):
            raise ValidationError("evidence cannot be observed after event recording")
        updates = tuple(StatusUpdate.from_dict(value) for value in raw_updates)
        if len({update.track for update in updates}) != len(updates):
            raise ValidationError("an event may update each status track once")
        evidence_ids = {item.evidence_id for item in evidence}
        if any(set(update.evidence_ids) - evidence_ids for update in updates):
            raise ValidationError("status update references missing same-event evidence")
        kind = require_string(item["kind"], "Event.kind")
        if kind not in EVENT_KINDS:
            raise ValidationError(f"unsupported event kind: {kind}")
        if kind == "status-change" and not updates:
            raise ValidationError("status-change event requires status_updates")
        correction = Correction.from_dict(item["correction"]) if "correction" in item else None
        if (kind == "correction") != (correction is not None):
            raise ValidationError("correction kind and correction object must appear together")
        if correction is not None and not evidence:
            raise ValidationError("correction events require replacement evidence")
        owner = LogicalLocator.from_dict(item["owner"])
        if owner.kind not in {"case", "study", "root"}:
            raise ValidationError("event owner must be a Case, Study, or root locator")
        if updates and owner.kind != "case":
            raise ValidationError("only Case-owned events may update status")
        event = cls(
            event_id=event_id,
            device_id=device_id,
            recorded_at=recorded_at,
            occurred_at=occurred_at,
            owner=owner,
            kind=kind,
            summary=require_string(item["summary"], "Event.summary"),
            evidence=evidence,
            status_updates=updates,
            correction=correction,
        )
        if len(canonical_json_bytes(event.to_dict())) > 64 * 1024:
            raise ValidationError("Event exceeds 65536 canonical bytes")
        return event

    def to_dict(self) -> dict[str, object]:
        """Return the exact portable event record without writing a stream."""

        result: dict[str, object] = {
            "schema": EVENT_SCHEMA,
            "schema_version": 1,
            "event_id": self.event_id,
            "device_id": self.device_id,
            "recorded_at": self.recorded_at,
            "occurred_at": self.occurred_at,
            "owner": self.owner.to_dict(),
            "kind": self.kind,
            "summary": self.summary,
            "evidence": [item.to_dict() for item in self.evidence],
            "status_updates": [item.to_dict() for item in self.status_updates],
        }
        if self.correction is not None:
            result["correction"] = self.correction.to_dict()
        return result


def build_event(
    *,
    event_id: str,
    device_id: str,
    recorded_at: str,
    occurred_at: str,
    owner: LogicalLocator,
    kind: str,
    summary: str,
    evidence: tuple[Evidence, ...] = (),
    status_updates: tuple[StatusUpdate, ...] = (),
    correction: Correction | None = None,
) -> Event:
    """Build and validate an Event in memory without appending a stream."""

    document: dict[str, object] = {
        "schema": EVENT_SCHEMA,
        "schema_version": 1,
        "event_id": event_id,
        "device_id": device_id,
        "recorded_at": recorded_at,
        "occurred_at": occurred_at,
        "owner": owner.to_dict(),
        "kind": kind,
        "summary": summary,
        "evidence": [copy.deepcopy(item.to_dict()) for item in evidence],
        "status_updates": [copy.deepcopy(item.to_dict()) for item in status_updates],
    }
    if correction is not None:
        document["correction"] = correction.to_dict()
    return Event.from_dict(document)


__all__ = [
    "EVENT_KINDS",
    "EVENT_SCHEMA",
    "EVIDENCE_KINDS",
    "STATUS_STATES",
    "Evidence",
    "Event",
    "StatusUpdate",
    "build_event",
]
