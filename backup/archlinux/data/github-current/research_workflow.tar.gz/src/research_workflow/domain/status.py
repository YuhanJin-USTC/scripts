"""Derive independent status tracks from merged events."""

from __future__ import annotations

from collections.abc import Callable

from research_workflow.core.errors import ConflictError

from .corrections import validate_corrections
from .events import Event, STATUS_STATES


def derive_case_status(
    events: list[Event],
    sim_id: str,
    *,
    lineage_ids: set[str] | None = None,
    canonical_case_identity: Callable[[str], str] | None = None,
) -> dict[str, dict[str, object]]:
    """Derive status from the complete canonical Case lineage."""

    corrected = validate_corrections(events, canonical_case_identity=canonical_case_identity)
    selected_ids = lineage_ids or {sim_id}
    selected = [
        event
        for event in events
        if event.owner.kind == "case" and event.owner.identity in selected_ids
    ]
    result: dict[str, dict[str, object]] = {
        track: {"state": "unknown", "event_id": "not-applicable", "conflict": False}
        for track in STATUS_STATES
    }
    for track in STATUS_STATES:
        candidates: list[tuple[str, str, str, object]] = []
        for event in selected:
            if track in corrected.get(event.event_id, set()):
                continue
            for update in event.status_updates:
                if update.track == track:
                    candidates.append((event.occurred_at, event.recorded_at, event.event_id, update))
        if not candidates:
            continue
        latest_time = max(item[0] for item in candidates)
        latest = [item for item in candidates if item[0] == latest_time]
        states = {item[3].state for item in latest}
        if len(states) > 1:
            result[track] = {
                "state": "unknown",
                "event_id": "not-applicable",
                "conflict": True,
                "conflict_event_ids": sorted(item[2] for item in latest),
            }
            continue
        winner = max(latest, key=lambda item: (item[1], item[2]))
        update = winner[3]
        result[track] = {
            "state": update.state,
            "event_id": winner[2],
            "occurred_at": winner[0],
            "evidence_ids": list(update.evidence_ids),
            "conflict": False,
        }
    return result


def require_unconflicted(status: dict[str, dict[str, object]]) -> None:
    """Raise when any derived status track has equal-time state conflict."""

    conflicts = sorted(track for track, value in status.items() if value.get("conflict"))
    if conflicts:
        raise ConflictError(f"status conflicts require correction: {', '.join(conflicts)}")


__all__ = ["derive_case_status", "require_unconflicted"]
