"""Define ordered reusable metadata profiles."""

from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Mapping

from research_workflow.core.canonical import require_fields, require_object, require_string
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.core.ids import validate_logical_id


PROFILE_SCHEMA = "research-workflow/profile"


@dataclass(frozen=True, slots=True)
class ProfileReference:
    """Identify one reusable profile in an ordered materialization sequence."""

    scope: str
    profile_id: str

    @classmethod
    def from_dict(cls, value: object) -> "ProfileReference":
        """Validate and construct a profile reference without resolving it."""

        item = require_object(value, "profile reference")
        require_fields(item, {"scope", "profile_id"}, "profile reference")
        return cls(
            scope=validate_logical_id(item["scope"], "profile scope"),
            profile_id=validate_logical_id(item["profile_id"], "profile_id"),
        )

    def to_dict(self) -> dict[str, object]:
        """Return the portable profile reference object."""

        return {"scope": self.scope, "profile_id": self.profile_id}


@dataclass(frozen=True, slots=True)
class Profile:
    """Represent one current schema-version-1 reusable profile."""

    profile_id: str
    scope: str
    name: str
    content: dict[str, object]

    @classmethod
    def from_dict(cls, value: object) -> "Profile":
        """Validate and construct a current profile document."""

        item = require_object(value, "Profile")
        require_fields(
            item,
            {"schema", "schema_version", "profile_id", "scope", "name", "content"},
            "Profile",
        )
        if item["schema"] != PROFILE_SCHEMA or item["schema_version"] != 1:
            raise ValidationError("Profile must use research-workflow/profile schema version 1")
        return cls(
            profile_id=validate_logical_id(item["profile_id"], "profile_id"),
            scope=validate_logical_id(item["scope"], "profile scope"),
            name=require_string(item["name"], "Profile.name"),
            content=copy.deepcopy(require_object(item["content"], "Profile.content")),
        )

    def to_dict(self) -> dict[str, object]:
        """Return the current portable profile document."""

        return {
            "schema": PROFILE_SCHEMA,
            "schema_version": 1,
            "profile_id": self.profile_id,
            "scope": self.scope,
            "name": self.name,
            "content": copy.deepcopy(self.content),
        }

    @property
    def reference(self) -> ProfileReference:
        """Return this profile's portable identity."""

        return ProfileReference(self.scope, self.profile_id)


def resolve_profiles(
    references: list[ProfileReference],
    profiles: Mapping[tuple[str, str], Profile],
) -> list[Profile]:
    """Resolve an ordered profile list and refuse duplicate or wrong identities."""

    result: list[Profile] = []
    seen: set[tuple[str, str]] = set()
    for reference in references:
        key = (reference.scope, reference.profile_id)
        if key in seen:
            raise ConflictError(f"duplicate ordered profile reference: {reference.scope}/{reference.profile_id}")
        seen.add(key)
        profile = profiles.get(key)
        if profile is None:
            raise ValidationError(f"missing profile: {reference.scope}/{reference.profile_id}")
        if profile.reference != reference:
            raise ConflictError(f"conflicting profile identity: {reference.scope}/{reference.profile_id}")
        result.append(profile)
    return result


__all__ = ["PROFILE_SCHEMA", "Profile", "ProfileReference", "resolve_profiles"]

