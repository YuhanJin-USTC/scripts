"""Validate append-only event corrections."""

from __future__ import annotations

import re
from dataclasses import dataclass
from collections.abc import Callable
from typing import Protocol

from research_workflow.core.canonical import require_fields, require_object
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.core.ids import validate_event_id

_POINTER_RE = re.compile(r"^/(?:[^~/]|~[01])+(?:/(?:[^~/]|~[01])+)*$")
_IMMUTABLE = {"schema", "schema_version", "event_id", "device_id", "recorded_at", "correction"}


class _StatusLike(Protocol):
    track: str


class _OwnerLike(Protocol):
    kind: str
    identity: str


class _EventLike(Protocol):
    event_id: str
    recorded_at: str
    owner: _OwnerLike
    correction: "Correction | None"
    status_updates: tuple[_StatusLike, ...]

    def to_dict(self) -> dict[str, object]:
        """Return the event document used for pointer validation."""


@dataclass(frozen=True, slots=True)
class Correction:
    """Name one earlier event and the exact fields or status tracks replaced."""

    corrects: str
    fields: tuple[str, ...]
    status_tracks: tuple[str, ...]

    @classmethod
    def from_dict(cls, value: object) -> "Correction":
        """Validate a correction target without editing event history."""

        item = require_object(value, "correction")
        require_fields(item, {"corrects", "fields", "status_tracks"}, "correction")
        fields = item["fields"]
        tracks = item["status_tracks"]
        if not isinstance(fields, list) or not isinstance(tracks, list):
            raise ValidationError("correction fields and status_tracks must be arrays")
        if not fields and not tracks:
            raise ValidationError("correction must replace at least one field or status track")
        normalized_fields: list[str] = []
        for pointer in fields:
            if not isinstance(pointer, str) or not _POINTER_RE.fullmatch(pointer):
                raise ValidationError(f"invalid correction JSON Pointer: {pointer!r}")
            root = pointer[1:].split("/", 1)[0].replace("~1", "/").replace("~0", "~")
            if root in _IMMUTABLE:
                raise ValidationError(f"correction targets immutable field: {root}")
            if root == "owner" and pointer != "/owner":
                raise ValidationError("owner correction must target the complete /owner field")
            normalized_fields.append(pointer)
        normalized_tracks: list[str] = []
        for track in tracks:
            if track not in {"run", "data", "analysis"}:
                raise ValidationError(f"invalid correction status track: {track!r}")
            normalized_tracks.append(str(track))
        if len(set(normalized_fields)) != len(normalized_fields) or len(set(normalized_tracks)) != len(normalized_tracks):
            raise ValidationError("correction fields and status tracks must be unique")
        if "/owner" in normalized_fields and (normalized_fields != ["/owner"] or normalized_tracks):
            raise ValidationError("owner migration must replace only /owner and no status tracks")
        return cls(validate_event_id(item["corrects"]), tuple(normalized_fields), tuple(normalized_tracks))

    def to_dict(self) -> dict[str, object]:
        """Return the append-only correction object."""

        return {
            "corrects": self.corrects,
            "fields": list(self.fields),
            "status_tracks": list(self.status_tracks),
        }


def _pointer_value(document: object, pointer: str) -> object:
    current = document
    for raw in pointer[1:].split("/"):
        part = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(current, dict) and part in current:
            current = current[part]
        elif isinstance(current, list) and part.isdigit() and int(part) < len(current):
            current = current[int(part)]
        else:
            raise ValidationError(f"correction pointer does not resolve: {pointer}")
    return current


def validate_corrections(
    events: list[_EventLike],
    *,
    registered_case_ids: set[str] | None = None,
    canonical_case_identity: Callable[[str], str] | None = None,
) -> dict[str, set[str]]:
    """Validate corrections, comparing Case owners through canonical lineage."""

    by_id = {event.event_id: event for event in events}
    if len(by_id) != len(events):
        raise ConflictError("correction validation requires unique merged event IDs")
    corrected: dict[str, set[str]] = {}
    for event in events:
        correction = event.correction
        if correction is None:
            continue
        target = by_id.get(correction.corrects)
        if target is None:
            raise ValidationError(f"correction target is missing: {correction.corrects}")
        if (target.recorded_at, target.event_id) >= (event.recorded_at, event.event_id):
            raise ConflictError("correction must name an earlier event")
        owner_migration = correction.fields == ("/owner",)
        if owner_migration:
            if target.owner.kind != "case" or event.owner.kind != "root":
                raise ConflictError("owner migration must replace an orphan Case owner with a root owner")
            if target.owner == event.owner:
                raise ConflictError("owner migration requires a different replacement owner")
            if target.status_updates or event.status_updates:
                raise ConflictError("owner migration cannot carry or replace status updates")
            if registered_case_ids is not None and target.owner.identity in registered_case_ids:
                raise ConflictError("owner migration cannot replace a registered Case owner")
        elif target.owner.kind == "case" and event.owner.kind == "case" and canonical_case_identity is not None:
            if canonical_case_identity(target.owner.identity) != canonical_case_identity(event.owner.identity):
                raise ConflictError("correction owner differs from target owner")
        elif target.owner != event.owner:
            raise ConflictError("correction owner differs from target owner")
        for pointer in correction.fields:
            _pointer_value(target.to_dict(), pointer)
            _pointer_value(event.to_dict(), pointer)
        target_tracks = {update.track for update in target.status_updates}
        replacement_tracks = {update.track for update in event.status_updates}
        if set(correction.status_tracks) - target_tracks:
            raise ValidationError("correction names a status track absent from its target")
        if set(correction.status_tracks) - replacement_tracks:
            raise ValidationError("correction lacks a replacement status update")
        corrected.setdefault(target.event_id, set()).update(correction.status_tracks)
    return corrected


__all__ = ["Correction", "validate_corrections"]
