"""Define current Project metadata."""

from __future__ import annotations

import copy
from dataclasses import dataclass

from research_workflow.core.canonical import require_fields, require_object, require_string
from research_workflow.core.errors import ValidationError
from research_workflow.core.ids import validate_logical_id

from .knowledge import KnowledgeLink, parse_knowledge_links
from .profiles import ProfileReference


PROJECT_SCHEMA = "research-workflow/project"


@dataclass(frozen=True, slots=True)
class Project:
    """Represent one current Project and its ordered default profiles."""

    project_id: str
    name: str
    profiles: tuple[ProfileReference, ...]
    content: dict[str, object]
    knowledge_links: tuple[KnowledgeLink, ...] = ()
    schema_version: int = 1

    @classmethod
    def from_dict(cls, value: object) -> "Project":
        """Validate and construct a schema-version-1 Project document."""

        item = require_object(value, "Project")
        version = item.get("schema_version")
        optional = {"knowledge_links"} if version == 2 else set()
        require_fields(
            item,
            {"schema", "schema_version", "project_id", "name", "profiles", "content"},
            "Project",
            optional,
        )
        if item["schema"] != PROJECT_SCHEMA or version not in {1, 2}:
            raise ValidationError("Project must use research-workflow/project schema version 1 or 2")
        raw_profiles = item["profiles"]
        if not isinstance(raw_profiles, list):
            raise ValidationError("Project.profiles must be an ordered array")
        return cls(
            project_id=validate_logical_id(item["project_id"], "project_id"),
            name=require_string(item["name"], "Project.name"),
            profiles=tuple(ProfileReference.from_dict(value) for value in raw_profiles),
            content=copy.deepcopy(require_object(item["content"], "Project.content")),
            knowledge_links=parse_knowledge_links(item.get("knowledge_links", []), "Project.knowledge_links"),
            schema_version=version,
        )

    def to_dict(self) -> dict[str, object]:
        """Return the current portable Project document."""

        result: dict[str, object] = {
            "schema": PROJECT_SCHEMA,
            "schema_version": self.schema_version,
            "project_id": self.project_id,
            "name": self.name,
            "profiles": [reference.to_dict() for reference in self.profiles],
            "content": copy.deepcopy(self.content),
        }
        if self.schema_version == 2 and self.knowledge_links:
            result["knowledge_links"] = [link.to_dict() for link in self.knowledge_links]
        return result


__all__ = ["PROJECT_SCHEMA", "Project"]
