"""Define current Study metadata and explicit Notes links."""

from __future__ import annotations

import copy
from dataclasses import dataclass

from research_workflow.core.canonical import require_fields, require_object, require_string
from research_workflow.core.errors import ValidationError
from research_workflow.core.ids import validate_logical_id, validate_sim_id
from research_workflow.workspace.locators import LogicalLocator

from .knowledge import KnowledgeLink, parse_knowledge_links
from .profiles import ProfileReference


STUDY_SCHEMA = "research-workflow/study"


@dataclass(frozen=True, slots=True)
class NotesLink:
    """Bind a Study to one exact Notes file and section."""

    locator: LogicalLocator
    section: str

    @classmethod
    def from_dict(cls, value: object) -> "NotesLink":
        """Validate an explicit Notes link without reading Notes."""

        item = require_object(value, "Study.notes")
        require_fields(item, {"locator", "section"}, "Study.notes")
        locator = LogicalLocator.from_dict(item["locator"])
        if locator.kind != "root" or locator.identity != "notes" or locator.path is None:
            raise ValidationError("Study.notes locator must name one root:notes file")
        return cls(locator=locator, section=require_string(item["section"], "Study.notes.section"))

    def to_dict(self) -> dict[str, object]:
        """Return the explicit Notes link object."""

        return {"locator": self.locator.to_dict(), "section": self.section}


@dataclass(frozen=True, slots=True)
class Study:
    """Represent one current Study and ordered profile layer."""

    project_id: str
    study_id: str
    name: str
    sim_prefix: str
    profiles: tuple[ProfileReference, ...]
    content: dict[str, object]
    notes: NotesLink | None = None
    knowledge_links: tuple[KnowledgeLink, ...] = ()
    schema_version: int = 1

    @classmethod
    def from_dict(cls, value: object) -> "Study":
        """Validate and construct a schema-version-1 Study document."""

        item = require_object(value, "Study")
        version = item.get("schema_version")
        optional = {"notes"} if version == 1 else {"knowledge_links"}
        require_fields(
            item,
            {"schema", "schema_version", "project_id", "study_id", "name", "sim_prefix", "profiles", "content"},
            "Study",
            optional,
        )
        if item["schema"] != STUDY_SCHEMA or version not in {1, 2}:
            raise ValidationError("Study must use research-workflow/study schema version 1 or 2")
        raw_profiles = item["profiles"]
        if not isinstance(raw_profiles, list):
            raise ValidationError("Study.profiles must be an ordered array")
        notes = NotesLink.from_dict(item["notes"]) if "notes" in item else None
        return cls(
            project_id=validate_logical_id(item["project_id"], "project_id"),
            study_id=validate_logical_id(item["study_id"], "study_id"),
            name=require_string(item["name"], "Study.name"),
            sim_prefix=validate_sim_id(item["sim_prefix"]),
            profiles=tuple(ProfileReference.from_dict(value) for value in raw_profiles),
            content=copy.deepcopy(require_object(item["content"], "Study.content")),
            notes=notes,
            knowledge_links=parse_knowledge_links(item.get("knowledge_links", []), "Study.knowledge_links"),
            schema_version=version,
        )

    def to_dict(self) -> dict[str, object]:
        """Return the current portable Study document."""

        result: dict[str, object] = {
            "schema": STUDY_SCHEMA,
            "schema_version": self.schema_version,
            "project_id": self.project_id,
            "study_id": self.study_id,
            "name": self.name,
            "sim_prefix": self.sim_prefix,
            "profiles": [reference.to_dict() for reference in self.profiles],
            "content": copy.deepcopy(self.content),
        }
        if self.notes is not None:
            result["notes"] = self.notes.to_dict()
        if self.schema_version == 2 and self.knowledge_links:
            result["knowledge_links"] = [link.to_dict() for link in self.knowledge_links]
        return result


__all__ = ["NotesLink", "STUDY_SCHEMA", "Study"]
