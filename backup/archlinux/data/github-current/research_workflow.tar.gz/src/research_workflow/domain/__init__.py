"""Expose current research metadata domain models."""

from .cases import (
    CASE_DELTA_SCHEMA,
    CASE_VIEW_SCHEMA,
    CaseDelta,
    CaseView,
    build_revised_case_delta,
    materialize_case,
    validate_revision,
)
from .case_records import (
    CASE_RECORD_ACTIONS,
    CASE_RECORD_SCHEMA,
    NO_PREVIOUS_DIGEST,
    CaseHead,
    CaseRecord,
    LegacyCaseBinding,
    LegacyDeletionBinding,
    reduce_case_records,
)
from .corrections import Correction, validate_corrections
from .events import (
    EVENT_KINDS,
    EVENT_SCHEMA,
    EVIDENCE_KINDS,
    STATUS_STATES,
    Evidence,
    Event,
    StatusUpdate,
    build_event,
)
from .knowledge import ExternalReference, KNOWLEDGE_ROLES, KnowledgeLink, parse_knowledge_links
from .profiles import PROFILE_SCHEMA, Profile, ProfileReference, resolve_profiles
from .projects import PROJECT_SCHEMA, Project
from .status import derive_case_status, require_unconflicted
from .studies import NotesLink, STUDY_SCHEMA, Study

__all__ = [
    "CASE_DELTA_SCHEMA",
    "CASE_RECORD_ACTIONS",
    "CASE_RECORD_SCHEMA",
    "CASE_VIEW_SCHEMA",
    "Correction",
    "EVENT_KINDS",
    "EVENT_SCHEMA",
    "EVIDENCE_KINDS",
    "ExternalReference",
    "Evidence",
    "CaseDelta",
    "CaseHead",
    "CaseRecord",
    "CaseView",
    "LegacyCaseBinding",
    "LegacyDeletionBinding",
    "KNOWLEDGE_ROLES",
    "KnowledgeLink",
    "NO_PREVIOUS_DIGEST",
    "build_revised_case_delta",
    "NotesLink",
    "PROFILE_SCHEMA",
    "PROJECT_SCHEMA",
    "Profile",
    "ProfileReference",
    "Project",
    "STATUS_STATES",
    "STUDY_SCHEMA",
    "StatusUpdate",
    "Study",
    "Event",
    "build_event",
    "derive_case_status",
    "materialize_case",
    "parse_knowledge_links",
    "require_unconflicted",
    "resolve_profiles",
    "reduce_case_records",
    "validate_corrections",
    "validate_revision",
]
