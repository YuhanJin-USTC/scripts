"""Define explicit opt-in links to curated research knowledge."""

from __future__ import annotations

from dataclasses import dataclass

from research_workflow.core.canonical import require_fields, require_object, require_string
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.core.ids import validate_logical_id
from research_workflow.workspace.locators import LogicalLocator


KNOWLEDGE_ROLES = ("literature", "theory")


@dataclass(frozen=True, slots=True)
class ExternalReference:
    """Keep one stable external identity without dereferencing it."""

    kind: str
    value: str

    @classmethod
    def from_dict(cls, value: object) -> "ExternalReference":
        item = require_object(value, "knowledge external_ref")
        require_fields(item, {"kind", "value"}, "knowledge external_ref")
        kind = require_string(item["kind"], "knowledge external_ref.kind")
        if kind != "zotero":
            raise ValidationError("knowledge external_ref.kind must be zotero")
        return cls(kind, require_string(item["value"], "knowledge external_ref.value"))

    def to_dict(self) -> dict[str, object]:
        return {"kind": self.kind, "value": self.value}


@dataclass(frozen=True, slots=True)
class KnowledgeLink:
    """Bind a Project or Study to one exact Notes section."""

    link_id: str
    role: str
    locator: LogicalLocator
    section: str
    external_ref: ExternalReference | None = None

    @classmethod
    def from_dict(cls, value: object) -> "KnowledgeLink":
        item = require_object(value, "knowledge link")
        require_fields(
            item,
            {"link_id", "role", "locator", "section"},
            "knowledge link",
            {"external_ref"},
        )
        role = require_string(item["role"], "knowledge link.role")
        if role not in KNOWLEDGE_ROLES:
            raise ValidationError("knowledge link.role must be literature or theory")
        locator = LogicalLocator.from_dict(item["locator"])
        if locator.kind != "root" or locator.identity != "notes" or locator.path is None:
            raise ValidationError("knowledge link locator must name one root:notes file")
        external = ExternalReference.from_dict(item["external_ref"]) if "external_ref" in item else None
        return cls(
            validate_logical_id(item["link_id"], "knowledge link_id"),
            role,
            locator,
            require_string(item["section"], "knowledge link.section"),
            external,
        )

    def to_dict(self) -> dict[str, object]:
        result: dict[str, object] = {
            "link_id": self.link_id,
            "role": self.role,
            "locator": self.locator.to_dict(),
            "section": self.section,
        }
        if self.external_ref is not None:
            result["external_ref"] = self.external_ref.to_dict()
        return result


def parse_knowledge_links(value: object, label: str) -> tuple[KnowledgeLink, ...]:
    """Validate an ordered set of unique knowledge links."""

    if not isinstance(value, list):
        raise ValidationError(f"{label} must be an ordered array")
    links = tuple(KnowledgeLink.from_dict(item) for item in value)
    identities = [link.link_id for link in links]
    if len(set(identities)) != len(identities):
        raise ConflictError(f"{label} link_id values must be unique")
    return links


__all__ = [
    "ExternalReference",
    "KNOWLEDGE_ROLES",
    "KnowledgeLink",
    "parse_knowledge_links",
]
