"""Dispatch current CLI commands to domain, storage, and context services."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, runtime_checkable

from research_workflow.core.canonical import decode_json, require_object
from research_workflow.core.errors import ConflictError, UnsupportedOperationError, ValidationError
from research_workflow.core.ids import validate_device_id, validate_event_id
from research_workflow.core.time import utc_now, validate_utc
from research_workflow.domain.cases import CASE_DELTA_SCHEMA, CaseDelta, build_revised_case_delta
from research_workflow.domain.corrections import Correction
from research_workflow.domain.events import Evidence, Event, StatusUpdate, build_event
from research_workflow.domain.profiles import ProfileReference
from research_workflow.domain.projects import PROJECT_SCHEMA, Project
from research_workflow.domain.studies import STUDY_SCHEMA, Study
from research_workflow.index import QueryIndex
from research_workflow.services.case_changes import CaseChanges
from research_workflow.services.plans import ConfirmationPlans
from research_workflow.services.owners import resolve_owner
from research_workflow.services.queries import MemoryQuery
from research_workflow.storage.devices import require_registered_device
from research_workflow.storage.locking import authority_lock
from research_workflow.services import CheckpointRequest, CheckpointService, ContextOptions, ContextService
from research_workflow.storage import (
    Store,
    append_event,
    atomic_json_write,
    materialized_case_document,
    read_json,
    validate_device_document,
)
from research_workflow.workspace import LogicalLocator, WorkspaceRegistry, parse_locator


@dataclass(frozen=True, slots=True)
class HandlerContext:
    """Bind CLI handlers to one fixture-safe workspace and Store."""

    workspace: WorkspaceRegistry
    store: Store


@runtime_checkable
class PolicyService(Protocol):
    """Define the policy service boundary used by existing CLI handlers."""

    def execute(self, command: str, args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
        """Execute one policy command or raise an expected failure."""


class UnavailablePolicyService:
    """Refuse policy behavior when no implementation is injected."""

    def execute(self, command: str, args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
        """Refuse without reading or writing policy authority."""

        if getattr(args, "write", False):
            context.workspace.require_device()
        raise UnsupportedOperationError(f"{command} requires the policy service")


def _target_locator(target: str, context: HandlerContext) -> LogicalLocator:
    return resolve_owner(target, context.workspace, context.store)


def _status_values(values: list[str], evidence_ids: tuple[str, ...]) -> tuple[StatusUpdate, ...]:
    result: list[StatusUpdate] = []
    for value in values:
        if "=" not in value:
            raise ValidationError("--status must use TRACK=STATE")
        track, state = value.split("=", 1)
        ids = evidence_ids if state != "unknown" else ()
        result.append(StatusUpdate.from_dict({"track": track, "state": state, "evidence_ids": list(ids)}))
    return tuple(result)


def _recorded_time(event_id: str | None, device_id: str) -> tuple[str, str]:
    if event_id is None:
        recorded = utc_now()
        return recorded, recorded.replace("-", "").replace(":", "") + "-" + device_id
    validated = validate_event_id(event_id)
    try:
        parsed = dt.datetime.strptime(validated[:16], "%Y%m%dT%H%M%SZ")
    except ValueError as exc:
        raise ValidationError("event_id has an invalid UTC prefix") from exc
    return parsed.strftime("%Y-%m-%dT%H:%M:%SZ"), validated


def _handle_context(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    return ContextService(context.workspace, context.store).build(
        args.target,
        ContextOptions(
            view=args.view,
            recent=args.recent,
            select=tuple(args.select),
            include=tuple(args.include),
            include_links=tuple(args.include_link),
            recursive=args.recursive,
        ),
    )


def _handle_checkpoint(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    service = CheckpointService(context.workspace, context.store)
    saved_digest = args.apply_plan or args.expect_digest
    if saved_digest is not None:
        if args.target is not None or args.request_json is not None or args.stdin or args.request is not None:
            raise ValidationError("saved plan replay cannot be combined with TARGET or request input; use case apply --plan DIGEST")
        return service.apply_saved(saved_digest, write=args.write)
    if args.request is not None and args.request != "-":
        raise ValidationError("compatibility --request accepts only -; use --stdin")
    if args.stdin or args.request == "-":
        raw = sys.stdin.read()
    elif args.request_json is not None:
        raw = args.request_json
    else:
        raise ValidationError("checkpoint requires --request-json or --stdin")
    request = CheckpointRequest.from_dict(
        decode_json(raw),
        default_target=args.target,
    )
    return service.execute(request, write=args.write)


def _handle_case_list(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    cases: list[dict[str, object]] = []
    for sim_id in context.store.list_case_ids():
        head = context.store.case_head(sim_id)
        if head is None or head.state != "active":
            continue
        delta = head.delta
        assert delta is not None
        if args.project is not None and delta.project_id != args.project:
            continue
        if args.study is not None and delta.study_id != args.study:
            continue
        cases.append(
            {
                "sim_id": sim_id,
                "project_id": delta.project_id,
                "study_id": delta.study_id,
                "revision": delta.revision,
                "current_spec_digest": head.delta_digest,
            }
        )
    return {"cases": cases, "count": len(cases)}


def _handle_case_show(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    return materialized_case_document(context.store, context.workspace.resolve_sim_id(args.target))


def _load_target_delta(args: argparse.Namespace, context: HandlerContext) -> CaseDelta:
    delta = CaseDelta.from_dict(read_json(args.delta, canonical=False))
    target = context.workspace.resolve_sim_id(args.target)
    if delta.sim_id != target:
        raise ConflictError("Case target and delta sim_id conflict")
    return delta


def _inline_content(value: str | None, label: str) -> dict[str, object]:
    """Decode one inline metadata content object with the core JSON gates."""

    if value is None:
        return {}
    return require_object(decode_json(value), label)


def _profile_references(values: list[str], option: str) -> list[dict[str, object]]:
    """Parse ordered SCOPE:PROFILE_ID flags into validated references."""

    references: list[dict[str, object]] = []
    for value in values:
        scope, separator, profile_id = value.partition(":")
        if not separator or not scope or not profile_id:
            raise ValidationError(f"{option} must use SCOPE:PROFILE_ID")
        reference = ProfileReference.from_dict({"scope": scope, "profile_id": profile_id})
        references.append(reference.to_dict())
    return references


def _profiles_json(value: str) -> tuple[ProfileReference, ...]:
    """Decode an explicit ordered Case profile replacement without ambiguity."""

    decoded = decode_json(value)
    if not isinstance(decoded, list):
        raise ValidationError("--profiles-json must be an array")
    return tuple(ProfileReference.from_dict(item) for item in decoded)


def _inline_case_documents(
    args: argparse.Namespace,
    context: HandlerContext,
) -> tuple[CaseDelta, Project | None, Study | None]:
    """Build canonical domain documents without temporary registration files."""

    if args.project_id is None or args.study_id is None:
        raise ValidationError("inline case create requires --project-id and --study-id")
    target = context.workspace.resolve_sim_id(args.target)
    delta = CaseDelta.from_dict(
        {
            "schema": CASE_DELTA_SCHEMA,
            "schema_version": 1,
            "sim_id": target,
            "project_id": args.project_id,
            "study_id": args.study_id,
            "revision": 1 if args.revision is None else args.revision,
            "profiles": _profile_references(args.case_profile, "--case-profile"),
            "content": _inline_content(args.content_json, "--content-json"),
        }
    )

    project_bootstrap = (args.project_name, args.project_content_json, *args.project_profile)
    project_path = context.store.project_path(delta.project_id)
    if project_path.exists():
        if any(value is not None for value in project_bootstrap):
            raise ValidationError("existing Project rejects inline bootstrap-only Project flags")
        project = None
    else:
        if args.project_name is None:
            raise ValidationError("missing Project requires --project-name")
        project = Project.from_dict(
            {
                "schema": PROJECT_SCHEMA,
                "schema_version": 2,
                "project_id": delta.project_id,
                "name": args.project_name,
                "profiles": _profile_references(args.project_profile, "--project-profile"),
                "content": _inline_content(args.project_content_json, "--project-content-json"),
            }
        )

    study_bootstrap = (
        args.study_name,
        args.study_prefix,
        args.study_content_json,
        *args.study_profile,
    )
    study_path = context.store.study_path(delta.project_id, delta.study_id)
    if study_path.exists():
        if any(value is not None for value in study_bootstrap):
            raise ValidationError("existing Study rejects inline bootstrap-only Study flags")
        study = None
    else:
        if args.study_name is None or args.study_prefix is None:
            raise ValidationError("missing Study requires --study-name and --study-prefix")
        study_document: dict[str, object] = {
            "schema": STUDY_SCHEMA,
            "schema_version": 2,
            "project_id": delta.project_id,
            "study_id": delta.study_id,
            "name": args.study_name,
            "sim_prefix": args.study_prefix,
            "profiles": _profile_references(args.study_profile, "--study-profile"),
            "content": _inline_content(args.study_content_json, "--study-content-json"),
        }
        study = Study.from_dict(study_document)
    return delta, project, study


def _handle_case_create(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    inline_values = (
        args.project_id,
        args.study_id,
        args.revision,
        args.content_json,
        args.project_name,
        args.project_content_json,
        args.study_name,
        args.study_prefix,
        args.study_content_json,
        *args.case_profile,
        *args.project_profile,
        *args.study_profile,
    )
    inline_requested = any(value is not None for value in inline_values)
    document_requested = any(value is not None for value in (args.delta, args.project, args.study))
    if inline_requested and document_requested:
        raise ValidationError("document and inline case create inputs cannot be combined")
    if document_requested:
        if args.delta is None:
            raise ValidationError("--project/--study document inputs require --delta")
        input_mode = "document"
        delta = _load_target_delta(args, context)
        project = Project.from_dict(read_json(args.project, canonical=False)) if args.project is not None else None
        study = Study.from_dict(read_json(args.study, canonical=False)) if args.study is not None else None
    else:
        input_mode = "inline"
        delta, project, study = _inline_case_documents(args, context)
    return CaseChanges(context.workspace, context.store).preview(
        "create", delta, project=project, study=study,
        input_configs=args.input_config, input_mode=input_mode, local_targets=[args.target],
    )


def _handle_case_revise(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    input_mode = "inline-patch"
    if args.revision is None:
        raise ValidationError("inline Case revision requires --revision")
    if not any((args.content_patch_json is not None, args.remove_content_path, args.profiles_json is not None)):
        raise ValidationError(
            "inline Case revision requires --content-patch-json, --remove-content-path, or --profiles-json"
        )
    target = context.workspace.resolve_sim_id(args.target)
    previous = context.store.load_case_delta(target)
    profiles = None if args.profiles_json is None else _profiles_json(args.profiles_json)
    patch = (
        None
        if args.content_patch_json is None
        else require_object(decode_json(args.content_patch_json), "--content-patch-json")
    )
    delta = build_revised_case_delta(
        previous,
        revision=args.revision,
        content_patch=patch,
        remove_content_paths=args.remove_content_path,
        profiles=profiles,
    )
    return CaseChanges(context.workspace, context.store).preview(
        "revise", delta, if_match=args.expect_digest, reason=args.reason,
        input_configs=args.input_config, input_mode=input_mode, local_targets=[args.target],
    )


def _handle_case_rename(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    return CaseChanges(context.workspace, context.store).preview(
        "rename", source=context.workspace.resolve_sim_id(args.source),
        destination=context.workspace.resolve_sim_id(args.destination),
        if_match=args.expect_digest, record_id=args.record_id, recorded_at=args.recorded_at,
        local_targets=[args.source, args.destination],
    )


def _handle_case_delete(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    return CaseChanges(context.workspace, context.store).preview(
        "delete", source=context.workspace.resolve_sim_id(args.target),
        if_match=args.expect_digest, record_id=args.record_id, recorded_at=args.recorded_at,
        local_targets=[args.target],
    )


def _handle_case_apply(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    return ConfirmationPlans(context.workspace, context.store).apply_saved(args.plan, write=args.write)


def _handle_event_record(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    device_id = context.workspace.require_device()
    recorded_at, event_id = _recorded_time(args.event_id, device_id)
    occurred_at = validate_utc(args.occurred_at, "occurred_at") if args.occurred_at else recorded_at
    owner = _target_locator(args.target, context)
    if owner.kind == "case":
        owner_state = context.store.case_state(owner.identity)
        if owner_state["state"] == "renamed":
            target = context.store.resolve_case_lineage(owner.identity)["canonical_sim_id"]
            raise ValidationError(f"Case {owner.identity} was renamed; record under canonical destination {target}")
        if owner_state["state"] == "deleted":
            raise ValidationError(f"cannot record an event for deleted Case {owner.identity}")
        if owner_state["state"] == "missing":
            raise ValidationError(
                f"cannot record an event for unregistered Case {owner.identity}; "
                "bootstrap it with case create first"
            )
    evidence: list[Evidence] = []
    for index, value in enumerate(args.evidence, start=1):
        locator = parse_locator(value, context.workspace)
        kind = "external-record" if locator.kind == "external" else "file"
        evidence.append(
            Evidence.from_dict(
                {
                    "id": f"E{index}",
                    "kind": kind,
                    "locator": locator.to_dict(),
                    "observation": "Explicit CLI evidence locator",
                    "observed_at": occurred_at,
                }
            )
        )
    evidence_ids = tuple(item.evidence_id for item in evidence)
    updates = _status_values(args.status, evidence_ids)
    correction: Correction | None = None
    if args.corrects is not None:
        if args.kind != "correction":
            raise ValidationError("--corrects requires --kind correction")
        tracks = tuple(update.track for update in updates)
        fields = () if tracks else ("/summary",)
        correction = Correction(args.corrects, fields, tracks)
    elif args.kind == "correction":
        raise ValidationError("correction events require --corrects")
    event = build_event(
        event_id=event_id,
        device_id=device_id,
        recorded_at=recorded_at,
        occurred_at=occurred_at,
        owner=owner,
        kind=args.kind,
        summary=args.summary,
        evidence=tuple(evidence),
        status_updates=updates,
        correction=correction,
    )
    result = append_event(
        context.store.root,
        event,
        current_device=device_id,
        write=args.write,
    )
    return {
        "mode": "write" if args.write else "preview",
        "event": event.to_dict(),
        "operation": result.to_dict(),
    }


def _handle_event_list(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    memory = MemoryQuery(context.workspace, context.store)
    selector = memory.selector(args.target) if args.target is not None else None
    return memory.events(selector, limit=args.limit, since=args.since, query=args.query, recursive=args.recursive)


def _handle_event_show(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    return QueryIndex(context.workspace.cache_path).show_event(context.store, validate_event_id(args.event_id))


def _handle_event_merge(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    events = context.store.read_events(args.device)
    states = context.store.list_case_state_ids()
    authority_ids = set(states["active"] + states["renamed"] + states["deleted"])
    deleted = [
        event.event_id
        for event in events
        if event.owner.kind == "case"
        and event.owner.identity in authority_ids
        and context.store.resolve_case_lineage(event.owner.identity)["state"] == "deleted"
    ]
    migrated = {
        event.correction.corrects
        for event in events
        if event.correction is not None and event.correction.fields == ("/owner",)
    }
    orphan = [
        event.event_id
        for event in events
        if event.owner.kind == "case"
        and event.owner.identity not in authority_ids
        and event.event_id not in migrated
    ]
    return {
        "events": [event.to_dict() for event in events],
        "count": len(events),
        "deleted_case_events": deleted,
        "orphan_case_events": orphan,
    }


def _handle_validate(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    if args.target is None:
        from research_workflow.services.validation import validate_workspace
        return validate_workspace(context.workspace, context.store)
    path = Path(args.target)
    if path.is_file():
        read_json(path, canonical=True)
        return {"valid": True, "checked": 1, "target": str(path.absolute())}
    sim_id = context.workspace.resolve_sim_id(args.target)
    state = context.store.case_state(sim_id)
    if state["state"] == "active":
        materialized_case_document(context.store, sim_id)
    elif state["state"] == "renamed":
        resolved = context.store.resolve_case_lineage(sim_id)
        state = {
            **state,
            "canonical_sim_id": resolved["canonical_sim_id"],
            "canonical_state": resolved["state"],
            "target_state": resolved["state"],
            "chain": resolved["chain"],
        }
    elif state["state"] == "deleted":
        pass
    else:
        raise ValidationError(f"Case target is missing: {sim_id}")
    return {"valid": True, "checked": 1, "sim_id": sim_id, **state}


def _handle_cache_rebuild(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    if not args.write:
        return {
            "action": "rebuild",
            "path": str(context.workspace.cache_path),
            "authority": False,
            "written": False,
        }
    context.workspace.require_device()
    return {"action": "rebuild", "written": True, **QueryIndex(context.workspace.cache_path).rebuild(context.store)}


def _handle_cache_update(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    if not args.write:
        return {
            "action": "update",
            "path": str(context.workspace.cache_path),
            "authority": False,
            "written": False,
        }
    context.workspace.require_device()
    index = QueryIndex(context.workspace.cache_path)
    index.ensure(context.store)
    return {"action": "update", "written": True, **index.stats()}


def _atomic_text(path: Path, text: str) -> None:
    path = path.absolute()
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=path.name + ".tmp-", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def _handle_device_onboard(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    device_id = validate_device_id(args.device_id)
    if context.workspace.device_id not in {None, device_id}:
        raise ConflictError("workspace already names a different current device")
    store_document = context.store.load_store()
    from research_workflow.storage.compatibility import require_compatible
    require_compatible(store_document)
    devices = [str(value) for value in store_document["devices"]]
    if device_id not in devices:
        store_document["devices"] = sorted(devices + [device_id])
    if context.store.device_path(device_id).exists():
        device_document = validate_device_document(read_json(context.store.device_path(device_id)))
        if device_document["device_id"] != device_id:
            raise ConflictError("Device path and document identity conflict")
    else:
        device_document = {
            "schema": "research-workflow/device",
            "schema_version": 1,
            "device_id": device_id,
            "name": device_id,
            "onboarded_at": utc_now(),
        }
    device_plan = atomic_json_write(context.store.device_path(device_id), device_document, create_only=True)
    store_plan = atomic_json_write(context.store.store_path, store_document)
    workspace_action = "reuse" if context.workspace.device_id == device_id else "append-device-table"
    if not args.write:
        return {
            "mode": "preview",
            "workspace_action": workspace_action,
            "operations": [device_plan.to_dict(), store_plan.to_dict()],
        }
    device_result = atomic_json_write(context.store.device_path(device_id), device_document, write=True, create_only=True)
    store_result = atomic_json_write(context.store.store_path, store_document, write=True)
    if context.workspace.device_id is None:
        try:
            text = context.workspace.config_path.read_text(encoding="utf-8")
        except OSError as exc:
            raise ValidationError(f"cannot read workspace for onboarding: {exc}") from exc
        suffix = "" if text.endswith("\n") else "\n"
        _atomic_text(context.workspace.config_path, text + suffix + f"\n[device]\ndevice_id = \"{device_id}\"\n")
    return {
        "mode": "write",
        "workspace_action": workspace_action,
        "operations": [device_result.to_dict(), store_result.to_dict()],
    }


def _handle_doctor(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    del args
    from research_workflow import __version__

    from research_workflow.services.validation import validate_workspace
    validation = validate_workspace(context.workspace, context.store)
    return {
        "framework_version": __version__,
        "workspace_id": context.workspace.workspace_id,
        "device_id": context.workspace.device_id or "unconfigured",
        "metadata_root": str(context.store.root),
        "cache": {"path": str(context.workspace.cache_path), "exists": context.workspace.cache_path.exists(), "authority": False},
        "validation": validation,
        "compatibility": validation["details"]["compatibility"],
    }


def _handle_sync_plan(args: argparse.Namespace, context: HandlerContext) -> dict[str, object]:
    del args, context
    return {
        "action": "none",
        "execution": False,
        "reason": "Synchronization remains an explicit external operation.",
    }


_HANDLERS = {
    "context": _handle_context,
    "checkpoint": _handle_checkpoint,
    "case.list": _handle_case_list,
    "case.show": _handle_case_show,
    "case.create": _handle_case_create,
    "case.apply": _handle_case_apply,
    "case.revise": _handle_case_revise,
    "case.rename": _handle_case_rename,
    "case.delete": _handle_case_delete,
    "event.record": _handle_event_record,
    "event.show": _handle_event_show,
    "event.list": _handle_event_list,
    "event.merge": _handle_event_merge,
    "validate": _handle_validate,
    "cache.rebuild": _handle_cache_rebuild,
    "cache.update": _handle_cache_update,
    "device.onboard": _handle_device_onboard,
    "doctor": _handle_doctor,
    "sync.plan": _handle_sync_plan,
}


def _dispatch(
    args: argparse.Namespace,
    context: HandlerContext,
    *,
    policy_service: PolicyService | None = None,
) -> dict[str, object]:
    """Dispatch one parsed command without compatibility or version routing."""

    command = str(args.handler)
    if command in {"case.create", "case.revise", "case.rename", "case.delete"} and args.write:
        raise ValidationError("direct Case --write is closed; preview without --write, ask the user, then case apply --plan DIGEST --write")
    if getattr(args, "write", False) and command != "device.onboard":
        require_registered_device(context.store.root, context.workspace.require_device())
    if command == "store.upgrade":
        from research_workflow.services.store_upgrade import StoreUpgradeService
        return StoreUpgradeService(context.workspace, context.store).execute(
            expect_digest=args.expect_digest, write=args.write)
    if command.startswith("policy."):
        from research_workflow.evolution import PolicyApplicationService

        service = policy_service or UnavailablePolicyService()
        if isinstance(service, PolicyApplicationService):
            service = PolicyApplicationService.from_workspace(context.workspace)
        return service.execute(command, args, context)
    handler = _HANDLERS.get(command)
    if handler is None:
        raise ValidationError(f"unknown command handler: {command}")
    return handler(args, context)


def dispatch(args, context, *, policy_service=None):
    command = str(args.handler)
    if getattr(args, "write", False) or command in {"checkpoint", "case.create", "case.revise", "case.rename", "case.delete"}:
        with authority_lock(context.store.root):
            context = HandlerContext(WorkspaceRegistry(context.workspace.config_path), context.store)
            return _dispatch(args, context, policy_service=policy_service)
    return _dispatch(args, context, policy_service=policy_service)


__all__ = ["HandlerContext", "PolicyService", "UnavailablePolicyService", "dispatch"]
