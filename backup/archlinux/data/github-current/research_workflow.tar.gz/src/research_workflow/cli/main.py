"""Run the current Research Workflow command-line interface."""

from __future__ import annotations

import json
import sys

from research_workflow.core.canonical import canonical_json_text
from research_workflow.core.errors import ConflictError, ResearchWorkflowError, UnsupportedOperationError, ValidationError
from research_workflow.evolution import PolicyApplicationService
from research_workflow.storage.store import Store
from research_workflow.workspace.registry import WorkspaceRegistry

from .handlers import HandlerContext, dispatch
from .parser import build_parser


def main(argv: list[str] | None = None) -> int:
    """Run one CLI command and return stable expected-failure exit codes."""

    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.handler == "doctor" and args.compatibility_only:
            from research_workflow.storage.compatibility import inspect_store
            if not args.store:
                raise ValidationError("doctor --compatibility-only requires --store ABSOLUTE_STORE")
            result = inspect_store(args.store)
            sys.stdout.write(canonical_json_text(result))
            return 0 if result["valid"] else 3
        if args.handler == "doctor" and args.store:
            raise ValidationError("--store requires doctor --compatibility-only")
        workspace = WorkspaceRegistry(args.workspace)
        context = HandlerContext(workspace, Store(workspace.metadata_root))
        policy_service = None
        if str(args.handler).startswith("policy."):
            policy_service = PolicyApplicationService.from_workspace(workspace)
        result = dispatch(args, context, policy_service=policy_service)
        if getattr(args, "json", False):
            sys.stdout.write(canonical_json_text(result))
        else:
            sys.stdout.write(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n")
        return 0
    except ConflictError as exc:
        code = 4
        message = str(exc)
    except UnsupportedOperationError as exc:
        code = 3
        message = str(exc)
    except ResearchWorkflowError as exc:
        code = 2
        message = str(exc)
    if getattr(args, "json", False):
        sys.stderr.write(canonical_json_text({"error": message, "exit_code": code}))
    else:
        sys.stderr.write(f"ERROR: {message}\n")
    return code


__all__ = ["main"]
