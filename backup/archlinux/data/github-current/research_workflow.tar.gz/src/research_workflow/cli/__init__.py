"""Expose the current versionless CLI entry point."""

from .main import main
from .parser import build_parser

__all__ = ["build_parser", "main"]

