"""Build the exact versionless Research Workflow command-line surface."""

from __future__ import annotations

import argparse
from pathlib import Path

from research_workflow.core.errors import ValidationError
from research_workflow.core.ids import validate_digest
from research_workflow.domain.events import EVENT_KINDS
from research_workflow.services.context import CONTEXT_INCLUDES


DEFAULT_WORKSPACE = Path(__file__).resolve().parents[3] / "workspace.toml"


def _digest(value: str) -> str:
    try:
        return validate_digest(value, "expect_digest")
    except ValidationError as exc:
        raise argparse.ArgumentTypeError(str(exc)) from exc


def _output(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--json", action="store_true")


def _write(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--write", action="store_true", help="perform the previewed write")
    _output(parser)


def build_parser() -> argparse.ArgumentParser:
    """Return the parser with the current versionless leaf commands."""

    parser = argparse.ArgumentParser(prog="researchctl", description="Research Workflow 0.x metadata control")
    parser.add_argument("--workspace", default=str(DEFAULT_WORKSPACE), help="workspace.toml path")
    root = parser.add_subparsers(dest="command", required=True)

    context = root.add_parser("context", help="build bounded current context")
    context.add_argument("target")
    context.add_argument("--view", choices=("compact", "deep"), default="compact")
    context.add_argument("--select", action="append", default=[], metavar="JSON_POINTER")
    context.add_argument("--include", action="append", default=[], choices=sorted(CONTEXT_INCLUDES))
    context.add_argument("--include-link", action="append", default=[], metavar="LINK_ID")
    context.add_argument("--recent", type=int, default=3)
    context.add_argument("--recursive", action="store_true")
    _output(context)
    context.set_defaults(handler="context")

    checkpoint = root.add_parser("checkpoint", help="record one structured daily checkpoint")
    checkpoint.add_argument("target", nargs="?", help="exact event owner; never an implicit Case change")
    checkpoint_input = checkpoint.add_mutually_exclusive_group(required=True)
    checkpoint_input.add_argument("--request-json", metavar="TEXT", help="inline checkpoint request object")
    checkpoint_input.add_argument("--stdin", action="store_true", help="read checkpoint request JSON from stdin")
    checkpoint_input.add_argument("--request", metavar="-", help=argparse.SUPPRESS)
    checkpoint_input.add_argument("--apply-plan", metavar="DIGEST", help="apply one saved replay plan")
    checkpoint.add_argument("--expect-digest", type=_digest, help=argparse.SUPPRESS)
    _write(checkpoint)
    checkpoint.set_defaults(handler="checkpoint")

    case = root.add_parser("case", help="inspect or change current Cases")
    case_commands = case.add_subparsers(dest="case_command", required=True)
    case_list = case_commands.add_parser("list", help="list current Cases")
    case_list.add_argument("--project")
    case_list.add_argument("--study")
    _output(case_list)
    case_list.set_defaults(handler="case.list")
    case_show = case_commands.add_parser("show", help="show an in-memory Case view")
    case_show.add_argument("target")
    _output(case_show)
    case_show.set_defaults(handler="case.show")
    case_create = case_commands.add_parser("create", help="preview or create a Case")
    case_create.add_argument("target")
    case_create.add_argument("--delta", help="durable Case delta document")
    case_create.add_argument("--project", help="Project document required only when the Case Project is missing")
    case_create.add_argument("--study", help="Study document required only when the Case Study is missing")
    case_create.add_argument("--project-id")
    case_create.add_argument("--study-id")
    case_create.add_argument("--revision", type=int)
    case_create.add_argument("--content-json")
    case_create.add_argument("--case-profile", action="append", default=[], metavar="SCOPE:PROFILE_ID")
    case_create.add_argument("--project-name")
    case_create.add_argument("--project-content-json")
    case_create.add_argument("--project-profile", action="append", default=[], metavar="SCOPE:PROFILE_ID")
    case_create.add_argument("--study-name")
    case_create.add_argument("--study-prefix")
    case_create.add_argument("--study-content-json")
    case_create.add_argument("--study-profile", action="append", default=[], metavar="SCOPE:PROFILE_ID")
    case_create.add_argument("--input-config", action="append", default=[], help="explicit configuration text; absolute path or root:/case: locator")
    _write(case_create)
    case_create.set_defaults(handler="case.create")
    case_revise = case_commands.add_parser("revise", help="preview or revise a Case")
    case_revise.add_argument("target")
    case_revise.add_argument("--revision", type=int, help="strictly higher inline revision")
    case_revise.add_argument("--content-patch-json", help="recursive object patch for current Case content")
    case_revise.add_argument(
        "--remove-content-path",
        action="append",
        default=[],
        metavar="JSON_POINTER",
        help="remove one existing /content/... object member",
    )
    case_revise.add_argument("--profiles-json", help="replace the ordered Case profiles array, including []")
    case_revise.add_argument("--expect-digest", required=True, type=_digest)
    case_revise.add_argument("--reason", choices=("input-change", "metadata-correction"), required=True)
    case_revise.add_argument("--input-config", action="append", default=[])
    _write(case_revise)
    case_revise.set_defaults(handler="case.revise")
    case_rename = case_commands.add_parser("rename", help="preview or digest-apply a metadata-only Case rename")
    case_rename.add_argument("source")
    case_rename.add_argument("destination")
    case_rename.add_argument("--record-id")
    case_rename.add_argument("--recorded-at")
    case_rename.add_argument("--expect-digest", required=True, type=_digest)
    _write(case_rename)
    case_rename.set_defaults(handler="case.rename")
    case_delete = case_commands.add_parser("delete", help="preview or digest-apply a metadata-only Case deletion")
    case_delete.add_argument("target")
    case_delete.add_argument("--record-id")
    case_delete.add_argument("--recorded-at")
    case_delete.add_argument("--expect-digest", required=True, type=_digest)
    _write(case_delete)
    case_delete.set_defaults(handler="case.delete")

    case_apply = case_commands.add_parser("apply", help="apply a saved preview after user confirmation")
    case_apply.add_argument("--plan", required=True, type=_digest)
    _write(case_apply)
    case_apply.set_defaults(handler="case.apply")

    event = root.add_parser("event", help="record or inspect append-only events")
    event_commands = event.add_subparsers(dest="event_command", required=True)
    event_list = event_commands.add_parser("list", help="query bounded work history")
    event_list.add_argument("target", nargs="?")
    event_list.add_argument("--limit", type=int, default=20)
    event_list.add_argument("--since", metavar="UTC")
    event_list.add_argument("--query", metavar="SUBSTRING")
    event_list.add_argument("--recursive", action="store_true")
    _output(event_list)
    event_list.set_defaults(handler="event.list")
    event_record = event_commands.add_parser("record", help="preview or append one event")
    event_record.add_argument("target")
    event_record.add_argument("--kind", required=True, choices=sorted(EVENT_KINDS))
    event_record.add_argument("--summary", required=True)
    event_record.add_argument("--evidence", action="append", default=[], metavar="LOCATOR")
    event_record.add_argument("--status", action="append", default=[], metavar="TRACK=STATE")
    event_record.add_argument("--corrects")
    event_record.add_argument("--event-id")
    event_record.add_argument("--occurred-at")
    _write(event_record)
    event_record.set_defaults(handler="event.record")
    event_show = event_commands.add_parser("show", help="show one exact event ID")
    event_show.add_argument("event_id")
    _output(event_show)
    event_show.set_defaults(handler="event.show")
    event_merge = event_commands.add_parser("merge", help="merge exact event identities")
    event_merge.add_argument("--device")
    _output(event_merge)
    event_merge.set_defaults(handler="event.merge")

    validate = root.add_parser("validate", help="validate current metadata structure")
    validate.add_argument("target", nargs="?")
    _output(validate)
    validate.set_defaults(handler="validate")

    cache = root.add_parser("cache", help="inspect or rebuild the disposable local index")
    cache_commands = cache.add_subparsers(dest="cache_command", required=True)
    cache_rebuild = cache_commands.add_parser("rebuild", help="preview or rebuild local cache")
    _write(cache_rebuild)
    cache_rebuild.set_defaults(handler="cache.rebuild")
    cache_update = cache_commands.add_parser("update", help="preview or update local cache")
    _write(cache_update)
    cache_update.set_defaults(handler="cache.update")

    device = root.add_parser("device", help="manage current device identity")
    device_commands = device.add_subparsers(dest="device_command", required=True)
    onboard = device_commands.add_parser("onboard", help="preview or onboard one device")
    onboard.add_argument("--device-id", required=True)
    _write(onboard)
    onboard.set_defaults(handler="device.onboard")

    doctor = root.add_parser("doctor", help="inspect current local configuration")
    doctor.add_argument("--compatibility-only", action="store_true")
    doctor.add_argument("--store", help="absolute STORE.json for compatibility-only inspection")
    _output(doctor)
    doctor.set_defaults(handler="doctor")

    store = root.add_parser("store", help="preview explicit Store upgrades")
    store_commands = store.add_subparsers(dest="store_command", required=True)
    upgrade = store_commands.add_parser("upgrade", help="activate approved Store capabilities")
    upgrade.add_argument("--to-schema", type=int, required=True, choices=(3,))
    upgrade.add_argument("--expect-digest", type=_digest)
    _write(upgrade)
    upgrade.set_defaults(handler="store.upgrade")

    policy = root.add_parser("policy", help="preview, approve, and propagate exact instruction policy")
    policy_commands = policy.add_subparsers(dest="policy_command", required=True)
    target = policy_commands.add_parser("target", help="preview exact target lifecycle changes")
    target_commands = target.add_subparsers(dest="target_command", required=True)
    for action in ("retire", "reenable"):
        leaf = target_commands.add_parser(action, help=f"prepare a pending target {action} proposal")
        leaf.add_argument("path")
        if action == "retire":
            leaf.add_argument("--replacement", required=True)
        leaf.add_argument("--proposal-id", required=True)
        leaf.add_argument("--evidence", action="append", required=True)
        _write(leaf)
        leaf.set_defaults(handler=f"policy.target.{action}")
    effective = policy_commands.add_parser("effective", help="show effective policy")
    effective.add_argument("--scope")
    _output(effective)
    effective.set_defaults(handler="policy.effective")
    propose = policy_commands.add_parser("propose", help="preview a policy proposal")
    propose.add_argument("--proposal", required=True)
    _write(propose)
    propose.set_defaults(handler="policy.propose")
    policy_list = policy_commands.add_parser("list", help="list policy proposals or rules")
    policy_list.add_argument("--status", choices=("open", "active", "closed"))
    _output(policy_list)
    policy_list.set_defaults(handler="policy.list")
    plan = policy_commands.add_parser("plan", help="preview pending or approved exact policy propagation")
    plan.add_argument("proposal_id")
    _output(plan)
    plan.set_defaults(handler="policy.plan")
    approve = policy_commands.add_parser("approve", help="record a real user decision for an exact preview digest")
    approve.add_argument("proposal_id")
    approve.add_argument("--expect-digest", required=True, type=_digest)
    approve.add_argument("--actor", required=True)
    approve.add_argument("--decided-at", required=True)
    _write(approve)
    approve.set_defaults(handler="policy.approve")
    apply = policy_commands.add_parser("apply", help="preview digest-bound policy application")
    apply.add_argument("proposal_id")
    apply.add_argument("--expect-digest", required=True, type=_digest)
    _write(apply)
    apply.set_defaults(handler="policy.apply")
    check = policy_commands.add_parser("check", help="check policy projection drift")
    _output(check)
    check.set_defaults(handler="policy.check")

    sync = root.add_parser("sync", help="plan external synchronization only")
    sync_commands = sync.add_subparsers(dest="sync_command", required=True)
    sync_plan = sync_commands.add_parser("plan", help="print a no-execution sync boundary")
    _output(sync_plan)
    sync_plan.set_defaults(handler="sync.plan")
    return parser


__all__ = ["DEFAULT_WORKSPACE", "build_parser"]
