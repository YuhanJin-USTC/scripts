"""Validate and create UTC timestamps."""

from __future__ import annotations

import datetime as dt
import re

from .errors import ValidationError


_UTC_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
_MONTH_RE = re.compile(r"^\d{4}-\d{2}$")


def parse_utc(value: object, label: str = "timestamp") -> dt.datetime:
    """Parse a UTC second timestamp and reject normalized-date drift."""

    if not isinstance(value, str) or not _UTC_RE.fullmatch(value):
        raise ValidationError(f"{label} must use YYYY-MM-DDTHH:MM:SSZ")
    try:
        return dt.datetime.strptime(value, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=dt.timezone.utc)
    except ValueError as exc:
        raise ValidationError(f"invalid {label}: {value}") from exc


def validate_utc(value: object, label: str = "timestamp") -> str:
    """Return a valid UTC second timestamp unchanged."""

    parse_utc(value, label)
    return str(value)


def utc_now() -> str:
    """Return the current UTC time at second precision."""

    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).strftime("%Y-%m-%dT%H:%M:%SZ")


def recorded_month(value: object) -> str:
    """Return the YYYY-MM stream partition for a UTC timestamp."""

    return validate_utc(value, "recorded_at")[:7]


def validate_month(value: object) -> str:
    """Validate a monthly stream partition identity."""

    if not isinstance(value, str) or not _MONTH_RE.fullmatch(value):
        raise ValidationError("month must use YYYY-MM")
    try:
        dt.datetime.strptime(value, "%Y-%m")
    except ValueError as exc:
        raise ValidationError(f"invalid month: {value}") from exc
    return value

