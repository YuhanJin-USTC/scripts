"""Expose stable core primitives."""

from .canonical import (
    canonical_digest,
    canonical_json_bytes,
    canonical_json_text,
    decode_json,
    require_fields,
    require_object,
    require_string,
    validate_json_value,
)
from .errors import (
    AccessError,
    ConflictError,
    DeviceIdentityError,
    ResearchWorkflowError,
    UnsupportedOperationError,
    ValidationError,
)
from .ids import (
    join_logical,
    validate_device_id,
    validate_digest,
    validate_event_id,
    validate_logical_id,
    validate_sim_id,
)
from .models import ValidationReport, WriteResult
from .time import parse_utc, recorded_month, utc_now, validate_month, validate_utc

FRAMEWORK_VERSION = "0"
SCHEMA_VERSION = 1

__all__ = [
    "AccessError",
    "ConflictError",
    "DeviceIdentityError",
    "FRAMEWORK_VERSION",
    "ResearchWorkflowError",
    "SCHEMA_VERSION",
    "UnsupportedOperationError",
    "ValidationError",
    "ValidationReport",
    "WriteResult",
    "canonical_digest",
    "canonical_json_bytes",
    "canonical_json_text",
    "decode_json",
    "join_logical",
    "parse_utc",
    "recorded_month",
    "require_fields",
    "require_object",
    "require_string",
    "utc_now",
    "validate_device_id",
    "validate_digest",
    "validate_event_id",
    "validate_json_value",
    "validate_logical_id",
    "validate_month",
    "validate_sim_id",
    "validate_utc",
]
