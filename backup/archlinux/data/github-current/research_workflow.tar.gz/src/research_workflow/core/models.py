"""Provide typed shared result models."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True, slots=True)
class WriteResult:
    """Describe a previewed or completed filesystem mutation."""

    action: str
    path: Path
    digest: str
    bytes_count: int
    written: bool = False
    detail: str = ""

    def to_dict(self) -> dict[str, object]:
        """Return a portable CLI representation without changing state."""

        result: dict[str, object] = {
            "action": self.action,
            "path": str(self.path),
            "digest": self.digest,
            "bytes": self.bytes_count,
            "written": self.written,
        }
        if self.detail:
            result["detail"] = self.detail
        return result


@dataclass(frozen=True, slots=True)
class ValidationReport:
    """Collect deterministic structure checks without scientific inference."""

    valid: bool
    checked: int
    errors: tuple[str, ...] = field(default_factory=tuple)
    details: dict[str, object] = field(default_factory=dict)

    def to_dict(self) -> dict[str, object]:
        """Return a portable validation summary without side effects."""

        return {
            "valid": self.valid,
            "checked": self.checked,
            "errors": list(self.errors),
            "details": dict(self.details),
        }

