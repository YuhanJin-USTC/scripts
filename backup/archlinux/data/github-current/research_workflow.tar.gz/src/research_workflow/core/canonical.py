"""Encode and validate canonical metadata JSON."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping

from .errors import ValidationError


def _unique_object(pairs: list[tuple[str, object]]) -> dict[str, object]:
    result: dict[str, object] = {}
    for key, value in pairs:
        if key in result:
            raise ValidationError(f"duplicate JSON key: {key}")
        result[key] = value
    return result


def validate_json_value(value: object, label: str = "value") -> None:
    """Validate the integer-only, null-free metadata value subset."""

    if value is None or isinstance(value, float):
        raise ValidationError(f"{label} contains a forbidden null or floating-point value")
    if isinstance(value, (str, bool, int)):
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            validate_json_value(item, f"{label}[{index}]")
        return
    if isinstance(value, Mapping):
        for key, item in value.items():
            if not isinstance(key, str):
                raise ValidationError(f"{label} contains a non-string object key")
            validate_json_value(item, f"{label}.{key}")
        return
    raise ValidationError(f"{label} contains unsupported type: {type(value).__name__}")


def canonical_json_bytes(value: object) -> bytes:
    """Return deterministic UTF-8 JSON without a trailing newline."""

    validate_json_value(value)
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def canonical_json_text(value: object) -> str:
    """Return deterministic JSON with one trailing newline."""

    return canonical_json_bytes(value).decode("utf-8") + "\n"


def canonical_digest(value: object) -> str:
    """Return the lowercase SHA-256 digest of canonical JSON bytes."""

    return hashlib.sha256(canonical_json_bytes(value)).hexdigest()


def decode_json(data: bytes | str, *, require_canonical: bool = False) -> object:
    """Decode UTF-8 JSON, rejecting duplicate keys and optional byte drift."""

    try:
        raw = data.encode("utf-8") if isinstance(data, str) else data
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object)
    except (UnicodeDecodeError, json.JSONDecodeError, ValidationError) as exc:
        raise ValidationError(f"invalid JSON: {exc}") from exc
    validate_json_value(value)
    if require_canonical and raw != canonical_json_bytes(value):
        raise ValidationError("JSON is not canonical")
    return value


def require_object(value: object, label: str) -> dict[str, object]:
    """Return an object value or raise a labeled validation failure."""

    if not isinstance(value, dict):
        raise ValidationError(f"{label} must be an object")
    return value


def require_fields(
    value: Mapping[str, object],
    required: set[str],
    label: str,
    optional: set[str] | None = None,
) -> None:
    """Require an exact set of object fields with named optional fields."""

    allowed = required | (optional or set())
    missing = sorted(required - set(value))
    extra = sorted(set(value) - allowed)
    if missing:
        raise ValidationError(f"{label} missing fields: {', '.join(missing)}")
    if extra:
        raise ValidationError(f"{label} has unsupported fields: {', '.join(extra)}")


def require_string(value: object, label: str, *, compact: bool = True) -> str:
    """Return a non-empty string and optionally reject line breaks."""

    if not isinstance(value, str) or not value.strip():
        raise ValidationError(f"{label} must be a non-empty string")
    if compact and ("\n" in value or "\r" in value):
        raise ValidationError(f"{label} must be a compact string")
    return value

