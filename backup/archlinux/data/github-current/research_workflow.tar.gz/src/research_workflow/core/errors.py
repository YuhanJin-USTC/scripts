"""Define expected Research Workflow failures."""


class ResearchWorkflowError(Exception):
    """Base class for expected workflow failures."""


class ValidationError(ResearchWorkflowError):
    """Report invalid input or metadata."""


class ConflictError(ResearchWorkflowError):
    """Report an immutable identity or optimistic-write conflict."""


class AccessError(ResearchWorkflowError):
    """Report a registered-root access-policy violation."""


class DeviceIdentityError(ResearchWorkflowError):
    """Report a missing or mismatched current device identity."""


class UnsupportedOperationError(ResearchWorkflowError):
    """Report behavior reserved for a later service implementation."""

