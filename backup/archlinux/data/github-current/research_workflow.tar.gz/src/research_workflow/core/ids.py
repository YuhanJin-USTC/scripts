"""Validate portable workflow identifiers."""

from __future__ import annotations

import re
from pathlib import PurePosixPath

from .errors import ValidationError


_DEVICE_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,31}$")
_LOGICAL_PART_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]*$")
_EVENT_RE = re.compile(r"^\d{8}T\d{6}Z-[a-z0-9][a-z0-9-]{0,31}(?:-[a-z0-9][a-z0-9-]*)?$")
_DIGEST_RE = re.compile(r"^[0-9a-f]{64}$")


def validate_logical_id(value: object, label: str = "logical id") -> str:
    """Validate a slash-separated Git-portable logical identity."""

    if not isinstance(value, str) or not value or value.startswith(("/", "\\")) or "\\" in value:
        raise ValidationError(f"{label} must be a relative POSIX identity")
    parts = value.split("/")
    if any(not _LOGICAL_PART_RE.fullmatch(part) for part in parts):
        raise ValidationError(f"{label} has invalid components: {value!r}")
    return value


def validate_sim_id(value: object) -> str:
    """Validate the canonical simulation-relative POSIX identity."""

    return validate_logical_id(value, "sim_id")


def validate_device_id(value: object) -> str:
    """Validate a compact portable device identity."""

    if not isinstance(value, str) or not _DEVICE_RE.fullmatch(value):
        raise ValidationError("device_id must match [a-z0-9][a-z0-9-]{0,31}")
    return value


def validate_event_id(value: object) -> str:
    """Validate a UTC- and device-shaped event identity."""

    if not isinstance(value, str) or not _EVENT_RE.fullmatch(value):
        raise ValidationError("event_id must use YYYYMMDDTHHMMSSZ-device[-slug]")
    return value


def validate_digest(value: object, label: str = "digest") -> str:
    """Validate a lowercase unprefixed SHA-256 digest."""

    if not isinstance(value, str) or not _DIGEST_RE.fullmatch(value):
        raise ValidationError(f"{label} must be a lowercase SHA-256 digest")
    return value


def join_logical(*parts: str) -> str:
    """Join validated logical identity components with POSIX separators."""

    value = PurePosixPath(*parts).as_posix()
    return validate_logical_id(value)

