"""Run the package CLI through python -m research_workflow."""

from .cli.main import main


if __name__ == "__main__":
    raise SystemExit(main())
