"""Select portable work memory without requiring local scientific files."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from research_workflow.core.errors import ValidationError
from research_workflow.core.ids import validate_logical_id, validate_sim_id
from research_workflow.index import QueryIndex
from research_workflow.storage.store import Store
from research_workflow.workspace import LogicalLocator, WorkspaceRegistry, parse_locator


@dataclass(frozen=True, slots=True)
class ReadSelector:
    """Name a memory scope; Project aggregation is not an event owner."""

    kind: str
    identity: str
    path: str | None = None

    @property
    def target(self) -> str:
        suffix = f"/{self.path}" if self.path is not None else ""
        return f"{self.kind}:{self.identity}{suffix}"

    def to_dict(self) -> dict[str, object]:
        if self.kind == "project":
            return {"kind": "project", "project_id": self.identity}
        return LogicalLocator(self.kind, self.identity, self.path).to_dict()

    def mapping_available(self, workspace: WorkspaceRegistry) -> bool:
        if self.kind == "root":
            return self.identity in workspace.roots
        if self.kind == "case":
            return "simulation" in workspace.roots
        return False


def resolve_selector(target: str, workspace: WorkspaceRegistry, store: Store, index: QueryIndex) -> ReadSelector:
    """Resolve logical reads independently from local write authorization."""

    if target.startswith("project:"):
        identity = validate_logical_id(target.split(":", 1)[1], "project_id")
        store.load_project(identity)
        return ReadSelector("project", identity)
    if ":" in target and target.split(":", 1)[0] in {"case", "study", "root"}:
        owner = parse_locator(target)
        if owner.kind == "study":
            store.load_study(*owner.identity.split("#", 1))
        return ReadSelector(owner.kind, owner.identity, owner.path)
    if Path(target).is_absolute() or Path(target).exists():
        resolved = workspace.find_root(target)
        if resolved.sim_id:
            if index.case(store, resolved.sim_id) is None and index.has_case_descendants(store, resolved.sim_id):
                return ReadSelector("root", "simulation", workspace.from_canonical("simulation", resolved.sim_id))
            return ReadSelector("case", resolved.sim_id)
        return ReadSelector("root", resolved.root.root_id, None if resolved.relative == "." else resolved.relative)
    return ReadSelector("case", validate_sim_id(target))


class MemoryQuery:
    """Combine exact owner queries with explicit Case lineage and mappings."""

    def __init__(self, workspace: WorkspaceRegistry, store: Store, index: QueryIndex | None = None):
        self.workspace = workspace
        self.store = store
        self.index = index or QueryIndex(workspace.cache_path)

    def selector(self, target: str) -> ReadSelector:
        return resolve_selector(target, self.workspace, self.store, self.index)

    def case_owners(self, sim_id: str) -> set[tuple[str, str, str]]:
        lineage = self.index.lineage_ids(self.store, sim_id) or {sim_id}
        owners = {("case", identity, "") for identity in lineage}
        for identity in lineage:
            for root_id, root in self.workspace.roots.items():
                if root.mapping in {"canonical", "same-relative-path"}:
                    candidates = {identity, self.workspace.from_canonical(root_id, identity)}
                    for path in candidates:
                        if self.workspace.to_canonical(root_id, path) == identity:
                            owners.add(("root", root_id, path))
        return owners

    def owners(self, selector: ReadSelector) -> set[tuple[str, str, str]]:
        if selector.kind == "case":
            return self.case_owners(selector.identity)
        if selector.kind == "root":
            return {("root", selector.identity, selector.path or "")}
        if selector.kind == "study":
            project_id, study_id = selector.identity.split("#", 1)
            owners = {("study", selector.identity, "")}
        else:
            project_id, study_id = selector.identity, None
            owners = {("study", item, "") for item in self.index.project_study_owners(self.store, project_id)}
        for sim_id in self.index.member_ids(self.store, project_id, study_id):
            owners.update(self.case_owners(sim_id))
        return owners

    def events(
        self, selector: ReadSelector | None = None, *, limit: int = 20,
        since: str | None = None, query: str | None = None, recursive: bool = False,
        details: bool = False,
    ) -> dict[str, object]:
        if recursive and (selector is None or selector.kind != "root"):
            raise ValidationError("--recursive requires a root/path selector")
        result = self.index.list_events(
            self.store, None if selector is None else self.owners(selector),
            limit=limit, since=since, query=query, recursive=recursive,
            details=details,
        )
        if selector is not None:
            result["selector"] = selector.to_dict()
            result["mappingAvailable"] = selector.mapping_available(self.workspace)
        result["recursive"] = recursive
        return result
