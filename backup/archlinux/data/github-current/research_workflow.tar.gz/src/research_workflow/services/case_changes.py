"""Prepare explicit simulation-definition changes for one confirmation gate."""

from research_workflow.core.canonical import canonical_digest
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.core.time import utc_now
from research_workflow.domain.case_records import CaseRecord
from research_workflow.domain.cases import materialize_case
from research_workflow.storage.devices import require_registered_device
from .plans import ConfirmationPlans
from .owners import target_root_ids


REASONS = {"registration", "input-change", "metadata-correction", "lifecycle"}


def change_reason(reason: str, responsibility: str = "simulation-definition") -> None:
    if responsibility != "simulation-definition" or reason not in REASONS:
        raise ValidationError("Case changes require responsibility=simulation-definition and a named reason")


def definition_equal(previous, proposed) -> bool:
    return (previous.sim_id, previous.project_id, previous.study_id, previous.content, previous.profiles) == (proposed.sim_id, proposed.project_id, proposed.study_id, proposed.content, proposed.profiles)


def delta_dependencies(store, delta, project=None, study=None):
    project = project or store.load_project(delta.project_id)
    study = study or store.load_study(delta.project_id, delta.study_id)
    references = project.profiles + study.profiles + delta.profiles
    profiles = {(item.scope, item.profile_id): store.load_profile(item) for item in references}
    materialize_case(project, study, profiles, delta)
    return [store.project_path(delta.project_id), store.study_path(delta.project_id, delta.study_id), *(store.profile_path(item) for item in references)]


class CaseChanges:
    """Normalize Case commands; no command here applies portable writes."""

    def __init__(self, workspace, store):
        self.workspace = workspace
        self.store = store
        self.confirmation = ConfirmationPlans(workspace, store)

    def plan(self, action, delta=None, *, source=None, destination=None, if_match=None, project=None, study=None, input_configs=(), reason=None, responsibility="simulation-definition", record_id=None, recorded_at=None, input_mode="inline", local_targets=()):
        reason = reason or ("registration" if action == "create" else "lifecycle" if action in {"rename", "delete"} else None)
        change_reason(reason, responsibility)
        if action == "revise" and reason not in {"input-change", "metadata-correction"}:
            raise ValidationError("Case revise requires --reason input-change or metadata-correction")
        device = require_registered_device(self.store.root, self.workspace.require_device())
        recorded_at = recorded_at or utc_now()
        source = source or delta.sim_id
        head = self.store.case_head(source)
        if action != "create":
            if head is None or head.state != "active":
                raise ValidationError(f"Case {action} requires an active Case")
            if if_match != head.delta_digest:
                raise ConflictError("expect_digest does not match current Case journal head")
        elif head is not None and (head.state != "active" or not definition_equal(head.delta, delta)):
            raise ConflictError(f"Case identity is already reserved: {source}")
        if action in {"rename", "delete"}:
            delta = head.delta
        for supplied, path, load in (
            (project, self.store.project_path(delta.project_id), lambda: self.store.load_project(delta.project_id)),
            (study, self.store.study_path(delta.project_id, delta.study_id), lambda: self.store.load_study(delta.project_id, delta.study_id)),
        ):
            if supplied is not None and path.exists() and supplied.to_dict() != load().to_dict():
                raise ConflictError("supplied hierarchy differs from current authority")
        dependencies = delta_dependencies(self.store, delta, project, study)
        if head is not None:
            dependencies += delta_dependencies(self.store, head.delta)
        documents = {}
        records = []
        target = destination or source
        unchanged = action in {"create", "revise"} and head is not None and definition_equal(head.delta, delta)
        stamp = recorded_at.replace("-", "").replace(":", "")
        record_id = record_id or f"{stamp}-{device}-{action}-{canonical_digest({'source': source, 'target': target, 'delta': delta.to_dict()})[:12]}"
        if not unchanged:
            common = dict(record_id=record_id, device_id=device, recorded_at=recorded_at)
            if action == "create":
                record = CaseRecord.build_create(delta, **common)
                self.store.bootstrap_case_record(record, current_device=device, project=project, study=study, write=False)
                registry = self.store.load_store()
                if delta.project_id not in registry["projects"]:
                    registry["projects"] = sorted([*registry["projects"], delta.project_id])
                    documents["STORE.json"] = registry
                for supplied, path in ((project, self.store.project_path(delta.project_id)), (study, self.store.study_path(delta.project_id, delta.study_id))):
                    if supplied is not None and not path.exists():
                        documents[path.relative_to(self.store.root).as_posix()] = supplied.to_dict()
            elif action == "revise":
                record = CaseRecord.build_revise(delta, previous_digest=head.delta_digest, **common)
            elif action == "rename":
                record = self.store.plan_journal_case_rename(source, destination, **common).record
            elif action == "delete":
                record = self.store.plan_journal_case_delete(source, **common).record
            else:
                raise ValidationError(f"unsupported Case action: {action}")
            records.append(record.to_dict())
        payload = {
            "confirmation_required": True, "risk": "high", "reason": reason,
            "responsibility": responsibility, "input_mode": input_mode,
            "records": records, "documents": documents,
            "cases": [{"target": target, "source": source, "action": "no-op" if unchanged else action,
                       "before": head.delta.to_dict() if head else {}, "after": (records[0]["delta"] if records else head.delta.to_dict())}],
            "registration": {"sim_id": target, "project_id": delta.project_id, "study_id": delta.study_id, "revision": head.revision if unchanged else delta.revision},
            "revision": head.revision if unchanged else delta.revision,
        }
        return self.confirmation.save(payload, dependencies=dependencies, heads=[source, target], input_configs=input_configs, root_ids=["simulation", *(root_id for target in local_targets for root_id in target_root_ids(target, self.workspace))])

    def preview(self, *args, **kwargs):
        return self.confirmation.apply(self.plan(*args, **kwargs), write=False)
