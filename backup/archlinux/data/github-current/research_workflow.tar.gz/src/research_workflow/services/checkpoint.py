"""Record work events; explicit Case changes use saved confirmation plans."""

from __future__ import annotations

import copy
import re
from dataclasses import dataclass

from research_workflow.core.canonical import canonical_digest, require_fields, require_object, require_string
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.core.ids import validate_digest
from research_workflow.core.time import utc_now, validate_utc
from research_workflow.domain.case_records import CaseRecord
from research_workflow.domain.cases import CaseDelta, build_revised_case_delta
from research_workflow.domain.events import Evidence, Event, StatusUpdate, build_event
from research_workflow.domain.profiles import ProfileReference
from research_workflow.workspace.locators import LogicalLocator
from research_workflow.storage.devices import require_registered_device
from .case_changes import change_reason, definition_equal, delta_dependencies
from .owners import resolve_owner, target_root_ids
from .plans import CheckpointPlanStore, ConfirmationPlans

CHECKPOINT_REQUEST_SCHEMA = "research-workflow/checkpoint-request"


@dataclass(frozen=True, slots=True)
class CheckpointChange:
    target: str
    if_match: str
    content_patch: dict | None
    remove_content_paths: tuple[str, ...]
    profiles: tuple[ProfileReference, ...] | None
    reason: str
    responsibility: str
    input_configs: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class CheckpointRequest:
    request_id: str
    occurred_at: str
    risk: str
    changes: tuple[CheckpointChange, ...]
    event: dict
    default_target: str | None = None

    @classmethod
    def from_dict(cls, value, *, default_target=None):
        item = require_object(value, "checkpoint request")
        require_fields(item, {"schema", "schema_version", "event"}, "checkpoint request", {"request_id", "occurred_at", "risk", "changes"})
        if item["schema"] != CHECKPOINT_REQUEST_SCHEMA or item["schema_version"] != 1:
            raise ValidationError("checkpoint request must use schema version 1")
        risk = item.get("risk", "normal")
        if risk not in {"normal", "high"}:
            raise ValidationError("checkpoint risk must be normal or high")
        raw_changes = item.get("changes", [])
        if not isinstance(raw_changes, list):
            raise ValidationError("checkpoint changes must be an array")
        changes = tuple(_parse_change(value) for value in raw_changes)
        if len({change.target for change in changes}) != len(changes):
            raise ConflictError("checkpoint changes contain duplicate Case targets")
        return cls(
            require_string(item.get("request_id", "automatic"), "request_id"),
            validate_utc(item["occurred_at"], "occurred_at") if "occurred_at" in item else "automatic",
            risk, changes, copy.deepcopy(require_object(item["event"], "checkpoint event")), default_target,
        )


class CheckpointService:
    """Build event-only requests or preview explicit simulation-definition changes."""

    def __init__(self, workspace, store, *, index=None):
        self.workspace = workspace
        self.store = store
        self.confirmation = ConfirmationPlans(workspace, store)
        self.plans = self.confirmation.plans

    def plan(self, request):
        device = require_registered_device(self.store.root, self.workspace.require_device())
        recorded_at = utc_now()
        occurred_at = recorded_at if request.occurred_at == "automatic" else request.occurred_at
        request_id = request.request_id
        if request_id == "automatic":
            request_id = "checkpoint-" + canonical_digest({"recorded_at": recorded_at, "event": request.event, "changes": [change.target for change in request.changes]})[:16]
        records, operations, cases, dependencies, inputs, targets = [], [], [], [], [], []
        for change in request.changes:
            target = self.workspace.resolve_sim_id(change.target)
            if target in targets:
                raise ConflictError("checkpoint changes resolve to duplicate Case targets")
            targets.append(target)
            head = self.store.case_head(target)
            if head is None or head.state != "active":
                raise ValidationError(f"checkpoint target must be an active Case: {target}")
            if change.if_match != head.delta_digest:
                raise ConflictError(f"checkpoint if_match is stale: {target}")
            previous = head.delta
            revised = build_revised_case_delta(previous, revision=previous.revision + 1, content_patch=change.content_patch, remove_content_paths=change.remove_content_paths, profiles=change.profiles)
            dependencies += delta_dependencies(self.store, previous) + delta_dependencies(self.store, revised)
            inputs.extend(change.input_configs)
            unchanged = definition_equal(previous, revised)
            if not unchanged:
                record = CaseRecord.build_revise(revised, previous_digest=head.delta_digest, record_id=_record_id(recorded_at, device, request_id, len(records) + 1), device_id=device, recorded_at=recorded_at)
                records.append(record.to_dict())
            operations.append({"target": target, "after_delta": revised.to_dict()})
            cases.append({"target": target, "action": "no-op" if unchanged else "revise", "reason": change.reason, "responsibility": change.responsibility, "before": previous.to_dict(), "after": previous.to_dict() if unchanged else revised.to_dict()})
        value = copy.deepcopy(request.event)
        if request.default_target is not None:
            owner = resolve_owner(request.default_target, self.workspace, self.store)
            if "owner" in value and resolve_owner(value["owner"], self.workspace, self.store) != owner:
                raise ConflictError("positional checkpoint target conflicts with event owner")
            value["owner"] = owner.to_dict()
        event = self._event(value, operations, device_id=device, request_id=request_id, recorded_at=recorded_at, occurred_at=occurred_at)
        roots = ["simulation"] if targets else []
        for change in request.changes:
            roots.extend(target_root_ids(change.target, self.workspace))
        if request.default_target is not None:
            roots.extend(target_root_ids(request.default_target, self.workspace))
        if event.owner.kind == "root":
            roots.append(event.owner.identity)
        payload = {
            "request_id": request_id, "risk": request.risk,
            "confirmation_required": bool(request.changes) or request.risk == "high",
            "records": records, "cases": cases, "event": event.to_dict(),
        }
        return self.confirmation.save(payload, dependencies=dependencies, heads=targets, input_configs=inputs, root_ids=roots)

    def execute(self, request, *, write=False):
        if write and (request.changes or request.risk == "high"):
            raise ValidationError("Case changes require preview, user confirmation, then case apply --plan DIGEST --write")
        return self.apply(self.plan(request), write=write)

    def apply(self, plan, *, write):
        return self.confirmation.apply(plan, write=write)

    def apply_saved(self, digest, *, write):
        return self.confirmation.apply_saved(digest, write=write)

    def _event(
        self,
        value: dict[str, object],
        operations: list[dict[str, object]],
        *,
        device_id: str,
        request_id: str,
        recorded_at: str,
        occurred_at: str,
    ) -> Event:
        require_fields(
            value,
            {"kind", "summary"},
            "checkpoint event",
            {"owner", "evidence", "status_updates"},
        )
        owner = self._owner(value.get("owner"), operations)
        raw_evidence = value.get("evidence", [])
        if not isinstance(raw_evidence, list):
            raise ValidationError("checkpoint event evidence must be an array")
        evidence: list[Evidence] = []
        for index, raw in enumerate(raw_evidence, start=1):
            item = require_object(raw, "checkpoint evidence")
            require_fields(
                item,
                {"kind", "locator", "observation"},
                "checkpoint evidence",
                {"observed_at"},
            )
            evidence.append(
                Evidence.from_dict(
                    {
                        "id": f"E{index}",
                        "kind": item["kind"],
                        "locator": LogicalLocator.from_dict(item["locator"], self.workspace).to_dict(),
                        "observation": item["observation"],
                        "observed_at": item.get("observed_at", occurred_at),
                    }
                )
            )
        raw_updates = value.get("status_updates", [])
        if not isinstance(raw_updates, list):
            raise ValidationError("checkpoint status_updates must be an array")
        if raw_updates and owner.kind != "case":
            raise ValidationError("Study/root checkpoint events cannot broadcast Case status")
        evidence_ids = [item.evidence_id for item in evidence]
        updates: list[StatusUpdate] = []
        for raw in raw_updates:
            item = require_object(raw, "checkpoint status update")
            require_fields(item, {"track", "state"}, "checkpoint status update", {"evidence_ids"})
            ids = item.get("evidence_ids", evidence_ids if item["state"] != "unknown" else [])
            updates.append(
                StatusUpdate.from_dict(
                    {"track": item["track"], "state": item["state"], "evidence_ids": ids}
                )
            )
        kind = require_string(value["kind"], "checkpoint event.kind")
        if kind == "correction":
            raise ValidationError("checkpoint does not construct correction events")
        return build_event(
            event_id=_event_id(recorded_at, device_id, request_id),
            device_id=device_id,
            recorded_at=recorded_at,
            occurred_at=occurred_at,
            owner=owner,
            kind=kind,
            summary=require_string(value["summary"], "checkpoint event.summary"),
            evidence=tuple(evidence),
            status_updates=tuple(updates),
        )

    def _owner(self, raw, operations):
        if raw is None:
            if len(operations) != 1:
                raise ValidationError("checkpoint requires an explicit owner or positional target")
            raw = {"kind": "case", "sim_id": operations[0]["target"]}
        owner = resolve_owner(raw, self.workspace, self.store)
        if owner.kind == "case" and operations:
            if len(operations) != 1 or owner.identity != operations[0]["target"]:
                raise ValidationError("Case checkpoint owner must match the single Case change")
        if owner.kind == "study":
            for operation in operations:
                delta = CaseDelta.from_dict(operation["after_delta"])
                if owner.identity != f"{delta.project_id}#{delta.study_id}":
                    raise ValidationError("Study checkpoint owner must contain every changed Case")
        return owner

def _parse_change(value: object) -> CheckpointChange:
    item = require_object(value, "checkpoint change")
    require_fields(
        item,
        {"target"},
        "checkpoint change",
        {"if_match", "content_patch", "remove_content_paths", "profiles", "reason", "responsibility", "input_configs"},
    )
    patch = item.get("content_patch")
    if patch is not None:
        patch = copy.deepcopy(require_object(patch, "checkpoint content_patch"))
    raw_removals = item.get("remove_content_paths", [])
    if not isinstance(raw_removals, list) or any(not isinstance(path, str) for path in raw_removals):
        raise ValidationError("checkpoint remove_content_paths must be an array of strings")
    raw_profiles = item.get("profiles")
    profiles = None
    if raw_profiles is not None:
        if not isinstance(raw_profiles, list):
            raise ValidationError("checkpoint profiles must be an array")
        profiles = tuple(ProfileReference.from_dict(profile) for profile in raw_profiles)
    if patch is None and not raw_removals and profiles is None:
        raise ValidationError("checkpoint change requires a patch, removal, or profiles replacement")
    if "if_match" not in item:
        raise ValidationError("checkpoint Case change requires explicit if_match")
    if_match = item["if_match"]
    if if_match == "not-specified":
        raise ValidationError("checkpoint if_match cannot be not-specified")
    if_match = validate_digest(if_match, "checkpoint if_match")
    reason = item.get("reason")
    responsibility = item.get("responsibility")
    change_reason(reason, responsibility)
    if reason not in {"input-change", "metadata-correction"}:
        raise ValidationError("checkpoint Case change reason must be input-change or metadata-correction")
    inputs = item.get("input_configs", [])
    if not isinstance(inputs, list) or any(not isinstance(value, str) for value in inputs):
        raise ValidationError("input_configs must be an array of explicit configuration selections")
    return CheckpointChange(
        reason=reason,
        responsibility=responsibility,
        input_configs=tuple(inputs),
        target=require_string(item["target"], "checkpoint target"),
        if_match=if_match,
        content_patch=patch,
        remove_content_paths=tuple(raw_removals),
        profiles=profiles,
    )



def _slug(value: str) -> str:
    selected = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return selected[:24] or "checkpoint"


def _event_id(recorded_at: str, device_id: str, request_id: str) -> str:
    prefix = recorded_at.replace("-", "").replace(":", "")
    return f"{prefix}-{device_id}-{_slug(request_id)}-{canonical_digest(request_id)[:8]}"


def _record_id(recorded_at: str, device_id: str, request_id: str, index: int) -> str:
    return _event_id(recorded_at, device_id, request_id) + f"-case-{index:03d}"


