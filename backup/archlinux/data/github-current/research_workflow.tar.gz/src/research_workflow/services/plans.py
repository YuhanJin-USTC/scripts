"""Save and atomically apply device-local confirmation plans."""

from __future__ import annotations

import codecs
import copy
from hashlib import sha256
from pathlib import Path

from research_workflow.core.canonical import canonical_digest, canonical_json_bytes
from research_workflow.core.errors import ConflictError, DeviceIdentityError, ValidationError
from research_workflow.core.ids import validate_digest
from research_workflow.domain.case_records import CaseRecord, reduce_case_records
from research_workflow.domain.events import Event
from research_workflow.storage import atomic_json_write, atomic_multi_write, case_journal_path, event_stream_path, read_json
from research_workflow.storage.devices import require_registered_device
from research_workflow.storage.locking import authority_lock
from research_workflow.storage.store import Store
from research_workflow.workspace import WorkspaceRegistry, parse_locator


def plan_digest(plan: dict) -> str:
    return canonical_digest({key: value for key, value in plan.items() if key != "plan_digest"})


def file_binding(path: Path) -> dict:
    for candidate in (path, *path.parents):
        if candidate.is_symlink():
            raise ConflictError(f"refusing symlinked plan dependency: {path}")
    if not path.exists():
        return {"exists": False}
    if not path.is_file():
        raise ValidationError(f"plan dependency is not a regular file: {path}")
    digest = sha256()
    size = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(65536), b""):
            digest.update(chunk)
            size += len(chunk)
    return {"exists": True, "sha256": digest.hexdigest(), "bytes": size}


def input_binding(selection: str, workspace: WorkspaceRegistry) -> tuple[Path, str, dict]:
    """Hash only explicitly selected UTF-8 configuration; never follow includes."""

    if selection.startswith(("root:", "case:")):
        path = parse_locator(selection, workspace).resolve_local(workspace, write=True)
    else:
        path = Path(selection)
        if not path.is_absolute():
            raise ValidationError("input-config requires an absolute path or root:/case: locator")
    resolved = workspace.find_root(path)
    workspace.authorize(resolved.root.root_id, write=True)
    for candidate in (path, *path.parents):
        if candidate.is_symlink():
            raise ConflictError(f"refusing symlinked input configuration: {path}")
    if not path.is_file():
        raise ValidationError(f"selected input configuration is missing: {selection}")
    before_stat = path.stat()
    decoder = codecs.getincrementaldecoder("utf-8")()
    digest = sha256()
    size = 0
    try:
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(65536), b""):
                text = decoder.decode(chunk)
                if "\x00" in text:
                    raise ValidationError("input-config must be configuration text, not binary/raw output")
                digest.update(chunk)
                size += len(chunk)
            decoder.decode(b"", final=True)
    except UnicodeDecodeError as exc:
        raise ValidationError("input-config must be UTF-8 configuration text") from exc
    after_stat = path.stat()
    if (before_stat.st_dev, before_stat.st_ino, before_stat.st_size, before_stat.st_mtime_ns, before_stat.st_ctime_ns) != (after_stat.st_dev, after_stat.st_ino, after_stat.st_size, after_stat.st_mtime_ns, after_stat.st_ctime_ns):
        raise ConflictError("input configuration changed while preparing preview")
    return path, resolved.root.root_id, {"exists": True, "sha256": digest.hexdigest(), "bytes": size}


class CheckpointPlanStore:
    """Keep previews and successful apply receipts in ignored local state."""

    def __init__(self, workspace: WorkspaceRegistry):
        self.root = workspace.project_root / ".research-workflow" / "plans"

    def save(self, plan: dict) -> Path:
        path = self.root / f"{plan['plan_digest']}.json"
        atomic_json_write(path, plan, write=True, create_only=True)
        return path

    def load(self, digest: str) -> dict:
        validate_digest(digest, "plan digest")
        plan = read_json(self.root / f"{digest}.json")
        if plan_digest(plan) != digest or plan.get("plan_digest") != digest:
            raise ConflictError("confirmation plan digest mismatch")
        return plan

    def receipt(self, digest: str) -> Path:
        validate_digest(digest, "plan digest")
        return self.root / f"{digest}.applied.json"


class ConfirmationPlans:
    """One expected-state transaction gate for Case and checkpoint writers."""

    def __init__(self, workspace: WorkspaceRegistry, store: Store):
        self.workspace = workspace
        self.store = store
        self.plans = CheckpointPlanStore(workspace)

    def _workspace_binding(self, root_ids: list[str], workspace: WorkspaceRegistry) -> dict:
        return {
            "workspace_id": workspace.workspace_id,
            "config_path": str(workspace.config_path),
            "metadata_root": str(self.store.root),
            "device_id": workspace.require_device(),
            "roots": {root_id: workspace.data["roots"].get(root_id, {}) for root_id in sorted(set(root_ids))},
            "aliases": [entry for entry in workspace.aliases if entry["root"] in root_ids],
        }

    def save(self, payload: dict, *, dependencies: list[Path], heads: list[str], input_configs=(), root_ids=()) -> dict:
        device = require_registered_device(self.store.root, self.workspace.require_device())
        payload = copy.deepcopy(payload)
        records = [CaseRecord.from_dict(item) for item in payload.get("records", [])]
        existing = self.store.read_case_records() if heads or records else []
        reduced = reduce_case_records(existing)
        reduce_case_records((*existing, *records))
        payload["heads"] = {
            target: ({"state": reduced[target].state, "digest": reduced[target].delta_digest} if target in reduced else {"state": "missing"})
            for target in sorted(set(heads))
        }
        paths = set(dependencies) | {self.store.store_path, self.store.device_path(device)}
        for record in records:
            paths.add(case_journal_path(self.store.root, record.project_id, record.study_id, device, record.recorded_at[:7]))
        selected_roots = set(root_ids)
        payload["inputs"] = {}
        for selection in input_configs:
            path, root_id, binding = input_binding(selection, self.workspace)
            payload["inputs"][str(path)] = {"selection": selection, **binding}
            selected_roots.add(root_id)
        payload["dependencies"] = {str(path): file_binding(path) for path in sorted(paths)}
        payload["root_ids"] = sorted(selected_roots)
        payload["workspace"] = self._workspace_binding(payload["root_ids"], self.workspace)
        payload["device_id"] = device
        payload["schema"] = "research-workflow/confirmation-plan"
        payload["schema_version"] = 1
        payload["plan_digest"] = plan_digest(payload)
        self.plans.save(payload)
        return payload

    def apply_saved(self, digest: str, *, write: bool) -> dict:
        return self.apply(self.plans.load(digest), write=write)

    def apply(self, plan: dict, *, write: bool) -> dict:
        with authority_lock(self.store.root):
            return self._apply(plan, write=write)

    def _apply(self, plan: dict, *, write: bool) -> dict:
        digest = str(plan["plan_digest"])
        if plan_digest(plan) != digest:
            raise ConflictError("plan bytes differ from the saved preview")
        workspace = WorkspaceRegistry(self.workspace.config_path)
        device = require_registered_device(self.store.root, workspace.require_device())
        if device != plan["device_id"]:
            raise DeviceIdentityError("confirmation plan device_id differs from the current device")
        if self._workspace_binding(plan["root_ids"], workspace) != plan["workspace"]:
            raise ConflictError("confirmation plan local mappings or workspace changed")
        if self.plans.load(digest) != plan:
            raise ConflictError("plan bytes differ from the saved preview")
        records = [CaseRecord.from_dict(item) for item in plan.get("records", [])]
        event = Event.from_dict(plan["event"]) if "event" in plan else None
        if any(record.device_id != device for record in records) or (event and event.device_id != device):
            raise DeviceIdentityError("planned stream differs from current device")
        existing = self.store.read_case_records() if plan["heads"] or records else []
        heads = reduce_case_records(existing)
        by_id = {record.record_id: record.to_dict() for record in existing}
        events = {item.event_id: item.to_dict() for item in self.store.read_events()} if event else {}
        present = []
        for record in records:
            value = by_id.get(record.record_id)
            if value is not None and value != record.to_dict():
                raise ConflictError("conflicting planned Case record ID")
            present.append(value is not None)
        if event:
            value = events.get(event.event_id)
            if value is not None and value != event.to_dict():
                raise ConflictError("conflicting duplicate event ID")
            present.append(value is not None)
        receipt_path = self.plans.receipt(digest)
        receipt = {"schema": "research-workflow/apply-receipt", "schema_version": 1, "plan_digest": digest, "device_id": device}
        if receipt_path.exists():
            if read_json(receipt_path) != receipt or not all(present):
                raise ConflictError("completed confirmation plan is partially present or conflicts")
            if plan.get("documents"):
                for relative in plan["documents"]:
                    read_json(self.store.root / relative)
                report = self.store.validate()
                if not report.valid:
                    raise ConflictError("completed bootstrap plan has missing or invalid authority: " + "; ".join(report.errors))
            return self._result(plan, [], "already-applied", write)
        if any(present):
            raise ConflictError("partial application or missing local receipt; refusing automatic resume")
        for target, before in plan["heads"].items():
            head = heads.get(target)
            current = {"state": head.state, "digest": head.delta_digest} if head else {"state": "missing"}
            if current != before:
                raise ConflictError(f"Case head changed after preview: {target}")
        for value, before in plan["dependencies"].items():
            if file_binding(Path(value)) != before:
                raise ConflictError(f"plan dependency bytes changed after preview: {value}")
        for value, before in plan["inputs"].items():
            path, _, current = input_binding(before["selection"], workspace)
            if str(path) != value or current != {key: item for key, item in before.items() if key != "selection"}:
                raise ConflictError(f"input configuration changed after preview: {value}")
        if event:
            from .owners import resolve_owner
            resolve_owner(event.owner.to_dict(), workspace, self.store)
        reduce_case_records((*existing, *records))
        def expected_bytes(path):
            before = self.store._safe_raw_bytes(path)
            binding = {"exists": False} if before is None else {"exists": True, "sha256": sha256(before).hexdigest(), "bytes": len(before)}
            if str(path) in plan["dependencies"] and binding != plan["dependencies"][str(path)]:
                raise ConflictError(f"plan dependency changed while preparing transaction: {path}")
            return before
        changes = {self.store.root / key: canonical_json_bytes(value) + b"\n" for key, value in plan.get("documents", {}).items()}
        expected = {path: expected_bytes(path) for path in changes}
        for record in records:
            path = case_journal_path(self.store.root, record.project_id, record.study_id, device, record.recorded_at[:7])
            if path not in changes:
                expected[path] = expected_bytes(path)
                changes[path] = expected[path] or b""
            changes[path] += canonical_json_bytes(record.to_dict()) + b"\n"
        if event:
            path = event_stream_path(self.store.root, device, event.recorded_at[:7])
            expected[path] = expected_bytes(path)
            changes[path] = (expected[path] or b"") + canonical_json_bytes(event.to_dict()) + b"\n"
        if write:
            expected[receipt_path] = None
            changes[receipt_path] = canonical_json_bytes(receipt) + b"\n"
        def validate():
            current_workspace = WorkspaceRegistry(self.workspace.config_path)
            if self._workspace_binding(plan["root_ids"], current_workspace) != plan["workspace"]:
                raise ConflictError("workspace changed during apply")
            for value, before in plan["dependencies"].items():
                if Path(value) not in changes and file_binding(Path(value)) != before:
                    raise ConflictError(f"plan dependency changed during apply: {value}")
            for value, before in plan["inputs"].items():
                if file_binding(Path(value)) != {key: item for key, item in before.items() if key != "selection"}:
                    raise ConflictError(f"input changed during apply: {value}")
            if records or plan.get("documents"):
                report = self.store.validate()
                if not report.valid:
                    raise ValidationError("post-apply validation failed: " + "; ".join(report.errors))
            if event and not any(item.to_dict() == event.to_dict() for item in self.store.read_events()):
                raise ConflictError("post-apply event mismatch")
        results = atomic_multi_write(changes, expected=expected, write=write, post_apply_validator=validate if write else None, completion_paths=(receipt_path,) if write else ())
        return self._result(plan, [result.to_dict() for result in results if result.path != receipt_path], "applied" if write else "pending", write)

    @staticmethod
    def _result(plan: dict, operations: list, status: str, write: bool) -> dict:
        return {
            "mode": "write" if write else "preview", "status": status,
            "plan_digest": plan["plan_digest"], "confirmation_required": plan["confirmation_required"],
            "confirmation": "Ask the user and wait before case apply; the digest cannot prove user consent." if plan["confirmation_required"] else "event-only",
            "cases": plan.get("cases", []), "operations": operations,
            **{key: plan[key] for key in ("event", "request_id", "risk", "registration", "revision", "input_mode", "reason", "responsibility") if key in plan},
        }
