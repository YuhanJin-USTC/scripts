"""Preview and explicitly activate the thin Store capability contract."""

from hashlib import sha256

from research_workflow.core.canonical import canonical_digest, canonical_json_bytes
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.storage.compatibility import TARGET_CAPABILITY, require_compatible
from research_workflow.storage.devices import require_registered_device
from research_workflow.storage.jsonio import atomic_multi_write
from research_workflow.storage.locking import authority_lock


class StoreUpgradeService:
    def __init__(self, workspace, store):
        self.workspace = workspace
        self.store = store

    def preview(self) -> tuple[dict, bytes, bytes]:
        device = require_registered_device(self.store.root, self.workspace.require_device())
        document = self.store.load_store()
        require_compatible(document)
        report = self.store.validate()
        if not report.valid:
            raise ValidationError("Store upgrade requires valid metadata: " + "; ".join(report.errors))
        from .validation import policy_authority_report
        policy = policy_authority_report(self.workspace, document)
        if not policy["valid"]:
            raise ValidationError("Store upgrade requires valid policy authority: " + "; ".join(policy["errors"]))
        before = self.store.store_path.read_bytes()
        if before != canonical_json_bytes(document) + b"\n":
            raise ConflictError("Store changed while preparing upgrade")
        candidate = {**document, "schema_version": 3, "required_capabilities": [TARGET_CAPABILITY]}
        after = canonical_json_bytes(candidate) + b"\n"
        import difflib
        plan = {
            "schema": "research-workflow/store-upgrade-plan", "schema_version": 1,
            "device_id": device, "workspace": str(self.workspace.config_path),
            "path": str(self.store.store_path), "before_digest": sha256(before).hexdigest(),
            "after_digest": sha256(after).hexdigest(), "before": document, "after": candidate,
            "diff": "".join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile="STORE.json:before", tofile="STORE.json:after")),
        }
        plan["digest"] = canonical_digest(plan)
        return plan, before, after

    def execute(self, *, expect_digest=None, write=False) -> dict:
        if not write:
            plan, before, after = self.preview()
            return {"mode": "preview", "action": "already-current" if before == after else "upgrade", "written": False, "plan": plan}
        if not expect_digest:
            raise ValidationError("store upgrade --write requires --expect-digest after real user confirmation")
        with authority_lock(self.store.root):
            plan, before, after = self.preview()
            if before == after:
                return {"mode": "write", "action": "already-current", "written": False, "plan": plan}
            if expect_digest != plan["digest"]:
                raise ConflictError("Store upgrade digest is stale")

            def validate():
                require_compatible(self.store.load_store(), target_lifecycle=True)
                report = self.store.validate()
                if not report.valid:
                    raise ValidationError("upgraded Store failed validation")

            operations = atomic_multi_write({self.store.store_path: after}, expected={self.store.store_path: before}, write=True, post_apply_validator=validate)
            return {"mode": "write", "action": "upgrade", "written": True, "plan": plan, "operations": [item.to_dict() for item in operations]}
