"""Resolve exact work owners without inventing research membership."""

from pathlib import Path

from research_workflow.core.errors import ValidationError
from research_workflow.storage.store import Store
from research_workflow.workspace import LogicalLocator, WorkspaceRegistry, parse_locator


def resolve_owner(target: str | dict, workspace: WorkspaceRegistry, store: Store) -> LogicalLocator:
    """Resolve a new event owner with local access and authority checks."""

    if isinstance(target, dict):
        owner = LogicalLocator.from_dict(target, workspace)
    elif target.split(":", 1)[0] in {"case", "study", "root"} and ":" in target:
        owner = parse_locator(target, workspace)
    elif Path(target).is_absolute() or Path(target).exists():
        resolved = workspace.find_root(target)
        workspace.authorize(resolved.root.root_id, write=True)
        if resolved.sim_id and store.case_state(resolved.sim_id)["state"] != "missing":
            owner = LogicalLocator("case", resolved.sim_id)
        elif resolved.sim_id:
            owner = LogicalLocator("root", "simulation", workspace.from_canonical("simulation", resolved.sim_id))
        else:
            owner = LogicalLocator("root", resolved.root.root_id, None if resolved.relative == "." else resolved.relative)
    else:
        sim_id = workspace.resolve_sim_id(target)
        owner = LogicalLocator("case", sim_id) if store.case_state(sim_id)["state"] != "missing" else LogicalLocator("root", "simulation", workspace.from_canonical("simulation", sim_id))
    if owner.kind == "case":
        if owner.path is not None:
            raise ValidationError("Case event owner cannot name a file path")
        state = store.case_state(owner.identity)["state"]
        if state != "active":
            raise ValidationError(f"Case event owner must be active, found {state}: {owner.identity}")
    elif owner.kind == "study":
        store.load_study(*owner.identity.split("#", 1))
    elif owner.kind == "root":
        path = owner.resolve_local(workspace, write=True)
        if owner.identity != "research_workflow":
            resolved = workspace.find_root(path)
            if resolved.root.root_id != owner.identity:
                raise ValidationError("root owner must use the longest registered root")
        if not path.is_dir():
            raise ValidationError(f"new root event requires an existing exact directory: {path}")
    else:
        raise ValidationError("event owner must be Case, Study, or root")
    return owner


def target_root_ids(target: str, workspace: WorkspaceRegistry) -> list[str]:
    """Retain every local mapping used by a write target."""

    if target.startswith("root:"):
        return [parse_locator(target, workspace).identity]
    if Path(target).is_absolute() or Path(target).exists():
        resolved = workspace.find_root(target)
        workspace.authorize(resolved.root.root_id, write=True)
        return [resolved.root.root_id]
    return ["simulation"] if not target.startswith("study:") else []
