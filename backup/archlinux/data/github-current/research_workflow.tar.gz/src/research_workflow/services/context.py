"""Build targeted compact and deep research context."""

from __future__ import annotations

import copy
import re
from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from research_workflow.core.canonical import canonical_json_bytes
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.domain.cases import CaseDelta, materialize_case
from research_workflow.index import CaseIndexRow, QueryIndex
from research_workflow.storage.store import Store
from research_workflow.services.queries import MemoryQuery, ReadSelector
from research_workflow.workspace.locators import LogicalLocator
from research_workflow.workspace.registry import WorkspaceRegistry


CONTEXT_VIEW_LIMITS = {"compact": 4 * 1024, "deep": 24 * 1024}
CONTEXT_INCLUDES = {"spec", "event-details", "study-members", "knowledge-links", "status"}


@runtime_checkable
class LinkProvider(Protocol):
    """Resolve one explicitly requested knowledge link."""

    def collect(self, link_id: str, sim_id: str) -> dict[str, object]:
        """Return one bounded portable fragment."""


@dataclass(frozen=True, slots=True)
class ContextOptions:
    """Select an intentional context view."""

    view: str = "compact"
    recent: int = 3
    select: tuple[str, ...] = ()
    include: tuple[str, ...] = ()
    include_links: tuple[str, ...] = ()
    recursive: bool = False

    def __post_init__(self) -> None:
        if self.view not in CONTEXT_VIEW_LIMITS:
            raise ValidationError(f"unsupported context view: {self.view}")
        if not isinstance(self.recent, int) or isinstance(self.recent, bool) or not 0 <= self.recent <= 100:
            raise ValidationError("context recent must be between 0 and 100")
        invalid = sorted(set(self.include) - CONTEXT_INCLUDES)
        if invalid:
            raise ValidationError(f"unsupported context include: {', '.join(invalid)}")
        if len(set(self.select)) != len(self.select):
            raise ValidationError("context selections must be unique")
        if len(set(self.include_links)) != len(self.include_links):
            raise ValidationError("context link IDs must be unique")


class ContextService:
    """Read only the selected Case, indexed events, and requested links."""

    def __init__(
        self,
        workspace: WorkspaceRegistry,
        store: Store,
        *,
        index: QueryIndex | None = None,
        link_provider: LinkProvider | None = None,
    ):
        self.workspace = workspace
        self.store = store
        self.index = index or QueryIndex(workspace.cache_path)
        self.link_provider = link_provider

    def build(self, target: str, options: ContextOptions | None = None) -> dict[str, object]:
        """Return deterministic context with a compact default."""

        selected = options or ContextOptions()
        memory = MemoryQuery(self.workspace, self.store, self.index)
        selector = memory.selector(target)
        if selected.recursive and selector.kind != "root":
            raise ValidationError("--recursive requires a root/path selector")
        document: dict[str, object] = {
            "schema": "research-workflow/context",
            "schema_version": 1,
            "view": selected.view,
            "selector": selector.to_dict(),
            "mappingAvailable": selector.mapping_available(self.workspace),
            "budget": {"limit_bytes": CONTEXT_VIEW_LIMITS[selected.view], "actual_bytes": 0},
        }
        if selector.kind != "case":
            return self._owner_context(document, selector, selected, memory)
        sim_id = selector.identity
        row = self.index.case(self.store, sim_id)
        document["sim_id"] = sim_id
        document["registered"] = row is not None and row.state == "active"
        if not selected.select or "event-details" in selected.include:
            self._progress(document, selector, selected, memory)
        if row is None:
            document["case"] = {"sim_id": sim_id, "state": "missing"}
            document["next_action"] = {"command": "case create", "reason": "registration-requires-user-confirmation"}
            return _bound(document, CONTEXT_VIEW_LIMITS[selected.view])
        document["case"] = self._case_summary(row)
        if row.state == "renamed":
            document["redirected"] = True
            document["target"] = row.target_sim_id
            return _bound(document, CONTEXT_VIEW_LIMITS[selected.view])
        if row.state == "deleted":
            document["deleted"] = True
            return _bound(document, CONTEXT_VIEW_LIMITS[selected.view])
        if row.state != "active":
            raise ValidationError(f"unsupported indexed Case state: {row.state}")

        spec = self._materialized(row)
        if selected.select:
            document["selection"] = {
                pointer: _select_pointer(spec, pointer)
                for pointer in selected.select
            }
            if "spec" in selected.include:
                document["spec"] = spec
            if "study-members" in selected.include:
                members = self.index.study_members(self.store, row.project_id, row.study_id)
                document["study"] = {
                    "project_id": row.project_id,
                    "study_id": row.study_id,
                    "member_count": members["count"],
                    "members": members["members"],
                    "omitted": members["omitted"],
                }
            if "knowledge-links" in selected.include:
                knowledge_links = self._knowledge_links(row)
                if knowledge_links:
                    document["knowledge_links"] = knowledge_links
            if "event-details" in selected.include:
                self._progress(document, selector, selected, memory)
            if "status" in selected.include:
                lineage = self.index.lineage_ids(self.store, sim_id) or {sim_id}
                document["status"] = self.index.case_status(self.store, sim_id, lineage)
            if selected.include_links:
                document["links"] = [self._link(link_id, sim_id) for link_id in selected.include_links]
            return _bound(document, CONTEXT_VIEW_LIMITS[selected.view])
        if selected.view == "compact":
            delta = CaseDelta.from_dict(row.delta)
            document["case_delta"] = {
                "revision": delta.revision,
                "profiles": [reference.to_dict() for reference in delta.profiles],
                "content": copy.deepcopy(delta.content),
            }
        if "status" in selected.include:
            lineage = self.index.lineage_ids(self.store, sim_id) or {sim_id}
            document["status"] = self.index.case_status(self.store, sim_id, lineage)
        project = self.store.load_project(row.project_id)
        parent_study = self.store.load_study(row.project_id, row.study_id)
        parent_events = self.index.list_events(
            self.store, {("study", f"{row.project_id}#{row.study_id}", "")}, limit=selected.recent,
        )
        document["parent_background"] = {
            "project": project.to_dict(), "study": parent_study.to_dict(),
            "recent_events": parent_events["events"], "omitted_events": parent_events["omitted"],
        }
        members = self.index.study_members(self.store, row.project_id, row.study_id)
        study: dict[str, object] = {
            "project_id": row.project_id,
            "study_id": row.study_id,
            "member_count": members["count"],
        }
        if "study-members" in selected.include:
            study["members"] = members["members"]
            study["omitted"] = members["omitted"]
        document["study"] = study
        knowledge_links = self._knowledge_links(row)
        if knowledge_links:
            document["knowledge_links"] = knowledge_links
        source_refs = _source_references(spec)
        if source_refs:
            document["source_refs"] = source_refs
        if selected.view == "deep" or "spec" in selected.include:
            document["spec"] = spec
        if selected.include_links:
            document["links"] = [self._link(link_id, sim_id) for link_id in selected.include_links]
        return _bound(document, CONTEXT_VIEW_LIMITS[selected.view])

    def _progress(self, document: dict[str, object], selector: ReadSelector, selected: ContextOptions, memory: MemoryQuery) -> None:
        events = memory.events(
            selector, limit=selected.recent, recursive=selected.recursive,
            details=selected.view == "deep" or "event-details" in selected.include,
        )
        document["recent_events"] = events["events"]
        document["progress"] = {
            "total": events["total"], "omitted": events["omitted"],
            "truncated": events["truncated"],
            "follow_up": {"command": "event list", "target": selector.target, "limit": 20, "recursive": selected.recursive},
        }

    def _owner_context(
        self, document: dict[str, object], selector: ReadSelector, selected: ContextOptions, memory: MemoryQuery,
    ) -> dict[str, object]:
        if selected.include_links:
            raise ValidationError("--include-link requires an exact Case link context")
        if selector.kind == "study":
            project_id, study_id = selector.identity.split("#", 1)
            study = self.store.load_study(project_id, study_id)
            source = study.to_dict()
            document["study"] = source
            document["parent_background"] = {"project": self.store.load_project(project_id).to_dict()}
            members = self.index.study_members(self.store, project_id, study_id)
            document["members"] = members
        elif selector.kind == "project":
            source = self.store.load_project(selector.identity).to_dict()
            document["project"] = source
            ids = self.index.member_ids(self.store, selector.identity)
            document["members"] = {"count": len(ids), "members": ids[:32], "omitted": max(0, len(ids) - 32)}
        else:
            source = selector.to_dict()
            document["root"] = source
        if selected.select:
            document["selection"] = {pointer: _select_pointer(source, pointer) for pointer in selected.select}
        if not selected.select or "event-details" in selected.include:
            self._progress(document, selector, selected, memory)
        return _bound(document, CONTEXT_VIEW_LIMITS[selected.view])

    @staticmethod
    def _case_summary(row: CaseIndexRow) -> dict[str, object]:
        result: dict[str, object] = {
            "sim_id": row.sim_id,
            "state": row.state,
            "project_id": row.project_id,
            "study_id": row.study_id,
            "revision": row.revision,
            "spec_digest": row.delta_digest,
            "write_digest": row.write_digest,
        }
        if row.target_sim_id != "not-applicable":
            result["target_sim_id"] = row.target_sim_id
        return result

    def _materialized(self, row: CaseIndexRow) -> dict[str, object]:
        if not row.delta:
            raise ValidationError(f"active Case has no indexed delta: {row.sim_id}")
        delta = CaseDelta.from_dict(row.delta)
        project = self.store.load_project(delta.project_id)
        study = self.store.load_study(delta.project_id, delta.study_id)
        references = project.profiles + study.profiles + delta.profiles
        profiles = {
            (reference.scope, reference.profile_id): self.store.load_profile(reference)
            for reference in references
        }
        return materialize_case(project, study, profiles, delta).to_dict()

    def _knowledge_links(self, row: CaseIndexRow) -> list[dict[str, object]]:
        project = self.store.load_project(row.project_id)
        study = self.store.load_study(row.project_id, row.study_id)
        return [
            {"scope": scope, **link.to_dict()}
            for scope, links in (
                ("project", project.knowledge_links),
                ("study", study.knowledge_links),
            )
            for link in links
        ]

    def _link(self, link_id: str, sim_id: str) -> dict[str, object]:
        if not isinstance(link_id, str) or not link_id.strip():
            raise ValidationError("--include-link requires a non-empty link ID")
        if self.link_provider is not None:
            fragment = self.link_provider.collect(link_id, sim_id)
            return {"link_id": link_id, **copy.deepcopy(fragment)}
        row = self.index.case(self.store, sim_id)
        if row is None or row.state != "active":
            raise ValidationError(f"knowledge link requires an active Case: {sim_id}")
        project = self.store.load_project(row.project_id)
        study = self.store.load_study(row.project_id, row.study_id)
        matches = [
            link
            for link in project.knowledge_links + study.knowledge_links
            if link.link_id == link_id
        ]
        if len(matches) > 1:
            raise ConflictError(f"knowledge link_id is ambiguous across Project and Study: {link_id}")
        if matches:
            link = matches[0]
            result = self._read_link(link.locator, link.section)
            result.update({"link_id": link.link_id, "role": link.role})
            if link.external_ref is not None:
                result["external_ref"] = link.external_ref.to_dict()
            return result
        if study.notes is not None and link_id in {"notes", "study-notes"}:
            return {
                "link_id": link_id,
                "role": "theory",
                **self._read_link(study.notes.locator, study.notes.section),
            }
        raise ValidationError(f"knowledge link is not registered: {link_id}")

    def _read_link(self, locator: object, section: str) -> dict[str, object]:
        path = locator.resolve_local(self.workspace, linked_notes=True)
        if not path.is_file() or path.is_symlink():
            raise ValidationError(f"linked Notes file is missing or unsafe: {path}")
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as exc:
            raise ValidationError(f"cannot read linked Notes file {path}: {exc}") from exc
        return {
            "locator": locator.to_dict(),
            "section": section,
            "content": extract_markdown_section(text, section),
        }


def extract_markdown_section(text: str, section: str) -> str:
    """Extract one exact Markdown heading body."""

    target = section.strip()
    lines = text.splitlines()
    start: int | None = None
    level = 0
    for index, line in enumerate(lines):
        match = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if match and match.group(2) == target:
            start = index + 1
            level = len(match.group(1))
            break
    if start is None:
        raise ValidationError(f"linked Notes section is missing: {target}")
    end = len(lines)
    for index in range(start, len(lines)):
        match = re.match(r"^(#{1,6})\s+", lines[index])
        if match and len(match.group(1)) <= level:
            end = index
            break
    return "\n".join(lines[start:end]).strip()


def _source_references(spec: dict[str, object]) -> dict[str, object]:
    content = spec.get("content")
    if not isinstance(content, dict):
        return {}
    reproducibility = content.get("reproducibility")
    if not isinstance(reproducibility, dict):
        return {}
    result: dict[str, object] = {}
    for key in ("input", "runner", "notebook", "configuration"):
        item = reproducibility.get(key)
        if not isinstance(item, dict):
            continue
        selected = {name: copy.deepcopy(item[name]) for name in ("locator", "sha256") if name in item}
        if selected:
            result[key] = selected
    return result


def _select_pointer(document: object, pointer: str) -> object:
    if not isinstance(pointer, str) or not pointer.startswith("/"):
        raise ValidationError("--select must use an absolute JSON Pointer")
    current = document
    for raw in pointer[1:].split("/"):
        part = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(current, dict) and part in current:
            current = current[part]
            continue
        if isinstance(current, list) and part.isdigit() and int(part) < len(current):
            current = current[int(part)]
            continue
        raise ValidationError(f"context selection is missing: {pointer}")
    return copy.deepcopy(current)


def _document_size(document: dict[str, object]) -> int:
    budget = document["budget"]
    assert isinstance(budget, dict)
    size = -1
    actual = 0
    while size != actual:
        size = actual
        budget["actual_bytes"] = actual
        actual = len(canonical_json_bytes(document)) + 1
    budget["actual_bytes"] = actual
    return len(canonical_json_bytes(document)) + 1


def _bound(document: dict[str, object], limit: int) -> dict[str, object]:
    result = copy.deepcopy(document)

    def omitted(path: str) -> None:
        result["budget"]["truncated"] = True
        paths = result.setdefault("omitted_paths", [])
        if path not in paths:
            paths.append(path)

    while _document_size(result) > limit:
        changed = False
        for key in ("study", "members"):
            members = result.get(key)
            if isinstance(members, dict) and isinstance(members.get("members"), list) and members["members"]:
                members["members"].pop()
                members["omitted"] = int(members.get("omitted", 0)) + 1
                omitted(f"/{key}/members")
                changed = True
                break
        if changed:
            continue
        for key in ("spec", "selection"):
            if key in result and result[key] != {"omitted": "context-budget"}:
                result[key] = {"omitted": "context-budget"}
                omitted(f"/{key}")
                changed = True
                break
        if changed:
            continue
        links = result.get("links")
        if isinstance(links, list):
            shrunk = False
            for item in links:
                if isinstance(item, dict) and isinstance(item.get("content"), str) and item["content"]:
                    item["content"] = item["content"][: len(item["content"]) // 2]
                    item["truncated"] = True
                    omitted("/links/content")
                    shrunk = True
                    break
            if shrunk:
                continue
        if "source_refs" in result:
            del result["source_refs"]
            omitted("/source_refs")
            continue
        knowledge_links = result.get("knowledge_links")
        if isinstance(knowledge_links, list) and knowledge_links:
            knowledge_links.pop()
            omitted("/knowledge_links")
            continue
        for name in ("case_delta", "study", "project"):
            item = result.get(name)
            if isinstance(item, dict) and isinstance(item.get("content"), dict) and item["content"]:
                content = item["content"]
                key = max(sorted(content), key=lambda key: len(canonical_json_bytes(content[key])))
                del content[key]
                escaped = key.replace("~", "~0").replace("/", "~1")
                omitted(f"/{name}/content/{escaped}")
                changed = True
                break
        if changed:
            continue
        if "parent_background" in result and result["parent_background"] != {"omitted": "context-budget"}:
            result["parent_background"] = {"omitted": "context-budget"}
            omitted("/parent_background")
            continue
        recent = result.get("recent_events")
        if isinstance(recent, list) and recent:
            for event in recent:
                if event.get("evidence"):
                    event["evidence_count"] = len(event["evidence"])
                    del event["evidence"]
                    event["details_omitted"] = True
                    omitted("/recent_events/evidence")
                    changed = True
                    break
                if len(event.get("summary", "")) > 240:
                    event["summary"] = event["summary"][:240]
                    event["summary_truncated"] = True
                    omitted("/recent_events/summary")
                    changed = True
                    break
            if changed:
                continue
            if len(recent) > 1:
                recent.pop()
                progress = result["progress"]
                progress["omitted"] += 1
                progress["truncated"] = True
                omitted("/recent_events")
                continue
            event = recent[0]
            essential = {"event_id", "occurred_at", "kind", "summary", "owner", "correction", "corrected_by", "summary_truncated"}
            if set(event) - essential - {"details_omitted"}:
                recent[0] = {key: value for key, value in event.items() if key in essential}
                recent[0]["details_omitted"] = True
                omitted("/recent_events/details")
                continue
        if "status" in result and result["status"] != {"omitted": "context-budget"}:
            result["status"] = {"omitted": "context-budget"}
            omitted("/status")
            continue
        raise ValidationError(f"mandatory context exceeds {limit} bytes")
    return result


__all__ = [
    "CONTEXT_INCLUDES",
    "CONTEXT_VIEW_LIMITS",
    "ContextOptions",
    "ContextService",
    "LinkProvider",
]
