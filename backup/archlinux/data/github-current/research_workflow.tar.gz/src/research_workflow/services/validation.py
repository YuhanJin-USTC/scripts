"""Aggregate metadata, policy authority and runtime compatibility checks."""

from research_workflow.core.errors import ResearchWorkflowError
from research_workflow.storage.compatibility import compatibility


def policy_authority_report(workspace, store_document) -> dict:
    from research_workflow.evolution.policy import load_active_rules, load_open_proposals, check_backlog_consistency, validate_rule_set
    from research_workflow.evolution.propagation import TargetAllowlist

    errors = []
    checked = 0
    try:
        policy_root = workspace.project_root / "policy"
        if not policy_root.exists():
            return {"valid": True, "checked": 0, "errors": [], "present": False}
        rules = load_active_rules(policy_root)
        proposals = load_open_proposals(policy_root)
        contexts = TargetAllowlist.from_workspace(workspace).contexts
        checked = len(rules) + len(proposals) + len(contexts)
        validate_rule_set(rules, contexts)
        if any(item.to_dict().get("schema_version") == 2 for item in (*rules, *proposals)):
            from research_workflow.storage.compatibility import require_compatible
            require_compatible(store_document, target_lifecycle=True)
        backlog = workspace.project_root / "EVOLUTION_BACKLOG.md"
        markdown = backlog.read_text(encoding="utf-8") if backlog.exists() else ""
        if not check_backlog_consistency(markdown, proposals):
            errors.append("policy backlog differs from proposal authority")
    except (ResearchWorkflowError, OSError) as exc:
        errors.append(str(exc))
    return {"valid": not errors, "checked": checked, "errors": errors, "present": True}


def validate_workspace(workspace, store) -> dict:
    metadata = store.validate().to_dict()
    errors = list(metadata["errors"])
    try:
        document = store.load_store()
        supported = compatibility(document)
        if not supported["compatible"]:
            errors.append("unsupported Store writer capabilities")
        policy = policy_authority_report(workspace, document)
        errors.extend(policy["errors"])
    except ResearchWorkflowError as exc:
        supported = {"compatible": False}
        policy = {"valid": False, "checked": 0, "errors": [str(exc)]}
        if str(exc) not in errors:
            errors.append(str(exc))
    return {"valid": not errors, "checked": metadata["checked"] + policy["checked"], "errors": errors,
            "details": {**metadata["details"], "policy": policy, "compatibility": supported}}
