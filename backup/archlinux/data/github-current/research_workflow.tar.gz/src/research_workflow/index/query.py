"""Maintain a transparent, disposable SQLite query index."""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from contextlib import closing
from dataclasses import dataclass
from pathlib import Path

from research_workflow.core.canonical import canonical_json_bytes, decode_json
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.core.time import validate_utc
from research_workflow.domain.events import Event
from research_workflow.domain.status import derive_case_status
from research_workflow.storage.store import Store


INDEX_SCHEMA_VERSION = 5

_SCHEMA = """
CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE cases (
    sim_id TEXT PRIMARY KEY,
    state TEXT NOT NULL,
    project_id TEXT NOT NULL,
    study_id TEXT NOT NULL,
    revision INTEGER NOT NULL,
    delta_digest TEXT NOT NULL,
    write_digest TEXT NOT NULL,
    target_sim_id TEXT NOT NULL,
    delta_json TEXT NOT NULL
);
CREATE INDEX cases_study ON cases(project_id, study_id, sim_id);
CREATE TABLE lineage (
    sim_id TEXT PRIMARY KEY,
    canonical_sim_id TEXT NOT NULL,
    state TEXT NOT NULL
);
CREATE INDEX lineage_canonical ON lineage(canonical_sim_id, sim_id);
CREATE TABLE streams (
    kind TEXT NOT NULL,
    path TEXT PRIMARY KEY,
    size INTEGER NOT NULL,
    mtime_ns INTEGER NOT NULL,
    device INTEGER NOT NULL,
    inode INTEGER NOT NULL,
    anchor_offset INTEGER NOT NULL,
    anchor_sha256 TEXT NOT NULL
);
CREATE TABLE events (
    event_id TEXT PRIMARY KEY,
    stream_path TEXT NOT NULL,
    byte_offset INTEGER NOT NULL,
    byte_length INTEGER NOT NULL,
    owner_kind TEXT NOT NULL,
    owner_id TEXT NOT NULL,
    owner_path TEXT NOT NULL,
    occurred_at TEXT NOT NULL,
    recorded_at TEXT NOT NULL,
    kind TEXT NOT NULL,
    summary TEXT NOT NULL,
    search_text TEXT NOT NULL,
    corrects TEXT NOT NULL,
    document TEXT NOT NULL
);
CREATE INDEX events_owner_time ON events(owner_kind, owner_id, owner_path, occurred_at DESC, recorded_at DESC, event_id DESC);
CREATE INDEX events_correction ON events(corrects);
CREATE TABLE status (
    sim_id TEXT NOT NULL,
    track TEXT NOT NULL,
    document TEXT NOT NULL,
    PRIMARY KEY(sim_id, track)
);
"""


@dataclass(frozen=True, slots=True)
class CaseIndexRow:
    """Describe one indexed Case head without claiming authority."""

    sim_id: str
    state: str
    project_id: str
    study_id: str
    revision: int
    delta_digest: str
    write_digest: str
    target_sim_id: str
    delta: dict[str, object]


class QueryIndex:
    """Serve targeted Case and Event queries from rebuildable SQLite state."""

    def __init__(self, path: str | os.PathLike[str]):
        self.path = Path(path).absolute()

    def ensure(self, store: Store) -> None:
        """Create or incrementally refresh the index from portable authority."""

        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._connect()) as connection:
            signature = self._store_signature(store)
            if self._metadata(connection, "store_signature") != signature:
                self._rebuild_cases(connection, store)
                self._set_metadata(connection, "store_signature", signature)
            self._refresh_case_journals(connection, store)
            self._refresh_events(connection, store)
            connection.commit()

    def rebuild(self, store: Store) -> dict[str, object]:
        """Explicitly discard and rebuild all derived index rows."""

        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._connect()) as connection:
            for table in ("cases", "lineage", "streams", "events", "status", "metadata"):
                connection.execute(f"DELETE FROM {table}")
            self._rebuild_cases(connection, store)
            self._set_metadata(connection, "store_signature", self._store_signature(store))
            self._refresh_case_journals(connection, store)
            self._refresh_events(connection, store)
            connection.commit()
            counts = {
                table: int(connection.execute(f"SELECT count(*) FROM {table}").fetchone()[0])
                for table in ("cases", "lineage", "events", "status", "streams")
            }
        return {"authority": False, "path": str(self.path), "counts": counts}

    def stats(self) -> dict[str, object]:
        """Return compact index diagnostics."""

        with closing(self._connect()) as connection:
            counts = {
                table: int(connection.execute(f"SELECT count(*) FROM {table}").fetchone()[0])
                for table in ("cases", "lineage", "events", "status", "streams")
            }
        return {"authority": False, "path": str(self.path), "counts": counts}

    def case(self, store: Store, sim_id: str) -> CaseIndexRow | None:
        """Return one fresh indexed Case row."""

        self.ensure(store)
        with closing(self._connect()) as connection:
            row = connection.execute(
                "SELECT sim_id,state,project_id,study_id,revision,delta_digest,write_digest,target_sim_id,delta_json "
                "FROM cases WHERE sim_id=?",
                (sim_id,),
            ).fetchone()
        if row is None:
            return None
        delta = json.loads(row[8]) if row[8] else {}
        return CaseIndexRow(
            sim_id=row[0],
            state=row[1],
            project_id=row[2],
            study_id=row[3],
            revision=int(row[4]),
            delta_digest=row[5],
            write_digest=row[6],
            target_sim_id=row[7],
            delta=delta,
        )

    def lineage_ids(self, store: Store, sim_id: str) -> set[str]:
        """Return indexed identities sharing one canonical lineage."""

        self.ensure(store)
        with closing(self._connect()) as connection:
            row = connection.execute(
                "SELECT canonical_sim_id FROM lineage WHERE sim_id=?",
                (sim_id,),
            ).fetchone()
            if row is None:
                return set()
            return {
                item[0]
                for item in connection.execute(
                    "SELECT sim_id FROM lineage WHERE canonical_sim_id=? ORDER BY sim_id",
                    (row[0],),
                )
            }

    def study_members(
        self,
        store: Store,
        project_id: str,
        study_id: str,
        *,
        limit: int = 32,
    ) -> dict[str, object]:
        """Return a bounded compact Study member table."""

        self.ensure(store)
        with closing(self._connect()) as connection:
            count = int(
                connection.execute(
                    "SELECT count(*) FROM cases WHERE project_id=? AND study_id=? AND state='active'",
                    (project_id, study_id),
                ).fetchone()[0]
            )
            rows = connection.execute(
                "SELECT sim_id,revision,delta_digest FROM cases "
                "WHERE project_id=? AND study_id=? AND state='active' ORDER BY sim_id LIMIT ?",
                (project_id, study_id, limit),
            ).fetchall()
        return {
            "count": count,
            "members": [
                {"sim_id": row[0], "revision": int(row[1]), "spec_digest": row[2]}
                for row in rows
            ],
            "omitted": max(0, count - len(rows)),
        }

    def member_ids(self, store: Store, project_id: str, study_id: str | None = None) -> list[str]:
        """Return explicit Case membership, retaining lifecycle history."""

        self.ensure(store)
        clause = "project_id=?" + (" AND study_id=?" if study_id is not None else "")
        parameters = (project_id, study_id) if study_id is not None else (project_id,)
        with closing(self._connect()) as connection:
            return [row[0] for row in connection.execute(
                f"SELECT sim_id FROM cases WHERE {clause} ORDER BY sim_id", parameters,
            )]

    def has_case_descendants(self, store: Store, sim_prefix: str) -> bool:
        """Recognize a strict Case ancestor without inventing its membership."""

        self.ensure(store)
        prefix = sim_prefix + "/"
        with closing(self._connect()) as connection:
            return connection.execute(
                "SELECT 1 FROM cases WHERE substr(sim_id,1,?)=? LIMIT 1", (len(prefix), prefix),
            ).fetchone() is not None

    def project_study_owners(self, store: Store, project_id: str) -> list[str]:
        """Select Study event owners by their exact Project identity."""

        self.ensure(store)
        prefix = project_id + "#"
        with closing(self._connect()) as connection:
            return [row[0] for row in connection.execute(
                "SELECT DISTINCT owner_id FROM events WHERE owner_kind='study' "
                "AND substr(owner_id,1,?)=? ORDER BY owner_id", (len(prefix), prefix),
            )]

    def list_events(
        self, store: Store, owners: set[tuple[str, str, str]] | None = None, *,
        limit: int = 20, since: str | None = None, query: str | None = None,
        recursive: bool = False, details: bool = False,
    ) -> dict[str, object]:
        """Return bounded work events with explicit filtering and omissions."""

        if not isinstance(limit, int) or isinstance(limit, bool) or not 0 <= limit <= 100:
            raise ValidationError("event limit must be between 0 and 100")
        if since is not None:
            validate_utc(since, "--since")
        if query is not None and (not isinstance(query, str) or not query.strip()):
            raise ValidationError("--query requires a non-empty substring")
        self.ensure(store)
        clauses: list[str] = []
        parameters: list[object] = []
        if owners is not None:
            path_match = "events.owner_path=selected.path"
            if recursive:
                path_match += (" OR (selected.kind='root' AND (selected.path='' OR "
                               "substr(events.owner_path,1,length(selected.path)+1)=selected.path||'/'))")
            clauses.append("EXISTS (SELECT 1 FROM selected_owners selected WHERE "
                           "events.owner_kind=selected.kind AND events.owner_id=selected.identity "
                           f"AND ({path_match}))")
        if since is not None:
            clauses.append("occurred_at>=?")
            parameters.append(since)
        if query is not None:
            clauses.append("instr(search_text,?)>0")
            parameters.append(query.casefold())
        where = " AND ".join(clauses) or "1"
        with closing(self._connect()) as connection:
            if owners is not None:
                connection.execute("CREATE TEMP TABLE selected_owners (kind TEXT,identity TEXT,path TEXT,PRIMARY KEY(kind,identity,path))")
                connection.executemany("INSERT INTO selected_owners VALUES(?,?,?)", sorted(owners))
            count = int(connection.execute(f"SELECT count(*) FROM events WHERE {where}", parameters).fetchone()[0])
            rows = connection.execute(
                f"SELECT document FROM events WHERE {where} "
                "ORDER BY occurred_at DESC,recorded_at DESC,event_id DESC LIMIT ?",
                (*parameters, limit),
            ).fetchall()
            events = [self._event_document(connection, json.loads(row[0]), details=details) for row in rows]
        result = {
            "events": events, "count": len(events), "total": count,
            "omitted": count - len(events), "truncated": count > len(events),
            "limit": limit,
        }
        if since is not None:
            result["since"] = since
        if query is not None:
            result["query"] = query
        return result

    @staticmethod
    def _event_document(connection: sqlite3.Connection, event: dict[str, object], *, details: bool) -> dict[str, object]:
        if details:
            result = dict(event)
        else:
            result = {key: event[key] for key in ("event_id", "device_id", "occurred_at", "recorded_at", "owner", "kind", "summary")}
            result["evidence_count"] = len(event["evidence"])
            result["evidence"] = [
                {key: item[key] for key in ("locator", "observation")}
                for item in event["evidence"]
            ]
            if "correction" in event:
                result["correction"] = event["correction"]
        result["scope"] = event["owner"]["kind"]
        corrected_by = [json.loads(row[0]) for row in connection.execute(
            "SELECT document FROM events WHERE corrects=? ORDER BY recorded_at,event_id", (event["event_id"],),
        )]
        if corrected_by:
            result["corrected_by"] = [
                {"event_id": item["event_id"], **item["correction"]} for item in corrected_by
            ]
        return result

    def show_event(self, store: Store, event_id: str) -> dict[str, object]:
        """Return the complete stored event plus correction relationships."""

        self.ensure(store)
        with closing(self._connect()) as connection:
            row = connection.execute("SELECT document FROM events WHERE event_id=?", (event_id,)).fetchone()
            if row is None:
                raise ValidationError(f"event not found: {event_id}")
            return self._event_document(connection, json.loads(row[0]), details=True)

    def recent_events(
        self,
        store: Store,
        owner_ids: set[str],
        *,
        limit: int = 3,
        details: bool = False,
        study_owner_id: str | None = None,
    ) -> list[dict[str, object]]:
        """Return recent Case-owned events without scanning complete streams."""

        if (not owner_ids and study_owner_id is None) or limit < 1:
            return []
        self.ensure(store)
        placeholders = ",".join("?" for _ in owner_ids)
        clauses: list[str] = []
        parameters: list[object] = []
        if owner_ids:
            clauses.append(f"(owner_kind='case' AND owner_id IN ({placeholders}))")
            parameters.extend(sorted(owner_ids))
        if study_owner_id is not None:
            clauses.append("(owner_kind='study' AND owner_id=?)")
            parameters.append(study_owner_id)
        query = (
            "SELECT event_id,occurred_at,kind,summary,document,owner_kind FROM events "
            f"WHERE {' OR '.join(clauses)} "
            "ORDER BY occurred_at DESC,recorded_at DESC,event_id DESC LIMIT ?"
        )
        parameters.append(limit)
        with closing(self._connect()) as connection:
            rows = connection.execute(query, tuple(parameters)).fetchall()
        if details:
            return [{"scope": row[5], **json.loads(row[4])} for row in rows]
        return [
            {
                "event_id": row[0],
                "occurred_at": row[1],
                "kind": row[2],
                "summary": row[3],
                "scope": row[5],
            }
            for row in rows
        ]

    def case_status(self, store: Store, sim_id: str, lineage_ids: set[str]) -> dict[str, dict[str, object]]:
        """Derive and cache status from indexed lineage events."""

        self.ensure(store)
        events = self._events_for_owners(lineage_ids)
        canonical = self._canonical_callback(store)
        status = derive_case_status(
            events,
            sim_id,
            lineage_ids=lineage_ids or {sim_id},
            canonical_case_identity=canonical,
        )
        with closing(self._connect()) as connection:
            for track, document in status.items():
                connection.execute(
                    "INSERT OR REPLACE INTO status(sim_id,track,document) VALUES(?,?,?)",
                    (sim_id, track, json.dumps(document, ensure_ascii=False, sort_keys=True, separators=(",", ":"))),
                )
            connection.commit()
        return status

    def event_location(self, event_id: str) -> dict[str, object] | None:
        """Expose one indexed stream offset for diagnostics and tests."""

        with closing(self._connect()) as connection:
            row = connection.execute(
                "SELECT stream_path,byte_offset,byte_length FROM events WHERE event_id=?",
                (event_id,),
            ).fetchone()
        if row is None:
            return None
        return {"path": row[0], "offset": int(row[1]), "bytes": int(row[2])}

    def _connect(self) -> sqlite3.Connection:
        if self.path.is_symlink():
            raise ValidationError(f"refusing symlinked query index: {self.path}")
        connection = sqlite3.connect(self.path)
        try:
            connection.execute("PRAGMA foreign_keys=ON")
            version = int(connection.execute("PRAGMA user_version").fetchone()[0])
            if version != INDEX_SCHEMA_VERSION:
                tables = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table'")]
                for table in tables:
                    if table.startswith("sqlite_"):
                        continue
                    safe = table.replace('"', '""')
                    connection.execute(f'DROP TABLE "{safe}"')
                connection.executescript(_SCHEMA)
                connection.execute(f"PRAGMA user_version={INDEX_SCHEMA_VERSION}")
                connection.commit()
        except Exception:
            connection.close()
            raise
        return connection

    @staticmethod
    def _metadata(connection: sqlite3.Connection, key: str) -> str | None:
        row = connection.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone()
        return None if row is None else str(row[0])

    @staticmethod
    def _set_metadata(connection: sqlite3.Connection, key: str, value: str) -> None:
        connection.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)", (key, value))

    @staticmethod
    def _store_signature(store: Store) -> str:
        try:
            raw = store.store_path.read_bytes()
        except OSError as exc:
            raise ValidationError(f"cannot fingerprint Store authority: {exc}") from exc
        return hashlib.sha256(raw).hexdigest()

    def _rebuild_cases(self, connection: sqlite3.Connection, store: Store) -> None:
        del store
        connection.execute("DELETE FROM cases")
        connection.execute("DELETE FROM lineage")
        connection.execute("DELETE FROM metadata WHERE key='case_journal_signature'")

    def _refresh_case_journals(self, connection: sqlite3.Connection, store: Store) -> None:
        """Refresh all journal heads from portable authority."""

        paths = tuple(Path(path).absolute() for path in store.case_record_paths())
        signature = self._paths_signature(paths)
        indexed = int(connection.execute("SELECT count(*) FROM cases").fetchone()[0])
        if self._metadata(connection, "case_journal_signature") == signature and (not paths or indexed > 0):
            return
        heads = store.journal_case_heads()
        connection.execute("DELETE FROM cases")
        connection.execute("DELETE FROM status")
        for sim_id, head in heads.items():
            document = head.to_dict() if hasattr(head, "to_dict") else {}
            delta = getattr(head, "delta", None)
            delta_document = delta.to_dict() if delta is not None else document.get("delta", {})
            state = str(getattr(head, "state", document.get("state", "active")))
            project_id = str(getattr(head, "project_id", document.get("project_id", "not-applicable")))
            study_id = str(getattr(head, "study_id", document.get("study_id", "not-applicable")))
            revision = int(getattr(head, "revision", document.get("revision", 0)))
            digest = str(getattr(head, "delta_digest", document.get("delta_digest", "not-applicable")))
            raw_target = getattr(head, "target_sim_id", document.get("target_sim_id"))
            target = "not-applicable" if raw_target is None else str(raw_target)
            connection.execute(
                "INSERT OR REPLACE INTO cases VALUES(?,?,?,?,?,?,?,?,?)",
                (
                    sim_id,
                    state,
                    project_id,
                    study_id,
                    revision,
                    digest,
                    digest,
                    target,
                    canonical_json_bytes(delta_document).decode("utf-8") if delta_document else "",
                ),
            )
        self._set_metadata(connection, "case_journal_signature", signature)
        self._rebuild_lineage(connection, store)

    @staticmethod
    def _paths_signature(paths: tuple[Path, ...]) -> str:
        parts: list[str] = []
        for path in sorted(paths):
            stat = path.stat()
            parts.append(f"{path}:{stat.st_size}:{stat.st_mtime_ns}:{stat.st_ino}")
        return hashlib.sha256("\n".join(parts).encode("utf-8")).hexdigest()

    def _rebuild_lineage(self, connection: sqlite3.Connection, store: Store) -> None:
        connection.execute("DELETE FROM lineage")
        rows = connection.execute("SELECT sim_id,state,target_sim_id FROM cases ORDER BY sim_id").fetchall()
        targets = {row[0]: (row[1], row[2]) for row in rows}
        for sim_id in targets:
            current = sim_id
            seen: set[str] = set()
            while targets.get(current, ("missing", "not-applicable"))[0] == "renamed":
                if current in seen:
                    raise ConflictError(f"Case redirect cycle detected while indexing: {sim_id}")
                seen.add(current)
                current = targets[current][1]
            state = targets.get(current, ("missing", "not-applicable"))[0]
            connection.execute(
                "INSERT INTO lineage(sim_id,canonical_sim_id,state) VALUES(?,?,?)",
                (sim_id, current, state),
            )

    def _refresh_events(self, connection: sqlite3.Connection, store: Store) -> None:
        current_paths = {str(path.absolute()): path.absolute() for path in store.event_paths()}
        indexed_paths = {row[0] for row in connection.execute("SELECT path FROM streams WHERE kind='event'")}
        for removed in sorted(indexed_paths - set(current_paths)):
            connection.execute("DELETE FROM events WHERE stream_path=?", (removed,))
            connection.execute("DELETE FROM streams WHERE path=?", (removed,))
        changed = bool(indexed_paths - set(current_paths))
        for text_path, path in current_paths.items():
            if self._refresh_event_stream(connection, path):
                changed = True
        if changed:
            connection.execute("DELETE FROM status")

    def _refresh_event_stream(self, connection: sqlite3.Connection, path: Path) -> bool:
        stat = path.stat()
        row = connection.execute(
            "SELECT size,mtime_ns,device,inode,anchor_offset,anchor_sha256 FROM streams WHERE path=?",
            (str(path),),
        ).fetchone()
        if row is not None and int(row[0]) == stat.st_size and int(row[1]) == stat.st_mtime_ns:
            return False
        start = 0
        reset = row is None
        if row is not None:
            old_size = int(row[0])
            same_file = int(row[2]) == stat.st_dev and int(row[3]) == stat.st_ino
            if same_file and stat.st_size >= old_size:
                with path.open("rb") as stream:
                    stream.seek(int(row[4]))
                    anchor = stream.read(old_size - int(row[4]))
                if hashlib.sha256(anchor).hexdigest() == row[5]:
                    start = old_size
                    reset = False
            if reset:
                connection.execute("DELETE FROM events WHERE stream_path=?", (str(path),))
        with path.open("rb") as stream:
            stream.seek(start)
            raw = stream.read()
        if raw and not raw.endswith(b"\n"):
            raise ValidationError(f"event stream has a truncated final line: {path}")
        offset = start
        for line in raw.splitlines(keepends=True):
            payload = line[:-1]
            if not payload:
                raise ValidationError(f"blank event line: {path}")
            event = Event.from_dict(decode_json(payload, require_canonical=True))
            document = canonical_json_bytes(event.to_dict()).decode("utf-8")
            existing = connection.execute("SELECT document FROM events WHERE event_id=?", (event.event_id,)).fetchone()
            if existing is not None:
                if existing[0] != document:
                    raise ConflictError(f"conflicting duplicate event ID: {event.event_id}")
            else:
                connection.execute(
                    "INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                    (
                        event.event_id,
                        str(path),
                        offset,
                        len(line),
                        event.owner.kind,
                        event.owner.identity,
                        event.owner.path or "",
                        event.occurred_at,
                        event.recorded_at,
                        event.kind,
                        event.summary,
                        "\n".join([event.summary, *(item.observation for item in event.evidence)]).casefold(),
                        event.correction.corrects if event.correction is not None else "",
                        document,
                    ),
                )
            offset += len(line)
        anchor_offset = max(0, stat.st_size - 4096)
        with path.open("rb") as stream:
            stream.seek(anchor_offset)
            anchor = stream.read()
        connection.execute(
            "INSERT OR REPLACE INTO streams VALUES(?,?,?,?,?,?,?,?)",
            (
                "event",
                str(path),
                stat.st_size,
                stat.st_mtime_ns,
                stat.st_dev,
                stat.st_ino,
                anchor_offset,
                hashlib.sha256(anchor).hexdigest(),
            ),
        )
        return True

    def _events_for_owners(self, owner_ids: set[str]) -> list[Event]:
        if not owner_ids:
            return []
        placeholders = ",".join("?" for _ in owner_ids)
        with closing(self._connect()) as connection:
            rows = connection.execute(
                f"SELECT document FROM events WHERE owner_kind='case' AND owner_id IN ({placeholders}) "
                "ORDER BY occurred_at,recorded_at,event_id",
                tuple(sorted(owner_ids)),
            ).fetchall()
        return [Event.from_dict(json.loads(row[0])) for row in rows]

    def _canonical_callback(self, store: Store):
        def canonical(sim_id: str) -> str:
            with closing(self._connect()) as connection:
                row = connection.execute(
                    "SELECT canonical_sim_id FROM lineage WHERE sim_id=?",
                    (sim_id,),
                ).fetchone()
            if row is None:
                return store.canonical_case_identity(sim_id)
            return str(row[0])

        return canonical


__all__ = ["INDEX_SCHEMA_VERSION", "CaseIndexRow", "QueryIndex"]
