"""Expose the disposable query index."""

from .query import CaseIndexRow, QueryIndex

__all__ = ["CaseIndexRow", "QueryIndex"]
