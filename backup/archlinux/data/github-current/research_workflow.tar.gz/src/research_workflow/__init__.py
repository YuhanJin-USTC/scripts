"""Provide the current Research Workflow V0 package."""

from .core import FRAMEWORK_VERSION, SCHEMA_VERSION, ResearchWorkflowError
from .domain import CaseDelta, CaseView, Event, Project, Study
from .storage import Store
from .workspace import LogicalLocator, WorkspaceRegistry

__version__ = "0.2.4"

__all__ = [
    "CaseDelta",
    "CaseView",
    "Event",
    "FRAMEWORK_VERSION",
    "LogicalLocator",
    "Project",
    "ResearchWorkflowError",
    "SCHEMA_VERSION",
    "Store",
    "Study",
    "WorkspaceRegistry",
    "__version__",
]
