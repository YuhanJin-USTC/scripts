"""Load Store sources and generate non-authoritative Case views."""

from __future__ import annotations

from research_workflow.domain.cases import CaseView, materialize_case
from research_workflow.domain.profiles import Profile

from .store import Store


def load_case_view(store: Store, sim_id: str) -> CaseView:
    """Load one current Case source set and materialize its view in memory."""

    delta = store.load_case_delta(sim_id)
    project = store.load_project(delta.project_id)
    study = store.load_study(delta.project_id, delta.study_id)
    references = project.profiles + study.profiles + delta.profiles
    profiles: dict[tuple[str, str], Profile] = {}
    for reference in references:
        key = (reference.scope, reference.profile_id)
        profiles.setdefault(key, store.load_profile(reference))
    return materialize_case(project, study, profiles, delta)


def materialized_case_document(store: Store, sim_id: str) -> dict[str, object]:
    """Return an output-only Case view and never persist a second authority."""

    return load_case_view(store, sim_id).to_dict()


__all__ = ["load_case_view", "materialized_case_document"]
