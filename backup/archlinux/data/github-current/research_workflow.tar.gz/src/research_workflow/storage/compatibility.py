"""Inspect explicit Store writer capabilities without local workspace state."""

from pathlib import Path

from research_workflow.core.errors import UnsupportedOperationError, ValidationError
from .jsonio import read_json


TARGET_CAPABILITY = "policy-target-lifecycle-v1"
SUPPORTED_CAPABILITIES = (TARGET_CAPABILITY,)


def required_capabilities(document: dict) -> tuple[str, ...]:
    values = document.get("required_capabilities", [])
    if not isinstance(values, list) or any(not isinstance(value, str) or not value for value in values):
        raise ValidationError("required_capabilities must be a sorted unique string array")
    if values != sorted(set(values)):
        raise ValidationError("required_capabilities must be sorted and unique")
    if document["schema_version"] == 3 and TARGET_CAPABILITY not in values:
        raise ValidationError("Store schema 3 requires policy-target-lifecycle-v1")
    return tuple(values)


def compatibility(document: dict) -> dict:
    required = required_capabilities(document)
    return {
        "store_schema": document["schema_version"],
        "required_capabilities": list(required),
        "supported_capabilities": list(SUPPORTED_CAPABILITIES),
        "policy_schema_versions": [1, 2],
        "compatible": set(required).issubset(SUPPORTED_CAPABILITIES),
    }


def require_compatible(document: dict, *, target_lifecycle: bool = False) -> dict:
    result = compatibility(document)
    if not result["compatible"]:
        raise UnsupportedOperationError("Store requires unsupported writer capabilities")
    if target_lifecycle and (document["schema_version"] != 3 or TARGET_CAPABILITY not in required_capabilities(document)):
        raise UnsupportedOperationError("target lifecycle requires an explicitly approved Store schema 3 upgrade")
    return result


def inspect_store(path: str | Path) -> dict:
    from research_workflow import __version__
    from .store import validate_store_document

    selected = Path(path)
    if not selected.is_absolute():
        raise ValidationError("--store requires an absolute STORE.json path")
    for candidate in (selected, *selected.parents):
        if candidate.is_symlink():
            raise ValidationError("refusing symlinked Store inspection path")
    document = validate_store_document(read_json(selected))
    result = compatibility(document)
    return {
        "mode": "compatibility-only", "framework_version": __version__,
        "store": str(selected), "compatibility": result,
        "valid": result["compatible"], "written": False,
    }
