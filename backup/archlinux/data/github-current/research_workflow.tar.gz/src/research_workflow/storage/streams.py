"""Read, append, and merge device-owned monthly event streams."""

from __future__ import annotations

import os
from pathlib import Path

from research_workflow.core.canonical import canonical_digest, canonical_json_bytes, decode_json
from research_workflow.core.errors import ConflictError, DeviceIdentityError, ValidationError
from research_workflow.core.ids import validate_device_id
from research_workflow.core.models import WriteResult
from research_workflow.core.time import recorded_month, validate_month
from research_workflow.domain.events import Event
from .devices import require_registered_device


def event_stream_path(metadata_root: str | os.PathLike[str], device_id: str, month: str) -> Path:
    """Return the exact current Store path for one device-month stream."""

    device = validate_device_id(device_id)
    partition = validate_month(month)
    return Path(metadata_root).absolute() / "events" / device / f"{partition}.jsonl"


def read_event_stream(
    path: str | os.PathLike[str],
    *,
    device_id: str,
    month: str,
) -> list[Event]:
    """Read a canonical stream and refuse corrupt, wrong-device, or wrong-month rows."""

    selected = Path(path).absolute()
    expected = event_stream_path(selected.parents[2], device_id, month)
    if selected != expected:
        raise ValidationError(f"stream path must bind {device_id}/{month}.jsonl: {selected}")
    if selected.is_symlink() or selected.parent.is_symlink():
        raise ValidationError(f"event stream paths must not use symlinks: {selected}")
    try:
        raw = selected.read_bytes()
    except OSError as exc:
        raise ValidationError(f"cannot read event stream {selected}: {exc}") from exc
    if raw and not raw.endswith(b"\n"):
        raise ValidationError(f"event stream has a truncated final line: {selected}")
    result: list[Event] = []
    for line_number, line in enumerate(raw.splitlines(), start=1):
        if not line:
            raise ValidationError(f"blank event line: {selected}:{line_number}")
        try:
            value = decode_json(line, require_canonical=True)
            event = Event.from_dict(value)
        except ValidationError as exc:
            raise ValidationError(f"invalid event record {selected}:{line_number}: {exc}") from exc
        if event.device_id != device_id:
            raise ConflictError(f"event/path device conflict: {selected}:{line_number}")
        if recorded_month(event.recorded_at) != month:
            raise ConflictError(f"event/path month conflict: {selected}:{line_number}")
        result.append(event)
    return result


def append_event(
    metadata_root: str | os.PathLike[str],
    event: Event,
    *,
    current_device: str | None,
    write: bool = False,
) -> WriteResult:
    """Preview by default and append only to the configured device's monthly stream."""

    if current_device is None:
        raise DeviceIdentityError("current device_id is not configured")
    device = require_registered_device(Path(metadata_root), current_device)
    if event.device_id != device:
        raise DeviceIdentityError("event device_id differs from the current device")
    path = event_stream_path(metadata_root, device, recorded_month(event.recorded_at))
    existing_events = read_event_stream(
        path,
        device_id=device,
        month=recorded_month(event.recorded_at),
    ) if path.exists() else []
    payload = canonical_json_bytes(event.to_dict())
    for existing in existing_events:
        if existing.event_id != event.event_id:
            continue
        if canonical_json_bytes(existing.to_dict()) == payload:
            return WriteResult("reuse", path, canonical_digest(event.to_dict()), len(payload) + 1, False, "equal event ID and bytes")
        raise ConflictError(f"conflicting duplicate event ID: {event.event_id}")
    result = WriteResult("append", path, canonical_digest(event.to_dict()), len(payload) + 1, False, "preview")
    if not write:
        return result
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.is_symlink():
        raise ConflictError(f"refusing symlinked event stream: {path}")
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
        try:
            written = os.write(descriptor, payload + b"\n")
            if written != len(payload) + 1:
                raise OSError("short append")
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    except OSError as exc:
        raise ValidationError(f"cannot append event stream {path}: {exc}") from exc
    return WriteResult("append", path, result.digest, result.bytes_count, True, "append-only fsync")


def merge_event_streams(paths: list[str | os.PathLike[str]]) -> list[Event]:
    """Merge streams by exact event bytes and reuse equal duplicates."""

    by_id: dict[str, Event] = {}
    for value in sorted(Path(path).absolute() for path in paths):
        device = value.parent.name
        month = value.stem
        for event in read_event_stream(value, device_id=device, month=month):
            existing = by_id.get(event.event_id)
            if existing is None:
                by_id[event.event_id] = event
            elif canonical_json_bytes(existing.to_dict()) != canonical_json_bytes(event.to_dict()):
                raise ConflictError(f"conflicting duplicate event ID: {event.event_id}")
    return sorted(by_id.values(), key=lambda event: (event.occurred_at, event.recorded_at, event.event_id))


__all__ = ["append_event", "event_stream_path", "merge_event_streams", "read_event_stream"]
