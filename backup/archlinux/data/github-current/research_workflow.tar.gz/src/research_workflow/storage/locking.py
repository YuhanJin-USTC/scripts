"""Serialize supported local writers to one metadata authority."""

from contextlib import contextmanager
from pathlib import Path
import os
import threading

from research_workflow.core.errors import ConflictError


_LOCKS = {}
_GUARD = threading.Lock()
_LOCAL = threading.local()


@contextmanager
def authority_lock(metadata_root: Path):
    """Hold a reentrant thread and process lock through checks and rollback."""

    import fcntl

    root = Path(metadata_root).absolute()
    path = root.parent / ".research-workflow" / "authority.lock"
    for candidate in (path, *path.parents):
        if candidate.is_symlink():
            raise ConflictError(f"refusing symlinked authority lock: {path}")
    with _GUARD:
        mutex = _LOCKS.setdefault(str(path), threading.RLock())
    with mutex:
        held = getattr(_LOCAL, "held", set())
        if str(path) in held:
            yield
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        descriptor = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX)
            _LOCAL.held = held | {str(path)}
            try:
                yield
            finally:
                _LOCAL.held = held
                fcntl.flock(descriptor, fcntl.LOCK_UN)
        finally:
            os.close(descriptor)
