"""Read canonical JSON and perform previewed atomic writes."""

from __future__ import annotations

import os
import tempfile
from collections.abc import Callable, Mapping
from hashlib import sha256
from pathlib import Path

from research_workflow.core.canonical import canonical_digest, canonical_json_bytes, decode_json
from research_workflow.core.errors import ConflictError, ResearchWorkflowError, ValidationError
from research_workflow.core.ids import validate_digest
from research_workflow.core.models import WriteResult


def read_json(path: str | os.PathLike[str], *, canonical: bool = True) -> dict[str, object]:
    """Read one JSON object and optionally require canonical bytes plus newline."""

    selected = Path(path).absolute()
    if selected.is_symlink():
        raise ValidationError(f"refusing symlinked JSON document: {selected}")
    try:
        raw = selected.read_bytes()
    except OSError as exc:
        raise ValidationError(f"cannot read JSON document {selected}: {exc}") from exc
    if canonical:
        if not raw.endswith(b"\n") or raw.endswith(b"\n\n"):
            raise ValidationError(f"canonical JSON must end with one newline: {selected}")
        value = decode_json(raw[:-1], require_canonical=True)
    else:
        value = decode_json(raw)
    if not isinstance(value, dict):
        raise ValidationError(f"JSON document must be an object: {selected}")
    return value


def file_digest(path: str | os.PathLike[str]) -> str:
    """Return the canonical document digest after validating its bytes."""

    return canonical_digest(read_json(path, canonical=True))


def atomic_json_write(
    path: str | os.PathLike[str],
    document: dict[str, object],
    *,
    write: bool = False,
    create_only: bool = False,
    expect_digest: str | None = None,
) -> WriteResult:
    """Preview by default and atomically create or replace one canonical JSON file."""

    selected = Path(path).absolute()
    payload = canonical_json_bytes(document) + b"\n"
    digest = canonical_digest(document)
    for parent in (selected.parent, *selected.parents):
        if parent.exists() and parent.is_symlink():
            raise ConflictError(f"refusing symlinked JSON parent: {parent}")
    existing: bytes | None = None
    if selected.exists():
        if selected.is_symlink() or not selected.is_file():
            raise ConflictError(f"refusing non-regular JSON target: {selected}")
        try:
            existing = selected.read_bytes()
        except OSError as exc:
            raise ValidationError(f"cannot read JSON target {selected}: {exc}") from exc
        current = read_json(selected, canonical=True)
        if expect_digest is not None and canonical_digest(current) != validate_digest(expect_digest, "expect_digest"):
            raise ConflictError(f"expected digest does not match current document: {selected}")
        if existing == payload:
            return WriteResult("reuse", selected, digest, len(payload), False, "equal canonical bytes")
        if create_only:
            raise ConflictError(f"immutable JSON identity already exists with different bytes: {selected}")
        action = "replace"
    else:
        if expect_digest is not None:
            validate_digest(expect_digest, "expect_digest")
            raise ConflictError(f"expected current JSON document is missing: {selected}")
        action = "create"
    if not write:
        return WriteResult(action, selected, digest, len(payload), False, "preview")
    selected.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary_name = tempfile.mkstemp(prefix=selected.name + ".tmp-", dir=selected.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, selected)
        directory = os.open(selected.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    except OSError as exc:
        raise ValidationError(f"cannot atomically write JSON document {selected}: {exc}") from exc
    finally:
        if temporary.exists():
            temporary.unlink()
    return WriteResult(action, selected, digest, len(payload), True, "atomic canonical write")


def _raw_digest(payload: bytes) -> str:
    return sha256(payload).hexdigest()


def _target_bytes(path: Path) -> bytes | None:
    for parent in (path, *path.parents):
        if parent.exists() and parent.is_symlink():
            raise ConflictError(f"refusing symlinked transaction target: {path}")
    if not path.exists():
        return None
    if not path.is_file():
        raise ConflictError(f"refusing non-regular transaction target: {path}")
    try:
        return path.read_bytes()
    except OSError as exc:
        raise ValidationError(f"cannot read transaction target {path}: {exc}") from exc


def _new_directories(parent: Path) -> list[Path]:
    missing: list[Path] = []
    selected = parent
    while not selected.exists():
        missing.append(selected)
        selected = selected.parent
    parent.mkdir(parents=True, exist_ok=True)
    return missing


def _stage_bytes(path: Path, payload: bytes) -> Path:
    descriptor, temporary_name = tempfile.mkstemp(prefix=path.name + ".txn-", dir=path.parent)
    temporary = Path(temporary_name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
    except OSError:
        if temporary.exists():
            temporary.unlink()
        raise
    return temporary


def atomic_multi_write(
    changes: Mapping[str | os.PathLike[str], bytes | None],
    *,
    write: bool = False,
    expected: Mapping[str | os.PathLike[str], bytes | None] | None = None,
    post_apply_validator: Callable[[], object] | None = None,
    completion_paths: tuple[Path, ...] = (),
) -> tuple[WriteResult, ...]:
    """Preview or transactionally replace and delete an exact file set.

    Payloads are staged before the first target changes. A process-visible
    failure restores its own writes while preserving later external edits.
    An optional post-apply validator runs inside the same process-visible
    rollback boundary. No cross-filesystem crash-atomic guarantee is claimed.
    """

    normalized: dict[Path, bytes | None] = {}
    for raw_path, payload in changes.items():
        path = Path(raw_path).absolute()
        if path in normalized:
            raise ConflictError(f"duplicate transaction target: {path}")
        if payload is not None and not isinstance(payload, bytes):
            raise ValidationError(f"transaction payload must be bytes: {path}")
        normalized[path] = payload
    completions = {Path(path).absolute() for path in completion_paths}
    if not completions <= set(normalized):
        raise ConflictError("completion paths must belong to the transaction")
    originals = {path: _target_bytes(path) for path in normalized}
    if expected is not None:
        normalized_expected = {Path(path).absolute(): payload for path, payload in expected.items()}
        if set(normalized_expected) != set(normalized):
            raise ConflictError("transaction expected-state paths do not match change paths")
        for path, original in originals.items():
            if original != normalized_expected[path]:
                raise ConflictError(f"transaction target changed after preview: {path}")
    results: list[WriteResult] = []
    changed: list[Path] = []
    for path in sorted(normalized, key=str):
        before = originals[path]
        after = normalized[path]
        if before == after:
            action = "reuse"
        elif after is None:
            action = "delete"
            changed.append(path)
        elif before is None:
            action = "create"
            changed.append(path)
        else:
            action = "replace"
            changed.append(path)
        digest = _raw_digest(after if after is not None else b"")
        results.append(
            WriteResult(
                action,
                path,
                digest,
                len(after or b""),
                False,
                "preview" if not write else "pending transaction",
            )
        )
    if not write:
        return tuple(results)
    if not changed:
        if post_apply_validator is not None:
            post_apply_validator()
        return tuple(results)

    staged: dict[Path, Path] = {}
    created_directories: list[Path] = []
    applied: list[Path] = []
    try:
        for path in changed:
            after = normalized[path]
            if after is None:
                continue
            created_directories.extend(_new_directories(path.parent))
            staged[path] = _stage_bytes(path, after)
        for path, original in originals.items():
            if _target_bytes(path) != original:
                raise ConflictError(f"transaction target changed during staging: {path}")
        for path in changed:
            if path in completions:
                continue
            if _target_bytes(path) != originals[path]:
                raise ConflictError(f"transaction target changed before replace: {path}")
            if normalized[path] is None:
                path.unlink()
            else:
                os.replace(staged[path], path)
            applied.append(path)
        for parent in sorted({path.parent for path in changed}, key=str):
            descriptor = os.open(parent, os.O_RDONLY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
        if post_apply_validator is not None:
            post_apply_validator()
        for path in changed:
            if path not in completions:
                continue
            if _target_bytes(path) != originals[path]:
                raise ConflictError(f"completion target changed before replace: {path}")
            if normalized[path] is None:
                raise ValidationError("completion markers cannot delete files")
            os.replace(staged[path], path)
            applied.append(path)
            descriptor = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
    except (OSError, ResearchWorkflowError) as exc:
        rollback_errors: list[str] = []
        for path in reversed(applied):
            try:
                if _target_bytes(path) != normalized[path]:
                    rollback_errors.append(f"{path}: externally changed after apply; left untouched")
                    continue
                original = originals[path]
                if original is None:
                    if path.exists():
                        path.unlink()
                else:
                    replacement = _stage_bytes(path, original)
                    try:
                        os.replace(replacement, path)
                    finally:
                        if replacement.exists():
                            replacement.unlink()
            except (OSError, ResearchWorkflowError) as rollback_exc:
                rollback_errors.append(f"{path}: {rollback_exc}")
        if isinstance(exc, ResearchWorkflowError) and not rollback_errors:
            raise
        detail = f"cannot apply atomic file transaction: {exc}"
        if rollback_errors:
            detail += "; rollback failures: " + "; ".join(rollback_errors)
        raise ValidationError(detail) from exc
    finally:
        for temporary in staged.values():
            if temporary.exists():
                temporary.unlink()
        for directory in sorted(set(created_directories), key=lambda item: len(item.parts), reverse=True):
            try:
                directory.rmdir()
            except OSError:
                pass
    by_path = {item.path: item for item in results}
    return tuple(
        WriteResult(
            by_path[path].action,
            path,
            by_path[path].digest,
            by_path[path].bytes_count,
            path in changed,
            "atomic multi-file transaction" if path in changed else "equal bytes",
        )
        for path in sorted(normalized, key=str)
    )


__all__ = ["atomic_json_write", "atomic_multi_write", "file_digest", "read_json"]
