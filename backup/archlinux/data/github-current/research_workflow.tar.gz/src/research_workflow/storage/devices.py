"""Shared device membership gate for portable writers."""

from pathlib import Path

from research_workflow.core.errors import DeviceIdentityError
from research_workflow.core.ids import validate_device_id
from .jsonio import read_json


def require_registered_device(metadata_root: Path, device_id: str | None) -> str:
    """Require one matching Store membership and device document."""

    from .store import validate_device_document, validate_store_document

    if device_id is None:
        raise DeviceIdentityError("current device_id is not configured")
    device = validate_device_id(device_id)
    root = Path(metadata_root)
    store = validate_store_document(read_json(root / "STORE.json"))
    from .compatibility import require_compatible
    require_compatible(store)
    if device not in store["devices"]:
        raise DeviceIdentityError("current device_id is not registered in the Store")
    path = root / "devices" / f"{device}.json"
    if not path.is_file():
        raise DeviceIdentityError("current device_id registration document is missing")
    document = validate_device_document(read_json(path))
    if document["device_id"] != device:
        raise DeviceIdentityError("current device registration differs from workspace device_id")
    return device
