"""Provide the single live metadata Store boundary."""

from __future__ import annotations

import copy
import hashlib
import os
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from research_workflow.core.canonical import canonical_digest, canonical_json_bytes, require_fields, require_object, require_string
from research_workflow.core.errors import ConflictError, DeviceIdentityError, ResearchWorkflowError, ValidationError
from research_workflow.core.ids import validate_device_id, validate_digest, validate_logical_id, validate_sim_id
from research_workflow.core.models import ValidationReport, WriteResult
from research_workflow.core.time import validate_utc
from research_workflow.domain.cases import CaseDelta, materialize_case
from research_workflow.domain.case_records import CaseHead, CaseRecord, reduce_case_records
from research_workflow.domain.corrections import validate_corrections
from research_workflow.domain.events import Event
from research_workflow.domain.profiles import Profile, ProfileReference
from research_workflow.domain.projects import Project
from research_workflow.domain.studies import Study

from .case_journals import (
    append_case_records as append_journal_case_records,
    case_journal_path,
    case_journal_study_path,
    merge_case_journals,
)
from .jsonio import atomic_json_write, atomic_multi_write, read_json
from .streams import merge_event_streams
from .devices import require_registered_device


STORE_SCHEMA = "research-workflow/store"
DEVICE_SCHEMA = "research-workflow/device"


@dataclass(frozen=True, slots=True)
class JournalCaseLifecyclePlan:
    """Bind one journal lifecycle record to exact stream bytes."""

    action: str
    source: str
    target: str
    record: CaseRecord
    journal_path: Path
    journal_before_exists: bool
    journal_before_raw_sha256: str
    journal_before_raw_bytes: int
    pre_validation: dict[str, object]
    projected_validation: dict[str, object]
    digest: str

    @classmethod
    def build(
        cls,
        *,
        action: str,
        source: str,
        target: str,
        record: CaseRecord,
        journal_path: Path,
        journal_before: bytes | None,
        pre_validation: dict[str, object],
        projected_validation: dict[str, object],
    ) -> "JournalCaseLifecyclePlan":
        before = journal_before or b""
        payload = {
            "schema": "research-workflow/case-journal-lifecycle-plan",
            "schema_version": 1,
            "action": action,
            "source": source,
            "target": target,
            "record": record.to_dict(),
            "journal_path": str(journal_path.absolute()),
            "journal_before_exists": journal_before is not None,
            "journal_before_raw_sha256": hashlib.sha256(before).hexdigest(),
            "journal_before_raw_bytes": len(before),
            "pre_validation": pre_validation,
            "projected_validation": projected_validation,
            "external_execution": False,
        }
        return cls(
            action,
            source,
            target,
            record,
            journal_path.absolute(),
            journal_before is not None,
            str(payload["journal_before_raw_sha256"]),
            len(before),
            copy.deepcopy(pre_validation),
            copy.deepcopy(projected_validation),
            canonical_digest(payload),
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "research-workflow/case-journal-lifecycle-plan",
            "schema_version": 1,
            "action": self.action,
            "source": self.source,
            "target": self.target,
            "record": self.record.to_dict(),
            "record_id": self.record.record_id,
            "recorded_at": self.record.recorded_at,
            "journal_path": str(self.journal_path),
            "journal_before_exists": self.journal_before_exists,
            "journal_before_raw_sha256": self.journal_before_raw_sha256,
            "journal_before_raw_bytes": self.journal_before_raw_bytes,
            "pre_validation": copy.deepcopy(self.pre_validation),
            "projected_validation": copy.deepcopy(self.projected_validation),
            "digest": self.digest,
            "external_execution": False,
            "write": False,
        }


def _rewrite_case_self_locators(value: object, source: str, target: str) -> object:
    """Rewrite only typed Case self-locators, never arbitrary strings."""

    if isinstance(value, list):
        return [_rewrite_case_self_locators(item, source, target) for item in value]
    if isinstance(value, dict):
        result = {
            key: _rewrite_case_self_locators(item, source, target)
            for key, item in value.items()
        }
        if result.get("kind") == "case" and result.get("sim_id") == source:
            result["sim_id"] = target
        return result
    return copy.deepcopy(value)


def validate_store_document(value: object) -> dict[str, object]:
    """Validate the thin current Store root document."""

    item = require_object(value, "Store")
    require_fields(
        item,
        {"schema", "schema_version", "framework_version", "store_id", "created_at", "projects", "devices"},
        "Store", {"required_capabilities"} if item.get("schema_version") == 3 else set(),
    )
    if item["schema"] != STORE_SCHEMA or item["schema_version"] not in {2, 3} or item["framework_version"] != "0":
        raise ValidationError("Store must use framework 0 and research-workflow/store schema version 2 or 3")
    if item["schema_version"] == 3 and "required_capabilities" not in item:
        raise ValidationError("Store schema 3 requires explicit writer capabilities")
    from .compatibility import required_capabilities
    required_capabilities(item)
    validate_logical_id(item["store_id"], "store_id")
    validate_utc(item["created_at"], "Store.created_at")
    projects = item["projects"]
    devices = item["devices"]
    if not isinstance(projects, list) or not isinstance(devices, list):
        raise ValidationError("Store projects and devices must be arrays")
    project_ids = [validate_logical_id(value, "Store project_id") for value in projects]
    device_ids = [validate_device_id(value) for value in devices]
    if len(set(project_ids)) != len(project_ids) or len(set(device_ids)) != len(device_ids):
        raise ConflictError("Store project and device identities must be unique")
    return item


def validate_device_document(value: object) -> dict[str, object]:
    """Validate one portable device registration document."""

    item = require_object(value, "Device")
    require_fields(item, {"schema", "schema_version", "device_id", "name", "onboarded_at"}, "Device")
    if item["schema"] != DEVICE_SCHEMA or item["schema_version"] != 1:
        raise ValidationError("Device must use research-workflow/device schema version 1")
    validate_device_id(item["device_id"])
    require_string(item["name"], "Device.name")
    validate_utc(item["onboarded_at"], "Device.onboarded_at")
    return item


class Store:
    """Read and preview writes against one live metadata authority."""

    def __init__(self, metadata_root: str | os.PathLike[str]):
        """Bind to one metadata root without creating or scanning other roots."""

        self.root = Path(metadata_root).absolute()

    @property
    def store_path(self) -> Path:
        """Return the authority root document path."""

        return self.root / "STORE.json"

    def project_path(self, project_id: str) -> Path:
        """Return the canonical Project document path."""

        value = validate_logical_id(project_id, "project_id")
        return self.root / "projects" / PurePosixPath(value) / "PROJECT.json"

    def study_path(self, project_id: str, study_id: str) -> Path:
        """Return the canonical Study document path."""

        project = validate_logical_id(project_id, "project_id")
        study = validate_logical_id(study_id, "study_id")
        return self.root / "studies" / PurePosixPath(project) / PurePosixPath(study) / "STUDY.json"

    def profile_path(self, reference: ProfileReference) -> Path:
        """Return the canonical ordered-profile document path."""

        return self.root / "profiles" / PurePosixPath(reference.scope) / PurePosixPath(reference.profile_id) / "PROFILE.json"

    def device_path(self, device_id: str) -> Path:
        """Return the canonical portable device registration path."""

        return self.root / "devices" / f"{validate_device_id(device_id)}.json"

    def load_store(self) -> dict[str, object]:
        """Load and validate the single Store root document."""

        return validate_store_document(read_json(self.store_path))

    def load_project(self, project_id: str) -> Project:
        """Load one exact current Project identity."""

        project = Project.from_dict(read_json(self.project_path(project_id)))
        if project.project_id != project_id:
            raise ConflictError("Project path and document identity conflict")
        return project

    def load_study(self, project_id: str, study_id: str) -> Study:
        """Load one exact current Study identity."""

        study = Study.from_dict(read_json(self.study_path(project_id, study_id)))
        if (study.project_id, study.study_id) != (project_id, study_id):
            raise ConflictError("Study path and document identity conflict")
        return study

    def load_profile(self, reference: ProfileReference) -> Profile:
        """Load one exact ordered profile identity."""

        profile = Profile.from_dict(read_json(self.profile_path(reference)))
        if profile.reference != reference:
            raise ConflictError("Profile path and document identity conflict")
        return profile

    def load_case_delta(self, sim_id: str) -> CaseDelta:
        """Load one active journal Case delta."""

        selected = validate_sim_id(sim_id)
        head = self.journal_case_heads().get(selected)
        if head is None or head.state != "active" or head.delta is None:
            raise ValidationError(f"Case identity is not active: {selected}")
        return head.delta

    def case_record_paths(
        self,
        project_id: str | None = None,
        study_id: str | None = None,
        device_id: str | None = None,
    ) -> list[Path]:
        """List portable Case journals without reading external roots."""

        root = self.root / "case-journals"
        selected = root
        if project_id is not None:
            project = validate_logical_id(project_id, "project_id")
            if study_id is not None:
                selected = case_journal_study_path(self.root, project, study_id)
            else:
                selected /= project.replace("/", "%2F")
        elif study_id is not None:
            raise ValidationError("study_id filter requires project_id")
        if not selected.exists():
            return []
        if selected.is_symlink() or not selected.is_dir():
            raise ConflictError(f"refusing unsafe Case journal root: {selected}")
        paths = sorted(selected.rglob("*.jsonl"))
        if device_id is not None:
            device = validate_device_id(device_id)
            paths = [path for path in paths if path.parent.name == device]
        return paths

    def read_case_records(
        self,
        project_id: str | None = None,
        study_id: str | None = None,
        device_id: str | None = None,
    ) -> list[CaseRecord]:
        """Read and exactly merge selected Case journals."""

        return merge_case_journals(self.case_record_paths(project_id, study_id, device_id))

    def journal_case_heads(
        self,
        project_id: str | None = None,
        study_id: str | None = None,
        device_id: str | None = None,
    ) -> dict[str, CaseHead]:
        """Reduce selected Case journals to unique current and reserved heads."""

        return reduce_case_records(self.read_case_records(project_id, study_id, device_id))

    def case_head(self, sim_id: str) -> CaseHead | None:
        """Return one reduced journal head."""

        selected = validate_sim_id(sim_id)
        return self.journal_case_heads().get(selected)

    def case_state(self, sim_id: str) -> dict[str, object]:
        """Return the registered lifecycle state for one portable identity."""

        selected = validate_sim_id(sim_id)
        journal_head = self.journal_case_heads().get(selected)
        if journal_head is not None:
            result: dict[str, object] = {"sim_id": selected, "state": journal_head.state, "authority": "journal"}
            if journal_head.target_sim_id is not None:
                result["target"] = journal_head.target_sim_id
            return result
        return {"sim_id": selected, "state": "missing"}

    def list_case_state_ids(self) -> dict[str, list[str]]:
        """List journal Case lifecycle identities."""

        result = {"active": [], "renamed": [], "deleted": []}
        heads = self.journal_case_heads()
        for sim_id, head in heads.items():
            result[head.state].append(sim_id)
        for values in result.values():
            values.sort()
        return result

    def resolve_case_lineage(self, sim_id: str) -> dict[str, object]:
        """Resolve a bounded redirect chain to its active or deleted terminus."""

        selected = validate_sim_id(sim_id)
        current = selected
        chain: list[str] = []
        for _ in range(256):
            if current in chain:
                raise ConflictError(f"Case redirect cycle detected: {' -> '.join(chain + [current])}")
            chain.append(current)
            state = self.case_state(current)
            if state["state"] == "renamed":
                current = str(state["target"])
                continue
            if state["state"] == "missing" and len(chain) > 1:
                raise ConflictError(f"dangling Case redirect target: {current}")
            return {
                "source": selected,
                "canonical_sim_id": current,
                "state": state["state"],
                "chain": chain,
            }
        raise ConflictError("Case redirect chain exceeds the bounded limit")

    def canonical_case_identity(self, sim_id: str) -> str:
        """Return one canonical active/deleted lineage identity."""

        resolved = self.resolve_case_lineage(sim_id)
        if resolved["state"] == "missing":
            raise ValidationError(f"Case identity is missing: {sim_id}")
        return str(resolved["canonical_sim_id"])

    def case_lineage_ids(self, sim_id: str) -> set[str]:
        """Return every authority identity resolving to the same terminus."""

        resolved = self.resolve_case_lineage(sim_id)
        if resolved["state"] == "missing":
            return set()
        canonical = str(resolved["canonical_sim_id"])
        states = self.list_case_state_ids()
        identities = set(states["active"] + states["renamed"] + states["deleted"])
        return {
            identity
            for identity in identities
            if str(self.resolve_case_lineage(identity)["canonical_sim_id"]) == canonical
        }

    def case_events(self, sim_id: str) -> list[Event]:
        """Return merged events owned by any identity in one Case lineage."""

        identities = self.case_lineage_ids(sim_id)
        return [
            event
            for event in self.read_events()
            if event.owner.kind == "case" and event.owner.identity in identities
        ]

    def is_case_registered(self, sim_id: str) -> bool:
        """Return whether one complete Case authority is registered."""

        return self.case_state(sim_id)["state"] == "active"

    def list_case_ids(self) -> list[str]:
        """List active Cases from reduced journal heads."""

        return self.list_case_state_ids()["active"]

    def event_paths(self, device_id: str | None = None) -> list[Path]:
        """List canonical event streams without reading other workspace roots."""

        root = self.root / "events"
        if not root.exists():
            return []
        selected = root / validate_device_id(device_id) if device_id is not None else root
        paths = sorted(selected.rglob("*.jsonl")) if selected.exists() else []
        for path in paths:
            validate_device_id(path.parent.name)
            if len(path.stem) != 7:
                raise ValidationError(f"invalid event stream filename: {path}")
        return paths

    def read_events(self, device_id: str | None = None) -> list[Event]:
        """Read and exactly merge all selected device streams."""

        return merge_event_streams(self.event_paths(device_id))

    def append_case_records(
        self,
        records: tuple[CaseRecord, ...] | list[CaseRecord],
        *,
        current_device: str | None,
        write: bool = False,
    ) -> tuple[WriteResult, ...]:
        """Preview or append schema-2 Case records after authority checks."""

        require_registered_device(self.root, current_device)
        selected = tuple(records)
        existing = tuple(self.read_case_records())
        return append_journal_case_records(
            self.root,
            selected,
            current_device=current_device,
            existing_records=existing,
            write=write,
        )

    def bootstrap_case_record(
        self,
        record: CaseRecord,
        *,
        current_device: str | None,
        project: Project | None = None,
        study: Study | None = None,
        write: bool = False,
    ) -> tuple[WriteResult, ...]:
        """Atomically bootstrap optional hierarchy and one schema-2 Case."""

        store_document = self.load_store()
        if store_document["schema_version"] not in {2, 3}:
            raise ValidationError("Case journal bootstrap requires thin Store schema version 2")
        if current_device is None:
            raise DeviceIdentityError("current device_id is not configured")
        device = require_registered_device(self.root, current_device)
        if record.device_id != device:
            raise DeviceIdentityError("Case record device_id differs from the current device")
        if record.action != "create" or record.delta is None:
            raise ValidationError("Case journal bootstrap requires one create record")
        delta = record.delta
        project_ids = [str(value) for value in store_document["projects"]]
        project_path = self.project_path(delta.project_id)
        if project_path.exists():
            selected_project = self.load_project(delta.project_id)
            if delta.project_id not in project_ids:
                raise ConflictError("Project document is missing thin Store registration")
            if project is not None and project.to_dict() != selected_project.to_dict():
                raise ConflictError("supplied Project differs from current Project authority")
        else:
            if delta.project_id in project_ids:
                raise ConflictError("thin Store registers a Project without its authority document")
            if project is None:
                raise ValidationError("Case Project is missing; supply one for atomic bootstrap")
            if project.schema_version != 2:
                raise ValidationError("new thin Store Project authority must use schema version 2")
            if project.project_id != delta.project_id:
                raise ConflictError("supplied Project and Case identities conflict")
            selected_project = project

        study_path = self.study_path(delta.project_id, delta.study_id)
        if study_path.exists():
            selected_study = self.load_study(delta.project_id, delta.study_id)
            if study is not None and study.to_dict() != selected_study.to_dict():
                raise ConflictError("supplied Study differs from current Study authority")
        else:
            if study is None:
                raise ValidationError("Case Study is missing; supply one for atomic bootstrap")
            if study.schema_version != 2:
                raise ValidationError("new thin Store Study authority must use schema version 2")
            if (study.project_id, study.study_id) != (delta.project_id, delta.study_id):
                raise ConflictError("supplied Study and Case identities conflict")
            selected_study = study
        references = selected_project.profiles + selected_study.profiles + delta.profiles
        profiles = {
            (reference.scope, reference.profile_id): self.load_profile(reference)
            for reference in references
        }
        materialize_case(selected_project, selected_study, profiles, delta)
        if self.case_state(delta.sim_id)["state"] != "missing":
            raise ConflictError(f"Case identity is already reserved: {delta.sim_id}")
        records = tuple(self.read_case_records())
        reduce_case_records((*records, record))

        projected_store = copy.deepcopy(store_document)
        if delta.project_id not in project_ids:
            projected_store["projects"] = sorted((*project_ids, delta.project_id))
        validate_store_document(projected_store)
        store_before = self._safe_raw_bytes(self.store_path)
        assert store_before is not None
        journal_path = case_journal_path(
            self.root,
            delta.project_id,
            delta.study_id,
            record.device_id,
            record.recorded_at[:7],
        )
        journal_before = self._safe_raw_bytes(journal_path)
        journal_payload = canonical_json_bytes(record.to_dict()) + b"\n"
        changes: dict[Path, bytes | None] = {
            self.store_path: canonical_json_bytes(projected_store) + b"\n",
            journal_path: (journal_before or b"") + journal_payload,
        }
        expected: dict[Path, bytes | None] = {
            self.store_path: store_before,
            journal_path: journal_before,
        }
        if not project_path.exists():
            changes[project_path] = canonical_json_bytes(selected_project.to_dict()) + b"\n"
            expected[project_path] = None
        if not study_path.exists():
            changes[study_path] = canonical_json_bytes(selected_study.to_dict()) + b"\n"
            expected[study_path] = None

        def post_apply() -> None:
            report = self.validate()
            if not report.valid:
                raise ValidationError("post-bootstrap Store validation failed: " + "; ".join(report.errors))

        raw_results = atomic_multi_write(
            changes,
            write=write,
            expected=expected,
            post_apply_validator=post_apply if write else None,
        )
        return tuple(
            WriteResult(
                "append" if result.path == journal_path else result.action,
                result.path,
                record.digest if result.path == journal_path else result.digest,
                len(journal_payload) if result.path == journal_path else result.bytes_count,
                result.written,
                "atomic thin Store Case bootstrap",
            )
            for result in raw_results
        )

    def append_case_record(
        self,
        record: CaseRecord,
        *,
        current_device: str | None,
        write: bool = False,
    ) -> WriteResult:
        """Preview or append one schema-2 Case record."""

        return self.append_case_records(
            (record,),
            current_device=current_device,
            write=write,
        )[0]

    def _safe_raw_bytes(self, path: Path) -> bytes | None:
        """Read one exact dependency byte state and fail closed on unsafe paths."""

        selected = path.absolute()
        for candidate in (selected, *selected.parents):
            if candidate.exists() and candidate.is_symlink():
                raise ConflictError(f"refusing symlinked lifecycle dependency: {selected}")
        if not selected.exists():
            return None
        if not selected.is_file():
            raise ConflictError(f"refusing non-regular lifecycle dependency: {selected}")
        try:
            return selected.read_bytes()
        except OSError as exc:
            raise ValidationError(f"cannot read lifecycle dependency {selected}: {exc}") from exc

    @staticmethod
    def _projected_validation(
        pre_validation: dict[str, object],
        *,
        active_delta: int,
        redirect_delta: int,
        deletion_delta: int,
        checked_delta: int,
    ) -> dict[str, object]:
        """Return the validated in-memory lifecycle projection summary."""

        result = copy.deepcopy(pre_validation)
        result["checked"] = int(result["checked"]) + checked_delta
        details = require_object(result["details"], "projected validation details")
        details["cases"] = int(details.get("cases", 0)) + active_delta
        details["case_redirects"] = int(details.get("case_redirects", 0)) + redirect_delta
        details["case_deletions"] = int(details.get("case_deletions", 0)) + deletion_delta
        return result

    def _validated_pre_lifecycle(self) -> dict[str, object]:
        report = self.validate().to_dict()
        if not report["valid"]:
            errors = report["errors"]
            raise ValidationError("Case lifecycle requires valid Store structure: " + "; ".join(errors))
        return report

    def _post_lifecycle_gate(self) -> None:
        report = self.validate()
        if not report.valid:
            raise ValidationError("post-apply Store validation failed: " + "; ".join(report.errors))

    def plan_journal_case_rename(
        self,
        source: str,
        target: str,
        *,
        record_id: str,
        device_id: str,
        recorded_at: str,
    ) -> JournalCaseLifecyclePlan:
        """Build one digest-bound journal rename plan."""

        if self.load_store()["schema_version"] not in {2, 3}:
            raise ValidationError("journal Case rename requires thin Store schema version 2")
        selected_source = validate_sim_id(source)
        selected_target = validate_sim_id(target)
        if selected_source == selected_target:
            raise ConflictError("Case rename source and destination must differ")
        source_state = self.case_state(selected_source)
        if source_state.get("authority") != "journal" or source_state["state"] != "active":
            raise ValidationError("schema-2 Case rename requires an active journal source")
        if self.case_state(selected_target)["state"] != "missing":
            raise ConflictError("Case rename destination identity is already reserved")
        head = self.case_head(selected_source)
        assert head is not None
        study = self.load_study(head.project_id, head.study_id)
        if selected_target == study.sim_prefix or not selected_target.startswith(study.sim_prefix + "/"):
            raise ConflictError("Case rename destination must remain a strict child of the source Study prefix")
        target_delta = CaseDelta.from_dict(
            {
                **head.delta.to_dict(),
                "sim_id": selected_target,
                "content": _rewrite_case_self_locators(
                    head.delta.content,
                    selected_source,
                    selected_target,
                ),
            }
        )
        project = self.load_project(head.project_id)
        profiles = {
            (reference.scope, reference.profile_id): self.load_profile(reference)
            for reference in project.profiles + study.profiles + target_delta.profiles
        }
        materialize_case(project, study, profiles, target_delta)
        record = CaseRecord.build_rename(
            selected_source,
            target_delta,
            previous_digest=head.delta_digest,
            record_id=record_id,
            device_id=device_id,
            recorded_at=recorded_at,
        )
        records = self.read_case_records()
        reduce_case_records((*records, record))
        pre = self._validated_pre_lifecycle()
        projected = self._projected_validation(
            pre,
            active_delta=0,
            redirect_delta=1,
            deletion_delta=0,
            checked_delta=1,
        )
        path = case_journal_path(
            self.root,
            head.project_id,
            head.study_id,
            record.device_id,
            record.recorded_at[:7],
        )
        return JournalCaseLifecyclePlan.build(
            action="rename",
            source=selected_source,
            target=selected_target,
            record=record,
            journal_path=path,
            journal_before=self._safe_raw_bytes(path),
            pre_validation=pre,
            projected_validation=projected,
        )

    def plan_journal_case_delete(
        self,
        sim_id: str,
        *,
        record_id: str,
        device_id: str,
        recorded_at: str,
    ) -> JournalCaseLifecyclePlan:
        """Build one digest-bound journal deletion plan."""

        if self.load_store()["schema_version"] not in {2, 3}:
            raise ValidationError("journal Case delete requires thin Store schema version 2")
        selected = validate_sim_id(sim_id)
        state = self.case_state(selected)
        if state.get("authority") != "journal" or state["state"] != "active":
            raise ValidationError("schema-2 Case delete requires an active journal source")
        head = self.case_head(selected)
        assert head is not None
        record = CaseRecord.build_delete(
            head.delta,
            previous_digest=head.delta_digest,
            record_id=record_id,
            device_id=device_id,
            recorded_at=recorded_at,
        )
        records = self.read_case_records()
        reduce_case_records((*records, record))
        pre = self._validated_pre_lifecycle()
        projected = self._projected_validation(
            pre,
            active_delta=-1,
            redirect_delta=0,
            deletion_delta=1,
            checked_delta=1,
        )
        path = case_journal_path(
            self.root,
            head.project_id,
            head.study_id,
            record.device_id,
            record.recorded_at[:7],
        )
        return JournalCaseLifecyclePlan.build(
            action="delete",
            source=selected,
            target=selected,
            record=record,
            journal_path=path,
            journal_before=self._safe_raw_bytes(path),
            pre_validation=pre,
            projected_validation=projected,
        )

    def apply_journal_case_lifecycle(
        self,
        plan: JournalCaseLifecyclePlan,
        *,
        expect_digest: str,
        current_device: str | None,
        write: bool = False,
    ) -> tuple[JournalCaseLifecyclePlan, WriteResult]:
        """Apply one freshly rebuilt journal lifecycle plan."""

        if current_device is None:
            raise DeviceIdentityError("current device_id is not configured")
        device = require_registered_device(self.root, current_device)
        if device != plan.record.device_id:
            raise DeviceIdentityError("Case lifecycle record differs from the current device")
        if validate_digest(expect_digest, "expect_digest") != plan.digest:
            raise ConflictError(f"Case {plan.action} plan digest is stale")
        if plan.action == "rename":
            rebuilt = self.plan_journal_case_rename(
                plan.source,
                plan.target,
                record_id=plan.record.record_id,
                device_id=device,
                recorded_at=plan.record.recorded_at,
            )
        elif plan.action == "delete":
            rebuilt = self.plan_journal_case_delete(
                plan.source,
                record_id=plan.record.record_id,
                device_id=device,
                recorded_at=plan.record.recorded_at,
            )
        else:
            raise ValidationError(f"unsupported journal lifecycle action: {plan.action}")
        if rebuilt.digest != plan.digest:
            raise ConflictError(f"Case {plan.action} dependencies changed after preview")
        before = self._safe_raw_bytes(rebuilt.journal_path)
        payload = canonical_json_bytes(rebuilt.record.to_dict()) + b"\n"
        result = atomic_multi_write(
            {rebuilt.journal_path: (before or b"") + payload},
            write=write,
            expected={rebuilt.journal_path: before},
            post_apply_validator=self._post_lifecycle_gate if write else None,
        )[0]
        return rebuilt, WriteResult(
            "append",
            result.path,
            rebuilt.record.digest,
            len(payload),
            result.written,
            "digest-bound Case journal lifecycle",
        )

    def rename_case(
        self,
        source: str,
        target: str,
        *,
        expect_digest: str | None = None,
        current_device: str | None = None,
        record_id: str | None = None,
        recorded_at: str | None = None,
        write: bool = False,
    ) -> tuple[JournalCaseLifecyclePlan, tuple[WriteResult, ...]]:
        """Preview or apply one freshly rebuilt digest-bound Case rename."""

        if current_device is None:
            raise DeviceIdentityError("current device_id is not configured")
        if record_id is None or recorded_at is None:
            raise ValidationError("journal Case rename requires record_id and recorded_at")
        plan = self.plan_journal_case_rename(
            source,
            target,
            record_id=record_id,
            device_id=current_device,
            recorded_at=recorded_at,
        )
        if not write:
            _, result = self.apply_journal_case_lifecycle(
                plan,
                expect_digest=plan.digest,
                current_device=current_device,
            )
            return plan, (result,)
        if expect_digest is None:
            raise ValidationError("Case rename --write requires --expect-digest")
        rebuilt, result = self.apply_journal_case_lifecycle(
            plan,
            expect_digest=expect_digest,
            current_device=current_device,
            write=True,
        )
        return rebuilt, (result,)

    def delete_case(
        self,
        sim_id: str,
        *,
        expect_digest: str | None = None,
        current_device: str | None = None,
        record_id: str | None = None,
        recorded_at: str | None = None,
        write: bool = False,
    ) -> tuple[JournalCaseLifecyclePlan, tuple[WriteResult, ...]]:
        """Preview or apply one freshly rebuilt digest-bound Case deletion."""

        if current_device is None:
            raise DeviceIdentityError("current device_id is not configured")
        if record_id is None or recorded_at is None:
            raise ValidationError("journal Case delete requires record_id and recorded_at")
        plan = self.plan_journal_case_delete(
            sim_id,
            record_id=record_id,
            device_id=current_device,
            recorded_at=recorded_at,
        )
        if not write:
            _, result = self.apply_journal_case_lifecycle(
                plan,
                expect_digest=plan.digest,
                current_device=current_device,
            )
            return plan, (result,)
        if expect_digest is None:
            raise ValidationError("Case delete --write requires --expect-digest")
        rebuilt, result = self.apply_journal_case_lifecycle(
            plan,
            expect_digest=expect_digest,
            current_device=current_device,
            write=True,
        )
        return rebuilt, (result,)

    def validate(self) -> ValidationReport:
        """Validate Store structure without changing authority or scientific status."""

        checked = 0
        errors: list[str] = []
        details: dict[str, object] = {}
        try:
            store = self.load_store()
            checked += 1
            project_ids = [str(value) for value in store["projects"]]
            actual_projects: set[str] = set()
            for project_id in project_ids:
                self.load_project(project_id)
                actual_projects.add(project_id)
                checked += 1
            for path in (self.root / "projects").rglob("PROJECT.json"):
                project = Project.from_dict(read_json(path))
                if path != self.project_path(project.project_id):
                    raise ConflictError("Project path and document identity conflict")
                actual_projects.add(project.project_id)
            if actual_projects != set(project_ids):
                raise ConflictError("Store project registry differs from Project documents")
            study_count = 0
            for path in (self.root / "studies").rglob("STUDY.json"):
                study = Study.from_dict(read_json(path))
                if path != self.study_path(study.project_id, study.study_id):
                    raise ConflictError("Study path and document identity conflict")
                study_count += 1
                checked += 1
            profile_count = 0
            for path in (self.root / "profiles").rglob("PROFILE.json"):
                profile = Profile.from_dict(read_json(path))
                if path != self.profile_path(profile.reference):
                    raise ConflictError("Profile path and document identity conflict")
                profile_count += 1
                checked += 1
            actual_devices: set[str] = set()
            for device_id in store["devices"]:
                document = validate_device_document(read_json(self.device_path(str(device_id))))
                if document["device_id"] != device_id:
                    raise ConflictError("Device path and document identity conflict")
                actual_devices.add(str(device_id))
                checked += 1
            for path in (self.root / "devices").glob("*.json"):
                document = validate_device_document(read_json(path))
                if path != self.device_path(str(document["device_id"])):
                    raise ConflictError("Device path and document identity conflict")
                actual_devices.add(str(document["device_id"]))
            if actual_devices != set(str(value) for value in store["devices"]):
                raise ConflictError("Store device registry differs from Device documents")
            states = self.list_case_state_ids()
            case_ids = states["active"]
            redirect_ids = states["renamed"]
            deletion_ids = states["deleted"]
            journal_heads = self.journal_case_heads()
            for sim_id in case_ids:
                delta = journal_heads[sim_id].delta
                assert delta is not None
                project = self.load_project(delta.project_id)
                study = self.load_study(delta.project_id, delta.study_id)
                references = project.profiles + study.profiles + delta.profiles
                profiles = {
                    (reference.scope, reference.profile_id): self.load_profile(reference)
                    for reference in references
                }
                materialize_case(project, study, profiles, delta)
                checked += 3
            for sim_id in redirect_ids:
                journal_head = journal_heads[sim_id]
                project_id = journal_head.project_id
                study_id = journal_head.study_id
                project = self.load_project(project_id)
                study = self.load_study(project_id, study_id)
                if project.project_id != study.project_id:
                    raise ConflictError("Case redirect Project and Study identities conflict")
                if sim_id == study.sim_prefix or not sim_id.startswith(study.sim_prefix + "/"):
                    raise ConflictError("Case redirect source is outside its Study sim_prefix")
                resolved = self.resolve_case_lineage(sim_id)
                if resolved["state"] not in {"active", "deleted"}:
                    raise ConflictError("Case redirect must terminate at an active or deleted identity")
                terminal = str(resolved["canonical_sim_id"])
                if resolved["state"] == "active":
                    terminal_delta = journal_heads[terminal].delta
                    assert terminal_delta is not None
                    terminal_identity = (terminal_delta.project_id, terminal_delta.study_id)
                else:
                    terminal_head = journal_heads[terminal]
                    terminal_identity = (terminal_head.project_id, terminal_head.study_id)
                if terminal_identity != (project_id, study_id):
                    raise ConflictError("Case redirect chain crosses Project or Study identity")
                checked += 3
            for sim_id in deletion_ids:
                journal_head = journal_heads[sim_id]
                project_id = journal_head.project_id
                study_id = journal_head.study_id
                self.load_project(project_id)
                study = self.load_study(project_id, study_id)
                if sim_id == study.sim_prefix or not sim_id.startswith(study.sim_prefix + "/"):
                    raise ConflictError("Case deletion identity is outside its Study sim_prefix")
                checked += 3
            events = self.read_events()
            authority_case_ids = set(case_ids + redirect_ids + deletion_ids)

            def event_identity(identity: str) -> str:
                resolved = self.resolve_case_lineage(identity)
                return identity if resolved["state"] == "missing" else str(resolved["canonical_sim_id"])

            validate_corrections(
                events,
                registered_case_ids=authority_case_ids,
                canonical_case_identity=event_identity,
            )
            checked += len(events)
            migrated_event_ids = {
                event.correction.corrects
                for event in events
                if event.correction is not None and event.correction.fields == ("/owner",)
            }
            orphan_events = [
                event
                for event in events
                if event.owner.kind == "case"
                and event.owner.identity not in authority_case_ids
                and event.event_id not in migrated_event_ids
            ]
            deleted_events = [
                event
                for event in events
                if event.owner.kind == "case"
                and event.owner.identity in authority_case_ids
                and self.resolve_case_lineage(event.owner.identity)["state"] == "deleted"
            ]
            diagnostics = [
                {
                    "code": "legacy-orphan-case-event",
                    "severity": "warning",
                    "event_id": event.event_id,
                    "sim_id": event.owner.identity,
                    "migration": "record future work under a registered Case or root owner; preserve existing stream bytes",
                }
                for event in orphan_events
            ]
            details = {
                "projects": len(project_ids),
                "studies": study_count,
                "profiles": profile_count,
                "devices": len(actual_devices),
                "cases": len(case_ids),
                "case_redirects": len(redirect_ids),
                "case_deletions": len(deletion_ids),
                "events": len(events),
                "orphan_case_events": len(orphan_events),
                "deleted_case_events": len(deleted_events),
                "migrated_orphan_case_events": len(migrated_event_ids),
                "diagnostics": diagnostics,
            }
        except ResearchWorkflowError as exc:
            errors.append(str(exc))
        return ValidationReport(not errors, checked, tuple(errors), details)


__all__ = [
    "DEVICE_SCHEMA",
    "JournalCaseLifecyclePlan",
    "STORE_SCHEMA",
    "Store",
    "validate_device_document",
    "validate_store_document",
]
