"""Read, reduce, and append device-owned Case journals."""

from __future__ import annotations

import os
from collections import defaultdict
from pathlib import Path
from typing import Iterable

from research_workflow.core.canonical import canonical_digest, canonical_json_bytes, decode_json
from research_workflow.core.errors import ConflictError, DeviceIdentityError, ValidationError
from research_workflow.core.ids import validate_device_id, validate_logical_id
from research_workflow.core.models import WriteResult
from research_workflow.core.time import recorded_month, validate_month
from research_workflow.domain.case_records import CaseRecord, reduce_case_records

from .jsonio import atomic_multi_write
from .devices import require_registered_device


def _encoded_id(value: str) -> str:
    return value.replace("/", "%2F")


def case_journal_study_path(
    metadata_root: str | os.PathLike[str],
    project_id: str,
    study_id: str,
) -> Path:
    """Return the collision-free journal directory for one Study."""

    project = validate_logical_id(project_id, "project_id")
    study = validate_logical_id(study_id, "study_id")
    return Path(metadata_root).absolute() / "case-journals" / _encoded_id(project) / _encoded_id(study)


def case_journal_path(
    metadata_root: str | os.PathLike[str],
    project_id: str,
    study_id: str,
    device_id: str,
    month: str,
) -> Path:
    """Return one canonical Study/device/month journal path."""

    device = validate_device_id(device_id)
    partition = validate_month(month)
    return (
        case_journal_study_path(metadata_root, project_id, study_id)
        / device
        / f"{partition}.jsonl"
    )


def read_case_journal(
    path: str | os.PathLike[str],
    *,
    project_id: str,
    study_id: str,
    device_id: str,
    month: str,
) -> list[CaseRecord]:
    """Read one canonical journal and enforce path identity."""

    selected = Path(path).absolute()
    metadata_root = _metadata_root(selected)
    expected = case_journal_path(metadata_root, project_id, study_id, device_id, month)
    if selected != expected:
        raise ValidationError(f"Case journal path identity conflict: {selected}")
    for candidate in (selected, *selected.parents):
        if candidate.exists() and candidate.is_symlink():
            raise ValidationError(f"Case journal paths must not use symlinks: {selected}")
    try:
        raw = selected.read_bytes()
    except OSError as exc:
        raise ValidationError(f"cannot read Case journal {selected}: {exc}") from exc
    if raw and not raw.endswith(b"\n"):
        raise ValidationError(f"Case journal has a truncated final line: {selected}")
    result: list[CaseRecord] = []
    for line_number, line in enumerate(raw.splitlines(), start=1):
        if not line:
            raise ValidationError(f"blank Case record line: {selected}:{line_number}")
        try:
            record = CaseRecord.from_dict(decode_json(line, require_canonical=True))
        except ValidationError as exc:
            raise ValidationError(f"invalid Case record {selected}:{line_number}: {exc}") from exc
        if record.device_id != device_id or recorded_month(record.recorded_at) != month:
            raise ConflictError(f"Case record stream identity conflict: {selected}:{line_number}")
        if (record.project_id, record.study_id) != (project_id, study_id):
            raise ConflictError(f"Case record Study identity conflict: {selected}:{line_number}")
        result.append(record)
    return result


def _metadata_root(path: Path) -> Path:
    for parent in path.parents:
        if parent.name == "case-journals":
            return parent.parent
    raise ValidationError(f"Case journal is outside case-journals: {path}")


def _read_unbound_case_journal(path: Path) -> list[CaseRecord]:
    if path.suffix != ".jsonl":
        raise ValidationError(f"invalid Case journal filename: {path}")
    device = validate_device_id(path.parent.name)
    month = validate_month(path.stem)
    root = _metadata_root(path)
    for candidate in (path, *path.parents):
        if candidate.exists() and candidate.is_symlink():
            raise ValidationError(f"Case journal paths must not use symlinks: {path}")
    try:
        raw = path.read_bytes()
    except OSError as exc:
        raise ValidationError(f"cannot read Case journal {path}: {exc}") from exc
    if raw and not raw.endswith(b"\n"):
        raise ValidationError(f"Case journal has a truncated final line: {path}")
    records: list[CaseRecord] = []
    for line_number, line in enumerate(raw.splitlines(), start=1):
        if not line:
            raise ValidationError(f"blank Case record line: {path}:{line_number}")
        try:
            record = CaseRecord.from_dict(decode_json(line, require_canonical=True))
        except ValidationError as exc:
            raise ValidationError(f"invalid Case record {path}:{line_number}: {exc}") from exc
        if record.device_id != device or recorded_month(record.recorded_at) != month:
            raise ConflictError(f"Case record stream identity conflict: {path}:{line_number}")
        expected = case_journal_path(
            root,
            record.project_id,
            record.study_id,
            device,
            month,
        )
        if path != expected:
            raise ConflictError(f"Case record Study identity conflict: {path}:{line_number}")
        records.append(record)
    return records


def merge_case_journals(paths: Iterable[str | os.PathLike[str]]) -> list[CaseRecord]:
    """Merge journals by exact record identity and validate all heads."""

    records: list[CaseRecord] = []
    selected_paths = sorted(Path(path).absolute() for path in paths)
    for raw_path in selected_paths:
        records.extend(_read_unbound_case_journal(raw_path))
    heads = reduce_case_records(records)
    for path in selected_paths:
        for record in _read_unbound_case_journal(path):
            if record.delta is not None:
                continue
            head = heads[record.sim_id]
            expected = case_journal_path(
                _metadata_root(path),
                head.project_id,
                head.study_id,
                record.device_id,
                recorded_month(record.recorded_at),
            )
            if path != expected:
                raise ConflictError(f"Case record Study identity conflict: {path}")
    return records


def _record_path(metadata_root: Path, record: CaseRecord) -> Path:
    return case_journal_path(
        metadata_root,
        record.project_id,
        record.study_id,
        record.device_id,
        recorded_month(record.recorded_at),
    )


def append_case_records(
    metadata_root: str | os.PathLike[str],
    records: Iterable[CaseRecord],
    *,
    current_device: str | None,
    existing_records: Iterable[CaseRecord] = (),
    write: bool = False,
) -> tuple[WriteResult, ...]:
    """Preview or append a validated batch without changing existing bytes."""

    if current_device is None:
        raise DeviceIdentityError("current device_id is not configured")
    device = validate_device_id(current_device)
    supplied = tuple(records)
    selected_by_id: dict[str, CaseRecord] = {}
    for record in supplied:
        existing = selected_by_id.get(record.record_id)
        if existing is not None and existing.to_dict() != record.to_dict():
            raise ConflictError(f"conflicting duplicate Case record ID: {record.record_id}")
        selected_by_id.setdefault(record.record_id, record)
    selected = tuple(selected_by_id.values())
    if not selected:
        raise ValidationError("Case record batch must not be empty")
    if any(record.action in {"migrate", "migrate-tombstone"} for record in selected):
        raise ValidationError("historical Case migration records are read-only")
    if any(record.device_id != device for record in selected):
        raise DeviceIdentityError("Case record device_id differs from the current device")
    require_registered_device(Path(metadata_root), device)
    current = tuple(existing_records)
    projected_heads = reduce_case_records((*current, *selected))
    root = Path(metadata_root).absolute()
    current_ids = {record.record_id: record for record in current}
    grouped: dict[Path, list[CaseRecord]] = defaultdict(list)
    reused: list[CaseRecord] = []
    for record in selected:
        existing = current_ids.get(record.record_id)
        if existing is not None:
            if existing.to_dict() != record.to_dict():
                raise ConflictError(f"conflicting duplicate Case record ID: {record.record_id}")
            reused.append(record)
            continue
        head = projected_heads.get(record.sim_id)
        if head is None:
            raise ConflictError(f"Case record requires a projected head: {record.sim_id}")
        path = _record_path(root, record)
        grouped[path].append(record)
    changes: dict[Path, bytes] = {}
    expected: dict[Path, bytes | None] = {}
    for path, additions in grouped.items():
        if path.exists():
            if path.is_symlink() or not path.is_file():
                raise ConflictError(f"refusing unsafe Case journal: {path}")
            before = path.read_bytes()
            if before and not before.endswith(b"\n"):
                raise ValidationError(f"Case journal has a truncated final line: {path}")
        else:
            before = b""
        payload = b"".join(canonical_json_bytes(record.to_dict()) + b"\n" for record in additions)
        expected[path] = before if path.exists() else None
        changes[path] = before + payload
    raw_results = {result.path: result for result in atomic_multi_write(changes, write=write, expected=expected)}
    results: list[WriteResult] = []
    for path, additions in sorted(grouped.items(), key=lambda item: str(item[0])):
        documents = [record.to_dict() for record in additions]
        digest = additions[0].digest if len(additions) == 1 else canonical_digest(documents)
        results.append(
            WriteResult(
                "append",
                path,
                digest,
                sum(len(canonical_json_bytes(document)) + 1 for document in documents),
                raw_results[path].written,
                "append-only Case journal batch",
            )
        )
    results.extend(
        WriteResult(
            "reuse",
            _record_path(root, record),
            record.digest,
            len(canonical_json_bytes(record.to_dict())) + 1,
            False,
            "equal Case record ID and bytes",
        )
        for record in reused
    )
    return tuple(results)


def append_case_record(
    metadata_root: str | os.PathLike[str],
    record: CaseRecord,
    *,
    current_device: str | None,
    existing_records: Iterable[CaseRecord] = (),
    write: bool = False,
) -> WriteResult:
    """Preview or append one Case record."""

    results = append_case_records(
        metadata_root,
        (record,),
        current_device=current_device,
        existing_records=existing_records,
        write=write,
    )
    return results[0]


__all__ = [
    "append_case_record",
    "append_case_records",
    "case_journal_path",
    "case_journal_study_path",
    "merge_case_journals",
    "read_case_journal",
]
