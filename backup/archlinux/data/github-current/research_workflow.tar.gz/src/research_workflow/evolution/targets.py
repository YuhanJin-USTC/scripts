"""Validate exact device target lifecycle records without file access."""

from dataclasses import dataclass
from pathlib import Path

from research_workflow.core.canonical import require_fields, require_string
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.core.ids import validate_device_id


@dataclass(frozen=True, slots=True)
class TargetChange:
    device_id: str
    path: str
    action: str
    replacement: str = ""

    @classmethod
    def from_dict(cls, item):
        required = {"kind", "device_id", "target", "action"}
        require_fields(item, required, "target change", {"replacement"})
        if item["kind"] != "target" or item["action"] not in {"retire", "reenable"}:
            raise ValidationError("policy schema 2 requires kind=target and retire or reenable")
        def path(value):
            text = require_string(value, "target path")
            selected = Path(text)
            if not selected.is_absolute() or ".." in selected.parts or selected.name != "AGENTS.md" or str(selected) != text:
                raise ValidationError("target paths must be exact normalized absolute AGENTS.md paths")
            return text
        target = path(item["target"])
        replacement = path(item["replacement"]) if "replacement" in item else ""
        if item["action"] == "retire":
            if not replacement or Path(replacement).parent not in Path(target).parent.parents:
                raise ValidationError("retirement replacement must be a strict ancestor AGENTS.md")
        elif replacement:
            raise ValidationError("reenable must not include a replacement")
        return cls(validate_device_id(item["device_id"]), target, item["action"], replacement)

    def to_dict(self):
        result = {"kind": "target", "device_id": self.device_id, "target": self.path, "action": self.action}
        if self.replacement:
            result["replacement"] = self.replacement
        return result

    @property
    def key(self):
        return self.device_id, self.path


def current_target_rules(rules):
    selected = tuple(rules)
    by_id = {rule.rule_id: rule for rule in selected}
    targets = tuple(rule for rule in selected if rule.target is not None)
    for rule in selected:
        if rule.target and len(rule.supersedes) > 1:
            raise ConflictError("target history cannot merge conflicting heads")
        for identity in rule.supersedes:
            previous = by_id.get(identity)
            if previous is None:
                if rule.target:
                    raise ConflictError("target history references a missing predecessor")
                continue
            if bool(rule.target) != bool(previous.target):
                raise ConflictError("policy and target rules cannot supersede each other")
            if rule.target and (rule.target.key != previous.target.key or rule.revision <= previous.revision):
                raise ConflictError("target supersedes must advance the same device/path history")
    superseded = {identity for rule in targets for identity in rule.supersedes}
    current = tuple(rule for rule in targets if rule.rule_id not in superseded)
    keys = [rule.target.key for rule in current]
    if len(keys) != len(set(keys)):
        raise ConflictError("conflicting target lifecycle heads for the same device/path")
    return current


def target_state(rules, device_id, path):
    return next((rule for rule in current_target_rules(rules) if rule.target.key == (device_id, str(path))), None)


def is_retired(rules, device_id, path):
    rule = target_state(rules, device_id, path)
    return rule is not None and rule.target.action == "retire"
