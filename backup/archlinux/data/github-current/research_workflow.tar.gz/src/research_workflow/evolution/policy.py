"""Define policy proposal, rule, resolution, and backlog authorities."""

from __future__ import annotations

import copy
import re
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Iterable

from research_workflow.core.canonical import (
    canonical_digest,
    require_fields,
    require_object,
    require_string,
    validate_json_value,
)
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.core.ids import validate_digest, validate_logical_id
from research_workflow.core.time import validate_utc
from research_workflow.storage.jsonio import read_json
from .targets import TargetChange, current_target_rules


PROPOSAL_SCHEMA = "research-workflow/policy-proposal"
RULE_SCHEMA = "research-workflow/policy-rule"
SCOPES = ("global", "role", "project", "subtree")
_SCOPE_RANK = {scope: index for index, scope in enumerate(SCOPES)}
_BACKLOG_ENTRY = re.compile(
    r"^## (?P<id>[^\n]+)\n"
    r"- Status: `(?P<status>[^`]+)`\n"
    r"- Scope: `(?P<scope>[^`]+)`\n"
    r"- Selector: `(?P<selector>[^`]+)`\n"
    r"- Digest: `(?P<digest>[0-9a-f]{64})`$",
    re.MULTILINE,
)


def _portable_id(value: object, label: str) -> str:
    result = validate_logical_id(value, label)
    if "/" in result:
        raise ValidationError(f"{label} must contain one portable component")
    return result


def _revision(value: object) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise ValidationError("policy revision must be a positive integer")
    return value


def _scope_selector(scope: object, selector: object) -> tuple[str, str]:
    selected_scope = require_string(scope, "policy scope")
    selected = require_string(selector, "policy selector")
    if selected_scope not in SCOPES:
        raise ValidationError("policy scope must be global, role, project, or subtree")
    if selected_scope == "global":
        if selected != "*":
            raise ValidationError("global policy selector must be *")
    elif selected_scope in {"role", "project"}:
        validate_logical_id(selected, f"{selected_scope} selector")
    else:
        path = Path(selected)
        if not path.is_absolute() or ".." in path.parts:
            raise ValidationError("subtree selector must be an absolute normalized path")
        selected = str(path.absolute())
    return selected_scope, selected


def _id_array(value: object, label: str) -> tuple[str, ...]:
    if not isinstance(value, list):
        raise ValidationError(f"{label} must be an array")
    result = tuple(_portable_id(item, label) for item in value)
    if len(set(result)) != len(result):
        raise ConflictError(f"{label} contains duplicate identities")
    return result


def _evidence(value: object) -> tuple[str, ...]:
    if not isinstance(value, list):
        raise ValidationError("policy evidence must be an array")
    result = tuple(require_string(item, "policy evidence") for item in value)
    if len(set(result)) != len(result):
        raise ConflictError("policy evidence must be unique")
    return result


def _content(value: object) -> dict[str, object]:
    result = copy.deepcopy(require_object(value, "policy content"))
    if not result:
        raise ValidationError("policy content must not be empty")
    for key in result:
        validate_logical_id(key, "policy content key")
    validate_json_value(result, "policy content")
    return result


def _parse_target(item, required, label, optional):
    if item.get("schema_version") == 2:
        required = (required - {"scope", "selector", "content"}) | {"kind", "device_id", "target", "action"}
        require_fields(item, required, label, optional | {"replacement"})
        return TargetChange.from_dict({key: item[key] for key in ("kind", "device_id", "target", "action", "replacement") if key in item})
    require_fields(item, required, label, optional)
    return None


def _target_payload(result, target):
    if target is not None:
        result["schema_version"] = 2
        for key in ("scope", "selector", "content"):
            result.pop(key)
        result.update(target.to_dict())


@dataclass(frozen=True, slots=True)
class Approval:
    """Represent an explicit pending, approved, or rejected human decision."""

    status: str
    actor: str = ""
    decided_at: str = ""
    authorized_targets: tuple[str, ...] = ()
    plan_digest: str = ""

    @classmethod
    def pending(cls) -> "Approval":
        """Return the canonical undecided approval value."""

        return cls("pending")

    @classmethod
    def from_dict(cls, value: object) -> "Approval":
        """Validate one approval decision without inferring an actor."""

        item = require_object(value, "policy approval")
        status = require_string(item.get("status"), "policy approval status")
        if status == "pending":
            require_fields(item, {"status"}, "policy approval")
            return cls.pending()
        if status not in {"approved", "rejected"}:
            raise ValidationError("policy approval status must be pending, approved, or rejected")
        required = {"status", "actor", "decided_at"}
        optional = {"authorized_targets", "plan_digest"} if status == "approved" else set()
        require_fields(item, required, "policy approval", optional)
        actor = require_string(item["actor"], "policy approval actor")
        decided_at = validate_utc(item["decided_at"], "policy approval decided_at")
        raw_targets = item.get("authorized_targets", [])
        if not isinstance(raw_targets, list):
            raise ValidationError("authorized_targets must be an array")
        targets: list[str] = []
        for raw in raw_targets:
            selected = Path(require_string(raw, "authorized target"))
            if not selected.is_absolute() or ".." in selected.parts:
                raise ValidationError("authorized targets must be absolute normalized paths")
            targets.append(str(selected.absolute()))
        if len(set(targets)) != len(targets):
            raise ConflictError("authorized_targets contains duplicate paths")
        plan_digest = validate_digest(item["plan_digest"], "approval plan_digest") if "plan_digest" in item else ""
        return cls(status, actor, decided_at, tuple(sorted(targets)), plan_digest)

    def to_dict(self) -> dict[str, object]:
        """Return the portable approval value."""

        if self.status == "pending":
            return {"status": "pending"}
        result: dict[str, object] = {
            "status": self.status,
            "actor": self.actor,
            "decided_at": self.decided_at,
        }
        if self.status == "approved":
            result["authorized_targets"] = list(self.authorized_targets)
            if self.plan_digest:
                result["plan_digest"] = self.plan_digest
        return result


@dataclass(frozen=True, slots=True)
class Proposal:
    """Represent one digest-bearing current policy proposal."""

    proposal_id: str
    status: str
    scope: str
    selector: str
    revision: int
    supersedes: tuple[str, ...]
    content: dict[str, object]
    evidence: tuple[str, ...]
    approval: Approval
    requested_targets: tuple[str, ...] = ()
    target: TargetChange | None = None

    @classmethod
    def from_dict(cls, value: object) -> "Proposal":
        """Validate a proposal and any supplied self-digest."""

        item = require_object(value, "Policy proposal")
        required = {
            "schema", "schema_version", "proposal_id", "status", "scope", "selector",
            "revision", "supersedes", "content", "evidence", "approval",
        }
        target = _parse_target(item, required, "Policy proposal", {"digest", "requested_targets"})
        if item["schema"] != PROPOSAL_SCHEMA or item["schema_version"] not in {1, 2}:
            raise ValidationError("Policy proposal must use schema version 1 or 2")
        scope, selector = ("subtree", target.path) if target else _scope_selector(item["scope"], item["selector"])
        approval = Approval.from_dict(item["approval"])
        status = require_string(item["status"], "Policy proposal status")
        expected_approval = {
            "open": "pending",
            "approved": "approved",
            "implemented": "approved",
            "rejected": "rejected",
        }
        if status not in expected_approval or approval.status != expected_approval[status]:
            raise ValidationError("Policy proposal status and approval decision conflict")
        requested = item.get("requested_targets", [])
        if not isinstance(requested, list):
            raise ValidationError("requested_targets must be an array")
        targets = []
        for raw in requested:
            selected = Path(require_string(raw, "requested target"))
            if not selected.is_absolute() or ".." in selected.parts or selected.name != "AGENTS.md":
                raise ValidationError("requested targets must be absolute normalized AGENTS.md paths")
            targets.append(str(selected.absolute()))
        if len(set(targets)) != len(targets):
            raise ConflictError("requested_targets contains duplicate paths")
        if approval.plan_digest and tuple(sorted(targets)) != approval.authorized_targets:
            raise ConflictError("approved targets differ from requested targets")
        proposal = cls(
            _portable_id(item["proposal_id"], "proposal_id"), status, scope, selector,
            _revision(item["revision"]), _id_array(item["supersedes"], "supersedes"),
            {} if target else _content(item["content"]), _evidence(item["evidence"]), approval, tuple(sorted(targets)), target,
        )
        if target and (not proposal.evidence or target.path not in proposal.requested_targets):
            raise ValidationError("target proposal requires evidence and its exact requested target")
        supplied = item.get("digest")
        if supplied is not None and validate_digest(supplied, "proposal digest") != proposal.digest:
            raise ConflictError("Policy proposal digest does not match canonical content")
        return proposal

    def _payload(self) -> dict[str, object]:
        result = {
            "schema": PROPOSAL_SCHEMA,
            "schema_version": 1,
            "proposal_id": self.proposal_id,
            "status": self.status,
            "scope": self.scope,
            "selector": self.selector,
            "revision": self.revision,
            "supersedes": list(self.supersedes),
            "content": copy.deepcopy(self.content),
            "evidence": list(self.evidence),
            "approval": self.approval.to_dict(),
        }
        _target_payload(result, self.target)
        if self.requested_targets:
            result["requested_targets"] = list(self.requested_targets)
        return result

    @property
    def digest(self) -> str:
        """Return the canonical digest excluding the self-digest field."""

        return canonical_digest(self._payload())

    @property
    def is_open(self) -> bool:
        """Return whether this proposal belongs in open-proposals authority."""

        return self.status in {"open", "approved"}

    def to_dict(self) -> dict[str, object]:
        """Return the canonical proposal document including its digest."""

        result = self._payload()
        result["digest"] = self.digest
        return result

    def approve(self, actor: str, decided_at: str, *, authorized_targets: Iterable[str] = (), plan_digest: str = "") -> "Proposal":
        """Return an explicitly human-approved proposal."""

        if self.status == "approved":
            return self
        if self.status != "open":
            raise ConflictError("only an open proposal can be approved")
        value = {
            "status": "approved", "actor": actor, "decided_at": decided_at,
            "authorized_targets": list(authorized_targets),
        }
        if plan_digest:
            value["plan_digest"] = plan_digest
        approval = Approval.from_dict(value)
        return replace(self, status="approved", approval=approval)

    def reject(self, actor: str, decided_at: str) -> "Proposal":
        """Return a rejected proposal that no longer belongs in the open set."""

        if not self.is_open:
            raise ConflictError("only an open proposal can be rejected")
        approval = Approval.from_dict({"status": "rejected", "actor": actor, "decided_at": decided_at})
        return replace(self, status="rejected", approval=approval)

    def implemented(self) -> "Proposal":
        """Return the implemented terminal transition after approval."""

        if self.status != "approved":
            raise ConflictError("only an approved proposal can be implemented")
        return replace(self, status="implemented")


@dataclass(frozen=True, slots=True)
class Rule:
    """Represent one active rule projected from an approved proposal."""

    rule_id: str
    proposal_id: str
    scope: str
    selector: str
    revision: int
    supersedes: tuple[str, ...]
    content: dict[str, object]
    evidence: tuple[str, ...]
    approval: Approval
    target: TargetChange | None = None

    @classmethod
    def from_proposal(cls, proposal: Proposal) -> "Rule":
        """Create one active rule only from an approved proposal."""

        if proposal.status not in {"approved", "implemented"} or proposal.approval.status != "approved":
            raise ConflictError("an active rule requires explicit proposal approval")
        return cls(
            proposal.proposal_id, proposal.proposal_id, proposal.scope, proposal.selector,
            proposal.revision, proposal.supersedes, copy.deepcopy(proposal.content),
            proposal.evidence, proposal.approval, proposal.target,
        )

    @classmethod
    def from_dict(cls, value: object) -> "Rule":
        """Validate an active rule and any supplied self-digest."""

        item = require_object(value, "Policy rule")
        required = {
            "schema", "schema_version", "rule_id", "proposal_id", "status", "scope",
            "selector", "revision", "supersedes", "content", "evidence", "approval",
        }
        target = _parse_target(item, required, "Policy rule", {"digest"})
        if item["schema"] != RULE_SCHEMA or item["schema_version"] not in {1, 2} or item["status"] != "active":
            raise ValidationError("Policy rule must be active schema version 1 or 2")
        scope, selector = ("subtree", target.path) if target else _scope_selector(item["scope"], item["selector"])
        approval = Approval.from_dict(item["approval"])
        if approval.status != "approved":
            raise ValidationError("active policy rule must retain explicit approval")
        rule = cls(
            _portable_id(item["rule_id"], "rule_id"),
            _portable_id(item["proposal_id"], "proposal_id"), scope, selector,
            _revision(item["revision"]), _id_array(item["supersedes"], "supersedes"),
            {} if target else _content(item["content"]), _evidence(item["evidence"]), approval, target,
        )
        if target and (not rule.evidence or target.path not in approval.authorized_targets or not approval.plan_digest):
            raise ValidationError("target rule requires evidence and an exact digest-bound approval")
        supplied = item.get("digest")
        if supplied is not None and validate_digest(supplied, "rule digest") != rule.digest:
            raise ConflictError("Policy rule digest does not match canonical content")
        return rule

    def _payload(self) -> dict[str, object]:
        result = {
            "schema": RULE_SCHEMA,
            "schema_version": 1,
            "rule_id": self.rule_id,
            "proposal_id": self.proposal_id,
            "status": "active",
            "scope": self.scope,
            "selector": self.selector,
            "revision": self.revision,
            "supersedes": list(self.supersedes),
            "content": copy.deepcopy(self.content),
            "evidence": list(self.evidence),
            "approval": self.approval.to_dict(),
        }
        _target_payload(result, self.target)
        return result

    @property
    def digest(self) -> str:
        """Return the canonical digest excluding the self-digest field."""

        return canonical_digest(self._payload())

    def to_dict(self) -> dict[str, object]:
        """Return the canonical active rule document."""

        result = self._payload()
        result["digest"] = self.digest
        return result


@dataclass(frozen=True, slots=True)
class PolicyContext:
    """Describe one exact allowlisted projection target for resolution."""

    path: Path
    role: str
    project: str


@dataclass(frozen=True, slots=True)
class EffectivePolicy:
    """Hold deterministic effective content and contributing rule identities."""

    content: dict[str, object]
    rule_ids: tuple[str, ...]

    @property
    def digest(self) -> str:
        """Return the managed-projection digest."""

        return canonical_digest({"content": self.content, "rule_ids": list(self.rule_ids)})

    def to_dict(self) -> dict[str, object]:
        """Return a read-only CLI representation."""

        return {"content": copy.deepcopy(self.content), "rule_ids": list(self.rule_ids), "digest": self.digest}


def _applies(rule: Rule, context: PolicyContext) -> bool:
    if rule.scope == "global":
        return True
    if rule.scope == "role":
        return rule.selector == context.role
    if rule.scope == "project":
        return rule.selector == context.project
    try:
        context.path.absolute().relative_to(Path(rule.selector))
    except ValueError:
        return False
    return True


def current_rules(rules: Iterable[Rule]) -> tuple[Rule, ...]:
    """Return active non-superseded rules and refuse duplicate identities."""

    selected = tuple(rules)
    current_target_rules(selected)
    identities = [rule.rule_id for rule in selected]
    if len(set(identities)) != len(identities):
        raise ConflictError("active rules contain duplicate identities")
    superseded = {identity for rule in selected for identity in rule.supersedes}
    current = tuple(rule for rule in selected if rule.rule_id not in superseded and rule.target is None)
    for index, left in enumerate(current):
        for right in current[index + 1 :]:
            if (left.scope, left.selector) != (right.scope, right.selector):
                continue
            overlap = sorted(set(left.content) & set(right.content))
            if overlap:
                raise ConflictError(
                    f"same-scope policy conflict for {overlap[0]}: {left.rule_id} and {right.rule_id}"
                )
    return current


def effective_policy(rules: Iterable[Rule], context: PolicyContext) -> EffectivePolicy:
    """Resolve global, role, project, and subtree precedence for one target."""

    applicable = [rule for rule in current_rules(rules) if _applies(rule, context)]
    by_rank: dict[int, list[Rule]] = {}
    for rule in applicable:
        by_rank.setdefault(_SCOPE_RANK[rule.scope], []).append(rule)
    content: dict[str, object] = {}
    ordered_ids: list[str] = []
    for rank in sorted(by_rank):
        owners: dict[str, str] = {}
        for rule in sorted(by_rank[rank], key=lambda item: item.rule_id):
            for key in rule.content:
                if key in owners:
                    raise ConflictError(f"same-scope policy conflict for {key}: {owners[key]} and {rule.rule_id}")
                owners[key] = rule.rule_id
            content.update(copy.deepcopy(rule.content))
            ordered_ids.append(rule.rule_id)
    return EffectivePolicy(content, tuple(ordered_ids))


def validate_rule_set(rules: Iterable[Rule], contexts: Iterable[PolicyContext]) -> None:
    """Validate identities and all allowlisted same-scope intersections."""

    selected = current_rules(rules)
    for context in contexts:
        effective_policy(selected, context)


def load_open_proposals(policy_root: str | Path) -> tuple[Proposal, ...]:
    """Load only current open proposal JSON authority in identity order."""

    directory = Path(policy_root).absolute() / "open-proposals"
    if not directory.exists():
        return ()
    proposals: list[Proposal] = []
    for path in sorted(directory.glob("*.json"), key=lambda item: item.name):
        proposal = Proposal.from_dict(read_json(path))
        if path.stem != proposal.proposal_id:
            raise ConflictError(f"proposal path and identity conflict: {path}")
        if not proposal.is_open:
            raise ConflictError(f"closed proposal stored in open authority: {path}")
        proposals.append(proposal)
    if len({item.proposal_id for item in proposals}) != len(proposals):
        raise ConflictError("open proposal identities must be unique")
    return tuple(proposals)


def load_active_rules(policy_root: str | Path) -> tuple[Rule, ...]:
    """Load only active rule JSON authority in identity order."""

    directory = Path(policy_root).absolute() / "rules"
    if not directory.exists():
        return ()
    rules: list[Rule] = []
    for path in sorted(directory.glob("*.json"), key=lambda item: item.name):
        rule = Rule.from_dict(read_json(path))
        if path.stem != rule.rule_id:
            raise ConflictError(f"rule path and identity conflict: {path}")
        rules.append(rule)
    current_rules(rules)
    return tuple(rules)


def open_proposal_records(proposals: Iterable[Proposal]) -> set[tuple[str, str, str, str]]:
    """Return the ID, status, scope, and digest set for current open proposals."""

    return {(item.proposal_id, item.status, item.scope, item.digest) for item in proposals if item.is_open}


def render_backlog(proposals: Iterable[Proposal]) -> str:
    """Render the non-authoritative Markdown view of current open proposals."""

    selected = sorted((item for item in proposals if item.is_open), key=lambda item: item.proposal_id)
    lines = ["# Evolution Backlog", "", "Generated from `policy/open-proposals/*.json`. Do not edit.", ""]
    if not selected:
        lines.append("No open proposals.")
        return "\n".join(lines) + "\n"
    for index, proposal in enumerate(selected):
        if index:
            lines.append("")
        lines.extend([
            f"## {proposal.proposal_id}", f"- Status: `{proposal.status}`",
            f"- Scope: `{proposal.scope}`", f"- Selector: `{proposal.selector}`",
            f"- Digest: `{proposal.digest}`",
        ])
    return "\n".join(lines) + "\n"


def backlog_record_set(markdown: str) -> set[tuple[str, str, str, str]]:
    """Extract the authoritative comparison fields from generated Markdown."""

    return {(match["id"], match["status"], match["scope"], match["digest"]) for match in _BACKLOG_ENTRY.finditer(markdown)}


def check_backlog_consistency(markdown: str, proposals: Iterable[Proposal]) -> bool:
    """Check exact rendering and ID/status/scope/digest set equality."""

    selected = tuple(proposals)
    return markdown == render_backlog(selected) and backlog_record_set(markdown) == open_proposal_records(selected)


__all__ = [
    "Approval", "EffectivePolicy", "PROPOSAL_SCHEMA", "PolicyContext", "Proposal",
    "RULE_SCHEMA", "Rule", "SCOPES", "backlog_record_set", "check_backlog_consistency",
    "current_rules", "effective_policy", "load_active_rules", "load_open_proposals",
    "open_proposal_records", "render_backlog", "validate_rule_set",
]
