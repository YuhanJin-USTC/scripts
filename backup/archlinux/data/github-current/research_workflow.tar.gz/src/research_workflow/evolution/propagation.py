"""Plan, apply, and check digest-bound policy projections."""

from __future__ import annotations

import argparse
import difflib
import json
import os
from dataclasses import dataclass, replace
from hashlib import sha256
from pathlib import Path
from typing import Iterable

from research_workflow.core.canonical import canonical_digest, canonical_json_bytes
from research_workflow.core.errors import AccessError, ConflictError, UnsupportedOperationError, ValidationError
from research_workflow.core.ids import validate_device_id, validate_digest, validate_logical_id
from research_workflow.storage.jsonio import atomic_multi_write, read_json
from research_workflow.workspace.registry import WorkspaceRegistry

from .targets import TargetChange, current_target_rules, is_retired, target_state
from research_workflow.storage.compatibility import require_compatible
from research_workflow.storage.devices import require_registered_device
from research_workflow.storage.locking import authority_lock

from .policy import (
    Approval,
    EffectivePolicy,
    PolicyContext,
    Proposal,
    Rule,
    check_backlog_consistency,
    current_rules,
    effective_policy,
    load_active_rules,
    load_open_proposals,
    render_backlog,
    validate_rule_set,
)


MANAGED_START = "<!-- research-workflow:policy:start -->"
MANAGED_END = "<!-- research-workflow:policy:end -->"


def _bytes_digest(payload: bytes) -> str:
    return sha256(payload).hexdigest()


def _read_target(path: Path) -> bytes | None:
    for parent in (path, *path.parents):
        if parent.is_symlink():
            raise ConflictError(f"refusing symlinked policy target: {path}")
    if not path.exists():
        return None
    if not path.is_file():
        raise ConflictError(f"refusing non-regular policy target: {path}")
    try:
        return path.read_bytes()
    except OSError as exc:
        raise ValidationError(f"cannot read policy target {path}: {exc}") from exc


@dataclass(frozen=True, slots=True)
class PolicyTarget:
    """Describe one exact allowlisted AGENTS.md projection target."""

    path: Path
    role: str
    project: str
    separate_approval: bool = False

    def __post_init__(self) -> None:
        selected = self.path
        if selected.name != "AGENTS.md" or not selected.is_absolute() or ".." in selected.parts:
            raise ValidationError("policy targets must be absolute AGENTS.md paths")
        validate_logical_id(self.role, "policy target role")
        validate_logical_id(self.project, "policy target project")
        object.__setattr__(self, "path", selected)

    @property
    def context(self) -> PolicyContext:
        """Return the domain-only resolution context."""

        return PolicyContext(self.path, self.role, self.project)

    def to_dict(self) -> dict[str, object]:
        """Return a read-only target description."""

        return {
            "path": str(self.path),
            "role": self.role,
            "project": self.project,
            "separate_approval": self.separate_approval,
        }


class TargetAllowlist:
    """Hold the complete exact target set available to one policy service."""

    def __init__(self, targets: Iterable[PolicyTarget]):
        """Validate unique explicit AGENTS.md targets without creating them."""

        selected = tuple(sorted(targets, key=lambda item: str(item.path)))
        paths = [item.path for item in selected]
        if len(set(paths)) != len(paths):
            raise ConflictError("policy target allowlist contains duplicate paths")
        for target in selected:
            _read_target(target.path)
        self.targets = selected

    @classmethod
    def from_workspace(cls, workspace: WorkspaceRegistry) -> "TargetAllowlist":
        """Use only the explicit device-local access boundary."""

        if not workspace.policy_targets:
            raise AccessError("policy operations require explicit policy.targets; automatic discovery is disabled")
        return cls(PolicyTarget(Path(str(item["path"])), str(item["role"]),
            str(item["project"]), bool(item["separate_approval"]))
            for item in workspace.policy_targets)

    @property
    def contexts(self) -> tuple[PolicyContext, ...]:
        """Return all domain resolution contexts in stable order."""

        return tuple(target.context for target in self.targets)

    def exact(self, path: str | os.PathLike[str]) -> PolicyTarget:
        """Return one exact target or refuse scope expansion."""

        selected = Path(path).absolute()
        for target in self.targets:
            if target.path == selected:
                return target
        raise AccessError(f"policy target is outside the exact allowlist: {selected}")


def render_managed_block(policy: EffectivePolicy) -> bytes:
    """Render one deterministic managed block from effective active rules."""

    if not policy.content:
        return b""
    lines = [
        MANAGED_START,
        f"<!-- digest: {policy.digest} -->",
        "## Managed Research Workflow Policy",
        "",
    ]
    for key in sorted(policy.content):
        value = json.dumps(
            policy.content[key],
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        lines.append(f"- `{key}`: {value}")
    lines.extend(["", MANAGED_END])
    return ("\n".join(lines) + "\n").encode("utf-8")


def project_managed_block(existing: bytes | None, policy: EffectivePolicy) -> bytes:
    """Replace only the managed block while preserving every outside byte."""

    original = existing or b""
    start_marker = MANAGED_START.encode("utf-8")
    end_marker = MANAGED_END.encode("utf-8")
    starts = [index for index in range(len(original)) if original.startswith(start_marker, index)]
    ends = [index for index in range(len(original)) if original.startswith(end_marker, index)]
    if len(starts) != len(ends) or len(starts) > 1:
        raise ConflictError("AGENTS.md must contain zero or one complete managed policy block")
    block = render_managed_block(policy)
    if not starts:
        if not block:
            return original
        separator = b"" if not original or original.endswith(b"\n") else b"\n"
        return original + separator + block
    start = starts[0]
    end = ends[0] + len(end_marker)
    if end < start:
        raise ConflictError("AGENTS.md managed policy markers are reversed")
    if end < len(original) and original[end : end + 1] == b"\n":
        end += 1
    return original[:start] + block + original[end:]


@dataclass(frozen=True, slots=True)
class PlanChange:
    """Describe one exact before/after file projection and unified diff."""

    path: Path
    kind: str
    action: str
    before_exists: bool
    after_exists: bool
    before_digest: str
    after_digest: str
    diff: str

    def to_dict(self) -> dict[str, object]:
        """Return the canonical digest input for one file change."""

        return {
            "path": str(self.path),
            "kind": self.kind,
            "action": self.action,
            "before_exists": self.before_exists,
            "after_exists": self.after_exists,
            "before_digest": self.before_digest,
            "after_digest": self.after_digest,
            "diff": self.diff,
        }


def _unified_diff(path: Path, before: bytes | None, after: bytes | None) -> str:
    try:
        old = (before or b"").decode("utf-8").splitlines(keepends=True)
        new = (after or b"").decode("utf-8").splitlines(keepends=True)
    except UnicodeDecodeError as exc:
        raise ValidationError(f"policy target must be UTF-8 text: {path}") from exc
    return "".join(
        difflib.unified_diff(
            old,
            new,
            fromfile=str(path) + ":before",
            tofile=str(path) + ":after",
        )
    )


def _change(path: Path, kind: str, before: bytes | None, after: bytes | None) -> PlanChange:
    if before == after:
        action = "reuse"
    elif after is None:
        action = "delete"
    elif before is None:
        action = "create"
    else:
        action = "replace"
    return PlanChange(
        path,
        kind,
        action,
        before is not None,
        after is not None,
        _bytes_digest(before or b""),
        _bytes_digest(after or b""),
        _unified_diff(path, before, after),
    )


@dataclass(frozen=True, slots=True)
class PropagationPlan:
    """Bind exact file diffs to one approved proposal and canonical digest."""

    proposal_id: str
    proposal_digest: str
    rule_digest: str
    changes: tuple[PlanChange, ...]
    authorization: dict[str, object]

    def _payload(self) -> dict[str, object]:
        return {
            "schema": "research-workflow/policy-plan",
            "schema_version": 3,
            "proposal_id": self.proposal_id,
            "proposal_digest": self.proposal_digest,
            "rule_digest": self.rule_digest,
            "changes": [item.to_dict() for item in self.changes],
            "authorization": self.authorization,
        }

    @property
    def digest(self) -> str:
        """Return the approval digest over all exact paths and diffs."""

        return canonical_digest(self.authorization)

    def to_dict(self) -> dict[str, object]:
        """Return the complete read-only plan and phase metrics."""

        result = self._payload()
        result["digest"] = self.digest
        result["metrics"] = {
            "files": len(self.changes),
            "targets": sum(item.kind == "managed-target" for item in self.changes),
            "mutations": sum(item.action != "reuse" for item in self.changes),
        }
        return result


class PolicyApplicationService:
    """Coordinate policy authorities and managed projections for one workspace."""

    def __init__(self, project_root: str | os.PathLike[str], targets: TargetAllowlist):
        """Bind exact policy and backlog paths without creating either."""

        self.project_root = Path(project_root).absolute()
        self.policy_root = self.project_root / "policy"
        self.backlog_path = self.project_root / "EVOLUTION_BACKLOG.md"
        self.targets = targets
        self.workspace = None

    @classmethod
    def from_workspace(cls, workspace: WorkspaceRegistry) -> "PolicyApplicationService":
        """Build the service from registered roots and existing AGENTS.md targets."""

        service = cls(workspace.project_root, TargetAllowlist.from_workspace(workspace))
        service.workspace = workspace
        return service

    def _runtime_binding(self, *, target_lifecycle=False):
        if self.workspace is None:
            return {}
        workspace = WorkspaceRegistry(self.workspace.config_path)
        current = TargetAllowlist.from_workspace(workspace)
        if [item.to_dict() for item in current.targets] != [item.to_dict() for item in self.targets.targets]:
            raise ConflictError("policy allowlist changed; rebuild the service and preview")
        from research_workflow.storage.store import Store
        store = Store(workspace.metadata_root)
        document = store.load_store()
        compatible = require_compatible(document, target_lifecycle=target_lifecycle)
        device_id = require_registered_device(store.root, workspace.require_device())
        return {"device_id": device_id, "workspace": workspace.data,
            "workspace_path": str(workspace.config_path),
            "workspace_digest": _bytes_digest(workspace.config_path.read_bytes()),
            "store_path": str(store.store_path),
            "store_digest": _bytes_digest(store.store_path.read_bytes()),
            "device_path": str(store.device_path(device_id)),
            "device_digest": _bytes_digest(store.device_path(device_id).read_bytes()),
            "compatibility": compatible}

    def _target_context(self, change, rules):
        runtime = self._runtime_binding(target_lifecycle=True)
        if not runtime or change.device_id != runtime["device_id"]:
            raise AccessError("target lifecycle belongs to one configured registered device")
        target = self.targets.exact(change.path)
        if change.action != "retire":
            return None
        replacement = self.targets.exact(change.replacement)
        workspace = WorkspaceRegistry(self.workspace.config_path)
        def owner(path):
            matches = [root for root in workspace.roots.values() if path.is_relative_to(root.path)]
            if not matches:
                raise AccessError("target lifecycle requires an exact registered root")
            return max(matches, key=lambda root: len(root.path.parts))
        if owner(target.path).root_id != owner(replacement.path).root_id:
            raise AccessError("retirement replacement must belong to the same registered root")
        if is_retired(rules, change.device_id, replacement.path):
            raise ConflictError("retirement replacement is itself retired")
        parent = _read_target(replacement.path)
        parent_policy = effective_policy(rules, replacement.context)
        child_policy = effective_policy(rules, target.context)
        if parent is None or parent != project_managed_block(parent, parent_policy):
            raise ConflictError("replacement must have a verified current managed block")
        if parent_policy.content != child_policy.content:
            raise ConflictError("replacement has incompatible effective policy")
        return {"target": replacement.to_dict(), "digest": _bytes_digest(parent),
            "content": parent.decode("utf-8"), "policy": parent_policy.to_dict()}

    def propose_target(self, path, *, action, replacement="", proposal_id, evidence, write=False):
        runtime = self._runtime_binding(target_lifecycle=True)
        change = TargetChange.from_dict({"kind": "target", "device_id": runtime.get("device_id"),
            "target": str(path), "action": action, **({"replacement": replacement} if replacement else {})})
        rules = load_active_rules(self.policy_root)
        self._target_context(change, rules)
        current = target_state(rules, change.device_id, change.path)
        if action == "reenable" and (current is None or current.target.action != "retire"):
            raise ConflictError("reenable requires a currently retired target")
        if action == "retire" and current and current.target.action == "retire":
            raise ConflictError("target is already retired")
        proposal = Proposal.from_dict({"schema": "research-workflow/policy-proposal", "schema_version": 2,
            "proposal_id": proposal_id, "status": "open", **change.to_dict(),
            "revision": current.revision + 1 if current else 1,
            "supersedes": [current.rule_id] if current else [], "evidence": list(evidence),
            "approval": {"status": "pending"},
            "requested_targets": sorted({change.path, *(current.approval.authorized_targets if current else ())})})
        return self.propose(proposal, device_id=change.device_id, write=write)

    def _approval_dependencies(self, plan):
        runtime = plan.authorization.get("runtime", {})
        expected = {runtime[f"{key}_path"]: runtime[f"{key}_digest"]
            for key in ("workspace", "store", "device") if f"{key}_path" in runtime}
        replacement = plan.authorization.get("replacement")
        if replacement:
            expected[replacement["target"]["path"]] = replacement["digest"]
        expected.update(plan.authorization.get("front_state", {}))
        result = {}
        for path, digest in expected.items():
            payload = _read_target(Path(path))
            if ("absent" if payload is None else _bytes_digest(payload)) != digest:
                raise ConflictError("policy dependency changed after plan construction")
            result[Path(path)] = payload
        return result

    def _completed_replay(self, proposal_id, digest, *, write):
        receipt_path = self.project_root / ".research-workflow" / "policy-plans" / f"{digest}.json"
        if _read_target(receipt_path) is None:
            return None
        receipt = read_json(receipt_path)
        rule = next((item for item in load_active_rules(self.policy_root) if item.proposal_id == proposal_id), None)
        if rule is None or rule.approval.plan_digest != digest or receipt.get("proposal_id") != proposal_id:
            raise ConflictError("policy replay receipt does not match completed approval")
        if receipt.get("runtime") != self._runtime_binding(target_lifecycle=rule.target is not None):
            raise ConflictError("policy replay dependencies changed")
        for path, expected in {**receipt["files"], **receipt["dependencies"]}.items():
            current = _read_target(Path(path))
            if ("absent" if current is None else _bytes_digest(current)) != expected:
                raise ConflictError("policy replay completed state changed")
        if not self.check()["valid"]:
            raise ConflictError("policy replay requires matching completed projections")
        return {"mode": "write" if write else "preview", "action": "reuse", "digest": digest, "operations": []}

    def apply(self, proposal_id, *, expect_digest, device_id, write=False):
        if write:
            with authority_lock(self.project_root / "metadata"):
                return self._apply(proposal_id, expect_digest=expect_digest, device_id=device_id, write=True)
        return self._apply(proposal_id, expect_digest=expect_digest, device_id=device_id, write=False)

    def _proposal_path(self, proposal_id: str) -> Path:
        selected = validate_logical_id(proposal_id, "proposal_id")
        if "/" in selected:
            raise ValidationError("proposal_id must contain one portable component")
        return self.policy_root / "open-proposals" / f"{selected}.json"

    def _rule_path(self, rule_id: str) -> Path:
        selected = validate_logical_id(rule_id, "rule_id")
        if "/" in selected:
            raise ValidationError("rule_id must contain one portable component")
        return self.policy_root / "rules" / f"{selected}.json"

    def _backlog_bytes(self, proposals: Iterable[Proposal]) -> bytes:
        return render_backlog(proposals).encode("utf-8")

    def propose(self, proposal: Proposal, *, device_id: str, write: bool = False) -> dict[str, object]:
        """Preview or create one open proposal and its generated backlog view."""

        validate_device_id(device_id)
        if proposal.target is not None:
            self._target_context(proposal.target, load_active_rules(self.policy_root))
        if not proposal.is_open:
            raise ConflictError("only open or approved proposals may enter open authority")
        open_proposals = list(load_open_proposals(self.policy_root))
        rules = load_active_rules(self.policy_root)
        active = next((rule for rule in rules if rule.proposal_id == proposal.proposal_id), None)
        if active is not None:
            if proposal.revision <= active.revision:
                raise ConflictError("active policy reauthorization requires a higher revision")
            stable = (
                proposal.scope == active.scope
                and proposal.selector == active.selector
                and proposal.supersedes == active.supersedes
                and proposal.content == active.content
                and proposal.target == active.target
            )
            if not stable:
                raise ConflictError("active policy reauthorization must preserve rule behavior")
        existing = next((item for item in open_proposals if item.proposal_id == proposal.proposal_id), None)
        if existing is not None and existing.to_dict() != proposal.to_dict():
            raise ConflictError("open proposal identity already exists with different content")
        if existing is None:
            open_proposals.append(proposal)
        changes = {
            self._proposal_path(proposal.proposal_id): canonical_json_bytes(proposal.to_dict()) + b"\n",
            self.backlog_path: self._backlog_bytes(open_proposals),
        }
        expected = {path: _read_target(path) for path in changes}
        results = atomic_multi_write(changes, write=write, expected=expected)
        return {
            "mode": "write" if write else "preview",
            "proposal": proposal.to_dict(),
            "operations": [item.to_dict() for item in results],
        }

    def approve(
        self,
        proposal_id: str,
        actor: str,
        decided_at: str,
        *,
        device_id: str,
        expect_digest: str,
        write: bool = False,
    ) -> dict[str, object]:
        """Preview or persist an explicit human approval transition."""

        validate_device_id(device_id)
        proposals = list(load_open_proposals(self.policy_root))
        proposal = next((item for item in proposals if item.proposal_id == proposal_id), None)
        if proposal is None:
            raise ValidationError(f"open proposal not found: {proposal_id}")
        expected = validate_digest(expect_digest, "expect_digest")
        plan = self.plan(proposal_id)
        if plan.digest != expected:
            raise ConflictError("expected policy plan digest is stale")
        if proposal.status == "approved" and proposal.approval.plan_digest != expected:
            raise ConflictError("existing approval does not bind this plan; prepare a new unique proposal ID")
        approved = proposal.approve(actor, decided_at,
            authorized_targets=proposal.requested_targets, plan_digest=expected)
        proposals[proposals.index(proposal)] = approved
        changes = {
            self._proposal_path(proposal_id): canonical_json_bytes(approved.to_dict()) + b"\n",
            self.backlog_path: self._backlog_bytes(proposals),
        }
        expected = {path: _read_target(path) for path in changes}
        results = atomic_multi_write(changes, write=write, expected=expected)
        return {
            "mode": "write" if write else "preview",
            "proposal": approved.to_dict(),
            "plan_digest": plan.digest,
            "operations": [item.to_dict() for item in results],
        }

    def reject(
        self,
        proposal_id: str,
        actor: str,
        decided_at: str,
        *,
        device_id: str,
        write: bool = False,
    ) -> dict[str, object]:
        """Preview or remove a rejected proposal from current open authority."""

        validate_device_id(device_id)
        proposals = list(load_open_proposals(self.policy_root))
        proposal = next((item for item in proposals if item.proposal_id == proposal_id), None)
        if proposal is None:
            raise ValidationError(f"open proposal not found: {proposal_id}")
        rejected = proposal.reject(actor, decided_at)
        remaining = [item for item in proposals if item.proposal_id != proposal_id]
        changes = {
            self._proposal_path(proposal_id): None,
            self.backlog_path: self._backlog_bytes(remaining),
        }
        expected = {path: _read_target(path) for path in changes}
        results = atomic_multi_write(changes, write=write, expected=expected)
        return {
            "mode": "write" if write else "preview",
            "proposal": rejected.to_dict(),
            "operations": [item.to_dict() for item in results],
        }

    def _authorized_targets(self, approval_paths: tuple[str, ...], selected: Iterable[PolicyTarget]) -> None:
        approved = set(approval_paths)
        for target in selected:
            if target.separate_approval and str(target.path) not in approved:
                raise AccessError(f"Data/Notes policy target requires separate approval: {target.path}")

    def _build_plan(
        self,
        proposal_id: str,
    ) -> tuple[PropagationPlan, dict[Path, bytes | None], dict[Path, bytes | None]]:
        proposals = list(load_open_proposals(self.policy_root))
        rules = list(load_active_rules(self.policy_root))
        proposal = next((item for item in proposals if item.proposal_id == proposal_id), None)
        existing_rule = next((item for item in rules if item.proposal_id == proposal_id), None)
        if proposal is None and existing_rule is None:
            raise ValidationError(f"proposal or active rule not found: {proposal_id}")
        if proposal is not None:
            if proposal.status == "open":
                rule = Rule(proposal.proposal_id, proposal.proposal_id, proposal.scope,
                    proposal.selector, proposal.revision, proposal.supersedes,
                    proposal.content, proposal.evidence, Approval.pending(), proposal.target)
            else:
                rule = Rule.from_proposal(proposal)
            proposal_digest = proposal.digest
            before_rules = tuple(rules)
            after_rules = tuple(
                item for item in rules if item.rule_id != rule.rule_id
            ) + (rule,)
            remaining = [item for item in proposals if item.proposal_id != proposal_id]
        else:
            rule = existing_rule
            assert rule is not None
            proposal_digest = rule.digest
            before_rules = tuple(rules)
            after_rules = tuple(rules)
            remaining = proposals
        validate_rule_set(after_rules, self.targets.contexts)

        runtime = self._runtime_binding(target_lifecycle=any(item.target for item in after_rules))
        device_id = runtime.get("device_id", "")
        replacement = self._target_context(rule.target, before_rules) if rule.target else None
        affected: list[PolicyTarget] = []
        if rule.target:
            affected = [self.targets.exact(rule.target.path)]
            previous = target_state(before_rules, device_id, rule.target.path)
            if proposal is not None:
                expected_heads = (previous.rule_id,) if previous else ()
                if rule.supersedes != expected_heads:
                    raise ConflictError("target proposal does not supersede the current exact head")
                if rule.target.action == "reenable" and (previous is None or previous.target.action != "retire"):
                    raise ConflictError("reenable requires a currently retired target")
                if rule.target.action == "retire" and previous and previous.target.action == "retire":
                    raise ConflictError("target is already retired")
        else:
            for target in self.targets.targets:
                if is_retired(after_rules, device_id, target.path):
                    continue
                before = effective_policy(before_rules, target.context)
                after = effective_policy(after_rules, target.context)
                if before.to_dict() != after.to_dict() or rule.rule_id in after.rule_ids:
                    affected.append(target)
        if proposal is not None and not affected:
            raise AccessError("approved proposal matches no exact allowlisted target")
        requested = proposal.requested_targets if proposal is not None else ()
        if proposal is not None and (proposal.status == "open" or proposal.approval.plan_digest):
            if not proposal.evidence:
                raise AccessError("policy proposal requires direct evidence")
            inherited = {path for old in rules
                if old.rule_id in set(proposal.supersedes) | {proposal.proposal_id}
                for path in old.approval.authorized_targets}
            required = inherited | {str(target.path) for target in affected}
            if not required.issubset(requested):
                raise AccessError("requested_targets must retain prior approvals and include every affected local target")
        else:
            self._authorized_targets(rule.approval.authorized_targets, affected)

        payloads: dict[Path, bytes | None] = {}
        kinds: dict[Path, str] = {}
        rule_path = self._rule_path(rule.rule_id)
        payloads[rule_path] = canonical_json_bytes(rule.to_dict()) + b"\n"
        kinds[rule_path] = "active-rule"
        if proposal is not None:
            proposal_path = self._proposal_path(proposal_id)
            payloads[proposal_path] = None
            kinds[proposal_path] = "open-proposal"
        payloads[self.backlog_path] = self._backlog_bytes(remaining)
        kinds[self.backlog_path] = "backlog-view"
        for target in affected:
            current = _read_target(target.path)
            if is_retired(after_rules, device_id, target.path):
                if proposal is not None:
                    expected_block = project_managed_block(current, effective_policy(before_rules, target.context))
                    if current != expected_block:
                        raise ConflictError("retirement requires a verified current managed block")
                projected = project_managed_block(current, EffectivePolicy({}, ())) if current is not None else None
            else:
                projected = project_managed_block(current, effective_policy(after_rules, target.context))
            payloads[target.path] = projected
            kinds[target.path] = "managed-target"

        originals = {path: _read_target(path) for path in payloads}
        changes = tuple(
            _change(path, kinds[path], originals[path], payloads[path])
            for path in sorted(payloads, key=str)
        )
        # Human bookkeeping does not alter the reviewed mutation intent.
        intent = rule.to_dict()
        for key in ("approval", "digest"):
            intent.pop(key, None)
        candidate = replace(proposal, status="open", approval=Approval.pending()) if proposal else None
        normalized_proposals = tuple(candidate if item.proposal_id == proposal_id else item for item in proposals)
        current_backlog = _read_target(self.backlog_path)
        if current_backlog is not None and current_backlog != self._backlog_bytes(proposals):
            raise ConflictError("policy backlog differs from proposal authority")
        authorization = {
            "schema": "research-workflow/policy-authorization", "schema_version": 2,
            "runtime": runtime,
            "target_states": [item.to_dict() for item in current_target_rules(before_rules)],
            "replacement": replacement or {},
            "front_state": {str(path): "absent" if data is None else _bytes_digest(data)
                for path, data in ((path, _read_target(path)) for path in (
                    *(target.path for target in self.targets.targets),
                    *(self._rule_path(item.rule_id) for item in before_rules)))},
            "candidate": intent,
            "authorized_targets": list(requested or rule.approval.authorized_targets),
            "local_targets": [target.to_dict() for target in self.targets.targets],
            "base_rules": [item.to_dict() for item in before_rules],
            "open_proposals": [item.to_dict() for item in normalized_proposals],
            "backlog_before_exists": current_backlog is not None,
            "backlog_before_digest": _bytes_digest(self._backlog_bytes(normalized_proposals)) if current_backlog is not None else "absent",
            "projections": [item.to_dict() for item in changes if item.kind in {"managed-target", "superseded-rule"}],
            "rule_path": str(rule_path),
            "rule_before_digest": _bytes_digest(originals[rule_path] or b""),
            "rule_before_exists": originals[rule_path] is not None,
            "proposal_path": str(self._proposal_path(proposal_id)) if proposal else "not-applicable",
            "backlog_path": str(self.backlog_path),
            "backlog_after": self._backlog_bytes(remaining).decode("utf-8"),
        }
        plan = PropagationPlan(proposal_id, proposal_digest, rule.digest, changes, authorization)
        return plan, payloads, originals

    def plan(self, proposal_id: str) -> PropagationPlan:
        """Return exact read-only diffs and the canonical approval digest."""

        return self._build_plan(proposal_id)[0]

    def _apply(
        self,
        proposal_id: str,
        *,
        expect_digest: str,
        device_id: str,
        write: bool = False,
    ) -> dict[str, object]:
        """Apply one current plan transactionally after digest and device gates."""

        validate_device_id(device_id)
        expected = validate_digest(expect_digest, "expect_digest")
        replay = self._completed_replay(proposal_id, expected, write=write)
        if replay is not None:
            return replay
        plan, payloads, originals = self._build_plan(proposal_id)
        if plan.digest != expected:
            raise ConflictError("expected policy plan digest is stale")
        proposal = next((item for item in load_open_proposals(self.policy_root) if item.proposal_id == proposal_id), None)
        if proposal is not None:
            if proposal.status != "approved":
                raise AccessError("policy apply requires real user approval through policy approve")
            if proposal.approval.plan_digest and proposal.approval.plan_digest != expected:
                raise ConflictError("policy approval does not bind the current plan")
        elif any(item.action != "reuse" for item in plan.changes):
            raise AccessError("active policy mutation requires a higher-revision pending proposal and fresh user approval")
        dependencies = self._approval_dependencies(plan)
        if write and proposal is not None:
            receipt_path = self.project_root / ".research-workflow" / "policy-plans" / f"{expected}.json"
            receipt = {"proposal_id": proposal_id, "digest": expected,
                "runtime": plan.authorization["runtime"],
                "files": {str(path): "absent" if data is None else _bytes_digest(data) for path, data in payloads.items()},
                "dependencies": {str(path): "absent" if data is None else _bytes_digest(data)
                    for path, data in dependencies.items() if path not in payloads}}
            payloads[receipt_path] = canonical_json_bytes(receipt) + b"\n"
            originals[receipt_path] = _read_target(receipt_path)
        for path, data in dependencies.items():
            if path not in payloads:
                payloads[path] = data
                originals[path] = data
        completions = (receipt_path,) if write and proposal is not None else ()

        def validate_applied():
            for path, expected_bytes in payloads.items():
                if path not in completions and _read_target(path) != expected_bytes:
                    raise ConflictError(f"policy transaction changed before completion: {path}")

        results = atomic_multi_write(payloads, write=write, expected=originals,
            post_apply_validator=validate_applied if write else None,
            completion_paths=completions)
        return {
            "mode": "write" if write else "preview",
            "action": "reuse" if all(item.action == "reuse" for item in results) else "apply",
            "plan": plan.to_dict(),
            "operations": [item.to_dict() for item in results],
        }

    def effective(self, scope: str | None = None) -> dict[str, object]:
        """Resolve effective active rules for allowlisted targets or one scope query."""

        if not self.policy_root.exists():
            raise UnsupportedOperationError("policy service is reserved until fixture policy authority is initialized")
        rules = load_active_rules(self.policy_root)
        contexts: list[PolicyContext]
        selected_rules = current_rules(rules)
        if scope is None:
            contexts = list(self.targets.contexts)
        elif scope == "global":
            selected_rules = tuple(rule for rule in selected_rules if rule.scope == "global")
            contexts = [PolicyContext(Path("/__policy_global__/AGENTS.md"), "unselected", "unselected")]
        elif scope.startswith("role:"):
            role = validate_logical_id(scope.split(":", 1)[1], "role scope")
            selected_rules = tuple(rule for rule in selected_rules if rule.scope in {"global", "role"})
            contexts = [PolicyContext(Path("/__policy_role__/AGENTS.md"), role, "unselected")]
        elif scope.startswith("project:"):
            project = validate_logical_id(scope.split(":", 1)[1], "project scope")
            selected_rules = tuple(rule for rule in selected_rules if rule.scope in {"global", "project"})
            contexts = [PolicyContext(Path("/__policy_project__/AGENTS.md"), "unselected", project)]
        else:
            contexts = [self.targets.exact(scope).context]
        runtime = self._runtime_binding(target_lifecycle=any(rule.target for rule in rules))
        entries = []
        for context in contexts:
            retired = is_retired(rules, runtime.get("device_id", ""), context.path)
            policy = EffectivePolicy({}, ()) if retired else effective_policy(selected_rules, context)
            entries.append({"path": str(context.path), "role": context.role, "project": context.project,
                "target_state": "retired" if retired else "active", "effective": policy.to_dict()})
        return {"entries": entries, "count": len(entries)}

    def list_policy(self, status: str | None = None) -> dict[str, object]:
        """List open proposals and active rules without reading Markdown authority."""

        proposals = load_open_proposals(self.policy_root)
        rules = load_active_rules(self.policy_root)
        if status == "open":
            rules = ()
        elif status == "active":
            proposals = ()
        elif status == "closed":
            proposals = ()
            rules = ()
        return {
            "proposals": [item.to_dict() for item in proposals],
            "rules": [item.to_dict() for item in rules],
            "count": len(proposals) + len(rules),
        }

    def check(self) -> dict[str, object]:
        """Check rule, backlog, and managed-block drift without repairing it."""

        proposals = load_open_proposals(self.policy_root)
        rules = load_active_rules(self.policy_root)
        validate_rule_set(rules, self.targets.contexts)
        drift: list[dict[str, object]] = []
        markdown = ""
        if self.backlog_path.exists():
            try:
                markdown = self.backlog_path.read_text(encoding="utf-8")
            except OSError as exc:
                raise ValidationError(f"cannot read backlog view: {exc}") from exc
        if not check_backlog_consistency(markdown, proposals):
            drift.append({"kind": "backlog", "path": str(self.backlog_path)})
        runtime = self._runtime_binding(target_lifecycle=any(rule.target for rule in rules))
        for target in self.targets.targets:
            current = _read_target(target.path)
            if is_retired(rules, runtime.get("device_id", ""), target.path):
                expected = project_managed_block(current, EffectivePolicy({}, ())) if current is not None else None
            else:
                expected = project_managed_block(current, effective_policy(rules, target.context))
            if current != expected:
                drift.append({"kind": "managed-target", "path": str(target.path)})
        return {
            "valid": not drift,
            "checked": len(proposals) + len(rules) + len(self.targets.targets) + 1,
            "drift": drift,
            "details": {
                "open_proposals": len(proposals),
                "active_rules": len(rules),
                "targets": len(self.targets.targets),
                "backlog_authority": False,
            },
        }

    def execute(self, command: str, args: argparse.Namespace, context: object) -> dict[str, object]:
        """Connect the supported policy CLI commands to this service."""

        workspace = getattr(context, "workspace")
        if command.startswith("policy.target."):
            return self.propose_target(args.path, action=command.rsplit(".", 1)[1],
                replacement=getattr(args, "replacement", ""), proposal_id=args.proposal_id,
                evidence=args.evidence, write=args.write)
        if command == "policy.effective":
            return self.effective(args.scope)
        if command == "policy.propose":
            proposal = Proposal.from_dict(read_json(args.proposal, canonical=False))
            if proposal.status != "open":
                raise AccessError("policy propose accepts only pending proposals; record real user approval with policy approve")
            return self.propose(proposal, device_id=workspace.require_device(), write=args.write)
        if command == "policy.list":
            return self.list_policy(args.status)
        if command == "policy.plan":
            return self.plan(args.proposal_id).to_dict()
        if command == "policy.approve":
            return self.approve(args.proposal_id, args.actor, args.decided_at,
                expect_digest=args.expect_digest, device_id=workspace.require_device(), write=args.write)
        if command == "policy.apply":
            proposal = next((item for item in load_open_proposals(self.policy_root) if item.proposal_id == args.proposal_id), None)
            if proposal is not None and not proposal.approval.plan_digest:
                raise AccessError("policy apply requires a digest-bound policy approve decision")
            return self.apply(
                args.proposal_id,
                expect_digest=args.expect_digest,
                device_id=workspace.require_device(),
                write=args.write,
            )
        if command == "policy.check":
            return self.check()
        raise ValidationError(f"unknown policy command: {command}")


__all__ = [
    "MANAGED_END",
    "MANAGED_START",
    "PlanChange",
    "PolicyApplicationService",
    "PolicyTarget",
    "PropagationPlan",
    "TargetAllowlist",
    "project_managed_block",
    "render_managed_block",
]
