"""Load registered roots and resolve canonical simulation identities."""

from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from research_workflow.core.errors import AccessError, DeviceIdentityError, ValidationError
from research_workflow.core.ids import validate_device_id, validate_sim_id
from research_workflow.core.time import validate_utc


@dataclass(frozen=True, slots=True)
class RootRegistration:
    """Describe one verified local registered root."""

    root_id: str
    path: Path
    kind: str
    mapping: str
    default_access: str


@dataclass(frozen=True, slots=True)
class ResolvedTarget:
    """Bind a local target to its registered root and logical path."""

    root: RootRegistration
    path: Path
    relative: str
    sim_id: str | None


class WorkspaceRegistry:
    """Parse schema-version-1 workspace configuration without writing it."""

    def __init__(self, config_path: str | os.PathLike[str]):
        """Load one local workspace registry and validate its path policy."""

        self.config_path = Path(os.path.abspath(os.path.expanduser(os.fspath(config_path))))
        if not self.config_path.is_file():
            raise ValidationError(f"workspace file not found: {self.config_path}")
        try:
            self.data = tomllib.loads(self.config_path.read_text(encoding="utf-8"))
        except (OSError, tomllib.TOMLDecodeError) as exc:
            raise ValidationError(f"cannot parse workspace: {exc}") from exc
        if self.data.get("schema_version") != 1:
            raise ValidationError("workspace schema_version must be 1")
        workspace_id = self.data.get("workspace_id")
        if not isinstance(workspace_id, str) or not workspace_id:
            raise ValidationError("workspace_id must be a non-empty string")
        self.workspace_id = workspace_id
        validate_utc(self.data.get("verified_at", ""), "workspace verified_at")
        self.project_root = self.config_path.parent
        self.device_id = self._load_device()
        self.roots = self._load_roots()
        self.clusters = self._load_clusters()
        self.aliases = self._load_aliases()
        self.policy_targets = self._load_policy_targets()
        self._validate_sim_policy()

    def _load_device(self) -> str | None:
        raw = self.data.get("device")
        if raw is None:
            return None
        if not isinstance(raw, dict):
            raise ValidationError("workspace device must be a table")
        return validate_device_id(raw.get("device_id"))

    def _load_roots(self) -> dict[str, RootRegistration]:
        raw = self.data.get("roots")
        if not isinstance(raw, dict) or "simulation" not in raw:
            raise ValidationError("workspace requires roots.simulation")
        roots: dict[str, RootRegistration] = {}
        for root_id, item in raw.items():
            if not isinstance(item, dict):
                raise ValidationError(f"registered root must be a table: {root_id}")
            required = ("path", "kind", "mapping", "default_access", "verified_at")
            if any(not isinstance(item.get(key), str) or not item[key] for key in required):
                raise ValidationError(f"registered root has invalid fields: {root_id}")
            path = Path(str(item["path"]))
            if not path.is_absolute():
                raise ValidationError(f"registered root must be absolute: {root_id}")
            mapping = str(item["mapping"])
            if mapping not in {"canonical", "same-relative-path", "explicit-link-only", "none"}:
                raise ValidationError(f"invalid root mapping: {root_id}")
            access = str(item["default_access"])
            if access not in {"project-policy", "read-only", "explicit-user-request"}:
                raise ValidationError(f"invalid root access: {root_id}")
            validate_utc(item["verified_at"], f"root {root_id} verified_at")
            roots[root_id] = RootRegistration(
                root_id=root_id,
                path=Path(os.path.abspath(path)),
                kind=str(item["kind"]),
                mapping=mapping,
                default_access=access,
            )
        if roots["simulation"].mapping != "canonical":
            raise ValidationError("roots.simulation mapping must be canonical")
        return roots

    def _load_clusters(self) -> dict[str, dict[str, object]]:
        raw = self.data.get("clusters", {})
        if not isinstance(raw, dict):
            raise ValidationError("workspace clusters must be a table")
        return raw

    def _load_aliases(self) -> tuple[dict[str, object], ...]:
        raw = self.data.get("path_aliases", {})
        if not isinstance(raw, dict) or raw.get("policy") != "explicit-and-evidence-backed-only":
            raise ValidationError("workspace requires explicit-and-evidence-backed-only aliases")
        entries = raw.get("entries", [])
        if not isinstance(entries, list):
            raise ValidationError("path_aliases.entries must be an array")
        result: list[dict[str, object]] = []
        for index, item in enumerate(entries):
            if not isinstance(item, dict):
                raise ValidationError(f"alias {index} must be a table")
            required = {"root", "source_prefix", "canonical_prefix", "evidence", "verified_at"}
            if not required <= set(item):
                raise ValidationError(f"alias {index} is incomplete")
            if item["root"] not in self.roots and item["root"] not in self.clusters:
                raise ValidationError(f"alias {index} references an unknown root")
            validate_sim_id(item["source_prefix"])
            validate_sim_id(item["canonical_prefix"])
            if not isinstance(item["evidence"], str) or not item["evidence"]:
                raise ValidationError(f"alias {index} requires evidence")
            validate_utc(item["verified_at"], f"alias {index} verified_at")
            result.append(dict(item))
        return tuple(result)

    def _load_policy_targets(self) -> tuple[dict[str, object], ...]:
        """Load an optional exact AGENTS.md allowlist without discovery."""

        raw = self.data.get("policy", {})
        if not isinstance(raw, dict):
            raise ValidationError("workspace policy must be a table")
        targets = raw.get("targets", [])
        if not isinstance(targets, list):
            raise ValidationError("workspace policy.targets must be an array")
        result: list[dict[str, object]] = []
        paths: set[Path] = set()
        for index, item in enumerate(targets):
            if not isinstance(item, dict):
                raise ValidationError(f"policy target {index} must be a table")
            required = {"path", "role", "project", "separate_approval"}
            if set(item) != required:
                raise ValidationError(f"policy target {index} fields are invalid")
            path = Path(str(item["path"]))
            if not path.is_absolute() or ".." in path.parts or path.name != "AGENTS.md":
                raise ValidationError(f"policy target {index} must be an absolute AGENTS.md path")
            path = Path(os.path.abspath(path))
            if path in paths:
                raise ValidationError(f"duplicate workspace policy target: {path}")
            role = item["role"]
            project = item["project"]
            separate = item["separate_approval"]
            if not isinstance(role, str) or not role or not isinstance(project, str) or not project:
                raise ValidationError(f"policy target {index} role and project must be strings")
            if not isinstance(separate, bool):
                raise ValidationError(f"policy target {index} separate_approval must be boolean")
            paths.add(path)
            result.append({
                "path": str(path),
                "role": role,
                "project": project,
                "separate_approval": separate,
            })
        return tuple(result)

    def _validate_sim_policy(self) -> None:
        expected = {
            "strategy": "simulation-relative-posix-path",
            "canonical_root": "simulation",
            "separator": "/",
            "case_sensitive": True,
            "same_relative_path_default": True,
            "allow_absolute": False,
            "allow_dot_segments": False,
        }
        raw = self.data.get("sim_id")
        if not isinstance(raw, dict) or any(raw.get(key) != value for key, value in expected.items()):
            raise ValidationError("workspace sim_id policy does not match schema version 1")

    @property
    def simulation_root(self) -> Path:
        """Return the canonical local simulation root."""

        return self.roots["simulation"].path

    @property
    def metadata_root(self) -> Path:
        """Return the single live metadata authority under the project root."""

        return self.project_root / "metadata"

    @property
    def cache_path(self) -> Path:
        """Return the device-local, non-authoritative cache path."""

        return self.project_root / ".research-workflow" / "index.sqlite3"

    def require_device(self) -> str:
        """Return the current device or refuse any gated write."""

        if self.device_id is None:
            raise DeviceIdentityError("current device_id is not configured")
        return self.device_id

    def find_root(self, path: str | os.PathLike[str]) -> ResolvedTarget:
        """Resolve one local path against the most specific registered root."""

        candidate = Path(os.path.abspath(os.path.expanduser(os.fspath(path))))
        matches: list[tuple[int, RootRegistration, Path]] = []
        for root in self.roots.values():
            try:
                relative = candidate.relative_to(root.path)
            except ValueError:
                continue
            matches.append((len(root.path.parts), root, relative))
        if not matches:
            raise ValidationError(f"path is outside registered local roots: {candidate}")
        _, root, relative = max(matches, key=lambda item: item[0])
        if candidate.exists():
            try:
                candidate.resolve(strict=True).relative_to(root.path.resolve(strict=True))
            except (OSError, ValueError) as exc:
                raise ValidationError(f"path resolves outside registered root {root.root_id}: {candidate}") from exc
        logical = PurePosixPath(relative.as_posix()).as_posix()
        sim_id = self.to_canonical(root.root_id, logical) if logical != "." else None
        return ResolvedTarget(root=root, path=candidate, relative=logical, sim_id=sim_id)

    def resolve_sim_id(self, target: str | os.PathLike[str]) -> str:
        """Resolve a canonical identity or a registered local target path."""

        text = os.fspath(target)
        candidate = Path(os.path.expanduser(text))
        if candidate.is_absolute() or candidate.exists():
            resolved = self.find_root(candidate)
            if resolved.sim_id is None:
                raise ValidationError("registered root itself is not a Case target")
            return resolved.sim_id
        return validate_sim_id(text)

    def to_canonical(self, root_id: str, relative: str) -> str | None:
        """Map a registered logical path to canonical sim_id without guessing."""

        root = self.roots.get(root_id)
        if root is None:
            raise ValidationError(f"unknown local root: {root_id}")
        if root.mapping not in {"canonical", "same-relative-path"}:
            return None
        value = validate_sim_id(relative)
        match = self._select_alias(root_id, value, reverse=False)
        if match is None:
            return value
        source = str(match["source_prefix"])
        canonical = str(match["canonical_prefix"])
        suffix = value[len(source):].lstrip("/")
        return validate_sim_id(canonical if not suffix else f"{canonical}/{suffix}")

    def from_canonical(self, root_id: str, sim_id: str) -> str:
        """Map canonical sim_id to one registered root using explicit aliases."""

        value = validate_sim_id(sim_id)
        root = self.roots.get(root_id)
        if root is None:
            raise ValidationError(f"unknown local root: {root_id}")
        if root.mapping not in {"canonical", "same-relative-path"}:
            raise ValidationError(f"root does not map Cases: {root_id}")
        match = self._select_alias(root_id, value, reverse=True)
        if match is None:
            return value
        source = str(match["source_prefix"])
        canonical = str(match["canonical_prefix"])
        suffix = value[len(canonical):].lstrip("/")
        return validate_sim_id(source if not suffix else f"{source}/{suffix}")

    def local_case_path(self, root_id: str, sim_id: str, *, write: bool = False) -> Path:
        """Resolve a Case path after enforcing Data and Notes access gates."""

        self.authorize(root_id, write=write)
        relative = self.from_canonical(root_id, sim_id)
        return self.roots[root_id].path.joinpath(*PurePosixPath(relative).parts)

    def authorize(self, root_id: str, *, write: bool = False, linked_notes: bool = False) -> None:
        """Enforce read-only Data and explicit-link-only Notes boundaries."""

        root = self.roots.get(root_id)
        if root is None:
            raise AccessError(f"unknown registered root: {root_id}")
        if root.kind == "data" or root.default_access == "read-only":
            if write:
                raise AccessError(f"registered Data root is read-only: {root_id}")
            return
        if root.kind == "notes" or root.mapping == "explicit-link-only":
            if write:
                raise AccessError("Notes writes are outside Research Workflow authority")
            if not linked_notes:
                raise AccessError("Notes reads require an explicit Study link and section")

    def _select_alias(self, root_id: str, value: str, *, reverse: bool) -> dict[str, object] | None:
        matches: list[tuple[int, dict[str, object]]] = []
        for item in self.aliases:
            if item["root"] != root_id:
                continue
            prefix = str(item["canonical_prefix"] if reverse else item["source_prefix"])
            if value == prefix or value.startswith(prefix + "/"):
                matches.append((len(prefix.split("/")), item))
        if not matches:
            return None
        longest = max(length for length, _ in matches)
        winners = [item for length, item in matches if length == longest]
        signatures = {(item["source_prefix"], item["canonical_prefix"]) for item in winners}
        if len(signatures) != 1:
            raise ValidationError(f"conflicting aliases for {root_id}: {value}")
        return winners[0]


Workspace = WorkspaceRegistry

__all__ = ["ResolvedTarget", "RootRegistration", "Workspace", "WorkspaceRegistry"]
