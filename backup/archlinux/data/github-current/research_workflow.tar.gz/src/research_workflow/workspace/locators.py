"""Represent Git-portable logical locators."""

from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path, PurePosixPath

from research_workflow.core.canonical import require_fields, require_object, require_string
from research_workflow.core.errors import AccessError, ValidationError
from research_workflow.core.ids import validate_logical_id, validate_sim_id

from .registry import WorkspaceRegistry


_URI_RE = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*:")


def validate_logical_path(value: object, label: str = "path") -> str:
    """Validate a relative POSIX path without dot segments."""

    text = require_string(value, label)
    if text.startswith("/") or "\\" in text or any(part in {"", ".", ".."} for part in text.split("/")):
        raise ValidationError(f"{label} must be a relative POSIX path")
    return text


@dataclass(frozen=True, slots=True)
class LogicalLocator:
    """Name a Case, Study, root-relative path, cluster path, or external URI."""

    kind: str
    identity: str
    path: str | None = None

    @classmethod
    def from_dict(cls, value: object, workspace: WorkspaceRegistry | None = None) -> "LogicalLocator":
        """Validate and construct a locator without touching its target."""

        item = require_object(value, "locator")
        kind = item.get("kind")
        if kind == "case":
            require_fields(item, {"kind", "sim_id"}, "locator", {"path"})
            identity = validate_sim_id(item["sim_id"])
        elif kind == "study":
            require_fields(item, {"kind", "project_id", "study_id"}, "locator")
            project_id = validate_logical_id(item["project_id"], "project_id")
            study_id = validate_logical_id(item["study_id"], "study_id")
            identity = f"{project_id}#{study_id}"
        elif kind == "root":
            require_fields(item, {"kind", "root_id"}, "locator", {"path"})
            identity = validate_logical_id(item["root_id"], "root_id")
            if workspace is not None and identity != "research_workflow" and identity not in workspace.roots:
                raise ValidationError(f"locator references unknown root: {identity}")
        elif kind == "cluster":
            require_fields(item, {"kind", "cluster_id"}, "locator", {"path"})
            identity = validate_logical_id(item["cluster_id"], "cluster_id")
            if workspace is not None and identity not in workspace.clusters:
                raise ValidationError(f"locator references unknown cluster: {identity}")
        elif kind == "external":
            require_fields(item, {"kind", "uri"}, "locator")
            identity = require_string(item["uri"], "locator.uri")
            if not _URI_RE.match(identity):
                raise ValidationError("external locator requires an explicit URI scheme")
        else:
            raise ValidationError(f"unsupported locator kind: {kind!r}")
        path = validate_logical_path(item["path"], "locator.path") if "path" in item else None
        return cls(kind=str(kind), identity=identity, path=path)

    def to_dict(self) -> dict[str, object]:
        """Return the canonical portable object form."""

        if self.kind == "study":
            project_id, separator, study_id = self.identity.partition("#")
            if not separator:
                raise ValidationError("Study locator identity is malformed")
            return {
                "kind": "study",
                "project_id": project_id,
                "study_id": study_id,
            }
        key = {"case": "sim_id", "root": "root_id", "cluster": "cluster_id", "external": "uri"}[self.kind]
        result: dict[str, object] = {"kind": self.kind, key: self.identity}
        if self.path is not None:
            result["path"] = self.path
        return result

    def resolve_local(
        self,
        workspace: WorkspaceRegistry,
        *,
        write: bool = False,
        linked_notes: bool = False,
    ) -> Path:
        """Resolve a local locator after enforcing authority and access gates."""

        if self.kind == "case":
            base = workspace.local_case_path("simulation", self.identity, write=write)
        elif self.kind == "root":
            if self.identity == "research_workflow":
                base = workspace.project_root
            else:
                workspace.authorize(self.identity, write=write, linked_notes=linked_notes)
                base = workspace.roots[self.identity].path
        else:
            raise AccessError(f"locator kind is not local: {self.kind}")
        if self.path is None:
            return base
        return base.joinpath(*PurePosixPath(self.path).parts)


def parse_locator(text: str, workspace: WorkspaceRegistry | None = None) -> LogicalLocator:
    """Parse KIND:IDENTITY[/PATH] CLI syntax without filesystem access."""

    if ":" not in text:
        raise ValidationError("locator must use KIND:IDENTITY syntax")
    kind, value = text.split(":", 1)
    if kind == "external":
        return LogicalLocator.from_dict({"kind": "external", "uri": value}, workspace)
    if kind == "case":
        return LogicalLocator.from_dict({"kind": "case", "sim_id": value}, workspace)
    if kind == "study":
        project_id, separator, study_id = value.partition("#")
        if not separator:
            raise ValidationError("Study locator must use study:PROJECT_ID#STUDY_ID")
        return LogicalLocator.from_dict(
            {"kind": "study", "project_id": project_id, "study_id": study_id},
            workspace,
        )
    if kind in {"root", "cluster"}:
        identity, separator, path = value.partition("/")
        key = "root_id" if kind == "root" else "cluster_id"
        data: dict[str, object] = {"kind": kind, key: identity}
        if separator:
            data["path"] = path
        return LogicalLocator.from_dict(data, workspace)
    raise ValidationError(f"unsupported locator kind: {kind}")


__all__ = ["LogicalLocator", "parse_locator", "validate_logical_path"]
