"""Expose registered-root and logical-locator services."""

from .locators import LogicalLocator, parse_locator, validate_logical_path
from .registry import ResolvedTarget, RootRegistration, Workspace, WorkspaceRegistry

__all__ = [
    "LogicalLocator",
    "ResolvedTarget",
    "RootRegistration",
    "Workspace",
    "WorkspaceRegistry",
    "parse_locator",
    "validate_logical_path",
]
