# Changelog

All release notes distinguish implemented behavior from target contracts.
Historical acceptance evidence remains in `FRAMEWORK_BASELINE.md`.

## 0.2.4 - implementation; deployment pending

- Add explicit Store 2 → 3 capability upgrade and workspace-independent archive
  compatibility inspection. No implicit migration or Case/Event schema change.
- Add schema-2 target retire/reenable proposals per device/exact path, retained
  approval history, same-root parent inheritance and explicit allowlists.
- Bind policy plan 3 / authorization 2 to Store, device, mappings, target state,
  file bytes and parent evidence; verify completed replay and preserve unmanaged
  bytes. Retired missing files remain absent; returned managed blocks are drift.
- Add isolated lifecycle, concurrency, rollback and compatibility regressions.
- Live Store/policy/body activation, deletion, release and cross-device sync
  require their separate reviewed approvals; fixtures do not certify deployment.

## 0.2.3 - 2026-09-20

### Changed

- Record ordinary completed work as one event; Case ownership no longer implies
  a definition edit. All explicit Case writers use saved preview/user/apply gates.
- Bind plans to inputs, heads, dependencies, device and local mappings; preserve
  no-op/retry behavior and refuse partial application. Serialize local writers.
- Query Case, Study, Project and exact root/path memory, including roots absent
  on this device. Add filtered event lists, correction relationships and bounded
  progress clues. Make automatic legacy status projection opt-in.
- Retain the Event schema and every historical byte; use summary/evidence for
  purpose, accepted reasons, results, validation level and unresolved limits.
- Add pending policy previews with a stable authorization digest and the sole
  supported `policy approve` transition. Preserve cumulative device scope;
  active replay cannot repair drift or expand targets without new approval.
- Register only the optional local Theory root; create no empty research hierarchy.
- Update skill/instruction contracts and device replay. Explicit full skill checks
  discover active Cases through the journal-backed CLI; default checks stay offline.
- Replace the obsolete live-source equality test with isolated historical-memory
  invariants across matching, changed and missing local input. Existing source
  drift remains reported evidence, not a reason to rewrite scientific history.

### Acceptance boundaries

Local laptop-2 implementation, user-approved policy/body deployment and final
independent release acceptance passed. The full gate reports 156 framework,
37 utility (one existing skip) and seven workflow skill tests: 199 passed and
one existing skip. Doctor/validate/event merge/full skill pass; 21 policy targets
have zero drift. Historical scientific bytes remain intact. Exact approvals,
source-validation limits and the complete inventory are in `FRAMEWORK_BASELINE.md`.
The selected publication branch is `update_0.2.3`; publication and actual
second-device deployment have not occurred. Historical sections below remain.

## 0.2.2 - 2026-08-23

Status: implemented; journal-only live cutover completed.

### Changed

- Complete the portable cutover with 207 active `migrate` records and 8
  `migrate-tombstone` records; remove `metadata/cases`.
- Preserve all 261 Event lines in the same four streams with unchanged bytes.
- Reduce the public CLI to 23 leaves; legacy Store upgrade and Case migration
  are historical provenance, not current mutation surfaces.
- Require explicit current-head `if_match` on every checkpoint Case change.
- Make multi-device work sequential: externally authorized sync before
  context, fail-closed sibling forks, and no automatic reconciliation.
- Consolidate context and local projection into one `ContextService` backed by
  one `QueryIndex`; remove the old context package and snapshot cache.
- Refuse symlinked query-index paths and retain corrupt-database bytes on
  refusal.
- Keep existing Project/Study schema versions 1 and 2 as supported current
  authority while removing executable schema-1 Case write documentation.

### Safety and compatibility

- Historical `migrate` and `migrate-tombstone` bindings remain permanently
  readable and immutable.
- Git, network, sync, cluster, simulation, Matlab, Data/Notes writes, builds,
  containers, and external APIs remain outside automatic execution.
- The previously documented external recovery tar is unavailable at its exact
  path; its actual location remains `to-confirm`.
- Exact live acceptance measurements are recorded only in
  `FRAMEWORK_BASELINE.md`.

## 0.2.1 - 2026-08-23

Status: implemented; bounded migration pilot accepted.

### Changed

- Replace Case registries and per-Case authority pairs with device-owned,
  monthly Case journals and a deterministic reducer.
- Bootstrap a missing schema-2 Project, Study, thin Store registry entry, and
  first Case journal record in one rollback-guarded transaction.
- Keep schema-2 `STORE.json` thin: Project and device registries only.
- Make the local SQLite index transparent, rebuildable, and non-authoritative.
- Remove stale cached legacy Case rows during journal catch-up so an in-place
  migration refreshes transparently without a false duplicate-authority error.
- Default context to a 4096-byte compact view with explicit deep, subtree, and
  knowledge-link inclusion.
- Add one structured `checkpoint` entry for Case changes plus one event while
  retaining existing leaves as thin compatibility wrappers.
- Add optional Project/Study `knowledge_links` and explicit on-demand reads
  without Notes or Zotero content ingestion. Existing-authority link mutation
  remains a documented future checkpoint seam.
- Split validation into fast, pilot, and explicit full tiers.

### Compatibility

- Framework family remains `"0"`; the Python package version becomes `0.2.1`.
- Schema-1 Store, Study `notes`, and Case pairs remain readable migration input.
- Existing JSONL event bytes remain immutable.
- Git, network, cluster, simulation, Matlab, Data writes, Notes writes, builds,
  and synchronization remain outside automatic framework execution.

### Acceptance

- Journal/checkpoint/context/index implementation: accepted.
- Approved LBW 11-Case migration: 11 records in one Study/device/month journal.
- Thin Store: 14,714 bytes reduced to 275 bytes.
- Pilot context maximum: 3,967 of 4,096 bytes.
- Four preserved events from 2026-08-20 UTC: 8,713 exact bytes.
- Five pilot tests: passed.
- Final root-owned acceptance event:
  `20260823T091132Z-laptop-2-v021-acceptance-b12f89db`.
- Post-acceptance hierarchy hardening event:
  `20260823T092017Z-laptop-2-v021-hierarchy-hardening-ff03db3c`.
- Full framework regression: 142/143 passed. The one failure is an explicit,
  out-of-pilot pre-existing runner digest drift documented in
  `FRAMEWORK_BASELINE.md`; both skill suites passed with one skip.

## 0.1.3

The accepted V0 implementation uses schema-1 Project, Study, profile, Case
pair, device, and monthly event authorities with preview-first writes,
digest-bound lifecycle operations, lineage-aware status, policy propagation,
and an explicit local cache. See `FRAMEWORK_BASELINE.md` for historical
acceptance evidence; its dated counts are not a live inventory.
