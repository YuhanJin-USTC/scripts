# Research Workflow 0.2.4 Metadata Contract

## 1. Current contract

Package version `0.2.4` keeps framework family string `"0"`. The current
portable Store supports schemas 2 and 3 with journal-only Case authority.
Schema 3 is activated only by an explicit digest-approved Store upgrade.
`implementation_status` is `implemented`.

This file is normative for current reads and writes. Historical `migrate` and
`migrate-tombstone` records remain permanently readable provenance, but
schema-1 Store registries and per-Case files are not a current write surface.
Structural acceptance never establishes run, data, analysis, or scientific
status.

## 2. Authority boundaries

| Information | Authority |
| --- | --- |
| Durable Agent behavior | Nearest applicable `AGENTS.md` |
| Device paths, aliases, identity, policy targets | `workspace.toml` |
| Project/device membership | `metadata/STORE.json` |
| Stable shared facts | Project, Study, and profile documents |
| Case head, lifecycle, and lineage | Case journals reduced in memory |
| Work history and status evidence | Device-owned event journals |
| Current policy | `policy/open-proposals/*.json` and `policy/rules/*.json` |
| Query acceleration | Device-local SQLite index |
| Scientific interpretation | Explicitly requested or linked Notes |

Primary inputs, runners, scheduler records, transfers, source files, build
artifacts, and analysis outputs remain evidence. Metadata does not replace
them. Missing evidence is `unknown`; a plausible value awaiting a decision is
`to-confirm`; `not-applicable` is used only when a field cannot apply.

## 3. Portable authority

```text
metadata/
  STORE.json
  projects/<project_id>/PROJECT.json
  studies/<project_id>/<study_id>/STUDY.json
  profiles/<scope>/<profile_id>/PROFILE.json
  devices/<device_id>.json
  case-journals/<encoded-project-id>/<encoded-study-id>/<device_id>/<YYYY-MM>.jsonl
  events/<device_id>/<YYYY-MM>.jsonl
```

`metadata/cases/` MUST NOT exist. `CASE_VIEW.json` is an in-memory shape only.
Portable authority MUST NOT contain local absolute paths, credentials, cache
state, raw scientific output, full conversations, hidden reasoning, or
unsupported scientific conclusions.

Schema-2 `STORE.json` contains exactly `schema`, `schema_version`,
`framework_version`, `store_id`, `created_at`, and sorted unique `projects` and
`devices`. Schema 3 adds sorted unique `required_capabilities`, containing
`policy-target-lifecycle-v1`; it remains thin and registers no policy targets.
Neither schema contains Case, redirect, or deletion registries. Unknown Store
schemas or required capabilities fail closed for writers. Package 0.2.4 reads
Store 2/3; old 0.2.3 rejects Store 3. Unsynchronized old copies still need manual
writer shutdown. Installation, import, context, doctor, validate and checkpoint
never upgrade Store implicitly.

`store upgrade --to-schema 3` returns exact before/after and stable digest.
After real user acceptance, repeat with `--expect-digest DIGEST --write`.
Only STORE.json changes; identity, Projects/devices and other authority bytes
remain unchanged. Invalid metadata/policy, stale input or unsupported capabilities
refuse. Already-current Store returns a no-op, without manufacturing approval.
`doctor --compatibility-only --store ABSOLUTE_STORE --json` runs before workspace
initialization, writes nothing and reports package version plus Store schema,
required/supported capabilities, policy schema versions and compatibility.
This archive inspection is not full workspace or device acceptance.

Project and Study schema versions 1 and 2 are both current readable authority.
This compatibility does not recreate schema-1 Case storage. Version 2 may add
sorted unique `knowledge_links`; a version-1 Study may retain one exact `notes`
locator and section as compatibility input. Profile and device documents remain
schema version 1. Existing Project/Study version 1 documents are supported and
need not be rewritten merely for a framework release.

Every Project/Study logical ID `/` is encoded as `%2F` in one journal scope
path component. Malformed escapes and path/document disagreement are invalid.

## 4. Canonical bytes and identity

RW-canonical JSON rejects duplicate keys, floats, non-finite numbers, and
`null`; permits objects, arrays, strings, integers, and booleans; sorts object
keys; uses UTF-8 without insignificant whitespace; and has no BOM or embedded
newline. A JSON document appends one LF. Each JSONL line is one canonical
object plus LF; blank or partial lines are invalid and existing lines are
immutable.

Canonical digests are lowercase SHA-256 of the canonical payload without the
file LF. Raw-byte digests and byte counts cover exact stored bytes. IDs are
non-empty portable POSIX components without empty, `.` or `..` segments.
`sim_id` is the case-sensitive path relative to the registered Simulation root.
Writers never infer identity, pairing, status, or scientific meaning from
names, existence, mtimes, or directory similarity.

Logical locators are `case`, `study`, `root`, `cluster`, or `external` records
with the required portable identity and optional relative path. A locator
grants no permission to read, write, connect, transfer, or execute.

## 5. Case journals

Each device appends only to its own recorded-month journal:

```text
metadata/case-journals/<project>/<study>/<device>/<YYYY-MM>.jsonl
```

A record uses `research-workflow/case-record` schema version 1 and binds
`record_id`, `device_id`, `recorded_at`, `action`, `sim_id`,
`previous_digest`, and action-specific fields. Current write actions are:

- `create`: first complete Case delta, with `previous_digest=not-applicable`;
- `revise`: complete new snapshot bound to the active head digest;
- `rename`: same-Study target snapshot bound to the source head;
- `delete`: unchanged active snapshot bound to the active head.

Historical read-only actions are:

- `migrate`: exact canonical/raw binding of one accepted legacy active pair;
- `migrate-tombstone`: exact canonical/raw binding of one accepted legacy
  deletion receipt without inventing deleted Case content or profiles.

Historical bindings are permanent audit evidence. Readers MUST continue to
validate and reduce them; writers MUST NOT rewrite, normalize, or discard them.

Reduction follows explicit `previous_digest` ancestry. Timestamps and IDs only
break ties between independent records; clocks do not establish causality. It
rejects equal record
IDs with different bytes, stale `previous_digest`, path identity mismatch,
cross-Study lifecycle, identity reuse, and sibling forks. If two devices append
incompatible children of the same head, reduction fails closed. The framework
does not select a winner, synthesize a merge record, rewrite JSONL, or perform
an automatic Git merge.

Rename remains within one Study and changes only the top-level identity and
structurally exact typed self-locators. Delete preserves the last snapshot so
the journal is self-contained. Migrated tombstones remain deleted and reserved;
their historical events remain `deleted_case_events`.

## 6. Materialization, Events, and status

The current Case view merges, in order: Project content; Study content;
Project, Study, then Case profiles; Case content. Objects merge recursively;
mapping/scalar conflicts fail; other values replace as a whole.

Events append only to `metadata/events/<device>/<YYYY-MM>.jsonl`. Required
fields include immutable identity/time, one Case/Study/root owner, kind,
summary, evidence, and status updates. Kinds are `modification`, `validation`,
`decision`, `status-change`, and `correction`. Record one event at the most
specific owner for one substantive result; do not duplicate it into parents,
siblings, Data, Matlab, or Notes. No event is required for read-only work,
ordinary Q&A, planning, or unsuccessful work without an enduring result.
Event schema version 1 is unchanged. Use existing `summary` and evidence
`observation` to retain purpose, actual results, accepted decisions/reasons,
validation level, and limits where known; these are guidance, not required
additional fields. Exact scientific details stay in linked evidence.

New events belong to an active Case, explicit Study, or registered root and
exact directory. Without membership, create no empty Project/Study/Case.
Prepared events retain their original root owner after later registration;
query association uses exact directories and explicit mappings only.

Status tracks are Run, Data, and Analysis. A non-`unknown` update cites direct
same-event evidence. Equal-time conflicts derive `unknown`. Corrections append
new bytes and never edit history. Active Case status follows canonical lineage;
deleted lineage events are classified separately; truly missing owners remain
diagnostics.

## 7. Context and local index

`MemoryQuery`/`ReadSelector` is the portable read boundary; it does not reuse
local new-write owner checks. `ContextService` uses one `QueryIndex`.
`.research-workflow/index.sqlite3` is local, disposable, non-authoritative and
rebuildable. Index schema 5 stores the complete owner path, searchable event
text and correction target. Missing/older indexes rebuild locally; symlinked
or corrupt paths refuse. Never copy SQLite between devices.

`context TARGET` accepts `case:SIM_ID`, bare canonical SIM_ID,
`study:PROJECT#STUDY`, `project:PROJECT`, `root:ROOT[/PATH]`, or a registered local
path. Local paths use longest registered root and explicit aliases/mappings.
Logical root reads need neither local root registration nor scientific files;
`mappingAvailable` reports direct configuration, not evidence-file existence.
Local file access and new root events still require valid local registration.
Study/Project aggregation requires an explicit logical selector. Similar names
or parent directories do not establish research membership.

Root/path owner match is exact unless `--recursive` is specified. Recursion is
root-only and respects path components. A local canonical/same-relative mapped
Case ancestor selects the canonical Simulation root/path; it does not union
all older paired-root events. `mapping=none` preserves its exact original owner.
Case selection follows rename lineage and exact directories related by explicit
canonical/same-relative mappings and aliases; never descendants, shared functions,
similar names, or mapping-none roots. Deduplicate by event ID and retain stored
owners. Parent Study history appears separately as `parent_background`.
Study queries aggregate their registered Cases plus explicit Study events;
Project queries aggregate their Studies and registered Cases, not arbitrary roots.

`event list [TARGET]` defaults to 20 rows, accepts `--limit 0..100`, inclusive
`--since YYYY-MM-DDTHH:MM:SSZ`, literal casefolded `--query` over summary and
evidence observations, and root-only `--recursive`. Omitted TARGET selects all
portable events. `%` and `_` are literal. Display order is descending
`(occurred_at, recorded_at, event_id)`, not causal order. Output includes `count`,
`total`, `omitted`, `truncated`, and `limit`; corrections retain relationships
outside the current filter/window. `event show ID` retains every original Event
field, full evidence, real `status_updates`, and correction relationships.

Compact/deep limits remain 4096/24576 canonical JSON bytes including LF.
`--recent` defaults to 3, range 0..100. Context retains `recent_events` and
`progress` counts, truncation and a follow-up query. Trim large content before
work clues; if work exists and recent is nonzero, retain an event ID and clue
or explicitly fail the budget. Never silently return complete-looking empty
progress. `omitted_paths` and truncation flags report reductions.
`--select` pointers remain narrow unless `--include event-details` is requested.
Case pointers address the materialized spec, Study/Project their document, and
root pointers the locator. Link bodies require explicit `--include-link ID`
and an exact Case Notes link/section; generic queries do not read evidence files.

Automatic Run/Data/Analysis status is absent by default, including deep/context
selection/event-details. `--include status` requests the legacy active-Case
projection. Root/Study/Project contexts never synthesize status tracks; stored
Event status updates remain intact.

## 8. Work recording and Case confirmation

A `research-workflow/checkpoint-request` schema-1 request has exactly one event,
optional request/time/risk fields, and `changes` defaulting to `[]`. A positional
TARGET only supplies the event owner. Case event-only work requires no head
digest or Case edit. Normal event-only results may write once with `--write`.
High-risk requests and every explicit Case change require preview and accepted
saved-plan replay. No broad content-field blacklist infers a Case mutation.

Each explicit Case change names `target`, current 64-character `if_match`,
`responsibility: "simulation-definition"`, `reason: "input-change"` or
`"metadata-correction"`, and patch/removal/profile fields. `input_configs` is an
optional string array. Top-level Case patch/head/profile shorthand is refused.
Keep registration, physical/numerical input changes, metadata correction, and
lifecycle meaning distinct; accepted settings are not physical validation.

Case mutation targets use bare canonical SIM_ID or registered absolute paths,
not query-only `case:` selectors.
`case create/revise/rename/delete` prepare saved local previews; their direct
`--write` is closed with a migration message. Create is registration, and
rename/delete are lifecycle operations. Revise requires `--reason` and current
`--expect-digest`; rename/delete require the current source head. Finish files
and checks, show the actual difference, ask the user, and await confirmation.
Only then run `case apply --plan DIGEST --write` (or the replay alias
`checkpoint --apply-plan DIGEST --write`). A CLI digest does not prove consent.
Replay cannot mix target/request/stdin. Case commands write no result event;
later accepted registration does not duplicate previously recorded work.

Repeated `--input-config` on create/revise, or change `input_configs`, selects
exact absolute local files or `root:`/`case:` file locators as configuration
text, generated parameters, or manifests. Read only named UTF-8/NUL-free text,
in 64 KiB chunks with pre/post-stat checks and no size cutoff. Do not expand
includes/dependency trees, infer config from names, scan raw Data, or execute
research programs. Data/Notes, unregistered/outside paths, symlinks and binary
inputs refuse. Input digests remain in local plans, not injected portable content.

Saved plans bind proposed records/documents, Case heads including no-ops,
relevant old/new Project/Study/profile dependencies, Store/device membership,
selected inputs, actual root/alias mappings, local paths and device. Head checks
precede equality checks. Unchanged accepted content/profile references produce
no revision; lifecycle still appends its actual action. Successful exact replay
returns `already-applied`; partial application, transplanted plans, conflicts
and stale state stop. Receipts follow writes/fsync/validation in the rollback
boundary; this is not arbitrary crash-atomic multi-file storage.

Every supported write checks configured/registered device identity and uses one
local authority lock from state reads through receipt/rollback. Devices append
only their own streams. Existing journal/event bytes remain immutable. Preview
may save local plans, and read queries may refresh derived cache; these are not
portable writes or Case registration.

## 9. Sequential multi-device workflow

Portable work on multiple devices is strictly sequential:

1. Begin only with a user-confirmed clean local repository state.
2. With separate user authorization, perform external fetch and fast-forward
   integration. The framework itself never runs Git or network.
3. Run `doctor`, `event merge`, and structural validation as needed.
4. Only after portable authority is current, run compact `context`.
5. Record a substantive result once. Explicit Case changes separately require
   current `if_match`, preview, real user acceptance and saved-plan apply.
6. Validate locally; then, only with separate user authorization, publish the
   exact portable changes through Git/network.
7. Every sibling device repeats synchronization before its next context or
   write.

`sync plan` is advisory only and always reports no execution. A fork detected
after synchronization or during reduction fails closed and requires an
explicit human resolution plan. There is no autonomous reconciliation.

## 10. Policy and safety

Policy schema 1 retains its original canonical payload and digest; old approved
rules stay readable. Schema 2 adds exact target lifecycle records in the same
proposal/rule directories, without a second registry. Pending proposals may declare sorted `requested_targets`. Promotion is
`policy propose --proposal FILE` preview/write, `policy plan ID`, real user
scope/target/digest approval, `policy approve ID --expect-digest DIGEST --actor
user --decided-at UTC --write`, then digest-bound `policy apply`. The CLI refuses
imported approved proposals; no hand-edited approval JSON is supported.

Plan schema 3 exposes actual changes and a separate stable `authorization`
payload version 2. Its digest binds candidate rule semantics/evidence, cumulative requested
targets, the full exact local allowlist, base rules, normalized candidate/other
open proposals, backlog consistency, managed diffs and exact front-state,
new-rule path/front-state, Store capabilities and bytes, registered device,
workspace mappings, exact target states, replacement parent bytes/effective
policy and authority paths. Superseded rule files remain byte-unchanged. Only
the candidate approval status/actor/time/self-digests are bookkeeping excluded
from this authorization digest; actual output shows those fields. Pending
preview does not record approval. Approval stores `plan_digest` and exactly the
requested targets. Changes to content, scope, targets or front-state need fresh
preview/consent; an approved proposal still in open authority needs a new unique proposal ID
if stale. Same-ID higher revision is only reauthorization of an active rule.

Retain all prior authorized device paths in reauthorization/supersession, while
applying only the current device's allowlist. Same-ID reauthorization raises
revision and preserves behavior; new behavior uses a new ID and supersedes.
Data/Notes require exact separate approval. Managed apply preserves every
unmanaged byte; body edits require an independent explicit patch scope. Active
rule replay may only reuse already-correct files: any drift repair or new target
requires a new pending reauthorization and approval. Approval-only changes do not
force rewriting correct managed blocks. `policy check` reports without repair.

A schema-2 target proposal retains `proposal_id`, `status`, `revision`,
`supersedes`, `evidence`, `approval`, optional `digest` and `requested_targets`.
It replaces schema-1 `scope`, `selector`, `content` with `kind: "target"`,
`device_id`, exact absolute `target`, `action: "retire" | "reenable"`, and
`replacement` only for retire. Rules retain the corresponding `rule_id`,
`proposal_id`, active status and digest-bound approval. One record names one
(device_id, path). Supersedes must reference a lower revision of that same pair;
missing predecessors or multiple unsuperseded heads refuse, without a winner.
Cumulative `authorized_targets` is approval history, never an active-target list.

`policy target retire PATH --replacement PARENT_AGENTS --proposal-id ID
--evidence LOCATOR` and `policy target reenable PATH --proposal-id ID
--evidence LOCATOR` only preview; `--write` saves a pending proposal. Store 3
and the capability are required. Promotion still uses plan → actual user
approval → approve → apply. Retirement removes only a verified managed block;
all outside bytes survive. The replacement is an explicit allowlisted active
ancestor in the same registered root with compatible effective policy. Its
entire current body is bound as the reviewed inheritance evidence. Retirement
does not delete files or remove allowlist entries. A missing retired file is
valid and never recreated; a returned managed block is drift. Reenable requires
a new approval and projects current policy without restoring old body text.
The same path on another device is a separate target state.

Policy operations require explicit `policy.targets`; no recursive discovery is
used. Completed replay uses local disposable receipts and checks the real
completed files/dependencies. Interrupted, changed or stale state refuses;
receipts cannot confer approval. Aggregate validation belongs in services/CLI,
not storage; it reports metadata, policy and capability validity, including
same-priority conflicts across overlapping subtrees at actual allowlisted
contexts. Scope queries reduce the complete supersession history before
filtering; retaining historical files never reactivates a superseded rule.
Before publishing a completion receipt, apply rechecks every bound unchanged
dependency and every intended output. Failure rolls back only transaction
writes still equal to their own after-images; later external edits are retained
and incomplete rollback is reported. This is process-visible rollback, not an
arbitrary external-writer or power-loss atomicity guarantee.

Data is read-only. Notes reads require one exact link and section; Notes writes
require an explicit user request. Git, network, SSH, synchronization, transfer,
cluster, simulation, Matlab, source build, container, SIF, and external API
operations are never automatic and require separate authorization. Registered
roots are independent scopes. No command scans raw results to discover context.

## 11. Public CLI

The current CLI has exactly 29 versionless leaves:

```text
context
checkpoint
case list
case show
case create
case apply
case revise
case rename
case delete
event record
event list
event show
event merge
validate
cache rebuild
cache update
device onboard
doctor
store upgrade
policy target retire
policy target reenable
policy effective
policy propose
policy list
policy plan
policy approve
policy apply
policy check
sync plan
```

Only explicit `--write` changes portable authority. Local plan preparation and
derived query-cache refresh are allowed without it. Gated writes require the configured and
registered current device. Unsupported legacy mutation commands are not a
compatibility fallback. `sync plan` never executes synchronization.

## Appendix A. Historical cutover and recovery

The accepted live cutover contains 207 active `migrate` records and 8 deleted
`migrate-tombstone` records. `metadata/cases` has been removed. All 261 Event
lines remain in their four original streams with unchanged stream bytes. Exact
measurements and acceptance digests belong in `FRAMEWORK_BASELINE.md`.

Historical migrate bindings preserve the accepted legacy pair or deletion
receipt identities permanently. They are readable validation input, not a
schema-1 write contract or permission to reconstruct old paths.

The formerly documented external recovery archive path is currently
unavailable and its actual location is `to-confirm`:

```text
/home/yuhanjin/Research_Workflow-pre-v0-reset-20260719.tar
expected sha256: 988a80543beb94b23ad06e7dde04a4347d5cbb7945a0e34091fb55792b3e7ade
availability: unavailable / to-confirm
```

The repository keeps only its minimal archive-backed fixture. Recovery is a
destructive or overwriting operation and requires exact target authorization;
the missing archive MUST NOT be inferred, recreated, or claimed verified.

## Appendix B. Completion reporting

Report exact changed paths, direct evidence, structural validation, separately
authorized scientific validation, skipped external operations, event outcome,
and every remaining `unknown` or `to-confirm` item. Do not record pure Q&A,
planning, read-only inspection, or unsuccessful work without a durable result.
