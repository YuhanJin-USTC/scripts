# Research Workflow 0.2.4

让科研工作自然地留下可信记忆。记忆主要供 agent 恢复工作背景、理解已接受的选择、
跟进实际结果和未解决问题，并减少登记、确认和查询对科研本身的打扰。

当前源码：Python package `0.2.4`、framework family `0`，兼容 thin Store schema 2/3。
Case/Event/workspace/SQLite 格式不变。Store 3 与目标生命周期需要独立确认后才启用；
本轮源码更新不代表已迁移本机 Store、部署 managed policy、发布或同步其他设备。
0.2.3 历史验收与本轮实际检查分别保留在 `FRAMEWORK_BASELINE.md`。

## 日常使用

| 工作 | 留下什么 |
| --- | --- |
| 参数查询、只读检查、普通问答 | 不写 journal/event |
| 后处理、理论、脚本或验证产生持久结果 | 最具体 owner 的一条有证据 event |
| 初次登记或仿真定义变化 | 先完成文件与检查，展示登记差异，真实询问并等待用户确认，再 apply |
| 工作已完成但 Case 未获接受 | 先记录在已注册 root 的精确目录，之后通过精确映射关联历史 |
| 没有 Project/Study 的工作 | 使用 root/path；不创建空层级 |
| 查询研究进展 | 默认查看工作、时间、证据和 correction；status 按需开启 |

`input.deck` 等实际影响物理/数值设置的输入属于仿真定义。Case owner 并不意味着
每次工作都要改 Case。没有跨任务待确认队列、自动登记或后台提醒。一次结果已记录
后，后来接受的登记只写 Case journal，不重复写结果 event。

## 核心分工

| 文件或目录 | 作用 |
| --- | --- |
| `workspace.toml` | 每台设备独立维护的 roots、映射、device_id、policy targets |
| `SCHEMA.md` | 当前格式、查询语义、确认和写入门槛 |
| `metadata/` | Project、Study、profile、device、Case/event journal 的便携 authority |
| `policy/` | pending proposal 与 active rule authority |
| `.research-workflow/` | 本机 SQLite、确认计划与临时事务状态；不通过 Git 同步 |
| `skills/research-workflow/` | 仓库提供的 Codex 入口；安装处通常是 symlink |
| `FRAMEWORK_BASELINE.md` | 历史验收、当前升级契约和已测证据 |

稳定背景放在 Project/Study/profile；接受的 Case 定义留在 journal；实际工作放在
event；公式、代码、参数的准确细节留在链接证据中按需阅读。使用已有 `summary` 和
证据 `observation` 保存科研目的、实际结果、已接受理由、验证层级和限制；它们是
书写指导，不增加必填表单或 Event 字段，不补造缺失事实。

Store 仅登记 Projects/devices，没有 Case map。Case 当前视图由不可变 journal
按 `previous_digest` 关系归约；Project/Study schema 1、2 均支持，不为版本统一而
重写旧记录。历史 migrate/migrate-tombstone 永久可读；`metadata/cases` 不恢复。
当前科研文件后来改变或缺失，不会使已保存的历史定义自动失效或被重新覆盖。

## 恢复与追问

以下命令均从控制仓库调用 `tools/researchctl.py`：

```bash
python3 -B tools/researchctl.py context case:project/study/case --json
python3 -B tools/researchctl.py context study:project#study --json
python3 -B tools/researchctl.py context project:project --json
python3 -B tools/researchctl.py context root:matlab_theory/tr_vortex_beam --json
python3 -B tools/researchctl.py event list root:matlab_theory/tr_vortex_beam --limit 20 --json
python3 -B tools/researchctl.py event list --since 2026-09-01T00:00:00Z --query validation --json
python3 -B tools/researchctl.py event show EVENT_ID --json
```

根路径默认精确 owner 匹配；`--recursive` 才包含该 root/path 的后代，且只适用于
root 查询。Study/Project 聚合使用显式逻辑 selector，不依据目录名称推断成员。
Case 会关联 rename lineage 和显式配对的精确登记前目录，保留原 owner，按 event ID
去重。父级背景单独显示，不冒充 Case 进度；correction 关系不因筛选窗口而消失。

列表默认 20 条、最大 100 条，`--limit 0` 仅取数量；`--since` 包含端点，`--query`
是不区分大小写的字面子串，`%`/`_` 不是通配符。显示顺序由时间与 ID 确定，不证明
跨设备因果。compact/deep 上限仍为 4096/24576 字节，输出进度条数、遗漏数量和
后续查询；大定义先裁剪，不能悄悄丢掉全部工作线索。`--select` 是窄字段查询；
还需工作历史时显式加 `--include event-details`。

`context --include status` 可取旧 Run/Data/Analysis 投影。`event show` 保留原记录
真实 `status_updates`，不会删掉历史字段。通用查询不读证据文件或 Notes 正文；
知识链接正文需要精确 link ID 和 Notes section。

逻辑 `root:` 记忆可在没有本地目录/映射的设备读取。`mappingAvailable` 仅表示
直接路径映射已配置，不能证明文件存在；本地文件访问和新 root event 仍需有效注册。

## 记录结果与确认 Case

普通结果可一次写入；把示例证据替换为本次实际文件与观察：

```bash
python3 -B tools/researchctl.py checkpoint root:scripts/process --request-json '{
  "schema":"research-workflow/checkpoint-request",
  "schema_version":1,
  "event":{
    "kind":"validation",
    "summary":"检查目的；实际结果；验证层级和仍未验证部分。",
    "evidence":[{
      "kind":"file",
      "locator":{"kind":"root","root_id":"scripts","path":"process/example.py"},
      "observation":"该文件提供的直接证据。"
    }]
  }
}' --write --json
```

TARGET 只指定 owner，`changes` 默认空。Case 的 event-only 结果不要求 `if_match`。
高风险结果以及所有显式 Case 修改先 preview，再按接受的计划 apply。

```bash
python3 -B tools/researchctl.py case revise project/study/case \
  --reason input-change --expect-digest HEAD_DIGEST \
  --content-patch-json '{"parameter":"verified value"}' \
  --input-config root:simulation/project/study/case/input.deck --json
# 展示差异，真实询问用户并等待明确答复后：
python3 -B tools/researchctl.py case apply --plan PLAN_DIGEST --write --json
```

Case 写命令 TARGET 使用裸 canonical sim_id 或注册的本地绝对路径；查询的 `case:`
selector 不直接用于这些写命令。

create/revise/rename/delete 的旧直接 `--write` 已关闭；revise 必须区分
`input-change` 与 `metadata-correction`，rename/delete 也绑定当前 source head。
checkpoint 中显式变化必须各自写 `target`、`if_match`、
`responsibility: "simulation-definition"`、`reason` 和修改内容，不能用顶层 shorthand。

重复 `--input-config` 或每个 change 的 `input_configs` 仅选择准确配置文本、生成
参数或 manifest（绝对路径、root:/case: locator）。只读选中文件；不展开 include，
不自动推断依赖，不设大小上限，不执行程序。Data/Notes、symlink、二进制输入拒绝。
输入 hash 留在本机计划，不自动写科学 metadata。输入、head、依赖、映射或 device
变化使旧计划失效；接受定义不变则无 revision；成功重试不重复追加，部分应用停止。

## Theory 与多设备

本机只新增 `matlab_theory`：`/mnt/d/document/MATLAB/Matlab/Theory`，`analysis`、
`mapping=none`。两个精确 owner 是 `epoch_initial_distribution` 和 `tr_vortex_beam`。
前者含 EPOCH photon distribution 与 colliding-beam 生成；后者计算频域/时域 TR
vortex fields。这来自代码检查，不是执行、数值或物理验收。未注册整个 Matlab，
未新建 Project/Study/Case。另一台没有真实等价目录就不注册，也能读同步过来的记忆。

设备逐台升级：旧版本停止 metadata 写入，科研计算/绘图/提交不受影响；本设备通过
验收才恢复记录。切换设备后，在 context 或任何 portable write（含 event-only）前，
先保留本机工作，再经单独授权同步，运行 doctor/event merge/validate。每台继续使用
各设备已登记的 device_id 与本机 TOML（本机为 desktop-1）；不把新任务或 subagent 当新设备。
SQLite、计划、外部 AGENTS 和 skill link 分别维护。框架无法证明外部同步或旧 writer
已经停止，必须如实记录这些操作状态。完整步骤见 `GIT_PRIVATE_REMOTE.md`。

## Tool_Project 工具项目

`Tool_Project/` 只组织工具目录，不初始化父级 Git 仓库，不建立新的研究 root。
`Daily_Arxiv/` 与 `Figure_Browser/` 各保留独立 Git 历史、Issues 和 PR。
两者均为 `kind=source`、`mapping=none`、`default_access=project-policy`；
本机路径只由各设备的 `workspace.toml` 解析，目录改名不改变稳定 root ID。

| 稳定 root ID | 项目与边界 | 工作记忆 |
| --- | --- | --- |
| `daily_arxiv` | Daily_Arxiv（公开源码仓库）；保留 `main`/`data` 分离、模型、邮件和发布边界 | `root:daily_arxiv` 或实际工作的精确子目录 |
| `matlab_html` | Figure_Browser（私有源码仓库）；浏览器来源只读，应用不读写研究元数据 | `root:matlab_html` 或实际工作的精确子目录 |

```bash
python3 -B tools/researchctl.py context root:daily_arxiv --view compact --json
python3 -B tools/researchctl.py context root:matlab_html --view compact --json
```

工作前恢复精确目录的记忆；有实质结果后通过事件型 `checkpoint` 记录一次，
在现有 summary/evidence 中保留目的、结果、已接受理由、检查和限制。
普通问答与规划不记事件，不创建空的 Project/Study/Case，也不从 Figure_Browser 的
Simulation、Theory、Archive 浏览来源推断研究成员或仿真映射。
研究元数据留在控制仓库，不进入应用、生成数据分支或浏览器缓存。

跨设备沿用相同 root ID；各项目 AGENTS 随各自源码仓库维护。本机路径、SQLite
和 saved plans 留在本机；历史策略批准随控制仓库保留，新设备目标仍须单独确认。
可同步的接入示例在 `workspace.example.toml`，逐设备接入及正文重放要求见
[Git 与设备指南](GIT_PRIVATE_REMOTE.md#daily-arxiv-and-html-device-onboarding)。
该指南也是父目录 README/AGENTS 在其他设备的初始化依据；父目录文件不会随任一
子仓库自动同步。代码通过各自 GitHub 仓库同步，科研图片沿用既有文件管理方式，
Figure_Browser 的个人资料、配置、密码和会话各设备独立；不复制整个 `.local/`。
另一设备没有对应目录时省略该 root，只读取已同步的逻辑记忆；不创建占位目录。
切换设备仍先保留本机工作、经授权同步并通过 doctor/event merge/validate，
再恢复 context 或记录事件。新策略目标必须在该设备重新预览并由用户批准。
仓库中的接入说明不代表已经推送、同步或完成另一设备验收。

## Policy、安装与验证

policy 流程为 pending propose → plan → 用户确认精确范围/差异/digest →
`policy approve` → `policy apply`。不能为拿 digest 伪造 approved，也不手工改批准 JSON。
累计保留另一设备批准路径，本机只应用本机 allowlist；Data/Notes 单独批准且只改
managed block。正文补丁独立审阅。active rule 只允许复用，修 drift/增 target 必须重新
提交和确认。批准信息同步本身不要求重写已正确的 block。

0.2.4 将目标退管与策略内容分开。allowlist 是访问边界，退管后仍保留该条目；
每个目标状态只作用于一个 `(device_id, exact path)`。旧批准路径和 superseded 规则保留，
不会因本机退管删除其他设备历史。没有显式 allowlist 时拒绝操作，不扫描目录补全。

### Store 迁移与归档预检

先停止该设备的旧 writer，并核对本机 `workspace.toml`、已登记 `device_id`、根映射和
精确 `policy.targets`。更换设备时还必须先保留本机工作，经单独授权同步完整源码与
portable authority，完成 doctor/event merge/validate 后再恢复 context 或写入。

```bash
python3 -B tools/researchctl.py doctor --json
python3 -B tools/researchctl.py event merge --json
python3 -B tools/researchctl.py validate --json
python3 -B tools/researchctl.py policy check --json
python3 -B tools/researchctl.py store upgrade --to-schema 3 --json
```

查看最后输出的 `plan.diff`、before/after、`plan.digest` 和 device/path。用户真实确认
当前差异后，才把下面的 `STORE_DIGEST` 换成该 digest：

```bash
python3 -B tools/researchctl.py store upgrade --to-schema 3 --expect-digest STORE_DIGEST --write --json
python3 -B tools/researchctl.py doctor --json
python3 -B tools/researchctl.py validate --json
```

此操作只改 thin Store schema 与 required capability，其他 authority 不迁移、不重写。
已是目标格式时返回 `already-current`、`written=false`，不伪造一次新批准。
源码安装、skill 更新、import、context、checkpoint 和检查命令均不会隐式升级 Store。

备份恢复使用归档自带的 CLI 检查同一归档 Store；绝对路径应替换为实际暂存位置：

```bash
python3 -B /staged/Research_Workflow/tools/researchctl.py \
  doctor --compatibility-only --store /staged/Research_Workflow/metadata/STORE.json --json
```

这条命令在 workspace 初始化之前运行，返回 package version、Store schema、
required/supported capabilities、policy schema versions 和 `compatible`，不写缓存。
它不能替代完整 doctor/validate、归档内容核验或另一设备验收。
旧 0.2.3 在读取已同步的 Store 3 时拒绝 writer；尚未同步的旧副本仍须人工停用。

### 退管与重新启用

先审阅并完成父文件的正文承接，再为每个 `(device_id, exact path)` 单独准备 proposal。
以下绝对路径、proposal ID 和 evidence 都是示例，使用前替换为已核验的实际值：

```bash
python3 -B tools/researchctl.py policy target retire /exact/root/child/AGENTS.md \
  --replacement /exact/root/AGENTS.md --proposal-id retire-child \
  --evidence root:scripts/build_containers/AGENTS.md --json
# 上一步只预览；保存 pending proposal：
python3 -B tools/researchctl.py policy target retire /exact/root/child/AGENTS.md \
  --replacement /exact/root/AGENTS.md --proposal-id retire-child \
  --evidence root:scripts/build_containers/AGENTS.md --write --json
python3 -B tools/researchctl.py policy plan retire-child --json
```

`--write` 在此只保存 pending，不表示批准，也不更改目标文件。审阅 plan 中目标实际
managed-block 差异、同 root 的祖先、父文件完整承接内容、当前 target 状态和累计批准
路径。用户确认这个 plan 的精确范围、diff 和 digest 后才记录批准并执行：

```bash
# POLICY_DIGEST 与 DECISION_UTC 替换为本次真实值，不能沿用示例或另一设备的值。
python3 -B tools/researchctl.py policy approve retire-child --expect-digest POLICY_DIGEST \
  --actor user --decided-at DECISION_UTC --write --json
python3 -B tools/researchctl.py policy apply retire-child --expect-digest POLICY_DIGEST --json
python3 -B tools/researchctl.py policy apply retire-child --expect-digest POLICY_DIGEST --write --json
python3 -B tools/researchctl.py policy check --json
```

`DECISION_UTC` 使用实际 UTC 时间，例如 `YYYY-MM-DDTHH:MM:SSZ`。retire 只移除已核验的
managed block，正文逐字保留，不删除文件，不删 allowlist 条目。祖先必须有效、
同 root 且策略兼容；父文件变化使原计划失效。退管后文件缺失不会被重建，再出现
managed block 则报 drift。对另一目标必须重新准备它自己的 plan 和批准。

重新启用用新的 ID 和证据，不指定 replacement；再次完整走 plan/确认/approve/apply：

```bash
python3 -B tools/researchctl.py policy target reenable /exact/root/child/AGENTS.md \
  --proposal-id reenable-child --evidence root:scripts/build_containers/AGENTS.md --json
python3 -B tools/researchctl.py policy target reenable /exact/root/child/AGENTS.md \
  --proposal-id reenable-child --evidence root:scripts/build_containers/AGENTS.md --write --json
python3 -B tools/researchctl.py policy plan reenable-child --json
# 用户确认新 plan 后，使用上述 approve/apply 命令和新 ID、新 digest、新决定时间。
```

reenable 只投影当前有效策略，不还原旧正文。正文精简、其他 root/Data/Notes 的变更及
最终文件删除都需各自精确审批。旧规则和批准历史始终保留，不能把 `authorized_targets`
当作当前启用列表，也不能按时间选择冲突的 target head。

### 策略内容、查询与失败处理

普通策略内容仍使用 schema-1 `templates/POLICY.json`。编辑一个独立候选文件，
填写实际 scope/selector、内容、证据、新 ID/revision、supersedes 和累计
`requested_targets`；模板的示例自 digest 不能沿用，删掉该可选字段交由 CLI 计算。
已有批准 JSON 不可直接改成新批准。内容变化使用新 ID 并 supersede；同 ID 更高
revision 只允许行为不变的 reauthorization。

```bash
python3 -B tools/researchctl.py policy propose --proposal /absolute/candidate.json --json
python3 -B tools/researchctl.py policy propose --proposal /absolute/candidate.json --write --json
python3 -B tools/researchctl.py policy plan PROPOSAL_ID --json
# 用户确认后，按上节 approve/apply；仅相等 digest 不能证明用户同意。
python3 -B tools/researchctl.py policy list --json
python3 -B tools/researchctl.py policy list --status open --json
python3 -B tools/researchctl.py policy effective --scope global --json
python3 -B tools/researchctl.py policy effective --scope role:simulation --json
python3 -B tools/researchctl.py policy effective --scope project:scripts --json
python3 -B tools/researchctl.py policy effective --scope /exact/root/AGENTS.md --json
```

scope 查询先归约完整历史再筛选，跨 scope supersede 不会让旧规则重新出现。
`validate` 检查 metadata、Store 能力、policy authority 和实际 allowlist 上的同级冲突；
`policy check` 另查 managed-block/backlog drift，两者都不修复文件。

| 情况 | 处理与边界 |
| --- | --- |
| Store schema/capability 不支持 | 停止 writer，核对归档或当前源码配对；不删 capability、不降级 schema 绕过门禁 |
| 无显式 allowlist、未登记设备、symlink 或跨 root 父目标 | 修正已获授权的准确配置/范围后重做预览；不扫描目录猜测目标 |
| Store 或 policy digest 过期 | 保留当前改动，重新查看实际差异并获取新确认；已批准且仍 open 的 stale proposal 使用新 ID，不能伪造批准 |
| 重叠 subtree 同级 key 或多个 target head 冲突 | 停止 apply/upgrade，核对 authority 来源；不按 revision/time 自动选胜者或合并分叉 |
| managed block 漂移、退管目标重现 block | 只报告；修复必须新的 pending proposal 和实际批准，不从旧 receipt 自动恢复 |
| apply 期间依赖被外部修改 | completion 前拒绝；只回滚自身仍未被外改的写入，保留外部修改；若已有写入也被外改，明确报告未完全回滚，保留现场后人工核对 |
| 重复 apply | 原 digest 的本地 receipt、当前文件及依赖全部匹配才复用；缺失 receipt、部分结果或后来变化不能声称原事务完成 |

错误通常以非零退出并给出 JSON `error`；2 表示验证/权限/设备错误，3 表示不支持的
能力或操作，4 表示冲突/过期。`validate`、普通 `doctor` 和 `policy check` 的
有效性还必须读取结果中的 `valid`/`validation.valid`，不能只看进程退出码。

CLI 不提供 Store 3→2 downgrade。target 的反向操作是新批准的 reenable，而不是
改旧规则或删 capability。进程可见事务失败有上述回滚保护，不承诺断电跨文件原子性。
灾难恢复只能在单独授权下核验并恢复匹配的源码/Store/policy 组合；不能恢复旧 Store
后继续用旧 writer 写已有生命周期 authority，也不能重写历史 Case/Event 来消除错误。

每台设备独立验证本机 roots、identity、skill 链接与 allowlist，再执行自己的批准流程。
仅同步 portable history 不复用另一设备的计划；SQLite、TOML、saved plans/receipts
不随设备复制。真实发布、同步、Store 激活、managed policy 部署与第二台设备验收
分别报告，详见 [设备步骤](GIT_PRIVATE_REMOTE.md) 与 [skill 安装](CODEX_SKILL_SYNC.md)。

默认 skill 检查仅检查安装/接口，不扫描 live authority，也不动 cache；显式 `--full`
通过 journal-backed `case list` 找真实 Case 并检查 context/validate/doctor，可刷新
派生 SQLite。安装 preview/write 与旧 skill 备份见 `CODEX_SKILL_SYNC.md`。

```bash
python3 -B tests/run_fast.py
python3 -B tools/researchctl.py doctor --json
python3 -B tools/researchctl.py event merge --json
python3 -B tools/researchctl.py validate --json
python3 -B tools/researchctl.py policy check --json
# 以下为本机 Codex home；其他设备替换为其实际路径。
python3 -B skills/research-workflow/scripts/check_installation.py --codex-home /mnt/d/Software/Codex/Data --json
# 明确执行 live 结构验收时：
python3 -B skills/research-workflow/scripts/check_installation.py --codex-home /mnt/d/Software/Codex/Data --full --json
```

日常只跑受影响模块和 fast；pilot 是显式 live acceptance；run_all 仅 release gate。
materialization 回归用隔离输入的匹配/变化/缺失三态验证历史记忆，不要求所有旧 Case
具有 reproducibility 或历史 hash 永远等于当前科研文件。已发现的 65 个未记录字段与
16 个 runner 漂移仍是既存科学源诊断，不改科学文件/hash来绿化测试。
结构验收不证明数值、物理或科研结论正确。

公开 CLI 共 29 leaves：context、checkpoint；case list/show/create/apply/revise/
rename/delete；event record/list/show/merge；validate；cache rebuild/update；
device onboard；doctor；store upgrade；policy target retire/reenable；policy effective/propose/list/plan/approve/apply/check；sync plan。
所有 Git、网络、SSH、cluster、simulation、MATLAB、build、SIF、transfer、sync 与 API
操作均非自动。Data 只读，Notes 写入需明确授权，`sync plan` 永不执行同步。

## Recovery 与 unknowns

原文档记录的外部 recovery tar 路径目前不存在：

```text
/home/yuhanjin/Research_Workflow-pre-v0-reset-20260719.tar
expected sha256: 988a80543beb94b23ad06e7dde04a4347d5cbb7945a0e34091fb55792b3e7ade
availability: unavailable / to-confirm
```

仓库只保留最小 archive-backed fixture。不得声称 archive 已核验，不得从名字推断其
新位置或自动重建。任何 recovery 都是可能覆盖用户内容的操作，需要 exact targets
与单独批准。

当前仍未知：所有未被 direct evidence 支持的科学结果与 Run/Data/Analysis 状态、
未建立的 lineage、未验证的 source-to-artifact provenance，以及 recovery tar 的
实际位置。
