# Evolution Backlog

Generated from `policy/open-proposals/*.json`. Do not edit.

## epoch-sif-provenance
- Status: `open`
- Scope: `project`
- Selector: `epoch-sif-provenance`
- Digest: `3175c1c893f42d6a387814162d2c5c6fca5c76b464bd1d52810634662fcd684e`
