# Research Workflow Codex Skills 跨设备同步

本文说明如何在已经安装过旧版 `research-workflow` 或
`edit-research-ppt` skill 的电脑上，将 Codex 切换为使用
`Research_Workflow` 仓库内置版本。完成一次迁移后，两份 skill 都会随仓库更新，
不再需要单独同步副本。

> Codex skill 目录通常是 `$CODEX_HOME/skills/`，其中 `skills` 是复数。

## 同步范围

会通过私有 Git 仓库同步：

- `skills/research-workflow/` 与 `skills/edit-research-ppt/` 中的 skill 源码、
  references、scripts 和 tests；
- `metadata/` 中的便携 Store；
- `policy/`、项目代码和项目文档。

不会通过仓库同步：

- `workspace.toml`；
- `.research-workflow/` 本地 cache；
- `$CODEX_HOME/skills/research-workflow` 和
  `$CODEX_HOME/skills/edit-research-ppt` 设备本地链接；
- `$CODEX_HOME/backups/` 中的旧 skill 备份；
- credentials、private keys、tokens 和虚拟环境。

每台电脑必须分别配置自己的 `workspace.toml`，包括唯一 `device_id` 和该设备的
绝对路径。

## 0.2.4 源码与 Store 能力

0.2.4 源码兼容 Store 2/3，skill 安装不迁移 Store。已指向仓库的 skill symlink
随源码更新，无需重新复制。Store 3 必须展示实际差异/digest 并获用户确认后升级；
旧 0.2.3 读取 Store 3 后拒绝 writer，尚未同步的旧副本仍须人工停用。
逐设备保留本机 TOML、路径、allowlist、SQLite 和 saved plans；同步、正文补丁、
退管和删除分别审批。归档兼容检查不等于 doctor/validate 或真实设备验收。
本轮未发布 0.2.4，也未同步或验收其他设备；下文 0.2.3 ref 属于历史部署说明，
不能推断为 0.2.4 交付 ref。实际发布后才填写并采用已核验的新 ref。

## 0.2.3 发布与设备顺序

本机 laptop-2 已通过 0.2.3 独立 release 验收及实际指令部署。
当前交付分支是 `update_0.2.3`，尚未发布、未生成 release commit；实际 commit/ref 与验收以
`FRAMEWORK_BASELINE.md` 和 `GIT_PRIVATE_REMOTE.md` 为准。只有确认实际发布后，
才执行下面 Git 命令。已有 laptop-1/laptop-2 identity 保持不变，保留各自 TOML，
按设备逐台升级；旧版本暂停 metadata 写入。本机 skill link 更新不代表另一设备
已验收，也不代表外部 AGENTS 已同步。完整指令与 policy 重放见 Git 指南。

## 前提条件

1. 主电脑已经把 `Research_Workflow` 的最新改动提交并推送到核验过的私有远端。
2. 目标电脑已经克隆同一个仓库。
3. 目标电脑能够读取 `$CODEX_HOME`；可先检查：

```bash
printf '%s\n' "$CODEX_HOME"
```

如果输出为空，执行安装命令时显式添加：

```text
--codex-home "/absolute/path/to/.codex"
```

## 第一步：更新 Research_Workflow 仓库

在目标电脑的仓库根目录执行：

```bash
git fetch origin
git merge --ff-only origin/update_0.2.3
```

如果不是 fast-forward、存在未处理修改或发生 metadata 冲突，停止迁移并先单独
处理 Git 状态。不要使用 force push、reset 或自动冲突覆盖。

确认内置 skill 已经存在：

```bash
test -f skills/research-workflow/SKILL.md
test -f skills/research-workflow/scripts/install.py
test -f skills/edit-research-ppt/SKILL.md
test -f skills/edit-research-ppt/scripts/install.py
```

## 第二步：为旧 skill 选择备份路径

已有普通目录版本时，必须提供一个尚不存在的精确备份路径。备份必须位于
`$CODEX_HOME` 内，但不要放在 `skills/` 目录中，以免 Codex 重复发现同名 skill。

示例：

```text
$CODEX_HOME/backups/research-workflow-pre-bundled-<device-tag>
$CODEX_HOME/backups/edit-research-ppt-pre-bundled-<device-tag>
```

将 `<device-tag>` 替换为能区分该电脑的固定名称。如果该路径已经存在，换一个
新的精确名称；每份 skill 使用独立备份，installer 不会覆盖既有备份。

## 第三步：预览迁移

从 `Research_Workflow` 仓库根目录执行：

```bash
python3 -B skills/research-workflow/scripts/install.py \
  --backup-existing "$CODEX_HOME/backups/research-workflow-pre-bundled-<device-tag>" \
  --json

python3 -B skills/edit-research-ppt/scripts/install.py \
  --backup-existing "$CODEX_HOME/backups/edit-research-ppt-pre-bundled-<device-tag>" \
  --json
```

检查输出至少满足：

```text
"action": "backup-and-link"
"written": false
```

同时检查以下路径完全正确：

- `source` 指向当前电脑相应的 `Research_Workflow/skills/<skill-name>`；
- `destination` 指向 `$CODEX_HOME/skills/<skill-name>`；
- `backup` 指向刚才选择的备份路径。

如果输出为 `"action": "reuse"`，说明该电脑已经链接到当前仓库版本，不需要
再次写入。

## 第四步：写入迁移

确认预览后，重复同一命令并添加 `--write`：

```bash
python3 -B skills/research-workflow/scripts/install.py \
  --backup-existing "$CODEX_HOME/backups/research-workflow-pre-bundled-<device-tag>" \
  --write \
  --json

python3 -B skills/edit-research-ppt/scripts/install.py \
  --backup-existing "$CODEX_HOME/backups/edit-research-ppt-pre-bundled-<device-tag>" \
  --write \
  --json
```

installer 会按以下顺序操作：

1. 将旧 `$CODEX_HOME/skills/<skill-name>` 普通目录移动到指定备份位置；
2. 建立指向仓库内置 skill 的符号链接；
3. 如果建立链接失败，将旧目录恢复到原位置。

成功输出应包含：

```text
"action": "backup-and-link"
"written": true
```

## 第五步：验证

运行普通安装自检（research-workflow 不扫描 live authority、不刷新 cache）：

```bash
python3 -B "$CODEX_HOME/skills/research-workflow/scripts/check_installation.py" --json
python3 -B "$CODEX_HOME/skills/edit-research-ppt/scripts/check_installation.py" --json
```

重点确认：

```text
"ok": true
"bundled_location": {"ok": true, ...}
"installed_link": {"ok": true, ...}
"skill_creator_validation": {"ok": true, ...}
"cache_unchanged": {"ok": true, ...}
```

明确执行 Research Workflow live 结构验收时另加 `--full`：

```bash
python3 -B "$CODEX_HOME/skills/research-workflow/scripts/check_installation.py" --codex-home "$CODEX_HOME" --full --json
```

完整检查通过 journal-backed `case list` 发现真实 Case，再检查逻辑 context、validate
与 doctor；不是读取已不存在的 Store.cases。无 active Case 会明确标注未执行 Case
smoke。完整查询允许创建/刷新派生 SQLite，输出 `derived_cache`，不会把普通模式的
`cache_unchanged` 当成完整模式要求。两种模式都不更改 portable metadata。
`edit-research-ppt` 保持自己的检查接口，不给它附加上述 `--full`。

Codex 通常会自动检测 skill 变化。如果 skill 没有出现在选择器中，重启 Codex，
然后分别调用 `$research-workflow` 和 `$edit-research-ppt` 验证。

## 以后如何同步

迁移只需执行一次。以后在该电脑更新仓库即可：

```bash
cd /path/to/Research_Workflow
git fetch origin
git merge --ff-only origin/update_0.2.3
python3 -B skills/research-workflow/scripts/check_installation.py --json
python3 -B skills/edit-research-ppt/scripts/check_installation.py --json
python3 -B tools/researchctl.py doctor --json
```

由于 `$CODEX_HOME/skills/<skill-name>` 已经指向仓库目录，Git 更新完成后两份
skill 内容会立即更新，不需要重复运行 installer。若 Codex 界面仍显示旧内容，
重启 Codex。

## 常见情况

### `existing installation requires --backup-existing`

目标位置仍是普通目录。重新执行预览，并提供 `$CODEX_HOME` 内、`skills/` 外且
尚不存在的精确备份路径。

### `backup path already exists`

installer 不覆盖备份。选择另一个新的精确路径后重新预览。

### `action` 是 `reuse`

该电脑已完成迁移。只需正常更新仓库和运行自检。

### `workspace.toml` 没有跟着变化

这是预期行为。`workspace.toml` 保存设备本地路径和 `device_id`，必须在每台电脑
分别维护；不要从另一台电脑直接覆盖。

### 权限错误

不要手工删除旧 skill。确认当前终端能够写入 `$CODEX_HOME`，然后重新运行同一
preview/write 流程。若系统要求授权，只批准上述精确 Codex skill 和备份路径。
