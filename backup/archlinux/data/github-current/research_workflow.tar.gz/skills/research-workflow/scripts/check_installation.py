#!/usr/bin/env python3
"""Check installation; explicit full checks may refresh the derived index."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tomllib
from pathlib import Path


INVOCATION_SKILL_ROOT = Path(__file__).absolute().parents[1]
SKILL_ROOT = Path(__file__).resolve().parents[1]
CONTROL_ROOT = SKILL_ROOT.parents[1]
WORKSPACE = CONTROL_ROOT / "workspace.toml"
SCHEMA = CONTROL_ROOT / "SCHEMA.md"
RESEARCHCTL = CONTROL_ROOT / "tools" / "researchctl.py"
STORE = CONTROL_ROOT / "metadata" / "STORE.json"
CACHE = CONTROL_ROOT / ".research-workflow" / "index.sqlite3"


def _absolute(value: str, label: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        raise ValueError(f"{label} must be absolute")
    return path.resolve(strict=False)


def _default_codex_home() -> Path:
    configured = os.environ.get("CODEX_HOME")
    return _absolute(configured, "CODEX_HOME") if configured else (Path.home() / ".codex").resolve()


def _quick_validate(codex_home: Path) -> Path | None:
    candidates = [
        INVOCATION_SKILL_ROOT.parent / ".system" / "skill-creator" / "scripts" / "quick_validate.py",
        codex_home / "skills" / ".system" / "skill-creator" / "scripts" / "quick_validate.py",
    ]
    return next((path for path in candidates if path.is_file()), None)


def run_command(args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, text=True, capture_output=True, check=False)


def fingerprint(path: Path) -> tuple[int, str] | None:
    if not path.is_file():
        return None
    payload = path.read_bytes()
    return len(payload), hashlib.sha256(payload).hexdigest()


def check_installation(codex_home: Path, *, full: bool = False) -> dict[str, object]:
    checks: dict[str, dict[str, object]] = {}
    errors: list[str] = []
    warnings: list[str] = []
    cache_before = fingerprint(CACHE)

    def add(name: str, ok: bool, detail: str) -> None:
        checks[name] = {"ok": ok, "detail": detail}
        if not ok:
            errors.append(f"{name}: {detail}")

    quick_validate = _quick_validate(codex_home)
    required = {
        "skill": SKILL_ROOT / "SKILL.md",
        "agent_metadata": SKILL_ROOT / "agents" / "openai.yaml",
        "operations": SKILL_ROOT / "references" / "operations.md",
        "installer": SKILL_ROOT / "scripts" / "install.py",
        "self_check": SKILL_ROOT / "scripts" / "check_installation.py",
        "workspace": WORKSPACE,
        "schema": SCHEMA,
        "researchctl": RESEARCHCTL,
        "store": STORE,
    }
    for name, path in required.items():
        add(name, path.is_file(), str(path))
    add("bundled_location", SKILL_ROOT == CONTROL_ROOT / "skills" / "research-workflow", str(SKILL_ROOT))

    installed = codex_home / "skills" / SKILL_ROOT.name
    add(
        "installed_link",
        installed.is_symlink() and installed.resolve() == SKILL_ROOT,
        f"{installed} -> {SKILL_ROOT}",
    )

    workspace_data: dict[str, object] = {}
    if WORKSPACE.is_file():
        try:
            workspace_data = tomllib.loads(WORKSPACE.read_text(encoding="utf-8"))
            roots = workspace_data.get("roots", {})
            add(
                "workspace_contract",
                workspace_data.get("schema_version") == 1 and isinstance(roots, dict),
                "schema version 1 with registered roots",
            )
            if isinstance(roots, dict):
                data = roots.get("data_simulation", {})
                notes = roots.get("notes", {})
                add("data_guard", isinstance(data, dict) and data.get("default_access") == "read-only", "Data is read-only")
                add("notes_guard", isinstance(notes, dict) and notes.get("default_access") == "explicit-user-request", "Notes is explicit opt-in")
                for root_id, config in roots.items():
                    path = config.get("path") if isinstance(config, dict) else None
                    add(f"root_{root_id}", isinstance(path, str) and Path(path).is_absolute(), str(path))
                    if isinstance(path, str) and not Path(path).exists():
                        warnings.append(f"registered root unavailable: {path}")
            policy = workspace_data.get("policy", {})
            targets = policy.get("targets", []) if isinstance(policy, dict) else []
            target_paths = [item.get("path") for item in targets if isinstance(item, dict)]
            add(
                "policy_targets",
                bool(targets)
                and len(target_paths) == len(targets)
                and len(set(target_paths)) == len(target_paths)
                and all(isinstance(path, str) and Path(path).is_absolute() for path in target_paths),
                "unique exact absolute AGENTS.md targets",
            )
            add(
                "policy_separate_approval",
                all(
                    item.get("separate_approval") is True
                    for item in targets
                    if isinstance(item, dict) and item.get("role") in {"data", "notes"}
                ),
                "Data and Notes targets require separate approval",
            )
        except (OSError, tomllib.TOMLDecodeError) as exc:
            add("workspace_contract", False, str(exc))

    if required["skill"].is_file():
        text = required["skill"].read_text(encoding="utf-8")
        add(
            "skill_contract",
            all(value in text for value in ("Research Workflow", "references/operations.md", "CONTROL_ROOT", "preview")),
            "portable bundled authority and operation reference",
        )
    if required["agent_metadata"].is_file():
        text = required["agent_metadata"].read_text(encoding="utf-8")
        add("agent_metadata_contract", all(value in text for value in ("Research Workflow", "$research-workflow", "0.2.4")), "current UI metadata")

    if required["installer"].is_file():
        result = run_command(
            [
                sys.executable,
                "-B",
                str(required["installer"]),
                "--codex-home",
                str(codex_home),
                "--json",
            ]
        )
        try:
            payload = json.loads(result.stdout)
            add(
                "installer_preview",
                result.returncode == 0
                and payload.get("mode") == "preview"
                and payload.get("written") is False,
                payload.get("action", (result.stderr or result.stdout).strip()),
            )
        except json.JSONDecodeError:
            add("installer_preview", False, (result.stderr or result.stdout).strip())

    if quick_validate is None:
        add("skill_creator_validation", False, "quick_validate.py not found through the installed Codex home")
    else:
        result = run_command([sys.executable, "-B", str(quick_validate), str(SKILL_ROOT)])
        add("skill_creator_validation", result.returncode == 0, (result.stdout or result.stderr).strip())

    if RESEARCHCTL.is_file():
        for label, command in (
            ("help", ["--help"]),
            ("context_help", ["context", "--help"]),
            ("checkpoint_help", ["checkpoint", "--help"]),
            ("event_help", ["event", "record", "--help"]),
            ("validate_help", ["validate", "--help"]),
            ("policy_help", ["policy", "--help"]),
            ("sync_help", ["sync", "plan", "--help"]),
        ):
            result = run_command([sys.executable, "-B", str(RESEARCHCTL), *command])
            add(f"researchctl_{label}", result.returncode == 0, "CLI help available")

    store_data: dict[str, object] = {}
    if full and STORE.is_file():
        try:
            store_data = json.loads(STORE.read_text(encoding="utf-8"))
            version = store_data.get("schema_version")
            thin = version in {2, 3} and all(
                key not in store_data for key in ("cases", "case_redirects", "case_deletions")
            )
            add(
                "store_contract",
                store_data.get("framework_version") == "0" and thin,
                f"framework 0 schema {version}",
            )
        except (OSError, json.JSONDecodeError) as exc:
            add("store_contract", False, str(exc))

    if full and RESEARCHCTL.is_file() and STORE.is_file():
        result = run_command([sys.executable, "-B", str(RESEARCHCTL), "case", "list", "--json"])
        try:
            payload = json.loads(result.stdout)
            cases = payload.get("cases")
            valid = result.returncode == 0 and isinstance(cases, list) and payload.get("count") == len(cases)
            add("case_discovery", valid, "active Cases discovered through journal-backed case list")
            if valid and cases:
                sim_id = cases[0].get("sim_id") if isinstance(cases[0], dict) else None
                if not isinstance(sim_id, str) or not sim_id:
                    add("context_smoke", False, "case list returned no valid sim_id")
                else:
                    result = run_command([sys.executable, "-B", str(RESEARCHCTL), "context", f"case:{sim_id}", "--recent", "1", "--json"])
                    payload = json.loads(result.stdout)
                    add("context_smoke", result.returncode == 0 and payload.get("sim_id") == sim_id,
                        f"bounded logical Case context for {sim_id}")
            elif valid:
                add("context_smoke", True, "not applicable: case list confirms zero active Cases")
                warnings.append("full context smoke has no active Case to exercise")
        except (json.JSONDecodeError, AttributeError) as exc:
            add("case_discovery", False, f"invalid case list or context response: {exc}")

    if full and RESEARCHCTL.is_file() and STORE.is_file():
        result = run_command([sys.executable, "-B", str(RESEARCHCTL), "validate", "--json"])
        try:
            payload = json.loads(result.stdout)
            add("validate_smoke", result.returncode == 0 and payload.get("valid") is True, "current Store validates")
        except json.JSONDecodeError:
            add("validate_smoke", False, (result.stderr or result.stdout).strip())
        result = run_command([sys.executable, "-B", str(RESEARCHCTL), "doctor", "--json"])
        try:
            payload = json.loads(result.stdout)
            add("doctor_smoke", result.returncode == 0 and payload.get("validation", {}).get("valid") is True, "device-local diagnosis passes")
        except json.JSONDecodeError:
            add("doctor_smoke", False, (result.stderr or result.stdout).strip())

    if not full:
        add("live_checks", True, "skipped; use --full for live Store/context/doctor validation")

    if full:
        add("derived_cache", True, "full queries may create or refresh the non-authoritative index")
    else:
        add("cache_unchanged", fingerprint(CACHE) == cache_before, "ordinary checks do not create or mutate cache")
    return {
        "ok": not errors,
        "skill_root": str(SKILL_ROOT),
        "control_root": str(CONTROL_ROOT),
        "codex_home": str(codex_home),
        "checks": checks,
        "warnings": warnings,
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Check bundled Research Workflow 0.2.4 integration")
    parser.add_argument("--codex-home")
    parser.add_argument("--full", action="store_true", help="include explicit live authority checks")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        codex_home = (
            _absolute(args.codex_home, "codex home")
            if args.codex_home
            else _default_codex_home()
        )
        result = check_installation(codex_home, full=args.full)
    except (OSError, ValueError) as exc:
        result = {
            "ok": False,
            "checks": {},
            "warnings": [],
            "errors": [str(exc)],
            "input_error": True,
        }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        for name, check in result["checks"].items():
            print(f"[{'OK' if check['ok'] else 'ERROR'}] {name}: {check['detail']}")
        for warning in result["warnings"]:
            print(f"[WARN] {warning}")
    if result.get("input_error"):
        return 2
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
