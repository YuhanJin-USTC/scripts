#!/usr/bin/env python3
"""Preview or install the repository-bundled Research Workflow skill."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
SKILL_NAME = SKILL_ROOT.name


def _absolute(value: str, label: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        raise ValueError(f"{label} must be absolute")
    return path.resolve(strict=False)


def _default_codex_home() -> Path:
    configured = os.environ.get("CODEX_HOME")
    return _absolute(configured, "CODEX_HOME") if configured else (Path.home() / ".codex").resolve()


def _inside(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def install(codex_home: Path, backup: Path | None, *, write: bool) -> dict[str, object]:
    skills_dir = codex_home / "skills"
    destination = skills_dir / SKILL_NAME
    exists = destination.exists() or destination.is_symlink()
    if destination.is_symlink() and destination.resolve() == SKILL_ROOT:
        return {
            "mode": "write" if write else "preview",
            "action": "reuse",
            "source": str(SKILL_ROOT),
            "destination": str(destination),
            "backup": None,
            "written": False,
        }
    if exists:
        if backup is None:
            raise ValueError("existing installation requires --backup-existing")
        if backup == destination or not _inside(backup, codex_home):
            raise ValueError("backup must be a different path inside CODEX_HOME")
        if _inside(backup, skills_dir):
            raise ValueError("backup must be outside CODEX_HOME/skills")
        if backup.exists() or backup.is_symlink():
            raise ValueError(f"backup path already exists: {backup}")
        action = "backup-and-link"
    else:
        if backup is not None:
            raise ValueError("--backup-existing is only valid for an existing installation")
        action = "create-link"

    result = {
        "mode": "write" if write else "preview",
        "action": action,
        "source": str(SKILL_ROOT),
        "destination": str(destination),
        "backup": str(backup) if backup is not None else None,
        "written": False,
    }
    if not write:
        return result

    skills_dir.mkdir(parents=True, exist_ok=True)
    if exists and backup is not None:
        backup.parent.mkdir(parents=True, exist_ok=True)
        destination.rename(backup)
    try:
        destination.symlink_to(SKILL_ROOT, target_is_directory=True)
    except OSError:
        if exists and backup is not None and not destination.exists() and not destination.is_symlink():
            backup.rename(destination)
        raise
    result["written"] = True
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Install the bundled Research Workflow skill")
    parser.add_argument("--codex-home")
    parser.add_argument("--backup-existing")
    parser.add_argument("--write", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        codex_home = (
            _absolute(args.codex_home, "codex home")
            if args.codex_home
            else _default_codex_home()
        )
        backup = _absolute(args.backup_existing, "backup") if args.backup_existing else None
        result = install(codex_home, backup, write=args.write)
    except (OSError, ValueError) as exc:
        result = {"error": str(exc), "written": False}
        if args.json:
            print(json.dumps(result, ensure_ascii=False, sort_keys=True))
        else:
            print(f"ERROR: {exc}")
        return 2
    if args.json:
        print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
