# Research Workflow 0.2.4 Operations

`CONTROL_ROOT/tools/researchctl.py` is the sole CLI; `SCHEMA.md` is normative.
Registry: `workspace.toml`; authority: `metadata/` and `policy/`; local state:
`.research-workflow/`. Do not copy local TOML, SQLite, or plans between devices.

## Sequential device gate

Before context or any portable write after changing device, including events:
confirm local work is preserved; with separate authorization synchronize the
published repository by fetch and fast-forward; run `doctor`, `event merge`,
and structural validation; only then restore memory. Stop on forks, conflicts,
or stale heads. Never choose a winner or auto-merge JSONL. Old framework writers
remain stopped until that device passes 0.2.4 acceptance. The CLI cannot prove
remote sync or writer shutdown. Publication is separate; see `GIT_PRIVATE_REMOTE.md`.

## Restore bounded memory

```text
context case:project/study/case --view compact --json
context study:project#study --json
context project:project --json
context root:matlab_theory/tr_vortex_beam --json
context root:scripts/process --recursive --json
event list root:matlab_theory/tr_vortex_beam --limit 20 --json
event list --since 2026-09-01T00:00:00Z --query "validation" --json
event show EVENT_ID --json
```

Exact owner match is the default; recursion applies only to root selectors.
Lists default to 20, maximum 100, with counts/truncation. Compact/deep budgets
are 4096/24576 bytes; progress retains clues and a follow-up query. `--select`
is narrow unless `--include event-details` is also requested. `--include status`
opts into legacy Case status. Event details retain real `status_updates`.
Logical roots need no local mapping; `mappingAvailable` means configured, not existing.
Link bodies require a named Case link and exact Notes section.

## Record one completed result

Choose the Case, Study or registered root/exact directory. Prepared work stays
at its root until registration; no empty hierarchy/pending list; never own Data.

```text
checkpoint TARGET --request-json '{"schema":"research-workflow/checkpoint-request","schema_version":1,"event":{"kind":"validation","summary":"Purpose; verified result; validation level and remaining limit.","evidence":[{"kind":"file","locator":{"kind":"root","root_id":"scripts","path":"process/example.py"},"observation":"Direct evidence of the reported change."}]}}' --write --json
```

Event-only checkpoints write once; TARGET owns the result; `changes` defaults to `[]`.
Use summary/observation for purpose, reasons, checks and limits; never invent evidence.

## Explicit simulation-definition confirmation

Case writes use canonical SIM_ID or registered absolute paths, not `case:`.
`case create`, `case revise`, `case rename`, and `case delete` only prepare local
saved previews. Their old `--write` fails with the supported migration path.
Revise requires `--reason input-change|metadata-correction` and current
`--expect-digest`; rename/delete also require the current source head.
Checkpoint Case changes name `target`, current `if_match`, `reason`, patch/profile
data and `responsibility: "simulation-definition"`; write only after plan acceptance.

```text
case revise TARGET --reason input-change --expect-digest HEAD --content-patch-json '{"parameter":"verified value"}' --input-config root:simulation/project/study/case/input.deck --json
case apply --plan PLAN_DIGEST --write --json
```

Between these commands, show the files/checks and registration difference,
actually ask the user, and await acceptance. Plan equality cannot prove consent.
`checkpoint --apply-plan DIGEST --write` is a replay alias; do not mix requests.
Repeated `--input-config` or change `input_configs` names exact UTF-8 configuration
text, generated parameters, or manifests. No include expansion, size cutoff,
raw-data scan or execution occurs; Data/Notes, symlinks and binary input refuse.
Digests stay local; changed heads/dependencies/inputs/mappings/device invalidate plans.
Unchanged definitions and successful retries add nothing; partial state stops. No Case result event.

## Store, policy and recovery

`store upgrade --to-schema 3 --json` previews the actual diff/digest; only real
confirmation permits `--expect-digest DIGEST --write`. Already-current is a no-op.
`doctor --compatibility-only --store ABSOLUTE_STORE --json` needs no workspace;
it checks archived code/Store pairing, not full acceptance. Never auto-migrate.
`policy target retire ABSOLUTE_PATH --replacement PARENT_AGENTS --proposal-id ID
--evidence LOCATOR` previews; `--write` saves pending. Reenable omits replacement:
`policy target reenable ABSOLUTE_PATH --proposal-id NEW_ID --evidence LOCATOR`.
`policy propose --proposal FILE` handles schema-1 policy; `--write` saves pending.
Then `policy plan ID --json`, show exact diff/scope/digest and await real consent.
Record it with `policy approve ID --expect-digest DIGEST --actor user
--decided-at UTC --write`, then `policy apply ID --expect-digest DIGEST --write`.
Run `policy check --json`; retain allowlists, history and unmanaged bytes.
Retirement requires a compatible same-root ancestor; file deletion is separate.
Stale approved open proposals need a new ID/preview/consent. Conflict or drift
never licenses repair. Reenable needs new approval and restores no old body.
Completion rechecks all bound files; rollback preserves later external edits and
reports any incomplete rollback. Stop on partial state; receipts are not authority.
No Store downgrade exists. Recovery needs an explicitly reviewed matching backup;
never remove capabilities or rewrite journals to bypass an incompatible writer.
`validate` checks actual allowlist conflicts; `policy check` additionally reports
drift. Inspect JSON valid fields, not only exit codes. Neither command repairs.
Use affected tests; fast is isolated, live/full acceptance requires explicit scope.
Full skill checks may refresh SQLite; default checks do not. Recovery tar is unknown.
Complete commands, failure handling and per-device steps: `CONTROL_ROOT/README.md`,
`GIT_PRIVATE_REMOTE.md` and `CODEX_SKILL_SYNC.md`. No external sync is automatic.
