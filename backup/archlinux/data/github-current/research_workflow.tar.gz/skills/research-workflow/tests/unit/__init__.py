"""Unit tests for the research-workflow skill bundle."""
