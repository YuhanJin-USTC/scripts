"""Tests for the research-workflow skill bundle."""
