---
name: research-workflow
description: Restore Research Workflow 0.2.4 research memory for Cases, Studies, Projects, and registered root paths; record substantive results once and require real user confirmation before changing a simulation definition. Use for research work, metadata queries, validation, corrections, or policy proposals under registered roots.
---

# Research Workflow

## Authority

- Resolve `CONTROL_ROOT` from this repository-backed skill; use absolute paths.
- Use `CONTROL_ROOT/tools/researchctl.py` as the only supported CLI.
- `workspace.toml` resolves local roots and device identity; `SCHEMA.md` defines
  the contract; metadata and policy JSON are portable authority. SQLite and
  saved confirmation plans are local derived state.
- Read [references/operations.md](references/operations.md) before writes,
  corrections, cross-root decisions, multi-device work, or a CLI failure.

## Task lifecycle

1. Read global, root, and nearest instructions. Resolve the exact target through
   the local registry. Similar names do not establish identity or pairing.
2. On a device switch, satisfy the sequential sync-before-context gate before
   queries or any portable write, including event-only work. External Git and
   network operations require separate authorization.
3. Run `context TARGET --view compact --json` for Case, Study, Project, or exact
   root/path memory. Request details only when compact evidence is insufficient.
4. Complete the authorized work and relevant checks. Distinguish structural,
   numerical, and physical validation; user acceptance is not scientific proof.
5. Record one substantive result with an event-only `checkpoint`. A positional
   Case target supplies ownership, never an implicit Case change. Without Case
   membership, use the registered root and exact directory; create no empty
   Project/Study/Case and no pending-confirmation queue.
6. Only explicit registration or a named simulation-definition operation starts
   a Case preview. Finish files/checks, show the actual difference, genuinely ask
   the user, and wait. Then use `case apply --plan DIGEST --write`. A digest
   proves equality, not consent. Every revision requires current `if_match`.
7. Report changed paths, evidence, validation, the single event outcome, skipped
   external operations, and remaining unknowns or limits.

Do not record pure Q&A, planning, read-only checks, or unsuccessful work without
an enduring result. Later accepted registration writes only the Case journal
when its completed-work event already exists.

## Useful research memory

Use existing event `summary` and evidence `observation` to retain purpose,
actual result, accepted decisions and reasons, validation level, and limits
when known. These are guidance, not mandatory fields or invented conclusions.
Keep exact equations, code, and parameters in evidence read on demand.

- `event list [TARGET]` shows bounded work history; `event show EVENT_ID` restores
  evidence and corrections. Default progress has no automatic three-track
  status projection; explicit `--include status` remains available for Cases.
- Root/path matching is exact unless `--recursive` is requested. Logical roots
  remain readable without a local mapping; local scientific access and writes
  still require registration. Theory work stays at its exact directory owner.
- Keep original owners and historical journal/event bytes. Preserve correction
  and rename lineage. Do not choose a winning sibling head or merge JSONL.

## Boundaries and installation

Data is read-only. Read Notes only through an exact requested link and section;
write Notes only on explicit request. Never scan raw results or ingest Notes,
Zotero, or external URIs to discover context. Git, network, SSH, sync, transfer,
cluster, simulation, MATLAB, builds, containers, SIF, and APIs require separate
authorization. `sync plan` never executes synchronization.

Store 3 requires explicit `store upgrade --to-schema 3` preview and real user
approval before digest-bound write; never migrate on import, queries or events.
Target retire/reenable commands save only pending proposals. Retain exact
allowlists, device/path history and every unmanaged byte; a same-root ancestor
must carry retirement inheritance. Missing retired files stay absent. Removing
an AGENTS file or changing its body needs separate exact approval.

Policy promotion uses pending preview, real user approval through
`policy approve`, and digest-bound apply. Preserve unmanaged instruction bytes;
Data/Notes need exact separate approval. Never self-approve or repair drift.

The ordinary installation check does not scan live authority or refresh cache.
Use `--full` only for explicit live structural acceptance; its queries may
refresh the derived index. Preview installation before `--write`.

```text
python3 -B "<CONTROL_ROOT>/skills/research-workflow/scripts/check_installation.py" --codex-home "/actual/Codex/home" --json
```

Historical `migrate`/`migrate-tombstone` records remain readable, and existing
Project/Study schema 1 stays supported. Do not normalize old metadata. The
historical recovery tar remains unavailable; its location is `to-confirm`.
