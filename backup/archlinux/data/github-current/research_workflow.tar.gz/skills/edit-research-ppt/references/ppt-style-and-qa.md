# PowerPoint edit contract and QA

## Contract

Use one absolute-path JSON document:

```json
{
  "schema": "edit-research-ppt/edit-contract",
  "schemaVersion": 1,
  "sourcePptx": "/abs/source.pptx",
  "fragmentPptx": "/abs/fragment.pptx",
  "outputPptx": "/abs/output.pptx",
  "expectedSourceSha256": "<sha256>",
  "expectedFragmentSha256": "<sha256>",
  "mathLedger": "/abs/math.json",
  "expectedMathLedgerSha256": "<sha256>",
  "expectedSlideCount": 12,
  "operations": [{"action": "insert_slide", "destinationAfter": 10,
    "fragmentSlide": 1, "referenceSlide": 8, "equations": []}],
  "equations": []
}
```
Use only `insert_slide` or `replace_slide`. Replacement uses
`destinationSlide`; insertion uses `destinationAfter` (zero means the start).
Slide numbers are 1-based; unaddressed slides are preserve-only.
Run:

```text
python3 -B scripts/pptx_preflight.py --source "/abs/source.pptx" --authorized-slides "" --json
powershell.exe -NoProfile -File scripts/assemble_with_powerpoint.ps1 -Mode ExtractFragment -Source "/abs/source.pptx" -Output "/abs/starter.pptx" -Contract "/abs/edit-contract.json" -ExpectedSourceSha256 "<sha256>"
node scripts/build_fragment.mjs --content-model "/abs/content.json" --output "/abs/fragment.pptx" --math-ledger "/abs/math.json"
powershell.exe -NoProfile -File scripts/assemble_with_powerpoint.ps1 -Mode Assemble -Source "/abs/source.pptx" -Fragment "/abs/fragment.pptx" -Output "/abs/output.pptx" -Contract "/abs/edit-contract.json" -ExpectedSourceSha256 "<sha256>"
python3 -B scripts/verify_pptx.py --source "/abs/source.pptx" --output "/abs/output.pptx" --contract "/abs/edit-contract.json" --json
node scripts/verify_math_reimport.mjs --pptx "/abs/output.pptx" --contract "/abs/edit-contract.json"
```

Use PowerPoint COM to extract only declared reference slides. The content model
must name the absolute `starterPptx` and exact inherited object IDs. Initialize
the workspace with the Presentations setup script, then use:

```json
{
  "schema": "edit-research-ppt/fragment-content",
  "schemaVersion": 1,
  "starterPptx": "/abs/starter.pptx",
  "expectedSlideCount": 1,
  "slides": [{"fragmentSlide": 1, "edits": [{"action": "set_shape_text",
    "targetId": "tx/from-inspect", "value": [["CFL = ", {"equationId": "eq-1",
    "latex": "\\frac{c\\,\\Delta t}{\\Delta x}", "displayMode": "inline"}]]}]}]
}
```

Extraction may use a draft contract. Before assembly, add both generated-file
hashes, copy ledger `equations` exactly, and reference every ID once. The final
contract rejects unknown fields.

## Native math

Use structured runs, not a string that merely looks like LaTeX:

```js
shape.text.set([[
  "CFL = ",
  { latex: String.raw`\frac{c\,\Delta t}{\Delta x}`, displayMode: "inline" },
]]);
```

An inline formula may share a paragraph with text. A block formula must be the
only run in its paragraph. Table cells accept the same structured input.

The builder records exact object/cell, ordinal, LaTeX, display mode, MathML,
structures, and OMML count. It rejects parser degradation, residual commands,
split equations, mixed block paragraphs, and text/image fallbacks.

Final validation requires `m:oMath` or `m:oMathPara` in the intended object and
successful re-import as `inlineNodes.math`.

## Preserve and compare

Compare slide order, object IDs/geometry/text, paragraph and run formats,
complete bullet tuples, media/dependency relationships, and normalized OMML.

Preserve-only slides must remain semantically identical. In particular,
`buChar="Ø"` with `buFont typeface="Wingdings"` is an arrow mapping; losing
`buFont` is a contract failure even when the character remains.

Render all slides at the same dimensions. Reject overflow, clipping, overlap,
font substitution, broken glyphs, changed preserve-only slides, or unexpected
page furniture. Compare changed slides with their declared reference slides.

Verify every scientific value, unit, sign, exponent, range, qualifier, and scan
group against the authorized source. Keep independent scans separate unless
the request says otherwise. Never infer missing values.

## Delivery

Require a distinct output, unchanged source hash, expected slide order/count,
editable objects, successful reopen/parse, and clean full-deck render. Inventory
retained scratch and delete only command-generated temporary files.
