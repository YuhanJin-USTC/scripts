"""Test the repository-bundled edit-research-ppt installation."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[4]
SKILL_NAMES = ("edit-research-ppt",)


class EditResearchPptSkillBundleTests(unittest.TestCase):
    """Keep installations preview-first, recoverable, and repository-backed."""

    def _script(
        self,
        skill_name: str,
        script_name: str = "install.py",
    ) -> Path:
        return ROOT / "skills" / skill_name / "scripts" / script_name

    def _run(
        self,
        skill_name: str,
        *args: str,
        script_name: str = "install.py",
        env: dict[str, str] | None = None,
    ) -> tuple[int, dict[str, object]]:
        environment = os.environ.copy()
        environment.pop("CODEX_HOME", None)
        if env:
            environment.update(env)
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(self._script(skill_name, script_name)),
                *args,
                "--json",
            ],
            text=True,
            capture_output=True,
            check=False,
            env=environment,
        )
        return result.returncode, json.loads(result.stdout)

    def test_create_preview_write_and_reuse(self) -> None:
        for skill_name in SKILL_NAMES:
            with self.subTest(skill=skill_name), tempfile.TemporaryDirectory() as temporary:
                codex_home = Path(temporary) / ".codex"
                destination = codex_home / "skills" / skill_name
                arguments = ("--codex-home", str(codex_home))

                code, preview = self._run(skill_name, *arguments)
                self.assertEqual(code, 0, preview)
                self.assertEqual(preview["action"], "create-link")
                self.assertFalse(preview["written"])
                self.assertFalse(destination.exists())

                code, written = self._run(skill_name, *arguments, "--write")
                self.assertEqual(code, 0, written)
                self.assertTrue(written["written"])
                self.assertTrue(destination.is_symlink())
                self.assertEqual(destination.resolve(), ROOT / "skills" / skill_name)

                code, reused = self._run(skill_name, *arguments)
                self.assertEqual(code, 0, reused)
                self.assertEqual(reused["action"], "reuse")
                self.assertFalse(reused["written"])

    def test_preview_then_backup_and_link_existing_skill(self) -> None:
        for skill_name in SKILL_NAMES:
            with self.subTest(skill=skill_name), tempfile.TemporaryDirectory() as temporary:
                codex_home = Path(temporary) / ".codex"
                destination = codex_home / "skills" / skill_name
                destination.mkdir(parents=True)
                (destination / "legacy.txt").write_text("legacy", encoding="utf-8")
                backup = codex_home / "backups" / f"{skill_name}-legacy"
                arguments = (
                    "--codex-home",
                    str(codex_home),
                    "--backup-existing",
                    str(backup),
                )

                code, preview = self._run(skill_name, *arguments)
                self.assertEqual(code, 0, preview)
                self.assertEqual(preview["action"], "backup-and-link")
                self.assertFalse(preview["written"])
                self.assertFalse(backup.exists())

                code, written = self._run(skill_name, *arguments, "--write")
                self.assertEqual(code, 0, written)
                self.assertTrue(destination.is_symlink())
                self.assertEqual((backup / "legacy.txt").read_text(encoding="utf-8"), "legacy")

    def test_reject_relative_paths_and_environment(self) -> None:
        for skill_name in SKILL_NAMES:
            with self.subTest(skill=skill_name):
                code, result = self._run(skill_name, "--codex-home", "relative-home")
                self.assertEqual(code, 2)
                self.assertIn("must be absolute", str(result["error"]))

                code, result = self._run(
                    skill_name,
                    env={"CODEX_HOME": "relative-from-env"},
                )
                self.assertEqual(code, 2)
                self.assertIn("CODEX_HOME must be absolute", str(result["error"]))

                code, result = self._run(
                    skill_name,
                    "--codex-home",
                    "relative-home",
                    script_name="check_installation.py",
                )
                self.assertEqual(code, 2)
                self.assertTrue(result["input_error"])

    def test_reject_unsafe_or_inapplicable_backup(self) -> None:
        for skill_name in SKILL_NAMES:
            with self.subTest(skill=skill_name), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                codex_home = root / ".codex"
                destination = codex_home / "skills" / skill_name
                destination.mkdir(parents=True)

                cases = (
                    (root / "outside", "inside CODEX_HOME"),
                    (codex_home / "skills" / "backup", "outside CODEX_HOME/skills"),
                )
                for backup, message in cases:
                    code, result = self._run(
                        skill_name,
                        "--codex-home",
                        str(codex_home),
                        "--backup-existing",
                        str(backup),
                    )
                    self.assertEqual(code, 2)
                    self.assertIn(message, str(result["error"]))
                    self.assertTrue(destination.is_dir())

                code, result = self._run(
                    skill_name,
                    "--codex-home",
                    str(codex_home),
                    "--backup-existing",
                    "relative-backup",
                )
                self.assertEqual(code, 2)
                self.assertIn("backup must be absolute", str(result["error"]))

                existing_backup = codex_home / "backups" / "existing"
                existing_backup.mkdir(parents=True)
                code, result = self._run(
                    skill_name,
                    "--codex-home",
                    str(codex_home),
                    "--backup-existing",
                    str(existing_backup),
                )
                self.assertEqual(code, 2)
                self.assertIn("already exists", str(result["error"]))

                code, result = self._run(
                    skill_name,
                    "--codex-home",
                    str(codex_home),
                )
                self.assertEqual(code, 2)
                self.assertIn("--backup-existing", str(result["error"]))

                destination.rename(codex_home / "moved")
                code, result = self._run(
                    skill_name,
                    "--codex-home",
                    str(codex_home),
                    "--backup-existing",
                    str(codex_home / "backups" / "unused"),
                )
                self.assertEqual(code, 2)
                self.assertIn("only valid", str(result["error"]))

    def test_failed_link_restores_existing_installation(self) -> None:
        for skill_name in SKILL_NAMES:
            with self.subTest(skill=skill_name), tempfile.TemporaryDirectory() as temporary:
                script = self._script(skill_name)
                spec = spec_from_file_location(f"installer_{skill_name}", script)
                self.assertIsNotNone(spec)
                self.assertIsNotNone(spec.loader)
                module = module_from_spec(spec)
                spec.loader.exec_module(module)

                codex_home = (Path(temporary) / ".codex").resolve()
                destination = codex_home / "skills" / skill_name
                destination.mkdir(parents=True)
                marker = destination / "legacy.txt"
                marker.write_text("legacy", encoding="utf-8")
                backup = codex_home / "backups" / skill_name

                with mock.patch.object(Path, "symlink_to", side_effect=OSError("forced")):
                    with self.assertRaises(OSError):
                        module.install(codex_home, backup, write=True)

                self.assertEqual(marker.read_text(encoding="utf-8"), "legacy")
                self.assertFalse(backup.exists())

    def test_skill_structure_and_progressive_disclosure(self) -> None:
        for skill_name in SKILL_NAMES:
            with self.subTest(skill=skill_name):
                skill_root = ROOT / "skills" / skill_name
                for relative in (
                    "SKILL.md",
                    "agents/openai.yaml",
                    "scripts/install.py",
                    "scripts/check_installation.py",
                ):
                    self.assertTrue((skill_root / relative).is_file(), relative)
                text = (skill_root / "SKILL.md").read_text(encoding="utf-8")
                self.assertTrue(text.startswith("---\nname:"))
                self.assertIn(f"${skill_name}", (skill_root / "agents" / "openai.yaml").read_text(encoding="utf-8"))
                self.assertLessEqual(len(text.splitlines()), 100)

        edit_reference = ROOT / "skills" / "edit-research-ppt" / "references" / "ppt-style-and-qa.md"
        self.assertLessEqual(len(edit_reference.read_text(encoding="utf-8").splitlines()), 100)


if __name__ == "__main__":
    unittest.main()
