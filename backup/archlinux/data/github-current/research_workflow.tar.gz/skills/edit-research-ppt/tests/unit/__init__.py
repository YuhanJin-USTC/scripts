"""Unit tests for the edit-research-ppt skill bundle."""
