"""Tests for the edit-research-ppt skill bundle."""
