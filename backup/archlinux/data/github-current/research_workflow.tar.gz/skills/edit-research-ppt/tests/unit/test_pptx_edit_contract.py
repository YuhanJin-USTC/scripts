"""Test bounded PPTX semantic preservation without private decks."""

from __future__ import annotations

import hashlib
import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[4]
SCRIPTS = ROOT / "skills" / "edit-research-ppt" / "scripts"
PREFLIGHT = SCRIPTS / "pptx_preflight.py"
VERIFY = SCRIPTS / "verify_pptx.py"


def _slide(
    text: str,
    *,
    name: str = "Body",
    bullet_font: str | None = None,
    bullet_char: str | None = None,
    math: str | None = None,
    block_math: bool = False,
    run_font: str = "Arial",
    x: int = 100,
) -> str:
    bullet = ""
    if bullet_char is not None:
        font = (
            f'<a:buFont typeface="{bullet_font}"/>'
            if bullet_font is not None
            else ""
        )
        bullet = f'<a:pPr marL="342900" indent="-342900">{font}<a:buChar char="{bullet_char}"/></a:pPr>'
    if math is None:
        content = (
            '<a:r><a:rPr lang="en-US">'
            f'<a:latin typeface="{run_font}"/>'
            f"</a:rPr><a:t>{text}</a:t></a:r>"
        )
    else:
        equation = (
            "<m:oMath><m:r><m:t>"
            f"{math}"
            "</m:t></m:r></m:oMath>"
        )
        if block_math:
            equation = f"<m:oMathPara>{equation}</m:oMathPara>"
        content = (
            '<a14:m xmlns:a14="http://schemas.microsoft.com/office/drawing/2010/main">'
            f"{equation}</a14:m>"
        )
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
        'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" '
        'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        "<p:cSld><p:spTree>"
        "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>"
        "<p:grpSpPr/>"
        "<p:sp><p:nvSpPr>"
        f'<p:cNvPr id="2" name="{name}"/>'
        "<p:cNvSpPr/><p:nvPr/></p:nvSpPr>"
        f'<p:spPr><a:xfrm><a:off x="{x}" y="200"/><a:ext cx="300" cy="400"/></a:xfrm></p:spPr>'
        f"<p:txBody><a:bodyPr/><a:lstStyle/><a:p>{bullet}{content}<a:endParaRPr lang=\"en-US\"/></a:p></p:txBody>"
        "</p:sp></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>"
        "</p:sld>"
    )


def _table_slide(math: str) -> str:
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
        'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" '
        'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">'
        "<p:cSld><p:spTree>"
        "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>"
        "<p:grpSpPr/><p:graphicFrame><p:nvGraphicFramePr>"
        '<p:cNvPr id="2" name="Equation Table"/><p:cNvGraphicFramePr/><p:nvPr/>'
        "</p:nvGraphicFramePr>"
        '<p:xfrm><a:off x="100" y="200"/><a:ext cx="300" cy="400"/></p:xfrm>'
        "<a:graphic><a:graphicData><a:tbl><a:tblPr/><a:tblGrid><a:gridCol w=\"300\"/></a:tblGrid>"
        "<a:tr h=\"400\"><a:tc><a:txBody><a:bodyPr/><a:lstStyle/><a:p>"
        '<a14:m xmlns:a14="http://schemas.microsoft.com/office/drawing/2010/main">'
        f"<m:oMath><m:r><m:t>{math}</m:t></m:r></m:oMath></a14:m>"
        "<a:endParaRPr/></a:p></a:txBody><a:tcPr/></a:tc></a:tr>"
        "</a:tbl></a:graphicData></a:graphic></p:graphicFrame>"
        "</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr>"
        "</p:sld>"
    )


def _field_slide(value: str) -> str:
    regular = (
        '<a:r><a:rPr lang="en-US"><a:latin typeface="Arial"/>'
        f"</a:rPr><a:t>{value}</a:t></a:r>"
    )
    field = (
        '<a:fld id="{00000000-0000-0000-0000-000000000001}" '
        'type="datetime8"><a:rPr lang="en-US">'
        '<a:latin typeface="Arial"/></a:rPr>'
        f"<a:t>{value}</a:t></a:fld>"
    )
    return _slide(value).replace(regular, field)


def _write_deck(
    path: Path,
    slides: list[str],
    *,
    media: dict[int, bytes] | None = None,
) -> None:
    media = media or {}
    slide_ids = "".join(
        f'<p:sldId id="{255 + index}" r:id="rId{index}"/>'
        for index in range(1, len(slides) + 1)
    )
    presentation = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        f"<p:sldIdLst>{slide_ids}</p:sldIdLst>"
        '<p:sldSz cx="12192000" cy="6858000"/><p:notesSz cx="6858000" cy="9144000"/>'
        "</p:presentation>"
    )
    relationships = "".join(
        f'<Relationship Id="rId{index}" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" '
        f'Target="slides/slide{index}.xml"/>'
        for index in range(1, len(slides) + 1)
    )
    content_overrides = "".join(
        f'<Override PartName="/ppt/slides/slide{index}.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>'
        for index in range(1, len(slides) + 1)
    )
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/ppt/presentation.xml" '
        'ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>'
        f"{content_overrides}</Types>"
    )
    package_relationships = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" '
        'Target="ppt/presentation.xml"/></Relationships>'
    )
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types)
        archive.writestr("_rels/.rels", package_relationships)
        archive.writestr("ppt/presentation.xml", presentation)
        archive.writestr(
            "ppt/_rels/presentation.xml.rels",
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            f"{relationships}</Relationships>",
        )
        for index, slide in enumerate(slides, 1):
            archive.writestr(f"ppt/slides/slide{index}.xml", slide)
            if index in media:
                archive.writestr(
                    f"ppt/slides/_rels/slide{index}.xml.rels",
                    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                    '<Relationship Id="rId1" '
                    'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" '
                    f'Target="../media/image{index}.png"/></Relationships>',
                )
                archive.writestr(
                    f"ppt/media/image{index}.png", media[index]
                )


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class PptxEditContractTests(unittest.TestCase):
    """Fail closed when a deck edit changes preserved semantics."""

    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.source = self.root / "source.pptx"
        self.output = self.root / "output.pptx"
        self.fragment = self.root / "fragment.pptx"
        self.math_ledger = self.root / "math-ledger.json"
        self.contract = self.root / "edit-contract.json"
        self.slides = [
            _slide(
                "Heading",
                bullet_font="Wingdings",
                bullet_char="Ø",
            ),
            _slide("Authorized body"),
            _slide("", name="Equation 1", math="x"),
        ]
        _write_deck(self.source, self.slides)
        _write_deck(self.fragment, [_slide("Fragment")])

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def _write_contract(
        self,
        *,
        operations: list[dict[str, Any]] | None = None,
        equations: list[dict[str, Any]] | None = None,
    ) -> None:
        normalized_equations = [
            {
                **equation,
                "sourceLatex": equation.get(
                    "sourceLatex", equation["latex"]
                ),
                "normalizedLatex": equation.get(
                    "normalizedLatex", equation["latex"]
                ),
            }
            for equation in (equations or [])
        ]
        for equation in normalized_equations:
            if " display=" not in equation["mathMl"]:
                equation["mathMl"] = equation["mathMl"].replace(
                    "<math ",
                    f'<math display="{equation["displayMode"]}" ',
                    1,
                )
        totals: dict[tuple[int, str, str], int] = {}
        ordinals: dict[tuple[int, str, str], int] = {}
        for equation in normalized_equations:
            key = (
                equation["fragmentSlide"],
                equation["targetId"],
                equation["location"],
            )
            totals[key] = totals.get(key, 0) + 1
        for equation in normalized_equations:
            key = (
                equation["fragmentSlide"],
                equation["targetId"],
                equation["location"],
            )
            ordinals[key] = ordinals.get(key, 0) + 1
            equation.setdefault("equationOrdinal", ordinals[key])
            equation.setdefault("expectedOmmlCount", totals[key])
        generated_keys = {
            "id",
            "fragmentSlide",
            "targetId",
            "objectName",
            "location",
            "latex",
            "sourceLatex",
            "normalizedLatex",
            "displayMode",
            "mathMl",
            "structures",
            "equationOrdinal",
            "expectedOmmlCount",
        }
        ledger = {
            "schema": "edit-research-ppt/math-ledger",
            "schemaVersion": 1,
            "sourceFragmentPptx": str(self.root / "starter.pptx"),
            "outputFragmentPptx": str(self.fragment),
            "equations": [
                {key: equation[key] for key in generated_keys}
                for equation in normalized_equations
            ],
        }
        self.math_ledger.write_text(
            json.dumps(ledger, ensure_ascii=False), encoding="utf-8"
        )
        value = {
            "schema": "edit-research-ppt/edit-contract",
            "schemaVersion": 1,
            "sourcePptx": str(self.source),
            "fragmentPptx": str(self.fragment),
            "outputPptx": str(self.output),
            "expectedSourceSha256": _sha256(self.source),
            "expectedFragmentSha256": _sha256(self.fragment),
            "mathLedger": str(self.math_ledger),
            "expectedMathLedgerSha256": _sha256(self.math_ledger),
            "expectedSlideCount": 3,
            "operations": operations
            if operations is not None
            else [
                {
                    "action": "replace_slide",
                    "fragmentSlide": 1,
                    "destinationSlide": 2,
                    "referenceSlide": 2,
                    "equations": [],
                }
            ],
            "equations": normalized_equations,
        }
        self.contract.write_text(
            json.dumps(value, ensure_ascii=False), encoding="utf-8"
        )

    def _run_verify(self) -> tuple[int, dict[str, Any]]:
        result = subprocess.run(
            [
                sys.executable,
                "-P",
                "-B",
                str(VERIFY),
                "--source",
                str(self.source),
                "--output",
                str(self.output),
                "--contract",
                str(self.contract),
                "--json",
            ],
            text=True,
            capture_output=True,
            check=False,
        )
        return result.returncode, json.loads(result.stdout)

    def _codes(self, result: dict[str, Any]) -> set[str]:
        return {str(error["code"]) for error in result.get("errors", [])}

    def test_preflight_inventories_authorized_and_preserved_slides(self) -> None:
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(PREFLIGHT),
                "--source",
                str(self.source),
                "--authorized-slides",
                "2-3",
                "--json",
            ],
            text=True,
            capture_output=True,
            check=False,
        )
        value = json.loads(result.stdout)
        self.assertEqual(result.returncode, 0, value)
        self.assertEqual(value["slideCount"], 3)
        self.assertEqual(value["authorizedSlides"], [2, 3])
        self.assertEqual(value["preserveSlides"], [1])
        self.assertEqual(value["slides"][0]["bullets"][0]["font"]["typeface"], "Wingdings")
        self.assertEqual(len(value["slides"][2]["equations"]), 1)

    def test_identical_preserved_slides_pass(self) -> None:
        _write_deck(self.output, self.slides)
        self._write_contract()
        code, result = self._run_verify()
        self.assertEqual(code, 0, result)
        self.assertTrue(result["ok"])
        self.assertEqual(result["preservedSourceSlides"], [1, 3])

    def test_wingdings_bullet_font_loss_fails(self) -> None:
        changed = list(self.slides)
        changed[0] = _slide("Heading", bullet_char="Ø")
        _write_deck(self.output, changed)
        self._write_contract()
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("bullet-font-missing", self._codes(result))
        self.assertIn("bullet-changed", self._codes(result))

    def test_authorized_slide_still_requires_wingdings_bullet_font(self) -> None:
        changed = list(self.slides)
        changed[0] = _slide("Heading", bullet_char="Ø")
        _write_deck(self.output, changed)
        operations = [
            {
                "action": "replace_slide",
                "fragmentSlide": 1,
                "destinationSlide": 1,
                "referenceSlide": 1,
                "equations": [],
            }
        ]
        self._write_contract(operations=operations)
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("bullet-font-missing", self._codes(result))
        self.assertIn("bullet-font-removed", self._codes(result))

    def test_slide_reorder_fails(self) -> None:
        changed = [self.slides[2], self.slides[1], self.slides[0]]
        _write_deck(self.output, changed)
        self._write_contract()
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("slide-order-changed", self._codes(result))

    def test_unauthorized_text_change_fails(self) -> None:
        changed = list(self.slides)
        changed[0] = _slide(
            "Changed",
            bullet_font="Wingdings",
            bullet_char="Ø",
        )
        _write_deck(self.output, changed)
        self._write_contract()
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("text-changed", self._codes(result))

    def test_cached_datetime_field_refresh_is_semantically_equal(self) -> None:
        source_slides = list(self.slides)
        output_slides = list(self.slides)
        source_slides[0] = _field_slide("27 July 2026")
        output_slides[0] = _field_slide("29 July 2026")
        _write_deck(self.source, source_slides)
        _write_deck(self.output, output_slides)
        self._write_contract()
        code, result = self._run_verify()
        self.assertEqual(code, 0, result)

    def test_unauthorized_geometry_and_run_font_changes_fail(self) -> None:
        changed = list(self.slides)
        changed[0] = _slide(
            "Heading",
            bullet_font="Wingdings",
            bullet_char="Ø",
            run_font="Calibri",
            x=101,
        )
        _write_deck(self.output, changed)
        self._write_contract()
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("geometry-changed", self._codes(result))
        self.assertIn("run-font-changed", self._codes(result))

    def test_unauthorized_paragraph_format_change_fails(self) -> None:
        changed = list(self.slides)
        changed[0] = changed[0].replace(
            '<a:pPr marL="342900"',
            '<a:pPr algn="ctr" marL="342900"',
            1,
        )
        _write_deck(self.output, changed)
        self._write_contract()
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("paragraph-format-changed", self._codes(result))

    def test_unauthorized_media_change_fails(self) -> None:
        _write_deck(self.source, self.slides, media={1: b"source-image"})
        _write_deck(self.output, self.slides, media={1: b"changed-image"})
        self._write_contract()
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("relationships-changed", self._codes(result))
        self.assertIn("media-relationships-changed", self._codes(result))

    def test_omml_loss_on_preserved_slide_fails(self) -> None:
        changed = list(self.slides)
        changed[2] = _slide("x", name="Equation 1")
        _write_deck(self.output, changed)
        self._write_contract()
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("equations-changed", self._codes(result))

    def test_plain_text_formula_on_replacement_fails(self) -> None:
        changed = list(self.slides)
        changed[2] = _slide(r"\frac{x}{y}", name="Equation 1")
        _write_deck(self.output, changed)
        equations = [
            {
                "id": "eq-1",
                "fragmentSlide": 1,
                "targetId": "equation-1",
                "objectName": "Equation 1",
                "location": "shape",
                "latex": r"\frac{x}{y}",
                "displayMode": "inline",
                "mathMl": (
                    '<math xmlns="http://www.w3.org/1998/Math/MathML">'
                    "<mfrac><mi>x</mi><mi>y</mi></mfrac></math>"
                ),
                "structures": ["fraction"],
            }
        ]
        operations = [
            {
                "action": "replace_slide",
                "fragmentSlide": 1,
                "destinationSlide": 3,
                "referenceSlide": 3,
                "equations": ["eq-1"],
            }
        ]
        self._write_contract(operations=operations, equations=equations)
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("equation-native-missing", self._codes(result))

    def test_block_native_equation_passes(self) -> None:
        changed = list(self.slides)
        changed[2] = _slide(
            "", name="Equation 1", math="x", block_math=True
        )
        _write_deck(self.output, changed)
        equations = [
            {
                "id": "eq-block",
                "fragmentSlide": 1,
                "targetId": "equation-block",
                "objectName": "Equation 1",
                "location": "shape",
                "latex": "x",
                "displayMode": "block",
                "mathMl": (
                    '<math xmlns="http://www.w3.org/1998/Math/MathML">'
                    "<mi>x</mi></math>"
                ),
                "structures": ["text"],
            }
        ]
        operations = [
            {
                "action": "replace_slide",
                "fragmentSlide": 1,
                "destinationSlide": 3,
                "referenceSlide": 3,
                "equations": ["eq-block"],
            }
        ]
        self._write_contract(operations=operations, equations=equations)
        code, result = self._run_verify()
        self.assertEqual(code, 0, result)

    def test_table_cell_native_equation_passes(self) -> None:
        changed = list(self.slides)
        changed[2] = _table_slide("x")
        _write_deck(self.output, changed)
        equations = [
            {
                "id": "eq-table",
                "fragmentSlide": 1,
                "targetId": "equation-table",
                "objectName": "Equation Table",
                "location": "table:R1C1",
                "latex": "x",
                "displayMode": "inline",
                "mathMl": (
                    '<math xmlns="http://www.w3.org/1998/Math/MathML">'
                    "<mi>x</mi></math>"
                ),
                "structures": ["text"],
            }
        ]
        operations = [
            {
                "action": "replace_slide",
                "fragmentSlide": 1,
                "destinationSlide": 3,
                "referenceSlide": 3,
                "equations": ["eq-table"],
            }
        ]
        self._write_contract(operations=operations, equations=equations)
        code, result = self._run_verify()
        self.assertEqual(code, 0, result)

    def test_unknown_authorization_field_is_rejected(self) -> None:
        _write_deck(self.output, self.slides)
        self._write_contract()
        value = json.loads(self.contract.read_text(encoding="utf-8"))
        value["authorizedSlides"] = [1]
        self.contract.write_text(json.dumps(value), encoding="utf-8")
        code, result = self._run_verify()
        self.assertEqual(code, 2, result)
        self.assertIn("unsupported field", result["error"])

    def test_fragment_hash_mismatch_is_rejected(self) -> None:
        _write_deck(self.output, self.slides)
        self._write_contract()
        value = json.loads(self.contract.read_text(encoding="utf-8"))
        value["expectedFragmentSha256"] = "0" * 64
        self.contract.write_text(json.dumps(value), encoding="utf-8")
        code, result = self._run_verify()
        self.assertEqual(code, 2, result)
        self.assertIn("fragment SHA-256 mismatch", result["error"])

    def test_wrong_table_cell_location_fails(self) -> None:
        changed = list(self.slides)
        changed[2] = _table_slide("x")
        _write_deck(self.output, changed)
        equations = [
            {
                "id": "eq-wrong-cell",
                "fragmentSlide": 1,
                "targetId": "equation-table",
                "objectName": "Equation Table",
                "location": "table:R1C2",
                "latex": "x",
                "displayMode": "inline",
                "mathMl": (
                    '<math xmlns="http://www.w3.org/1998/Math/MathML">'
                    "<mi>x</mi></math>"
                ),
                "structures": ["text"],
            }
        ]
        self._write_contract(
            operations=[
                {
                    "action": "replace_slide",
                    "fragmentSlide": 1,
                    "destinationSlide": 3,
                    "referenceSlide": 3,
                    "equations": ["eq-wrong-cell"],
                }
            ],
            equations=equations,
        )
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("equation-count-mismatch", self._codes(result))
        self.assertIn("equation-ordinal-missing", self._codes(result))

    def test_split_omml_fails_exact_count(self) -> None:
        changed = list(self.slides)
        changed[2] = _slide("", name="Equation 1", math="x").replace(
            "</a14:m>",
            (
                "</a14:m>"
                '<a14:m xmlns:a14="http://schemas.microsoft.com/office/drawing/2010/main">'
                "<m:oMath><m:r><m:t>y</m:t></m:r></m:oMath></a14:m>"
            ),
            1,
        )
        _write_deck(self.output, changed)
        equations = [
            {
                "id": "eq-split",
                "fragmentSlide": 1,
                "targetId": "equation-1",
                "objectName": "Equation 1",
                "location": "shape",
                "latex": "x",
                "displayMode": "inline",
                "mathMl": (
                    '<math xmlns="http://www.w3.org/1998/Math/MathML">'
                    "<mi>x</mi></math>"
                ),
                "structures": ["text"],
            }
        ]
        self._write_contract(
            operations=[
                {
                    "action": "replace_slide",
                    "fragmentSlide": 1,
                    "destinationSlide": 3,
                    "referenceSlide": 3,
                    "equations": ["eq-split"],
                }
            ],
            equations=equations,
        )
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("equation-count-mismatch", self._codes(result))
        self.assertIn("equation-inventory-mismatch", self._codes(result))

    def test_block_math_mixed_with_text_fails(self) -> None:
        changed = list(self.slides)
        changed[2] = _slide(
            "", name="Equation 1", math="x", block_math=True
        ).replace(
            '<a14:m xmlns:a14=',
            '<a:r><a:t>prefix</a:t></a:r><a14:m xmlns:a14=',
            1,
        )
        _write_deck(self.output, changed)
        equations = [
            {
                "id": "eq-mixed",
                "fragmentSlide": 1,
                "targetId": "equation-1",
                "objectName": "Equation 1",
                "location": "shape",
                "latex": "x",
                "displayMode": "block",
                "mathMl": (
                    '<math xmlns="http://www.w3.org/1998/Math/MathML">'
                    "<mi>x</mi></math>"
                ),
                "structures": ["text"],
            }
        ]
        self._write_contract(
            operations=[
                {
                    "action": "replace_slide",
                    "fragmentSlide": 1,
                    "destinationSlide": 3,
                    "referenceSlide": 3,
                    "equations": ["eq-mixed"],
                }
            ],
            equations=equations,
        )
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("equation-block-mixed", self._codes(result))

    def test_ascii_formula_fallback_fails_without_ledger(self) -> None:
        changed = list(self.slides)
        changed[1] = _slide("E=mc^2")
        _write_deck(self.output, changed)
        self._write_contract()
        code, result = self._run_verify()
        self.assertEqual(code, 1, result)
        self.assertIn("equation-plain-text-fallback", self._codes(result))

    def test_relative_preflight_path_is_input_error(self) -> None:
        result = subprocess.run(
            [
                sys.executable,
                "-B",
                str(PREFLIGHT),
                "--source",
                "relative.pptx",
                "--json",
            ],
            text=True,
            capture_output=True,
            check=False,
        )
        value = json.loads(result.stdout)
        self.assertEqual(result.returncode, 2, value)
        self.assertFalse(value["ok"])

    def test_invalid_contract_is_verify_input_error(self) -> None:
        _write_deck(self.output, self.slides)
        self._write_contract()
        value = json.loads(self.contract.read_text(encoding="utf-8"))
        value["expectedSourceSha256"] = "INVALID"
        self.contract.write_text(json.dumps(value), encoding="utf-8")
        code, result = self._run_verify()
        self.assertEqual(code, 2, result)
        self.assertFalse(result["ok"])


if __name__ == "__main__":
    unittest.main()
