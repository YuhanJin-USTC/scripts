"""Test native-math gates for the research PowerPoint fragment builder."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[4]
BUILDER = ROOT / "skills" / "edit-research-ppt" / "scripts" / "build_fragment.mjs"
REIMPORT_VERIFIER = (
    ROOT
    / "skills"
    / "edit-research-ppt"
    / "scripts"
    / "verify_math_reimport.mjs"
)
CONTRACT_SCHEMA = (
    ROOT
    / "skills"
    / "edit-research-ppt"
    / "references"
    / "edit-contract.schema.json"
)
ASSEMBLER = (
    ROOT
    / "skills"
    / "edit-research-ppt"
    / "scripts"
    / "assemble_with_powerpoint.ps1"
)
WINDOWS_NODE = Path("/mnt/b/software/Nodejs/node.exe")
ARTIFACT_TOOL = Path(
    "/mnt/c/Users/jinyuhan/.cache/codex-runtimes/"
    "codex-primary-runtime/dependencies/node/node_modules/"
    "@oai/artifact-tool/dist/artifact_tool.mjs"
)


class PptMathBuilderTests(unittest.TestCase):
    """Keep formula authoring native and fail closed on parser degradation."""

    @classmethod
    def setUpClass(cls) -> None:
        cls.source = BUILDER.read_text(encoding="utf-8")

    def test_builder_is_valid_ecmascript(self) -> None:
        """Catch syntax regressions without loading the native canvas runtime."""

        node = shutil.which("node")
        if node is None:
            self.skipTest("node is unavailable")
        result = subprocess.run(
            [node, "--check", str(BUILDER)],
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_allowlist_contains_only_runtime_verified_commands(self) -> None:
        """Reject common commands that the current parser silently literalizes."""

        commands = set(
            re.findall(r'^\s*\["([A-Za-z]+)", \{ structure:', self.source, re.MULTILINE)
        )
        self.assertTrue(
            {
                "frac",
                "sqrt",
                "sum",
                "int",
                "alpha",
                "delta",
                "Delta",
                "epsilon",
                "varepsilon",
                "rho",
                "partial",
                "nabla",
                "cdot",
                "infty",
            }.issubset(commands)
        )
        self.assertTrue(
            {
                "prod",
                "unknown",
                "mathbf",
            }.isdisjoint(commands)
        )
        self.assertIn("unsupported LaTeX command(s)", self.source)
        self.assertIn("degraded instead of producing native math", self.source)

    def test_builder_enforces_structured_math_and_block_isolation(self) -> None:
        """Prevent strings, Unicode scripts, and mixed block paragraphs."""

        self.assertIn("artifactToolApi.mathFromLatex({", self.source)
        self.assertIn("artifactToolApi.mathToMathMl(math)", self.source)
        self.assertIn("sourceLatex", self.source)
        self.assertIn("normalizedLatex", self.source)
        self.assertIn("PresentationFile.importPptx(", self.source)
        self.assertIn("verifyReimportedMath(reopened, equations)", self.source)
        self.assertIn("inlineNodes.math nodes", self.source)
        self.assertIn("plain-text formula fallback", self.source)
        self.assertIn("block math must be the paragraph's only run", self.source)
        self.assertIn('target.text.set(value)', self.source)
        self.assertIn('target.cells.set(row, column, value)', self.source)

    def test_contract_requires_native_formula_locator(self) -> None:
        """Keep the ledger addressable in final OOXML by object name."""

        schema = json.loads(CONTRACT_SCHEMA.read_text(encoding="utf-8"))
        equation = schema["$defs"]["equation"]
        for field in (
            "expectedFragmentSha256",
            "mathLedger",
            "expectedMathLedgerSha256",
        ):
            self.assertIn(field, schema["required"])
        self.assertIn("objectName", equation["required"])
        self.assertIn("mathMl", equation["required"])
        self.assertIn("structures", equation["required"])
        self.assertIn("sourceLatex", equation["required"])
        self.assertIn("normalizedLatex", equation["required"])
        self.assertIn("equationOrdinal", equation["required"])
        self.assertIn("expectedOmmlCount", equation["required"])
        self.assertEqual(
            set(equation["properties"]["displayMode"]["enum"]),
            {"inline", "block"},
        )

    def test_final_reimport_verifier_is_valid_ecmascript(self) -> None:
        node = shutil.which("node")
        if node is None:
            self.skipTest("node is unavailable")
        result = subprocess.run(
            [node, "--check", str(REIMPORT_VERIFIER)],
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_reimport_gate_requires_inline_math_nodes_and_display_mode(self) -> None:
        node = shutil.which("node")
        if node is None:
            self.skipTest("node is unavailable")
        module_url = BUILDER.as_uri()
        code = (
            f"const m=await import({json.dumps(module_url)});"
            "const presentation={slides:{items:[{toProto:()=>({elements:["
            "{name:'Equation 1',paragraphs:[{inlineNodes:["
            "{math:{displayMode:2}}]}]}]})}]}};"
            "const result=m.verifyReimportedMath(presentation,[{id:'eq-1',"
            "fragmentSlide:1,objectName:'Equation 1',displayMode:'inline'}]);"
            "console.log(JSON.stringify(result));"
        )
        result = subprocess.run(
            [node, "--input-type=module", "-e", code],
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["equationCount"], 1)

    def test_package_resolves_from_content_model_workspace(self) -> None:
        """Use the Presentations TMP_DIR node_modules link, not repository lookup."""

        node = shutil.which("node")
        if node is None:
            self.skipTest("node is unavailable")
        with tempfile.TemporaryDirectory() as temporary:
            workspace = Path(temporary)
            package = workspace / "package"
            package.mkdir()
            (package / "package.json").write_text(
                json.dumps(
                    {
                        "name": "@oai/artifact-tool",
                        "type": "module",
                        "exports": "./index.mjs",
                    }
                ),
                encoding="utf-8",
            )
            (package / "index.mjs").write_text(
                "export const FileBlob={load:async()=>{"
                "throw new Error('stub import reached')}};"
                "export const PresentationFile={};"
                "export const mathFromLatex=()=>({});"
                "export const mathToMathMl=()=>'<math display=\"inline\"/>';",
                encoding="utf-8",
            )
            module_link = (
                workspace / "node_modules" / "@oai" / "artifact-tool"
            )
            module_link.parent.mkdir(parents=True)
            module_link.symlink_to(package, target_is_directory=True)
            model = workspace / "content-model.json"
            model.write_text(
                json.dumps(
                    {
                        "schema": "edit-research-ppt/fragment-content",
                        "schemaVersion": 1,
                        "starterPptx": str(workspace / "starter.pptx"),
                        "expectedSlideCount": 1,
                        "slides": [
                            {
                                "fragmentSlide": 1,
                                "edits": [
                                    {
                                        "action": "set_shape_text",
                                        "targetId": "sh/test",
                                        "value": "text",
                                    }
                                ],
                            }
                        ],
                    }
                ),
                encoding="utf-8",
            )
            result = subprocess.run(
                [
                    node,
                    str(BUILDER),
                    "--content-model",
                    str(model),
                    "--output",
                    str(workspace / "out.pptx"),
                    "--math-ledger",
                    str(workspace / "math.json"),
                ],
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertIn("stub import reached", result.stdout)
            self.assertNotIn("cannot resolve @oai/artifact-tool", result.stdout)

    def test_runtime_exposes_silent_degradation(self) -> None:
        """Document the exact artifact-tool behavior behind the fail-closed gate."""

        if not WINDOWS_NODE.is_file() or not ARTIFACT_TOOL.is_file():
            self.skipTest("Windows artifact-tool runtime is unavailable")
        module_url = f"file:///C:{str(ARTIFACT_TOOL).split('/mnt/c', 1)[1]}"
        code = (
            f'const m=await import({json.dumps(module_url)});'
            "const parse=(latex)=>m.mathToMathMl("
            'm.mathFromLatex({latex,displayMode:"inline"}));'
            "console.log(JSON.stringify({"
            'fraction:parse(String.raw`\\frac{a}{b}`),'
            'greek:parse(String.raw`\\alpha`),'
            'normalized:parse("Δ+ϵ+ρ+∂+∇"),'
            'unknown:parse(String.raw`\\unknown{x}`)'
            "}));"
        )
        result = subprocess.run(
            [str(WINDOWS_NODE), "--input-type=module", "-e", code],
            text=True,
            capture_output=True,
            check=False,
        )
        if "UtilBindVsockAnyPort" in result.stderr:
            self.skipTest("WSL interop is blocked by the current sandbox")
        self.assertEqual(result.returncode, 0, result.stderr)
        payload = json.loads(result.stdout)
        self.assertIn("<mfrac", payload["fraction"])
        self.assertIn("α", payload["greek"])
        for symbol in "Δϵρ∂∇":
            self.assertIn(symbol, payload["normalized"])
        self.assertIn(">unknown<", payload["unknown"])

    def test_assembler_contract_and_bullet_gates_are_explicit(self) -> None:
        """Keep native extraction and Wingdings restoration fail closed."""

        source = ASSEMBLER.read_text(encoding="utf-8")
        self.assertIn('[ValidateSet("ExtractFragment", "Assemble")]', source)
        self.assertIn("contract fragmentSlide values must be unique and contiguous", source)
        self.assertIn("referenceSlide", source)
        self.assertIn("Slides.InsertFromFile", source)
        self.assertIn("Get-BulletSnapshot", source)
        self.assertIn("Restore-BulletSnapshot", source)
        self.assertIn("$shape.TextFrame.TextRange", source)
        self.assertIn("$legacyParagraph.ParagraphFormat.Bullet", source)
        self.assertIn("$bullet.UseTextFont = $entry.UseTextFont", source)
        self.assertIn("$format.LeftIndent", source)
        self.assertIn('$entry.Character -eq 216', source)
        self.assertIn('$entry.FontName -eq "Wingdings"', source)
        self.assertIn("Assert-SourceHash $sourcePath $expectedHash", source)
        self.assertIn("fragment SHA-256 mismatch", source)
        self.assertIn("fragment slide count must equal the operation count", source)
        self.assertIn("Remove-Item -LiteralPath $outputPath", source)


if __name__ == "__main__":
    unittest.main()
