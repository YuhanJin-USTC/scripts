#!/usr/bin/env python3
"""Inventory a PPTX before a bounded slide edit."""

from __future__ import annotations

import argparse
import hashlib
import json
import posixpath
import sys
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any
from xml.etree import ElementTree as ET


NS = {
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "m": "http://schemas.openxmlformats.org/officeDocument/2006/math",
    "p": "http://schemas.openxmlformats.org/presentationml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "pr": "http://schemas.openxmlformats.org/package/2006/relationships",
}
RELATIONSHIP_ID = f"{{{NS['r']}}}id"
SHAPE_TAGS = {"sp", "pic", "graphicFrame", "grpSp", "cxnSp"}
DEPENDENCY_RELATIONS = {"slideLayout", "slideMaster", "theme"}
MEDIA_RELATIONS = {"audio", "image", "media", "video"}


class PptxInputError(ValueError):
    """Reject an invalid or unsupported PPTX input."""


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def local_name(name: str) -> str:
    return name.rsplit("}", 1)[-1]


def canonical_node(
    element: ET.Element, *, inside_field: bool = False
) -> list[Any]:
    """Return a prefix-independent XML value."""

    attributes = sorted(
        (local_name(key), value) for key, value in element.attrib.items()
    )
    if len(element):
        text = element.text if element.text and element.text.strip() else ""
    else:
        text = element.text or ""
    if inside_field and local_name(element.tag) == "t":
        text = ""
    child_inside_field = inside_field or local_name(element.tag) == "fld"
    return [
        local_name(element.tag),
        attributes,
        text,
        [
            canonical_node(child, inside_field=child_inside_field)
            for child in element
        ],
    ]


def stable_hash(value: Any) -> str:
    encoded = json.dumps(
        value, ensure_ascii=False, separators=(",", ":"), sort_keys=True
    ).encode("utf-8")
    return sha256_bytes(encoded)


def parse_slide_ranges(value: str, slide_count: int) -> list[int]:
    slides: set[int] = set()
    if not value.strip():
        return []
    try:
        for item in value.split(","):
            token = item.strip()
            if not token:
                raise ValueError
            if "-" in token:
                start_text, end_text = token.split("-", 1)
                start = int(start_text)
                end = int(end_text)
                if end < start:
                    raise ValueError
                slides.update(range(start, end + 1))
            else:
                slides.add(int(token))
    except ValueError as exc:
        raise PptxInputError(
            "authorized slides must use comma-separated 1-based values or ranges"
        ) from exc
    if any(index < 1 or index > slide_count for index in slides):
        raise PptxInputError(
            f"authorized slides must be between 1 and {slide_count}"
        )
    return sorted(slides)


def _absolute_file(value: str, label: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        raise PptxInputError(f"{label} must be an absolute path")
    path = path.resolve(strict=False)
    if not path.is_file():
        raise PptxInputError(f"{label} does not exist: {path}")
    return path


def _rels_name(part_name: str) -> str:
    part = PurePosixPath(part_name)
    return str(part.parent / "_rels" / f"{part.name}.rels")


def _resolve_target(part_name: str, target: str) -> str:
    if target.startswith("/"):
        return target.lstrip("/")
    return posixpath.normpath(posixpath.join(posixpath.dirname(part_name), target))


def _relationship_kind(value: str) -> str:
    return value.rstrip("/").rsplit("/", 1)[-1]


class PptxPackage:
    """Read the small OOXML surface needed by the edit contract."""

    def __init__(self, path: Path):
        self.path = path
        try:
            self.archive = zipfile.ZipFile(path)
            self.names = set(self.archive.namelist())
        except (OSError, zipfile.BadZipFile) as exc:
            raise PptxInputError(f"invalid PPTX package: {path}") from exc
        required = {
            "[Content_Types].xml",
            "ppt/presentation.xml",
            "ppt/_rels/presentation.xml.rels",
        }
        missing = sorted(required - self.names)
        if missing:
            self.archive.close()
            raise PptxInputError(
                "PPTX package is missing required parts: " + ", ".join(missing)
            )
        self._xml_cache: dict[str, ET.Element] = {}
        self._dependency_cache: dict[str, str] = {}

    def __enter__(self) -> "PptxPackage":
        return self

    def __exit__(self, *_: object) -> None:
        self.archive.close()

    def read(self, name: str) -> bytes:
        try:
            return self.archive.read(name)
        except KeyError as exc:
            raise PptxInputError(f"PPTX part is missing: {name}") from exc

    def xml(self, name: str) -> ET.Element:
        if name not in self._xml_cache:
            try:
                self._xml_cache[name] = ET.fromstring(self.read(name))
            except ET.ParseError as exc:
                raise PptxInputError(f"invalid XML part: {name}") from exc
        return self._xml_cache[name]

    def relationships(self, part_name: str) -> list[dict[str, str]]:
        rels_name = _rels_name(part_name)
        if rels_name not in self.names:
            return []
        records: list[dict[str, str]] = []
        for relation in self.xml(rels_name):
            target = relation.attrib.get("Target", "")
            mode = relation.attrib.get("TargetMode", "Internal")
            resolved = (
                target
                if mode == "External"
                else _resolve_target(part_name, target)
            )
            records.append(
                {
                    "id": relation.attrib.get("Id", ""),
                    "type": relation.attrib.get("Type", ""),
                    "kind": _relationship_kind(relation.attrib.get("Type", "")),
                    "target": target,
                    "resolvedTarget": resolved,
                    "targetMode": mode,
                }
            )
        return records

    def part_semantic_hash(self, part_name: str) -> str:
        if part_name not in self.names:
            return stable_hash(["missing"])
        if part_name.endswith((".xml", ".rels")):
            return stable_hash(canonical_node(self.xml(part_name)))
        return sha256_bytes(self.read(part_name))

    def dependency_hash(
        self, part_name: str, trail: frozenset[str] = frozenset()
    ) -> str:
        if part_name in self._dependency_cache:
            return self._dependency_cache[part_name]
        if part_name in trail:
            return stable_hash(["cycle"])
        if part_name not in self.names:
            return stable_hash(["missing"])
        payload: list[Any] = [self.part_semantic_hash(part_name)]
        next_trail = trail | {part_name}
        if part_name.startswith("ppt/slideLayouts/"):
            allowed_kinds = {"slideMaster"}
        elif part_name.startswith("ppt/slideMasters/"):
            allowed_kinds = {"theme"}
        else:
            allowed_kinds = set()
        for relation in self.relationships(part_name):
            if (
                relation["targetMode"] == "Internal"
                and relation["kind"] in allowed_kinds
            ):
                payload.append(
                    [
                        relation["kind"],
                        self.dependency_hash(
                            relation["resolvedTarget"], next_trail
                        ),
                    ]
                )
        result = stable_hash(payload)
        if not trail:
            self._dependency_cache[part_name] = result
        return result

    def slide_parts(self) -> list[dict[str, str]]:
        presentation = self.xml("ppt/presentation.xml")
        relations = {
            relation["id"]: relation
            for relation in self.relationships("ppt/presentation.xml")
        }
        parts: list[dict[str, str]] = []
        for slide_id in presentation.findall("./p:sldIdLst/p:sldId", NS):
            relation_id = slide_id.attrib.get(RELATIONSHIP_ID, "")
            relation = relations.get(relation_id)
            if not relation or relation["kind"] != "slide":
                raise PptxInputError(
                    f"presentation slide relationship is missing: {relation_id}"
                )
            part_name = relation["resolvedTarget"]
            if part_name not in self.names:
                raise PptxInputError(f"slide part is missing: {part_name}")
            parts.append(
                {
                    "id": slide_id.attrib.get("id", ""),
                    "relationshipId": relation_id,
                    "part": part_name,
                }
            )
        if not parts:
            raise PptxInputError("presentation contains no slides")
        return parts

    def slide_inventory(
        self, index: int, identity: dict[str, str]
    ) -> dict[str, Any]:
        part_name = identity["part"]
        root = self.xml(part_name)
        shapes = _shape_inventory(root)
        bullets = [
            bullet
            for shape in shapes
            for bullet in shape["bullets"]
        ]
        equations = [
            equation
            for shape in shapes
            for equation in shape["equations"]
        ]
        relationships = self.relationships(part_name)
        semantic_relationships: list[dict[str, Any]] = []
        media_relationships: list[dict[str, Any]] = []
        for relation in relationships:
            record: dict[str, Any] = {
                "id": relation["id"],
                "type": relation["type"],
                "kind": relation["kind"],
                "target": relation["target"],
                "targetMode": relation["targetMode"],
            }
            if relation["targetMode"] == "Internal":
                target = relation["resolvedTarget"]
                record["targetExists"] = target in self.names
                if target in self.names:
                    record["targetSha256"] = self.part_semantic_hash(target)
                if relation["kind"] in DEPENDENCY_RELATIONS:
                    record["dependencySha256"] = self.dependency_hash(target)
            semantic_relationships.append(record)
            if relation["kind"] in MEDIA_RELATIONS:
                media_relationships.append(record)
        relationship_values = sorted(
            (
                {
                    key: value
                    for key, value in record.items()
                    if key != "target" or record["targetMode"] == "External"
                }
                for record in semantic_relationships
            ),
            key=lambda item: json.dumps(
                item, ensure_ascii=False, separators=(",", ":"), sort_keys=True
            ),
        )
        media_values = sorted(
            (
                {
                    key: value
                    for key, value in record.items()
                    if key != "target" or record["targetMode"] == "External"
                }
                for record in media_relationships
            ),
            key=lambda item: json.dumps(
                item, ensure_ascii=False, separators=(",", ":"), sort_keys=True
            ),
        )
        text_value = [
            [shape["id"], shape["paragraphs"]]
            for shape in shapes
            if shape["paragraphs"]
        ]
        geometry_value = [
            [shape["kind"], shape["id"], shape["name"], shape["geometry"]]
            for shape in shapes
        ]
        run_value = [
            [shape["id"], shape["runProperties"]]
            for shape in shapes
            if shape["runProperties"]
        ]
        paragraph_value = [
            [shape["id"], shape["paragraphProperties"]]
            for shape in shapes
            if shape["paragraphProperties"]
        ]
        equation_value = [
            [
                shape["id"],
                [
                    [
                        equation["location"],
                        equation["paragraph"],
                        equation["equationOrdinal"],
                        equation["displayMode"],
                        equation["sha256"],
                        equation["tags"],
                    ]
                    for equation in shape["equations"]
                ],
            ]
            for shape in shapes
            if shape["equations"]
        ]
        return {
            "index": index,
            **identity,
            "slideXmlSha256": stable_hash(canonical_node(root)),
            "textSha256": stable_hash(text_value),
            "geometrySha256": stable_hash(geometry_value),
            "bulletSha256": stable_hash(bullets),
            "paragraphFormatSha256": stable_hash(paragraph_value),
            "runFontSha256": stable_hash(run_value),
            "equationSha256": stable_hash(equation_value),
            "relationshipSha256": stable_hash(relationship_values),
            "mediaRelationshipSha256": stable_hash(media_values),
            "semanticSha256": stable_hash(
                [
                    text_value,
                    geometry_value,
                    bullets,
                    paragraph_value,
                    run_value,
                    equation_value,
                    relationship_values,
                ]
            ),
            "text": text_value,
            "shapes": shapes,
            "bullets": bullets,
            "equations": equations,
            "relationships": semantic_relationships,
            "mediaRelationships": media_relationships,
        }

    def presentation_geometry_hash(self) -> str:
        presentation = self.xml("ppt/presentation.xml")
        nodes = [
            canonical_node(child)
            for child in presentation
            if local_name(child.tag) in {"sldSz", "notesSz"}
        ]
        return stable_hash(nodes)


def _first_descendant(element: ET.Element, name: str) -> ET.Element | None:
    return next(
        (candidate for candidate in element.iter() if local_name(candidate.tag) == name),
        None,
    )


def _paragraph_text(paragraph: ET.Element) -> list[str]:
    values: list[str] = []

    def visit(element: ET.Element) -> None:
        if local_name(element.tag) == "fld":
            values.append(f"{{field:{element.attrib.get('type', '')}}}")
            return
        if local_name(element.tag) == "t":
            values.append(element.text or "")
            return
        for child in element:
            visit(child)

    visit(paragraph)
    return values


def _shape_inventory(root: ET.Element) -> list[dict[str, Any]]:
    shapes: list[dict[str, Any]] = []
    for shape_number, shape in enumerate(
        (
            element
            for element in root.iter()
            if local_name(element.tag) in SHAPE_TAGS
        ),
        1,
    ):
        non_visual = _first_descendant(shape, "cNvPr")
        shape_id = non_visual.attrib.get("id", "") if non_visual is not None else ""
        shape_name = (
            non_visual.attrib.get("name", "") if non_visual is not None else ""
        )
        geometry = [
            canonical_node(element)
            for element in shape.iter()
            if local_name(element.tag) == "xfrm"
        ]
        paragraphs: list[list[str]] = []
        paragraph_properties_list: list[str | None] = []
        bullets: list[dict[str, Any]] = []
        run_properties: list[list[Any]] = []
        for paragraph_number, paragraph in enumerate(
            (
                element
                for element in shape.iter()
                if local_name(element.tag) == "p"
                and element.tag.startswith(f"{{{NS['a']}}}")
            ),
            1,
        ):
            paragraphs.append(_paragraph_text(paragraph))
            paragraph_properties = paragraph.find("./a:pPr", NS)
            paragraph_properties_value = (
                canonical_node(paragraph_properties)
                if paragraph_properties is not None
                else None
            )
            paragraph_properties_list.append(paragraph_properties_value)
            bullets.extend(
                _bullet_inventory(
                    paragraph_properties,
                    shape_number,
                    shape_id,
                    shape_name,
                    paragraph_number,
                )
            )
            run_properties.append(
                [
                    canonical_node(element)
                    for element in paragraph.iter()
                    if local_name(element.tag)
                    in {"defRPr", "endParaRPr", "rPr"}
                ]
            )
        equation_records = _equation_inventory(
            shape,
            shape_id=shape_id,
            shape_name=shape_name,
        )
        shapes.append(
            {
                "number": shape_number,
                "kind": local_name(shape.tag),
                "id": shape_id,
                "name": shape_name,
                "geometry": geometry,
                "paragraphs": paragraphs,
                "paragraphProperties": paragraph_properties_list,
                "bullets": bullets,
                "runProperties": run_properties,
                "equations": equation_records,
                "containsTable": any(
                    local_name(element.tag) == "tbl" for element in shape.iter()
                ),
                "textValue": "".join(
                    element.text or ""
                    for element in shape.iter()
                    if local_name(element.tag) == "t"
                    and not element.tag.startswith(f"{{{NS['m']}}}")
                ),
            }
        )
    return shapes


def _bullet_inventory(
    properties: ET.Element | None,
    shape_number: int,
    shape_id: str,
    shape_name: str,
    paragraph_number: int,
) -> list[dict[str, Any]]:
    if properties is None:
        return []
    font = next(
        (
            child
            for child in properties
            if local_name(child.tag) in {"buFont", "buFontTx"}
        ),
        None,
    )
    bullet_nodes = [
        child
        for child in properties
        if local_name(child.tag)
        in {"buAutoNum", "buBlip", "buChar", "buNone"}
    ]
    if not bullet_nodes:
        return []
    records: list[dict[str, Any]] = []
    for bullet in bullet_nodes:
        records.append(
            {
                "shapeNumber": shape_number,
                "shapeId": shape_id,
                "shapeName": shape_name,
                "paragraph": paragraph_number,
                "type": local_name(bullet.tag),
                "char": bullet.attrib.get("char"),
                "font": dict(sorted(font.attrib.items())) if font is not None else None,
                "properties": canonical_node(properties),
            }
        )
    return records


def _equation_inventory(
    shape: ET.Element,
    *,
    shape_id: str,
    shape_name: str,
) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []

    def collect(container: ET.Element, location: str) -> None:
        equation_ordinal = 0
        paragraphs = [
            element
            for element in container.iter()
            if element.tag == f"{{{NS['a']}}}p"
        ]
        for paragraph_number, paragraph in enumerate(paragraphs, 1):
            equations = [
                element
                for element in paragraph.iter()
                if element.tag == f"{{{NS['m']}}}oMath"
            ]
            math_descendants = {
                id(element)
                for equation in equations
                for element in equation.iter()
            }
            ordinary_text = "".join(
                element.text or ""
                for element in paragraph.iter()
                if element.tag == f"{{{NS['a']}}}t"
                and id(element) not in math_descendants
            )
            for equation in equations:
                equation_ordinal += 1
                block_container = next(
                    (
                        candidate
                        for candidate in paragraph.iter()
                        if candidate.tag == f"{{{NS['m']}}}oMathPara"
                        and any(
                            id(item) == id(equation)
                            for item in candidate.iter()
                        )
                    ),
                    None,
                )
                display_mode = (
                    "block" if block_container is not None else "inline"
                )
                node = canonical_node(equation)
                records.append(
                    {
                        "shapeId": shape_id,
                        "shapeName": shape_name,
                        "location": location,
                        "paragraph": paragraph_number,
                        "equationOrdinal": equation_ordinal,
                        "displayMode": display_mode,
                        "sha256": stable_hash(node),
                        "containerSha256": stable_hash(
                            canonical_node(block_container)
                            if block_container is not None
                            else node
                        ),
                        "tags": sorted(
                            {
                                local_name(item.tag)
                                for item in equation.iter()
                            }
                        ),
                        "text": "".join(
                            item.text or ""
                            for item in equation.iter()
                            if local_name(item.tag) == "t"
                        ),
                        "mixedWithText": bool(ordinary_text.strip())
                        or (
                            display_mode == "block"
                            and len(equations) != 1
                        ),
                    }
                )

    table = next(
        (
            element
            for element in shape.iter()
            if element.tag == f"{{{NS['a']}}}tbl"
        ),
        None,
    )
    if table is None:
        collect(shape, "shape")
        return records
    rows = [
        child
        for child in table
        if child.tag == f"{{{NS['a']}}}tr"
    ]
    for row_number, row in enumerate(rows, 1):
        cells = [
            child
            for child in row
            if child.tag == f"{{{NS['a']}}}tc"
        ]
        for column_number, cell in enumerate(cells, 1):
            collect(cell, f"table:R{row_number}C{column_number}")
    return records


def inspect_pptx(path: Path) -> dict[str, Any]:
    with PptxPackage(path) as package:
        slides = [
            package.slide_inventory(index, identity)
            for index, identity in enumerate(package.slide_parts(), 1)
        ]
        presentation_geometry = package.presentation_geometry_hash()
    return {
        "path": str(path),
        "sha256": sha256_file(path),
        "slideCount": len(slides),
        "presentationGeometrySha256": presentation_geometry,
        "slides": slides,
    }


def build_preflight(
    source_value: str, authorized_value: str
) -> dict[str, Any]:
    source = _absolute_file(source_value, "source")
    inventory = inspect_pptx(source)
    authorized = parse_slide_ranges(
        authorized_value, int(inventory["slideCount"])
    )
    return {
        "ok": True,
        "sourcePptx": str(source),
        "sourceSha256": inventory["sha256"],
        "slideCount": inventory["slideCount"],
        "authorizedSlides": authorized,
        "preserveSlides": [
            index
            for index in range(1, int(inventory["slideCount"]) + 1)
            if index not in authorized
        ],
        "slides": inventory["slides"],
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True)
    parser.add_argument("--authorized-slides", default="")
    parser.add_argument("--json", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        result = build_preflight(args.source, args.authorized_slides)
    except PptxInputError as exc:
        result = {"ok": False, "error": str(exc)}
        if args.json:
            print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
        else:
            print(f"error: {exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
    else:
        print(
            f"{result['sourcePptx']}: {result['slideCount']} slides; "
            f"sha256={result['sourceSha256']}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
