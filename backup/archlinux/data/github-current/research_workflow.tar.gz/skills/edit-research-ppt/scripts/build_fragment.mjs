#!/usr/bin/env node

import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { randomUUID } from "node:crypto";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";

const CONTENT_SCHEMA = "edit-research-ppt/fragment-content";
const LEDGER_SCHEMA = "edit-research-ppt/math-ledger";
const RAW_LATEX = /\\[A-Za-z]+/u;
const UNICODE_SCRIPT = /[\u00b2\u00b3\u00b9\u2070-\u209f]/u;
const ASCII_SCRIPT = /\b[A-Za-z][A-Za-z0-9]*\s*[\^_]\s*(?:\{[^}]+\}|[A-Za-z0-9])/u;
const PLAIN_FRACTION = /\b[A-Za-z0-9]\s*\/\s*[A-Za-z0-9]\b/u;
const PLAIN_MATH_SYMBOL = /[α-ωΑ-Ω∂∇∑∫]\s*(?:[=+\-*/^_<>]|$)/u;
let artifactToolApi;

const COMMAND_RULES = new Map([
  ["frac", { structure: "fraction", token: "<mfrac" }],
  ["sqrt", { structure: "radical", token: "<msqrt" }],
  ["sum", { structure: "nary", token: "∑" }],
  ["int", { structure: "nary", token: "∫" }],
  ["left", { structure: "delimiter", token: "<mfenced" }],
  ["right", { structure: "delimiter", token: "<mfenced" }],
  ["mathrm", { structure: "text", token: "<mtext" }],
  ["text", { structure: "text", token: "<mtext" }],
  ["cdot", { structure: "operator", token: "·" }],
  ["times", { structure: "operator", token: "×" }],
  ["pm", { structure: "operator", token: "±" }],
  ["leq", { structure: "operator", token: "≤" }],
  ["geq", { structure: "operator", token: "≥" }],
  ["neq", { structure: "operator", token: "≠" }],
  ["infty", { structure: "operator", token: "∞" }],
]);

const UNICODE_NORMALIZATION = new Map([
  ["alpha", { structure: "greek", symbol: "α" }],
  ["beta", { structure: "greek", symbol: "β" }],
  ["gamma", { structure: "greek", symbol: "γ" }],
  ["delta", { structure: "greek", symbol: "δ" }],
  ["epsilon", { structure: "greek", symbol: "ϵ" }],
  ["varepsilon", { structure: "greek", symbol: "ε" }],
  ["zeta", { structure: "greek", symbol: "ζ" }],
  ["eta", { structure: "greek", symbol: "η" }],
  ["theta", { structure: "greek", symbol: "θ" }],
  ["vartheta", { structure: "greek", symbol: "ϑ" }],
  ["iota", { structure: "greek", symbol: "ι" }],
  ["kappa", { structure: "greek", symbol: "κ" }],
  ["varkappa", { structure: "greek", symbol: "ϰ" }],
  ["lambda", { structure: "greek", symbol: "λ" }],
  ["mu", { structure: "greek", symbol: "μ" }],
  ["nu", { structure: "greek", symbol: "ν" }],
  ["xi", { structure: "greek", symbol: "ξ" }],
  ["omicron", { structure: "greek", symbol: "ο" }],
  ["pi", { structure: "greek", symbol: "π" }],
  ["varpi", { structure: "greek", symbol: "ϖ" }],
  ["rho", { structure: "greek", symbol: "ρ" }],
  ["varrho", { structure: "greek", symbol: "ϱ" }],
  ["sigma", { structure: "greek", symbol: "σ" }],
  ["varsigma", { structure: "greek", symbol: "ς" }],
  ["tau", { structure: "greek", symbol: "τ" }],
  ["upsilon", { structure: "greek", symbol: "υ" }],
  ["phi", { structure: "greek", symbol: "ϕ" }],
  ["varphi", { structure: "greek", symbol: "φ" }],
  ["chi", { structure: "greek", symbol: "χ" }],
  ["psi", { structure: "greek", symbol: "ψ" }],
  ["omega", { structure: "greek", symbol: "ω" }],
  ["Alpha", { structure: "greek", symbol: "Α" }],
  ["Beta", { structure: "greek", symbol: "Β" }],
  ["Gamma", { structure: "greek", symbol: "Γ" }],
  ["Delta", { structure: "greek", symbol: "Δ" }],
  ["Epsilon", { structure: "greek", symbol: "Ε" }],
  ["Zeta", { structure: "greek", symbol: "Ζ" }],
  ["Eta", { structure: "greek", symbol: "Η" }],
  ["Theta", { structure: "greek", symbol: "Θ" }],
  ["Iota", { structure: "greek", symbol: "Ι" }],
  ["Kappa", { structure: "greek", symbol: "Κ" }],
  ["Lambda", { structure: "greek", symbol: "Λ" }],
  ["Mu", { structure: "greek", symbol: "Μ" }],
  ["Nu", { structure: "greek", symbol: "Ν" }],
  ["Xi", { structure: "greek", symbol: "Ξ" }],
  ["Omicron", { structure: "greek", symbol: "Ο" }],
  ["Pi", { structure: "greek", symbol: "Π" }],
  ["Rho", { structure: "greek", symbol: "Ρ" }],
  ["Sigma", { structure: "greek", symbol: "Σ" }],
  ["Tau", { structure: "greek", symbol: "Τ" }],
  ["Upsilon", { structure: "greek", symbol: "Υ" }],
  ["Phi", { structure: "greek", symbol: "Φ" }],
  ["Chi", { structure: "greek", symbol: "Χ" }],
  ["Psi", { structure: "greek", symbol: "Ψ" }],
  ["Omega", { structure: "greek", symbol: "Ω" }],
  ["partial", { structure: "operator", symbol: "∂" }],
  ["nabla", { structure: "operator", symbol: "∇" }],
]);

export class InputError extends Error {}

function fail(message) {
  throw new InputError(message);
}

function object(value, label) {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    fail(`${label} must be an object`);
  }
  return value;
}

function integer(value, label, minimum = 0) {
  if (!Number.isInteger(value) || value < minimum) {
    fail(`${label} must be an integer >= ${minimum}`);
  }
  return value;
}

function nonempty(value, label) {
  if (typeof value !== "string" || value.length === 0) {
    fail(`${label} must be a non-empty string`);
  }
  return value;
}

function assertAbsolute(value, label) {
  let input = nonempty(value, label);
  if (process.platform === "win32") {
    const mounted = input.match(/^\/mnt\/([A-Za-z])(?:\/(.*))?$/u);
    if (mounted) {
      const tail = (mounted[2] ?? "").replaceAll("/", "\\");
      input = `${mounted[1].toUpperCase()}:\\${tail}`;
    }
  }
  if (!path.isAbsolute(input)) {
    fail(`${label} must be an absolute local path`);
  }
  return path.resolve(input);
}

function balancedBraces(latex) {
  let depth = 0;
  for (let index = 0; index < latex.length; index += 1) {
    const character = latex[index];
    if (character === "\\" && latex[index + 1] === "{") {
      index += 1;
      continue;
    }
    if (character === "{") depth += 1;
    if (character === "}") depth -= 1;
    if (depth < 0) return false;
  }
  return depth === 0;
}

function latexCommands(latex) {
  return [...latex.matchAll(/\\([A-Za-z]+)/gu)].map((match) => match[1]);
}

function normalizeLatex(sourceLatex) {
  return sourceLatex.replace(/\\([A-Za-z]+)/gu, (match, command) => {
    const normalized = UNICODE_NORMALIZATION.get(command);
    return normalized === undefined ? match : normalized.symbol;
  });
}

function containsMathMl(mathMl, token) {
  return mathMl.includes(token);
}

export function validateLatex(latexValue, displayModeValue) {
  const sourceLatex = nonempty(latexValue, "latex");
  const displayMode = displayModeValue;
  if (displayMode !== "inline" && displayMode !== "block") {
    fail("displayMode must be inline or block");
  }
  if (!balancedBraces(sourceLatex)) {
    fail("latex has unbalanced braces");
  }

  const commands = latexCommands(sourceLatex);
  const unknown = [
    ...new Set(
      commands.filter(
        (name) =>
          !COMMAND_RULES.has(name) && !UNICODE_NORMALIZATION.has(name),
      ),
    ),
  ];
  if (unknown.length > 0) {
    fail(`unsupported LaTeX command(s): ${unknown.join(", ")}`);
  }
  const hasLeft = commands.includes("left");
  const hasRight = commands.includes("right");
  if (hasLeft !== hasRight) {
    fail("\\left and \\right must be paired");
  }
  const normalizedLatex = normalizeLatex(sourceLatex);
  if (artifactToolApi === undefined) {
    fail("artifact-tool math API is not loaded");
  }

  let math;
  let mathMl;
  try {
    math = artifactToolApi.mathFromLatex({
      latex: normalizedLatex,
      displayMode,
    });
    mathMl = artifactToolApi.mathToMathMl(math);
  } catch (error) {
    fail(`LaTeX parse failed: ${String(error)}`);
  }

  const expectedDisplay = `display="${displayMode}"`;
  if (
    typeof mathMl !== "string" ||
    !mathMl.startsWith("<math ") ||
    !containsMathMl(mathMl, expectedDisplay) ||
    mathMl.includes("\\")
  ) {
    fail("LaTeX did not produce the expected MathML root");
  }

  const structures = new Set();
  for (const name of commands) {
    const normalized = UNICODE_NORMALIZATION.get(name);
    if (normalized !== undefined) {
      if (!containsMathMl(mathMl, normalized.symbol)) {
        fail(`LaTeX command \\${name} degraded instead of producing native math`);
      }
      structures.add(normalized.structure);
      continue;
    }
    const rule = COMMAND_RULES.get(name);
    if (!containsMathMl(mathMl, rule.token)) {
      fail(`LaTeX command \\${name} degraded instead of producing native math`);
    }
    structures.add(rule.structure);
  }
  if (normalizedLatex.includes("_")) {
    if (!/<msub|<msubsup/u.test(mathMl)) {
      fail("subscript degraded instead of producing native math");
    }
    structures.add("scripts");
  }
  if (normalizedLatex.includes("^")) {
    if (!/<msup|<msubsup/u.test(mathMl)) {
      fail("superscript degraded instead of producing native math");
    }
    structures.add("scripts");
  }

  return {
    sourceLatex,
    normalizedLatex,
    displayMode,
    mathMl,
    structures: [...structures].sort(),
  };
}

function rejectPlainFormula(value, label) {
  if (
    RAW_LATEX.test(value) ||
    UNICODE_SCRIPT.test(value) ||
    ASCII_SCRIPT.test(value) ||
    PLAIN_FRACTION.test(value) ||
    PLAIN_MATH_SYMBOL.test(value)
  ) {
    fail(`${label} contains a plain-text formula fallback`);
  }
  return value;
}

function prepareMathRun(run, context, ledger, equationIds) {
  const equationId = nonempty(run.equationId, `${context}.equationId`);
  if (equationIds.has(equationId)) {
    fail(`duplicate equationId: ${equationId}`);
  }
  const validated = validateLatex(run.latex, run.displayMode);
  equationIds.add(equationId);
  ledger.push({
    id: equationId,
    fragmentSlide: context.fragmentSlide,
    targetId: context.editTargetId,
    objectName: context.targetName,
    location: context.location,
    latex: validated.sourceLatex,
    sourceLatex: validated.sourceLatex,
    normalizedLatex: validated.normalizedLatex,
    displayMode: validated.displayMode,
    mathMl: validated.mathMl,
    structures: validated.structures,
  });
  return {
    latex: validated.normalizedLatex,
    displayMode: validated.displayMode,
  };
}

function prepareRun(run, context, ledger, equationIds) {
  if (typeof run === "string") {
    return rejectPlainFormula(run, context.label);
  }
  if (typeof run === "number") return run;
  const item = object(run, context.label);
  if ("latex" in item || "equationId" in item || "displayMode" in item) {
    return prepareMathRun(item, context, ledger, equationIds);
  }
  if (typeof item.run === "string") {
    rejectPlainFormula(item.run, `${context.label}.run`);
    return item;
  }
  fail(`${context.label} is not a supported text or math run`);
}

function prepareParagraph(paragraph, context, ledger, equationIds) {
  const paragraphObject = Array.isArray(paragraph)
    ? { runs: paragraph, arrayForm: true }
    : { ...object(paragraph, context.label), arrayForm: false };
  if (!Array.isArray(paragraphObject.runs)) {
    fail(`${context.label}.runs must be an array`);
  }
  const mathRuns = paragraphObject.runs.filter(
    (run) =>
      run !== null &&
      typeof run === "object" &&
      !Array.isArray(run) &&
      ("latex" in run || "equationId" in run || "displayMode" in run),
  );
  if (
    mathRuns.some((run) => run.displayMode === "block") &&
    (paragraphObject.runs.length !== 1 || mathRuns.length !== 1)
  ) {
    fail(`${context.label} block math must be the paragraph's only run`);
  }
  const runs = paragraphObject.runs.map((run, index) =>
    prepareRun(
      run,
      { ...context, label: `${context.label}.runs[${index}]` },
      ledger,
      equationIds,
    ),
  );
  if (paragraphObject.arrayForm) return runs;
  const { arrayForm: _arrayForm, ...result } = paragraphObject;
  result.runs = runs;
  return result;
}

function prepareTextValue(value, context, ledger, equationIds) {
  if (typeof value === "string") {
    return rejectPlainFormula(value, context.label);
  }
  if (!Array.isArray(value) || value.length === 0) {
    fail(`${context.label} must be a string or a non-empty paragraph array`);
  }
  return value.map((paragraph, index) =>
    prepareParagraph(
      paragraph,
      { ...context, label: `${context.label}[${index}]` },
      ledger,
      equationIds,
    ),
  );
}

function parseArguments(argv) {
  const result = {};
  for (let index = 0; index < argv.length; index += 1) {
    const key = argv[index];
    if (!["--content-model", "--output", "--math-ledger"].includes(key)) {
      fail(`unknown argument: ${key}`);
    }
    const value = argv[index + 1];
    if (value === undefined || value.startsWith("--")) {
      fail(`missing value for ${key}`);
    }
    if (result[key] !== undefined) fail(`duplicate argument: ${key}`);
    result[key] = value;
    index += 1;
  }
  for (const key of ["--content-model", "--output", "--math-ledger"]) {
    if (result[key] === undefined) fail(`missing required argument: ${key}`);
  }
  return {
    contentModel: assertAbsolute(result["--content-model"], "--content-model"),
    output: assertAbsolute(result["--output"], "--output"),
    mathLedger: assertAbsolute(result["--math-ledger"], "--math-ledger"),
  };
}

async function readContentModel(filePath) {
  let model;
  try {
    model = JSON.parse(await fs.readFile(filePath, "utf8"));
  } catch (error) {
    fail(`cannot read content model: ${String(error)}`);
  }
  object(model, "content model");
  if (model.schema !== CONTENT_SCHEMA || model.schemaVersion !== 1) {
    fail(`content model must use ${CONTENT_SCHEMA} version 1`);
  }
  model.starterPptx = assertAbsolute(model.starterPptx, "starterPptx");
  model.expectedSlideCount = integer(
    model.expectedSlideCount,
    "expectedSlideCount",
    1,
  );
  if (!Array.isArray(model.slides) || model.slides.length === 0) {
    fail("slides must be a non-empty array");
  }
  return model;
}

async function loadArtifactTool(contentModelPath) {
  const resolver = createRequire(
    pathToFileURL(
      path.join(path.dirname(contentModelPath), "__artifact_tool_resolver__.cjs"),
    ),
  );
  let entryPoint;
  try {
    entryPoint = resolver.resolve("@oai/artifact-tool");
  } catch (error) {
    fail(
      "cannot resolve @oai/artifact-tool from the content-model workspace; " +
        "run setup_artifact_tool_workspace.mjs first",
    );
  }
  try {
    artifactToolApi = await import(pathToFileURL(entryPoint).href);
  } catch (error) {
    fail(`cannot load @oai/artifact-tool: ${String(error)}`);
  }
  for (const name of [
    "FileBlob",
    "PresentationFile",
    "mathFromLatex",
    "mathToMathMl",
  ]) {
    if (artifactToolApi[name] === undefined) {
      fail(`@oai/artifact-tool is missing ${name}`);
    }
  }
  return artifactToolApi;
}

async function ensureNewOutput(filePath, label) {
  try {
    await fs.lstat(filePath);
    fail(`${label} already exists`);
  } catch (error) {
    if (error instanceof InputError) throw error;
    if (error.code !== "ENOENT") throw error;
  }
  await fs.mkdir(path.dirname(filePath), { recursive: true });
}

async function writeJson(filePath, value) {
  await fs.writeFile(filePath, `${JSON.stringify(value)}\n`, "utf8");
}

function targetName(target, label) {
  if (typeof target?.name !== "string" || target.name.length === 0) {
    fail(`${label} has no stable PowerPoint object name`);
  }
  return target.name;
}

function finalizeEquationLedger(equations) {
  const totals = new Map();
  for (const equation of equations) {
    const key = [
      equation.fragmentSlide,
      equation.targetId,
      equation.location,
    ].join("\u0000");
    totals.set(key, (totals.get(key) ?? 0) + 1);
  }
  const ordinals = new Map();
  for (const equation of equations) {
    const key = [
      equation.fragmentSlide,
      equation.targetId,
      equation.location,
    ].join("\u0000");
    const ordinal = (ordinals.get(key) ?? 0) + 1;
    ordinals.set(key, ordinal);
    equation.equationOrdinal = ordinal;
    equation.expectedOmmlCount = totals.get(key);
  }
}

function collectNamedObjects(value, name, matches, seen) {
  if (value === null || typeof value !== "object" || seen.has(value)) return;
  seen.add(value);
  if (!Array.isArray(value) && value.name === name) matches.push(value);
  for (const child of Object.values(value)) {
    collectNamedObjects(child, name, matches, seen);
  }
}

function collectMathNodes(value, nodes, seen) {
  if (value === null || typeof value !== "object" || seen.has(value)) return;
  seen.add(value);
  if (
    !Array.isArray(value) &&
    Object.prototype.hasOwnProperty.call(value, "math") &&
    value.math !== null &&
    typeof value.math === "object"
  ) {
    nodes.push(value.math);
  }
  for (const child of Object.values(value)) {
    collectMathNodes(child, nodes, seen);
  }
}

export function verifyReimportedMath(
  presentation,
  equations,
  slideField = "fragmentSlide",
) {
  const groups = new Map();
  for (const equation of equations) {
    const slideNumber = integer(
      equation[slideField],
      `equation ${equation.id} ${slideField}`,
      1,
    );
    const key = `${slideNumber}\u0000${equation.objectName}`;
    const group = groups.get(key) ?? {
      slideNumber,
      objectName: equation.objectName,
      equations: [],
    };
    group.equations.push(equation);
    groups.set(key, group);
  }
  for (const group of groups.values()) {
    const slide = presentation.slides.items[group.slideNumber - 1];
    if (slide === undefined || typeof slide.toProto !== "function") {
      fail(`re-imported slide ${group.slideNumber} is unavailable`);
    }
    const matches = [];
    collectNamedObjects(slide.toProto(), group.objectName, matches, new Set());
    if (matches.length !== 1) {
      fail(
        `re-imported object name ${group.objectName} is not unique on ` +
          `slide ${group.slideNumber}`,
      );
    }
    const mathNodes = [];
    collectMathNodes(matches[0], mathNodes, new Set());
    if (mathNodes.length !== group.equations.length) {
      fail(
        `re-imported object ${group.objectName} has ${mathNodes.length} ` +
          `inlineNodes.math nodes; expected ${group.equations.length}`,
      );
    }
    const expectedModes = group.equations
      .map((equation) => (equation.displayMode === "block" ? 1 : 2))
      .sort();
    const actualModes = mathNodes.map((math) => math.displayMode).sort();
    if (JSON.stringify(actualModes) !== JSON.stringify(expectedModes)) {
      fail(`re-imported object ${group.objectName} has wrong math display modes`);
    }
  }
  return { equationCount: equations.length, objectCount: groups.size };
}

export async function buildFragment({ contentModel, output, mathLedger }) {
  const model = await readContentModel(contentModel);
  const artifactTool = await loadArtifactTool(contentModel);
  if (new Set([model.starterPptx, output, mathLedger]).size !== 3) {
    fail("starterPptx, output, and math ledger must be distinct paths");
  }
  await ensureNewOutput(output, "output");
  await ensureNewOutput(mathLedger, "math ledger");

  let presentation;
  try {
    presentation = await artifactTool.PresentationFile.importPptx(
      await artifactTool.FileBlob.load(model.starterPptx),
    );
  } catch (error) {
    throw new Error(`cannot import starter fragment: ${String(error)}`);
  }
  if (presentation.slides.items.length !== model.expectedSlideCount) {
    fail(
      `starter fragment has ${presentation.slides.items.length} slides; ` +
        `expected ${model.expectedSlideCount}`,
    );
  }

  const seenSlides = new Set();
  const seenTargetNames = new Map();
  const equationIds = new Set();
  const equations = [];
  for (let slideIndex = 0; slideIndex < model.slides.length; slideIndex += 1) {
    const slideModel = object(model.slides[slideIndex], `slides[${slideIndex}]`);
    const fragmentSlide = integer(
      slideModel.fragmentSlide,
      `slides[${slideIndex}].fragmentSlide`,
      1,
    );
    if (fragmentSlide > model.expectedSlideCount) {
      fail(`fragmentSlide ${fragmentSlide} is outside the starter fragment`);
    }
    if (seenSlides.has(fragmentSlide)) {
      fail(`duplicate fragmentSlide entry: ${fragmentSlide}`);
    }
    seenSlides.add(fragmentSlide);
    if (!Array.isArray(slideModel.edits) || slideModel.edits.length === 0) {
      fail(`slides[${slideIndex}].edits must be a non-empty array`);
    }

    for (let editIndex = 0; editIndex < slideModel.edits.length; editIndex += 1) {
      const label = `slides[${slideIndex}].edits[${editIndex}]`;
      const edit = object(slideModel.edits[editIndex], label);
      const editTargetId = nonempty(edit.targetId, `${label}.targetId`);
      let target;
      try {
        target = presentation.resolve(editTargetId);
      } catch (error) {
        fail(`${label}.targetId cannot be resolved: ${String(error)}`);
      }
      const name = targetName(target, label);
      const nameKey = `${fragmentSlide}\u0000${name}`;
      if (
        seenTargetNames.has(nameKey) &&
        seenTargetNames.get(nameKey) !== editTargetId
      ) {
        fail(`${label} maps duplicate object name ${name} to different targets`);
      }
      seenTargetNames.set(nameKey, editTargetId);

      if (edit.action === "set_shape_text") {
        if (typeof target.text?.set !== "function") {
          fail(`${label}.targetId is not a text shape`);
        }
        const value = prepareTextValue(
          edit.value,
          {
            fragmentSlide,
            editTargetId,
            targetName: name,
            location: "shape",
            label: `${label}.value`,
          },
          equations,
          equationIds,
        );
        target.text.set(value);
        continue;
      }

      if (edit.action === "set_table_cell") {
        const row = integer(edit.row, `${label}.row`, 0);
        const column = integer(edit.column, `${label}.column`, 0);
        if (typeof target.cells?.set !== "function") {
          fail(`${label}.targetId is not a table`);
        }
        const value = prepareTextValue(
          edit.value,
          {
            fragmentSlide,
            editTargetId,
            targetName: name,
            location: `table:R${row + 1}C${column + 1}`,
            label: `${label}.value`,
          },
          equations,
          equationIds,
        );
        target.cells.set(row, column, value);
        continue;
      }

      fail(`${label}.action must be set_shape_text or set_table_cell`);
    }
  }

  finalizeEquationLedger(equations);
  const suffix = `.partial-${randomUUID()}`;
  const outputPartial = `${output}${suffix}`;
  const ledgerPartial = `${mathLedger}${suffix}`;
  try {
    const pptx = await artifactTool.PresentationFile.exportPptx(presentation);
    await pptx.save(outputPartial);
    const reopened = await artifactTool.PresentationFile.importPptx(
      await artifactTool.FileBlob.load(outputPartial),
    );
    verifyReimportedMath(reopened, equations);
    const ledger = {
      schema: LEDGER_SCHEMA,
      schemaVersion: 1,
      sourceFragmentPptx: model.starterPptx,
      outputFragmentPptx: output,
      equations,
    };
    await writeJson(ledgerPartial, ledger);
    await fs.rename(outputPartial, output);
    try {
      await fs.rename(ledgerPartial, mathLedger);
    } catch (error) {
      await fs.unlink(output);
      throw error;
    }
  } finally {
    await fs.rm(outputPartial, { force: true });
    await fs.rm(ledgerPartial, { force: true });
  }

  return {
    action: "build-fragment",
    output,
    mathLedger,
    slideCount: model.expectedSlideCount,
    equationCount: equations.length,
    written: true,
  };
}

async function main() {
  const options = parseArguments(process.argv.slice(2));
  return buildFragment(options);
}

const isMain =
  process.argv[1] !== undefined &&
  import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href;
if (isMain) {
  main()
    .then((result) => {
      process.stdout.write(`${JSON.stringify(result)}\n`);
    })
    .catch((error) => {
      const code = error instanceof InputError ? 2 : 1;
      process.stdout.write(
        `${JSON.stringify({ error: String(error.message ?? error), written: false })}\n`,
      );
      process.exitCode = code;
    });
}
