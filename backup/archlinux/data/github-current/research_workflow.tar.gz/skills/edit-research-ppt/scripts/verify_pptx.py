#!/usr/bin/env python3
"""Verify a bounded PPTX edit against its edit contract."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from pptx_preflight import PptxInputError, inspect_pptx, sha256_file


class ContractInputError(ValueError):
    """Reject an invalid edit contract."""


TOP_LEVEL_KEYS = {
    "schema",
    "schemaVersion",
    "sourcePptx",
    "fragmentPptx",
    "outputPptx",
    "expectedSourceSha256",
    "expectedFragmentSha256",
    "mathLedger",
    "expectedMathLedgerSha256",
    "expectedSlideCount",
    "operations",
    "equations",
}
EQUATION_KEYS = {
    "id",
    "fragmentSlide",
    "targetId",
    "objectName",
    "objectId",
    "location",
    "latex",
    "sourceLatex",
    "normalizedLatex",
    "displayMode",
    "mathMl",
    "structures",
    "equationOrdinal",
    "expectedOmmlCount",
    "expectedOmmlTags",
    "action",
    "sourceSlide",
    "sourceObjectName",
}
EQUATION_REQUIRED = {
    "id",
    "fragmentSlide",
    "targetId",
    "objectName",
    "location",
    "latex",
    "sourceLatex",
    "normalizedLatex",
    "displayMode",
    "mathMl",
    "structures",
    "equationOrdinal",
    "expectedOmmlCount",
}
HASH_PATTERN = re.compile(r"[0-9a-f]{64}")


def _keys(value: dict[str, Any], allowed: set[str], label: str) -> None:
    extra = sorted(set(value) - allowed)
    if extra:
        raise ContractInputError(
            f"{label} contains unsupported field(s): {', '.join(extra)}"
        )


def _nonempty(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise ContractInputError(f"{label} must be a non-empty string")
    return value


def _hash_value(value: Any, label: str) -> str:
    if not isinstance(value, str) or HASH_PATTERN.fullmatch(value) is None:
        raise ContractInputError(f"{label} must be a lowercase SHA-256 value")
    return value


def _portable_path(value: str, label: str) -> Path:
    path = Path(value).expanduser()
    if path.is_absolute():
        return path.resolve(strict=False)
    drive = re.fullmatch(r"([A-Za-z]):[\\/](.*)", value)
    if drive:
        suffix = drive.group(2).replace("\\", "/")
        return (
            Path("/mnt") / drive.group(1).lower() / suffix
        ).resolve(strict=False)
    unc = value.replace("\\", "/")
    match = re.fullmatch(r"//(?:wsl\.localhost|wsl\$)/[^/]+(/.*)", unc, re.I)
    if match:
        return Path(match.group(1)).resolve(strict=False)
    raise ContractInputError(f"{label} must be an absolute path")


def _absolute_file(value: str, label: str) -> Path:
    path = _portable_path(value, label)
    if not path.is_file():
        raise ContractInputError(f"{label} does not exist: {path}")
    return path


def _contract_path(
    contract: dict[str, Any],
    field: str,
    actual: Path,
) -> None:
    value = contract.get(field)
    if value is None:
        raise ContractInputError(f"{field} is required")
    candidate = _portable_path(str(value), field)
    if candidate != actual:
        raise ContractInputError(f"{field} does not match the CLI path")


def _positive_int(value: Any, label: str, *, allow_zero: bool = False) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ContractInputError(f"{label} must be an integer")
    minimum = 0 if allow_zero else 1
    if value < minimum:
        raise ContractInputError(f"{label} must be at least {minimum}")
    return value


def _load_contract(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ContractInputError(f"invalid contract JSON: {path}") from exc
    if not isinstance(value, dict):
        raise ContractInputError("contract root must be an object")
    _keys(value, TOP_LEVEL_KEYS, "contract")
    missing = sorted(TOP_LEVEL_KEYS - set(value))
    if missing:
        raise ContractInputError(
            "contract is missing required field(s): " + ", ".join(missing)
        )
    if value.get("schema") != "edit-research-ppt/edit-contract":
        raise ContractInputError(
            "contract schema must be edit-research-ppt/edit-contract"
        )
    if value.get("schemaVersion") != 1:
        raise ContractInputError("contract schemaVersion must be 1")
    for field in (
        "expectedSourceSha256",
        "expectedFragmentSha256",
        "expectedMathLedgerSha256",
    ):
        _hash_value(value[field], field)
    for field in ("sourcePptx", "fragmentPptx", "outputPptx", "mathLedger"):
        _nonempty(value[field], field)
        _portable_path(value[field], field)
    _positive_int(value["expectedSlideCount"], "expectedSlideCount")
    operations = value["operations"]
    if not isinstance(operations, list) or not operations:
        raise ContractInputError("operations must contain at least one operation")
    fragment_slides: list[int] = []
    referenced_equations: set[str] = set()
    for position, operation in enumerate(operations, 1):
        if not isinstance(operation, dict):
            raise ContractInputError(f"operation {position} must be an object")
        action = operation.get("action")
        common = {
            "action",
            "fragmentSlide",
            "referenceSlide",
            "equations",
        }
        if action == "insert_slide":
            allowed = common | {"destinationAfter"}
            required = allowed
            _positive_int(
                operation.get("destinationAfter"),
                f"operation {position} destinationAfter",
                allow_zero=True,
            )
        elif action == "replace_slide":
            allowed = common | {"destinationSlide"}
            required = allowed
            _positive_int(
                operation.get("destinationSlide"),
                f"operation {position} destinationSlide",
            )
        else:
            raise ContractInputError(
                f"operation {position} action must be insert_slide or replace_slide"
            )
        _keys(operation, allowed, f"operation {position}")
        absent = sorted(required - set(operation))
        if absent:
            raise ContractInputError(
                f"operation {position} is missing: {', '.join(absent)}"
            )
        fragment_slides.append(
            _positive_int(
                operation["fragmentSlide"],
                f"operation {position} fragmentSlide",
            )
        )
        _positive_int(
            operation["referenceSlide"],
            f"operation {position} referenceSlide",
        )
        equation_ids = operation["equations"]
        if not isinstance(equation_ids, list) or any(
            not isinstance(item, str) or not item for item in equation_ids
        ):
            raise ContractInputError(
                f"operation {position} equations must be equation ids"
            )
        if len(equation_ids) != len(set(equation_ids)):
            raise ContractInputError(
                f"operation {position} equations must be unique"
            )
        overlap = referenced_equations & set(equation_ids)
        if overlap:
            raise ContractInputError(
                "equation id is referenced more than once: "
                + ", ".join(sorted(overlap))
            )
        referenced_equations.update(equation_ids)
    if sorted(fragment_slides) != list(range(1, len(operations) + 1)):
        raise ContractInputError(
            "fragmentSlide values must be unique and contiguous from 1"
        )
    equations = value["equations"]
    if not isinstance(equations, list):
        raise ContractInputError("equations must be an array")
    equation_ids: set[str] = set()
    equation_groups: dict[tuple[int, str, str], list[dict[str, Any]]] = {}
    for position, equation in enumerate(equations, 1):
        if not isinstance(equation, dict):
            raise ContractInputError(f"equation {position} must be an object")
        _keys(equation, EQUATION_KEYS, f"equation {position}")
        absent = sorted(EQUATION_REQUIRED - set(equation))
        if absent:
            raise ContractInputError(
                f"equation {position} is missing: {', '.join(absent)}"
            )
        identifier = _nonempty(equation["id"], f"equation {position} id")
        if identifier in equation_ids:
            raise ContractInputError(f"duplicate equation id: {identifier}")
        equation_ids.add(identifier)
        _positive_int(
            equation["fragmentSlide"],
            f"equation {identifier} fragmentSlide",
        )
        _positive_int(
            equation["equationOrdinal"],
            f"equation {identifier} equationOrdinal",
        )
        _positive_int(
            equation["expectedOmmlCount"],
            f"equation {identifier} expectedOmmlCount",
        )
        for field in (
            "targetId",
            "objectName",
            "latex",
            "sourceLatex",
            "normalizedLatex",
            "mathMl",
        ):
            _nonempty(equation[field], f"equation {identifier} {field}")
        if not re.fullmatch(
            r"(?:shape|table:R[1-9][0-9]*C[1-9][0-9]*)",
            str(equation["location"]),
        ):
            raise ContractInputError(
                f"equation {identifier} location is invalid"
            )
        if equation["displayMode"] not in {"inline", "block"}:
            raise ContractInputError(
                f"equation {identifier} displayMode must be inline or block"
            )
        _mathml_text(
            equation["mathMl"],
            f"equation {identifier} mathMl",
            equation["displayMode"],
        )
        for field in ("structures", "expectedOmmlTags"):
            if field in equation:
                items = equation[field]
                if (
                    not isinstance(items, list)
                    or any(not isinstance(item, str) for item in items)
                    or len(items) != len(set(items))
                ):
                    raise ContractInputError(
                        f"equation {identifier} {field} "
                        "must contain unique strings"
                    )
        allowed_structures = {
            "fraction",
            "radical",
            "nary",
            "scripts",
            "delimiter",
            "greek",
            "operator",
            "text",
        }
        if not set(equation["structures"]) <= allowed_structures:
            raise ContractInputError(
                f"equation {identifier} structures contains an unknown value"
            )
        if "objectId" in equation:
            _positive_int(equation["objectId"], f"equation {identifier} objectId")
        if "sourceSlide" in equation:
            _positive_int(
                equation["sourceSlide"],
                f"equation {identifier} sourceSlide",
            )
        if "sourceObjectName" in equation:
            _nonempty(
                equation["sourceObjectName"],
                f"equation {identifier} sourceObjectName",
            )
        if equation.get("action", "create") not in {
            "create",
            "rewrite",
            "preserve",
        }:
            raise ContractInputError(
                f"equation {identifier} action is invalid"
            )
        group_key = (
            equation["fragmentSlide"],
            equation["targetId"],
            equation["location"],
        )
        equation_groups.setdefault(group_key, []).append(equation)
    for group in equation_groups.values():
        count = len(group)
        if sorted(item["equationOrdinal"] for item in group) != list(
            range(1, count + 1)
        ):
            raise ContractInputError(
                "equationOrdinal values must be unique and contiguous "
                "within each target location"
            )
        if any(item["expectedOmmlCount"] != count for item in group):
            raise ContractInputError(
                "expectedOmmlCount must equal the equation count "
                "within each target location"
            )
    if referenced_equations != equation_ids:
        missing_refs = sorted(equation_ids - referenced_equations)
        unknown_refs = sorted(referenced_equations - equation_ids)
        detail = missing_refs or unknown_refs
        raise ContractInputError(
            "contract equation references do not match definitions: "
            + ", ".join(detail)
        )
    return value


def _simulate_operations(
    contract: dict[str, Any], source_count: int
) -> tuple[list[dict[str, Any]], set[int], list[dict[str, Any]]]:
    tokens: list[dict[str, Any]] = [
        {"kind": "source", "sourceSlide": index}
        for index in range(1, source_count + 1)
    ]
    authorized: set[int] = set()
    operation_records: list[dict[str, Any]] = []
    for position, raw_operation in enumerate(contract.get("operations", []), 1):
        if not isinstance(raw_operation, dict):
            raise ContractInputError(f"operation {position} must be an object")
        operation = dict(raw_operation)
        action = operation.get("action")
        token = {"kind": "operation", "operation": position}
        if action == "insert_slide":
            destination_after = _positive_int(
                operation.get("destinationAfter"),
                f"operation {position} destinationAfter",
                allow_zero=True,
            )
            if destination_after > len(tokens):
                raise ContractInputError(
                    f"operation {position} destinationAfter is outside the current deck"
                )
            _positive_int(
                operation.get("fragmentSlide"),
                f"operation {position} fragmentSlide",
            )
            tokens.insert(destination_after, token)
        elif action == "replace_slide":
            destination = _positive_int(
                operation.get("destinationSlide"),
                f"operation {position} destinationSlide",
            )
            if destination > len(tokens):
                raise ContractInputError(
                    f"operation {position} destinationSlide is outside the current deck"
                )
            _positive_int(
                operation.get("fragmentSlide"),
                f"operation {position} fragmentSlide",
            )
            replaced = tokens[destination - 1]
            if replaced["kind"] != "source":
                raise ContractInputError(
                    f"operation {position} may replace only an original source slide"
                )
            authorized.add(int(replaced["sourceSlide"]))
            operation["replacedSourceSlide"] = int(replaced["sourceSlide"])
            tokens[destination - 1] = token
        else:
            raise ContractInputError(
                f"operation {position} action must be insert_slide or replace_slide"
            )
        reference = operation.get("referenceSlide")
        if reference is None:
            raise ContractInputError(
                f"operation {position} referenceSlide is required"
            )
        reference_number = _positive_int(
            reference, f"operation {position} referenceSlide"
        )
        if reference_number > source_count:
            raise ContractInputError(
                f"operation {position} referenceSlide is outside the source deck"
            )
        operation["referenceSlide"] = reference_number
        operation_records.append(operation)
    for output_index, token in enumerate(tokens, 1):
        if token["kind"] == "operation":
            operation_records[int(token["operation"]) - 1][
                "outputSlide"
            ] = output_index
    return tokens, authorized, operation_records


def _add(
    errors: list[dict[str, Any]],
    code: str,
    message: str,
    **details: Any,
) -> None:
    errors.append({"code": code, "message": message, **details})


def _font_name(bullet: dict[str, Any]) -> str | None:
    font = bullet.get("font")
    if not isinstance(font, dict):
        return None
    value = font.get("typeface")
    return str(value) if value is not None else None


def _check_global_bullets(
    output: dict[str, Any], errors: list[dict[str, Any]]
) -> None:
    for slide in output["slides"]:
        for bullet in slide["bullets"]:
            if bullet.get("char") != "Ø":
                continue
            font = _font_name(bullet)
            if font is None or font.casefold() != "wingdings":
                _add(
                    errors,
                    "bullet-font-missing",
                    'buChar="Ø" requires an explicit Wingdings buFont',
                    slide=slide["index"],
                    shapeId=bullet.get("shapeId"),
                    paragraph=bullet.get("paragraph"),
                )


def _check_reference_bullets(
    source_slide: dict[str, Any],
    output_slide: dict[str, Any],
    errors: list[dict[str, Any]],
) -> None:
    output_by_location = {
        (str(item.get("shapeName")), int(item.get("paragraph", 0))): item
        for item in output_slide["bullets"]
    }
    for source_bullet in source_slide["bullets"]:
        if not source_bullet.get("char") or not _font_name(source_bullet):
            continue
        location = (
            str(source_bullet.get("shapeName")),
            int(source_bullet.get("paragraph", 0)),
        )
        actual = output_by_location.get(location)
        if actual is None:
            _add(
                errors,
                "bullet-mapping-missing",
                "a reference bullet paragraph is missing",
                slide=output_slide["index"],
                shapeName=location[0],
                paragraph=location[1],
            )
            continue
        expected_tuple = {
            key: source_bullet.get(key)
            for key in ("type", "char", "font", "properties")
        }
        actual_tuple = {
            key: actual.get(key)
            for key in ("type", "char", "font", "properties")
        }
        if expected_tuple != actual_tuple:
            _add(
                errors,
                "bullet-format-changed",
                "a reference bullet tuple changed",
                slide=output_slide["index"],
                shapeName=location[0],
                paragraph=location[1],
                expected=expected_tuple,
                actual=actual_tuple,
            )
        if _font_name(source_bullet) != _font_name(actual):
            _add(
                errors,
                "bullet-font-removed",
                "a reference bullet character lost its explicit font",
                slide=output_slide["index"],
                char=source_bullet.get("char"),
                expectedFont=_font_name(source_bullet),
                actualFont=_font_name(actual),
            )


def _compare_preserved_slide(
    source_slide: dict[str, Any],
    output_slide: dict[str, Any],
    source_slides: list[dict[str, Any]],
    errors: list[dict[str, Any]],
) -> None:
    source_index = int(source_slide["index"])
    output_index = int(output_slide["index"])
    if source_slide["id"] != output_slide["id"]:
        _add(
            errors,
            "slide-order-changed",
            "a preserved slide lost its source presentation identity",
            sourceSlide=source_index,
            outputSlide=output_index,
        )
    checks = [
        ("textSha256", "text-changed", "text"),
        ("geometrySha256", "geometry-changed", "geometry"),
        ("bulletSha256", "bullet-changed", "bullet formatting"),
        (
            "paragraphFormatSha256",
            "paragraph-format-changed",
            "paragraph formatting",
        ),
        ("runFontSha256", "run-font-changed", "run formatting"),
        ("equationSha256", "equations-changed", "native equations"),
        ("relationshipSha256", "relationships-changed", "relationships"),
        (
            "mediaRelationshipSha256",
            "media-relationships-changed",
            "media relationships",
        ),
    ]
    if source_slide["semanticSha256"] != output_slide["semanticSha256"]:
        other = next(
            (
                item
                for item in source_slides
                if item["index"] != source_index
                and item["semanticSha256"] == output_slide["semanticSha256"]
            ),
            None,
        )
        if other is not None:
            _add(
                errors,
                "slide-order-changed",
                "a different source slide occupies a preserved position",
                sourceSlide=source_index,
                foundSourceSlide=other["index"],
                outputSlide=output_index,
            )
    for field, code, label in checks:
        if source_slide[field] != output_slide[field]:
            _add(
                errors,
                code,
                f"preserved slide {label} changed",
                sourceSlide=source_index,
                outputSlide=output_index,
            )


def _shape(
    slide: dict[str, Any], target: Any, *, by_name: bool
) -> tuple[dict[str, Any] | None, bool]:
    key = "name" if by_name else "id"
    matches = [
        shape for shape in slide["shapes"] if str(shape[key]) == str(target)
    ]
    if not matches:
        return None, False
    if len(matches) == 1:
        return matches[0], False
    identities = {(str(shape["id"]), str(shape["name"])) for shape in matches}
    if len(identities) != 1:
        return None, True
    merged = dict(matches[0])
    equations: dict[tuple[str, int, str, str], dict[str, Any]] = {}
    for shape in matches:
        for equation in shape["equations"]:
            equations[
                (
                    equation["location"],
                    equation["equationOrdinal"],
                    equation["displayMode"],
                    equation["sha256"],
                )
            ] = equation
    merged["equations"] = list(equations.values())
    merged["containsTable"] = any(shape["containsTable"] for shape in matches)
    merged["textValue"] = "".join(
        dict.fromkeys(str(shape["textValue"]) for shape in matches)
    )
    return merged, False


def _equation_ledgers(
    contract: dict[str, Any], operations: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    definitions: dict[str, dict[str, Any]] = {
        value["id"]: value for value in contract["equations"]
    }
    ledgers: list[dict[str, Any]] = []
    for operation in operations:
        for identifier in operation["equations"]:
            record = dict(definitions[identifier])
            record.setdefault("outputSlide", operation["outputSlide"])
            record.setdefault(
                "sourceSlide",
                operation.get(
                    "referenceSlide", operation.get("replacedSourceSlide")
                ),
            )
            if record["fragmentSlide"] != operation["fragmentSlide"]:
                raise ContractInputError(
                    f"equation {record['id']} fragmentSlide "
                    "does not match its operation"
                )
            ledgers.append(record)
    return ledgers


def _check_math_ledger(
    contract: dict[str, Any], fragment_path: Path
) -> Path:
    ledger_path = _absolute_file(contract["mathLedger"], "mathLedger")
    if sha256_file(ledger_path) != contract["expectedMathLedgerSha256"]:
        raise ContractInputError("math ledger SHA-256 mismatch")
    try:
        ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ContractInputError("invalid math ledger JSON") from exc
    if not isinstance(ledger, dict):
        raise ContractInputError("math ledger root must be an object")
    _keys(
        ledger,
        {
            "schema",
            "schemaVersion",
            "sourceFragmentPptx",
            "outputFragmentPptx",
            "equations",
        },
        "math ledger",
    )
    if (
        ledger.get("schema") != "edit-research-ppt/math-ledger"
        or ledger.get("schemaVersion") != 1
    ):
        raise ContractInputError(
            "math ledger must use edit-research-ppt/math-ledger version 1"
        )
    ledger_fragment = _portable_path(
        _nonempty(
            ledger.get("outputFragmentPptx"),
            "math ledger outputFragmentPptx",
        ),
        "math ledger outputFragmentPptx",
    )
    if ledger_fragment != fragment_path:
        raise ContractInputError(
            "math ledger outputFragmentPptx does not match fragmentPptx"
        )
    generated_keys = {
        "id",
        "fragmentSlide",
        "targetId",
        "objectName",
        "location",
        "latex",
        "sourceLatex",
        "normalizedLatex",
        "displayMode",
        "mathMl",
        "structures",
        "equationOrdinal",
        "expectedOmmlCount",
    }
    equations = ledger.get("equations")
    if not isinstance(equations, list):
        raise ContractInputError("math ledger equations must be an array")
    ledger_by_id: dict[str, dict[str, Any]] = {}
    for position, equation in enumerate(equations, 1):
        if not isinstance(equation, dict):
            raise ContractInputError(
                f"math ledger equation {position} must be an object"
            )
        _keys(equation, generated_keys, f"math ledger equation {position}")
        missing = sorted(generated_keys - set(equation))
        if missing:
            raise ContractInputError(
                f"math ledger equation {position} is missing: "
                + ", ".join(missing)
            )
        identifier = _nonempty(
            equation["id"], f"math ledger equation {position} id"
        )
        if identifier in ledger_by_id:
            raise ContractInputError(
                f"duplicate math ledger equation id: {identifier}"
            )
        ledger_by_id[identifier] = equation
    contract_by_id = {item["id"]: item for item in contract["equations"]}
    if set(ledger_by_id) != set(contract_by_id):
        raise ContractInputError(
            "math ledger equation ids do not match the contract"
        )
    for identifier, generated in ledger_by_id.items():
        declared = contract_by_id[identifier]
        for field in generated_keys:
            if declared.get(field) != generated.get(field):
                raise ContractInputError(
                    f"equation {identifier} field {field} "
                    "does not match the math ledger"
                )
    return ledger_path


def _mathml_text(value: Any, label: str, expected_display: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ContractInputError(f"{label} must be non-empty MathML")
    try:
        root = ET.fromstring(value)
    except ET.ParseError as exc:
        raise ContractInputError(f"{label} is invalid MathML") from exc
    if root.tag.startswith("{"):
        namespace, _, local = root.tag[1:].partition("}")
    else:
        namespace, local = "", root.tag
    if local != "math" or namespace not in {
        "",
        "http://www.w3.org/1998/Math/MathML",
    }:
        raise ContractInputError(f"{label} root must be MathML math")
    if root.attrib.get("display") != expected_display:
        raise ContractInputError(
            f"{label} display must be {expected_display}"
        )
    return _normalize_math_text("".join(root.itertext()))


def _normalize_math_text(value: str) -> str:
    ignored = {"\u2061", "\u2062", "\u2063", "\u2064"}
    return "".join(
        character
        for character in value
        if not character.isspace() and character not in ignored
    )


def _plain_formula_reason(value: str) -> str | None:
    checks = (
        (r"\\[A-Za-z]+", "LaTeX command"),
        (r"[\u00b2\u00b3\u00b9\u2070-\u209f]", "Unicode script"),
        (r"\b[A-Za-z][A-Za-z0-9]*\s*[\^_]\s*(?:\{[^}]+\}|[A-Za-z0-9])", "ASCII script"),
        (r"\b[A-Za-z0-9]\s*/\s*[A-Za-z0-9]\b", "plain fraction"),
        (r"[α-ωΑ-Ω∂∇∑∫]\s*(?:[=+\-*/^_<>]|$)", "plain math symbol"),
    )
    return next(
        (label for pattern, label in checks if re.search(pattern, value)),
        None,
    )


def _check_equations(
    contract: dict[str, Any],
    operations: list[dict[str, Any]],
    source: dict[str, Any],
    output: dict[str, Any],
    errors: list[dict[str, Any]],
) -> None:
    ledgers = _equation_ledgers(contract, operations)
    for position, ledger in enumerate(ledgers, 1):
        output_index = _positive_int(
            ledger.get("outputSlide", ledger.get("slide")),
            f"equation {position} outputSlide",
        )
        if output_index > output["slideCount"]:
            raise ContractInputError(
                f"equation {position} outputSlide is outside the output deck"
            )
        by_name = "objectName" in ledger
        object_id = (
            ledger.get("objectName")
            if by_name
            else ledger.get("objectId", ledger.get("targetObjectId"))
        )
        if object_id is None:
            raise ContractInputError(
                f"equation {position} requires objectName or numeric objectId"
            )
        output_slide = output["slides"][output_index - 1]
        output_shape, ambiguous = _shape(
            output_slide, object_id, by_name=by_name
        )
        if ambiguous:
            _add(
                errors,
                "equation-object-ambiguous",
                "the equation target name is not unique",
                equation=position,
                slide=output_index,
                objectName=str(object_id),
            )
            continue
        if output_shape is None:
            _add(
                errors,
                "equation-object-missing",
                "the equation target object is missing",
                equation=position,
                slide=output_index,
                objectName=str(object_id) if by_name else None,
                objectId=None if by_name else str(object_id),
                targetId=ledger.get("targetId"),
            )
            continue
        all_equations = output_shape["equations"]
        if not all_equations:
            _add(
                errors,
                "equation-native-missing",
                "the target contains no editable Office Math object",
                equation=position,
                slide=output_index,
                objectId=str(object_id),
            )
            continue
        location = str(ledger["location"])
        if location.startswith("table:") and not output_shape["containsTable"]:
            _add(
                errors,
                "equation-location-mismatch",
                "a table-cell equation is not inside a table object",
                equation=position,
                slide=output_index,
            )
        if location == "shape" and output_shape["containsTable"]:
            _add(
                errors,
                "equation-location-mismatch",
                "a textbox equation is inside a table object",
                equation=position,
                slide=output_index,
            )
        equations = [
            equation
            for equation in all_equations
            if equation["location"] == location
        ]
        expected_count = ledger["expectedOmmlCount"]
        if len(equations) != expected_count:
            _add(
                errors,
                "equation-count-mismatch",
                "the native equation count at the target location "
                "does not match the ledger",
                equation=position,
                slide=output_index,
                location=location,
                expected=expected_count,
                actual=len(equations),
            )
        ordinal = ledger["equationOrdinal"]
        selected = next(
            (
                equation
                for equation in equations
                if equation["equationOrdinal"] == ordinal
            ),
            None,
        )
        if selected is None:
            _add(
                errors,
                "equation-ordinal-missing",
                "the declared native equation ordinal is missing",
                equation=position,
                slide=output_index,
                location=location,
                equationOrdinal=ordinal,
            )
            continue
        expected_object_id = ledger.get("objectId")
        if (
            expected_object_id is not None
            and str(output_shape["id"]) != str(expected_object_id)
        ):
            _add(
                errors,
                "equation-object-id-mismatch",
                "the equation target numeric object id does not match",
                equation=position,
                slide=output_index,
                expected=int(expected_object_id),
                actual=output_shape["id"],
            )
        display_mode = ledger["displayMode"]
        if selected["displayMode"] != display_mode:
            _add(
                errors,
                "equation-display-mode-mismatch",
                "the native equation display mode does not match the ledger",
                equation=position,
                slide=output_index,
                expected=display_mode,
                actual=selected["displayMode"],
            )
        if display_mode == "block" and selected["mixedWithText"]:
            _add(
                errors,
                "equation-block-mixed",
                "block math must be the paragraph's only content",
                equation=position,
                slide=output_index,
            )
        required_tags = ledger.get("expectedOmmlTags", [])
        actual_tags = set(selected["tags"])
        missing_tags = sorted(
            str(tag) for tag in required_tags if str(tag) not in actual_tags
        )
        if missing_tags:
            _add(
                errors,
                "equation-structure-mismatch",
                "the Office Math structure is missing required elements",
                equation=position,
                slide=output_index,
                missingTags=missing_tags,
            )
        structure_tags = {
            "fraction": {"f"},
            "radical": {"rad"},
            "nary": {"nary"},
            "scripts": {"sSub", "sSup", "sSubSup"},
            "delimiter": {"d"},
        }
        structures = ledger["structures"]
        for structure in structures:
            required = structure_tags.get(str(structure))
            if required and not (required & actual_tags):
                _add(
                    errors,
                    "equation-structure-mismatch",
                    "the Office Math structure does not match the ledger",
                    equation=position,
                    slide=output_index,
                    structure=str(structure),
                )
        expected_text = _mathml_text(
            ledger["mathMl"],
            f"equation {position} mathMl",
            ledger["displayMode"],
        )
        actual_text = _normalize_math_text(selected["text"])
        if expected_text != actual_text:
            _add(
                errors,
                "equation-semantic-text-mismatch",
                "Office Math text does not match the preflight MathML",
                equation=position,
                slide=output_index,
                expected=expected_text,
                actual=actual_text,
            )
        if ledger["latex"] in output_shape["textValue"]:
            _add(
                errors,
                "equation-raw-latex",
                "raw LaTeX remains as ordinary slide text",
                equation=position,
                slide=output_index,
            )
        action = ledger.get("action", "create")
        if action == "create":
            continue
        source_index_value = ledger.get("sourceSlide")
        if source_index_value is None:
            raise ContractInputError(
                f"equation {position} {action} requires sourceSlide"
            )
        source_index = _positive_int(
            source_index_value, f"equation {position} sourceSlide"
        )
        if source_index > source["slideCount"]:
            raise ContractInputError(
                f"equation {position} sourceSlide is outside the source deck"
            )
        source_object_id = (
            ledger.get("sourceObjectName", object_id)
            if by_name
            else ledger.get("sourceObjectId", object_id)
        )
        source_shape, source_ambiguous = _shape(
            source["slides"][source_index - 1],
            source_object_id,
            by_name=by_name,
        )
        if source_ambiguous:
            raise ContractInputError(
                f"equation {position} source target is not unique"
            )
        source_equations = (
            [
                item
                for item in source_shape["equations"]
                if item["location"] == location
                and item["equationOrdinal"] == ordinal
            ]
            if source_shape
            else []
        )
        source_hashes = [item["sha256"] for item in source_equations]
        output_hashes = [selected["sha256"]]
        if not source_equations:
            _add(
                errors,
                "equation-source-missing",
                "the ledger source contains no native equation",
                equation=position,
                sourceSlide=source_index,
            )
        elif action == "preserve" and source_hashes != output_hashes:
            _add(
                errors,
                "equation-preserve-failed",
                "the native equation changed despite a preserve action",
                equation=position,
                slide=output_index,
            )
        elif action == "rewrite" and source_hashes == output_hashes:
            _add(
                errors,
                "equation-rewrite-missing",
                "the native equation did not change for a rewrite action",
                equation=position,
                slide=output_index,
            )
    for operation in operations:
        output_index = int(operation["outputSlide"])
        if output_index > output["slideCount"]:
            continue
        output_slide = output["slides"][output_index - 1]
        expected_count = len(operation["equations"])
        actual_count = len(output_slide["equations"])
        if actual_count != expected_count:
            _add(
                errors,
                "equation-inventory-mismatch",
                "the changed slide native-equation inventory "
                "does not match its operation",
                slide=output_index,
                expected=expected_count,
                actual=actual_count,
            )
        for shape in output_slide["shapes"]:
            reason = _plain_formula_reason(str(shape["textValue"]))
            if reason is not None:
                _add(
                    errors,
                    "equation-plain-text-fallback",
                    "a changed slide contains a probable plain-text formula",
                    slide=output_index,
                    objectName=shape["name"],
                    reason=reason,
                )


def verify(
    source_path: Path, output_path: Path, contract: dict[str, Any]
) -> dict[str, Any]:
    if source_path == output_path:
        raise ContractInputError("output must be distinct from source")
    _contract_path(contract, "sourcePptx", source_path)
    _contract_path(contract, "outputPptx", output_path)
    fragment_path = _absolute_file(contract["fragmentPptx"], "fragmentPptx")
    if sha256_file(fragment_path) != contract["expectedFragmentSha256"]:
        raise ContractInputError("fragment SHA-256 mismatch")
    ledger_path = _check_math_ledger(contract, fragment_path)
    if len({source_path, output_path, fragment_path, ledger_path}) != 4:
        raise ContractInputError(
            "source, output, fragment, and math ledger paths must be distinct"
        )
    source_hash_before = sha256_file(source_path)
    errors: list[dict[str, Any]] = []
    expected_hash = contract.get("expectedSourceSha256")
    if expected_hash is not None and str(expected_hash) != source_hash_before:
        _add(
            errors,
            "source-hash-mismatch",
            "source SHA-256 does not match the edit contract",
            expected=str(expected_hash),
            actual=source_hash_before,
        )
    source = inspect_pptx(source_path)
    fragment = inspect_pptx(fragment_path)
    output = inspect_pptx(output_path)
    tokens, authorized, operations = _simulate_operations(
        contract, int(source["slideCount"])
    )
    expected_count = len(tokens)
    if fragment["slideCount"] != len(operations):
        raise ContractInputError(
            "fragment slide count must equal the operation count"
        )
    declared_count = contract.get("expectedSlideCount")
    if declared_count is not None:
        declared = _positive_int(declared_count, "expectedSlideCount")
        if declared != expected_count:
            raise ContractInputError(
                "expectedSlideCount disagrees with the operation sequence"
            )
    if output["slideCount"] != expected_count:
        _add(
            errors,
            "slide-count-mismatch",
            "output slide count does not match the operation sequence",
            expected=expected_count,
            actual=output["slideCount"],
        )
    if (
        source["presentationGeometrySha256"]
        != output["presentationGeometrySha256"]
    ):
        _add(
            errors,
            "presentation-geometry-changed",
            "presentation slide or notes dimensions changed",
        )
    for output_index, token in enumerate(tokens, 1):
        if output_index > output["slideCount"]:
            break
        if token["kind"] != "source":
            continue
        source_index = int(token["sourceSlide"])
        if source_index in authorized:
            continue
        _compare_preserved_slide(
            source["slides"][source_index - 1],
            output["slides"][output_index - 1],
            source["slides"],
            errors,
        )
    _check_global_bullets(output, errors)
    for operation in operations:
        output_index = operation.get("outputSlide")
        if output_index is None or int(output_index) > output["slideCount"]:
            continue
        reference_indices = {
            int(value)
            for value in (
                operation.get("referenceSlide"),
                operation.get("replacedSourceSlide"),
            )
            if value is not None
        }
        for reference_index in sorted(reference_indices):
            _check_reference_bullets(
                source["slides"][reference_index - 1],
                output["slides"][int(output_index) - 1],
                errors,
            )
    _check_equations(contract, operations, source, output, errors)
    source_hash_after = sha256_file(source_path)
    if source_hash_after != source_hash_before:
        _add(
            errors,
            "source-changed-during-verification",
            "source SHA-256 changed during verification",
            before=source_hash_before,
            after=source_hash_after,
        )
    return {
        "ok": not errors,
        "sourcePptx": str(source_path),
        "outputPptx": str(output_path),
        "sourceSha256": source_hash_after,
        "sourceSlideCount": source["slideCount"],
        "outputSlideCount": output["slideCount"],
        "preservedSourceSlides": [
            index
            for index in range(1, int(source["slideCount"]) + 1)
            if index not in authorized
        ],
        "authorizedSourceSlides": sorted(authorized),
        "errors": errors,
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--contract", required=True)
    parser.add_argument("--json", action="store_true")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        source = _absolute_file(args.source, "source")
        output = _absolute_file(args.output, "output")
        contract_path = _absolute_file(args.contract, "contract")
        contract = _load_contract(contract_path)
        result = verify(source, output, contract)
    except (ContractInputError, PptxInputError) as exc:
        result = {"ok": False, "error": str(exc)}
        if args.json:
            print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
        else:
            print(f"error: {exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
    elif result["ok"]:
        print(f"verified: {result['outputPptx']}")
    else:
        for error in result["errors"]:
            print(f"{error['code']}: {error['message']}", file=sys.stderr)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
