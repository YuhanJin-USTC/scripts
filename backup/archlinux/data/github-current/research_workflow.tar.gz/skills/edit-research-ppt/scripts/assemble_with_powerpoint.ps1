[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet("ExtractFragment", "Assemble")]
    [string]$Mode,

    [Parameter(Mandatory = $true)]
    [string]$Source,

    [Parameter()]
    [string]$Fragment,

    [Parameter(Mandatory = $true)]
    [string]$Contract,

    [Parameter(Mandatory = $true)]
    [string]$Output,

    [Parameter(Mandatory = $true)]
    [ValidatePattern("^[0-9a-fA-F]{64}$")]
    [string]$ExpectedSourceSha256
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$msoTrue = -1
$msoFalse = 0
$ppAlertsNone = 1
$ppSaveAsOpenXmlPresentation = 24
$createdOutput = $false
$application = $null
$sourceDeck = $null
$workingDeck = $null
$checkDeck = $null
$fragmentDeck = $null
$outputPath = $null

function Write-CompactJson {
    param([hashtable]$Value)

    [Console]::Out.WriteLine(($Value | ConvertTo-Json -Compress -Depth 8))
}

function Throw-Input {
    param([string]$Message)

    throw [System.ArgumentException]::new($Message)
}

function Resolve-AbsoluteWindowsPath {
    param(
        [string]$Value,
        [string]$Label
    )

    if ([string]::IsNullOrWhiteSpace($Value)) {
        Throw-Input "$Label must be a non-empty path"
    }
    if ($Value -match "^/mnt/([A-Za-z])/(.+)$") {
        $drive = $Matches[1].ToUpperInvariant()
        $tail = $Matches[2].Replace("/", "\")
        return [System.IO.Path]::GetFullPath("${drive}:\${tail}")
    }
    if ($Value.StartsWith("/")) {
        try {
            $converted = (& wsl.exe wslpath -w -- $Value).Trim()
        }
        catch {
            Throw-Input "$Label cannot be converted from WSL to Windows"
        }
        if ($LASTEXITCODE -ne 0 -or [string]::IsNullOrWhiteSpace($converted)) {
            Throw-Input "$Label cannot be converted from WSL to Windows"
        }
        return [System.IO.Path]::GetFullPath($converted)
    }
    if ($Value -notmatch "^(?:[A-Za-z]:[\\/]|\\\\)") {
        Throw-Input "$Label must be an absolute Windows or WSL path"
    }
    return [System.IO.Path]::GetFullPath($Value)
}

function Get-Sha256 {
    param([string]$Path)

    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Assert-SourceHash {
    param(
        [string]$Path,
        [string]$Expected
    )

    $actual = Get-Sha256 $Path
    if ($actual -ne $Expected.ToLowerInvariant()) {
        Throw-Input "source SHA-256 mismatch"
    }
}

function Find-ShapeByName {
    param(
        $Slide,
        [string]$Name
    )

    $matches = @()
    for ($shapeIndex = 1; $shapeIndex -le $Slide.Shapes.Count; $shapeIndex += 1) {
        $candidate = $Slide.Shapes.Item($shapeIndex)
        if ([string]$candidate.Name -eq $Name) {
            $matches += $candidate
        }
    }
    if ($matches.Count -ne 1) {
        throw "shape mapping for '$Name' is not unique"
    }
    return $matches[0]
}

function Get-BulletSnapshot {
    param($Slide)

    $snapshot = @()
    $shapeNames = @{}
    for ($shapeIndex = 1; $shapeIndex -le $Slide.Shapes.Count; $shapeIndex += 1) {
        $shape = $Slide.Shapes.Item($shapeIndex)
        if ($shape.HasTextFrame -ne $msoTrue) {
            continue
        }
        if ($shape.TextFrame2.HasText -ne $msoTrue) {
            continue
        }

        $shapeName = [string]$shape.Name
        if ($shapeNames.ContainsKey($shapeName)) {
            throw "source shape name '$shapeName' is not unique"
        }
        $shapeNames[$shapeName] = $true
        $textRange = $shape.TextFrame2.TextRange
        $legacyRange = $shape.TextFrame.TextRange
        $paragraphCount = $textRange.Paragraphs().Count
        for ($paragraphIndex = 1; $paragraphIndex -le $paragraphCount; $paragraphIndex += 1) {
            $paragraph = $textRange.Paragraphs($paragraphIndex, 1)
            $format = $paragraph.ParagraphFormat
            $legacyParagraph = $legacyRange.Paragraphs($paragraphIndex, 1)
            $bullet = $legacyParagraph.ParagraphFormat.Bullet
            if ([int]$bullet.Type -eq 0) {
                continue
            }
            $fontName = [string]$bullet.Font.Name
            $snapshot += [pscustomobject]@{
                ShapeName = $shapeName
                ParagraphIndex = $paragraphIndex
                Type = [int]$bullet.Type
                Character = [int]$bullet.Character
                FontName = $fontName
                UseTextFont = [int]$bullet.UseTextFont
                MarginLeft = [double]$format.LeftIndent
                FirstLineIndent = [double]$format.FirstLineIndent
            }
        }
    }
    return $snapshot
}

function Restore-BulletSnapshot {
    param(
        $Slide,
        [object[]]$Snapshot
    )

    foreach ($entry in $Snapshot) {
        $shape = Find-ShapeByName $Slide $entry.ShapeName
        if ($shape.HasTextFrame -ne $msoTrue -or $shape.TextFrame2.HasText -ne $msoTrue) {
            throw "replacement shape '$($entry.ShapeName)' has no text"
        }
        $textRange = $shape.TextFrame2.TextRange
        if ($textRange.Paragraphs().Count -lt $entry.ParagraphIndex) {
            throw "replacement paragraph mapping for '$($entry.ShapeName)' is missing"
        }
        $paragraph = $textRange.Paragraphs($entry.ParagraphIndex, 1)
        $format = $paragraph.ParagraphFormat
        $legacyParagraph = $shape.TextFrame.TextRange.Paragraphs(
            $entry.ParagraphIndex,
            1
        )
        $bullet = $legacyParagraph.ParagraphFormat.Bullet
        if ([int]$bullet.Character -ne $entry.Character) {
            throw "bullet character changed in '$($entry.ShapeName)' paragraph $($entry.ParagraphIndex)"
        }

        $bullet.Type = $entry.Type
        $bullet.Character = $entry.Character
        $bullet.UseTextFont = $entry.UseTextFont
        if (-not [string]::IsNullOrWhiteSpace($entry.FontName)) {
            $bullet.Font.Name = $entry.FontName
        }
        $format.LeftIndent = $entry.MarginLeft
        $format.FirstLineIndent = $entry.FirstLineIndent

        if (
            [int]$bullet.Type -ne $entry.Type -or
            [int]$bullet.Character -ne $entry.Character -or
            [int]$bullet.UseTextFont -ne $entry.UseTextFont -or
            [math]::Abs([double]$format.LeftIndent - $entry.MarginLeft) -gt 0.01 -or
            [math]::Abs([double]$format.FirstLineIndent - $entry.FirstLineIndent) -gt 0.01
        ) {
            throw "bullet restoration failed in '$($entry.ShapeName)' paragraph $($entry.ParagraphIndex)"
        }
        if (
            -not [string]::IsNullOrWhiteSpace($entry.FontName) -and
            [string]$bullet.Font.Name -ne $entry.FontName
        ) {
            throw "bullet font restoration failed in '$($entry.ShapeName)' paragraph $($entry.ParagraphIndex)"
        }
        if ($entry.Character -eq 216 -and $entry.FontName -eq "Wingdings") {
            if ([string]$bullet.Font.Name -ne "Wingdings") {
                throw "Wingdings bullet restoration failed"
            }
        }
    }
}

function Open-ReadOnlyDeck {
    param(
        $PowerPoint,
        [string]$Path
    )

    return $PowerPoint.Presentations.Open($Path, $msoTrue, $msoFalse, $msoFalse)
}

function Open-EditableDeck {
    param(
        $PowerPoint,
        [string]$Path
    )

    return $PowerPoint.Presentations.Open($Path, $msoFalse, $msoFalse, $msoFalse)
}

function Confirm-Reopen {
    param(
        $PowerPoint,
        [string]$Path,
        [int]$ExpectedSlides
    )

    $script:checkDeck = Open-ReadOnlyDeck $PowerPoint $Path
    if ($script:checkDeck.Slides.Count -ne $ExpectedSlides) {
        throw "reopened output has an unexpected slide count"
    }
    $script:checkDeck.Close()
    $script:checkDeck = $null
}

try {
    $sourcePath = Resolve-AbsoluteWindowsPath $Source "source"
    $outputPath = Resolve-AbsoluteWindowsPath $Output "output"
    $contractPath = Resolve-AbsoluteWindowsPath $Contract "contract"
    $expectedHash = $ExpectedSourceSha256.ToLowerInvariant()
    if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
        Throw-Input "source does not exist"
    }
    if (-not (Test-Path -LiteralPath $contractPath -PathType Leaf)) {
        Throw-Input "contract does not exist"
    }
    if (Test-Path -LiteralPath $outputPath) {
        Throw-Input "output already exists"
    }
    if ($sourcePath -eq $outputPath) {
        Throw-Input "source and output must be distinct"
    }
    if ([System.IO.Path]::GetExtension($sourcePath) -ne ".pptx") {
        Throw-Input "source must be a .pptx file"
    }
    if ([System.IO.Path]::GetExtension($outputPath) -ne ".pptx") {
        Throw-Input "output must be a .pptx file"
    }
    Assert-SourceHash $sourcePath $expectedHash

    $editContract = Get-Content -LiteralPath $contractPath -Raw | ConvertFrom-Json
    if (
        $editContract.schema -ne "edit-research-ppt/edit-contract" -or
        [int]$editContract.schemaVersion -ne 1
    ) {
        Throw-Input "contract schema must be edit-research-ppt/edit-contract version 1"
    }
    $contractSource = Resolve-AbsoluteWindowsPath $editContract.sourcePptx "contract.sourcePptx"
    if ($contractSource -ne $sourcePath) {
        Throw-Input "contract sourcePptx does not match the command source"
    }
    if ([string]$editContract.expectedSourceSha256 -ne $expectedHash) {
        Throw-Input "contract source SHA-256 does not match the command"
    }
    $expectedSlideCount = [int]$editContract.expectedSlideCount
    if ($expectedSlideCount -lt 1) {
        Throw-Input "contract expectedSlideCount must be positive"
    }
    $operations = @($editContract.operations)
    if ($operations.Count -eq 0) {
        Throw-Input "contract operations must not be empty"
    }

    try {
        $application = New-Object -ComObject PowerPoint.Application
    }
    catch {
        throw "PowerPoint COM is unavailable: $($_.Exception.Message)"
    }
    $application.DisplayAlerts = $ppAlertsNone
    $sourceDeck = Open-ReadOnlyDeck $application $sourcePath

    if ($Mode -eq "ExtractFragment") {
        $ordered = @($operations | Sort-Object { [int]$_.fragmentSlide })
        $referenceSlides = @()
        for ($index = 0; $index -lt $ordered.Count; $index += 1) {
            $expectedFragmentSlide = $index + 1
            $actualFragmentSlide = [int]$ordered[$index].fragmentSlide
            if ($actualFragmentSlide -ne $expectedFragmentSlide) {
                Throw-Input "contract fragmentSlide values must be unique and contiguous from 1"
            }
            $referenceSlide = [int]$ordered[$index].referenceSlide
            if ($referenceSlide -lt 1 -or $referenceSlide -gt $sourceDeck.Slides.Count) {
                Throw-Input "referenceSlide $referenceSlide is outside the source deck"
            }
            $referenceSlides += $referenceSlide
        }

        $workingDeck = $application.Presentations.Add($msoFalse)
        foreach ($slideNumber in $referenceSlides) {
            $inserted = $workingDeck.Slides.InsertFromFile(
                $sourcePath,
                $workingDeck.Slides.Count,
                $slideNumber,
                $slideNumber
            )
            if ($inserted -ne 1) {
                throw "PowerPoint did not extract slide $slideNumber"
            }
        }
        $createdOutput = $true
        $workingDeck.SaveAs($outputPath, $ppSaveAsOpenXmlPresentation)
        $workingDeck.Close()
        $workingDeck = $null
        Confirm-Reopen $application $outputPath $referenceSlides.Count
        Assert-SourceHash $sourcePath $expectedHash
        Write-CompactJson @{
            action = "extract-fragment"
            output = $outputPath
            slideCount = $referenceSlides.Count
            sourceSha256 = $expectedHash
            written = $true
        }
        exit 0
    }

    if ([string]::IsNullOrWhiteSpace($Fragment)) {
        Throw-Input "fragment is required in Assemble mode"
    }
    $fragmentPath = Resolve-AbsoluteWindowsPath $Fragment "fragment"
    if (-not (Test-Path -LiteralPath $fragmentPath -PathType Leaf)) {
        Throw-Input "fragment does not exist"
    }
    if (
        $fragmentPath -eq $sourcePath -or
        $fragmentPath -eq $outputPath -or
        $contractPath -eq $outputPath
    ) {
        Throw-Input "source, fragment, contract, and output paths must not overlap"
    }

    $contractFragment = Resolve-AbsoluteWindowsPath $editContract.fragmentPptx "contract.fragmentPptx"
    $contractOutput = Resolve-AbsoluteWindowsPath $editContract.outputPptx "contract.outputPptx"
    if (
        $contractFragment -ne $fragmentPath -or
        $contractOutput -ne $outputPath
    ) {
        Throw-Input "contract paths do not match the command paths"
    }
    $expectedFragmentHash = [string]$editContract.expectedFragmentSha256
    if ($expectedFragmentHash -notmatch "^[0-9a-f]{64}$") {
        Throw-Input "contract expectedFragmentSha256 must be a lowercase SHA-256 value"
    }
    if ((Get-Sha256 $fragmentPath) -ne $expectedFragmentHash) {
        Throw-Input "fragment SHA-256 mismatch"
    }
    $orderedFragmentSlides = @(
        $operations |
        ForEach-Object { [int]$_.fragmentSlide } |
        Sort-Object
    )
    for ($index = 0; $index -lt $orderedFragmentSlides.Count; $index += 1) {
        if ($orderedFragmentSlides[$index] -ne ($index + 1)) {
            Throw-Input "contract fragmentSlide values must be unique and contiguous from 1"
        }
    }
    $fragmentDeck = Open-ReadOnlyDeck $application $fragmentPath
    if ($fragmentDeck.Slides.Count -ne $operations.Count) {
        Throw-Input "fragment slide count must equal the operation count"
    }
    $fragmentDeck.Close()
    $fragmentDeck = $null
    $createdOutput = $true
    $sourceDeck.SaveCopyAs($outputPath, $ppSaveAsOpenXmlPresentation)
    $sourceDeck.Close()
    $sourceDeck = $null
    $workingDeck = Open-EditableDeck $application $outputPath

    foreach ($operation in $operations) {
        $fragmentSlide = [int]$operation.fragmentSlide
        if ($fragmentSlide -lt 1) {
            Throw-Input "fragmentSlide must be positive"
        }
        if ($operation.action -eq "insert_slide") {
            $destinationAfter = [int]$operation.destinationAfter
            if (
                $destinationAfter -lt 0 -or
                $destinationAfter -gt $workingDeck.Slides.Count
            ) {
                Throw-Input "destinationAfter is outside the current deck"
            }
            $inserted = $workingDeck.Slides.InsertFromFile(
                $fragmentPath,
                $destinationAfter,
                $fragmentSlide,
                $fragmentSlide
            )
            if ($inserted -ne 1) {
                throw "PowerPoint did not insert fragment slide $fragmentSlide"
            }
            continue
        }

        if ($operation.action -eq "replace_slide") {
            $destinationSlide = [int]$operation.destinationSlide
            if (
                $destinationSlide -lt 1 -or
                $destinationSlide -gt $workingDeck.Slides.Count
            ) {
                Throw-Input "destinationSlide is outside the current deck"
            }
            $oldSlide = $workingDeck.Slides.Item($destinationSlide)
            $bulletSnapshot = @(Get-BulletSnapshot $oldSlide)
            $inserted = $workingDeck.Slides.InsertFromFile(
                $fragmentPath,
                $destinationSlide,
                $fragmentSlide,
                $fragmentSlide
            )
            if ($inserted -ne 1) {
                throw "PowerPoint did not insert replacement slide $fragmentSlide"
            }
            $oldSlide.Delete()
            $replacement = $workingDeck.Slides.Item($destinationSlide)
            Restore-BulletSnapshot $replacement $bulletSnapshot
            continue
        }

        Throw-Input "unsupported contract operation: $($operation.action)"
    }

    if ($workingDeck.Slides.Count -ne $expectedSlideCount) {
        throw "assembled slide count does not match the contract"
    }
    $workingDeck.Save()
    $workingDeck.Close()
    $workingDeck = $null
    Confirm-Reopen $application $outputPath $expectedSlideCount
    Assert-SourceHash $sourcePath $expectedHash
    Write-CompactJson @{
        action = "assemble"
        output = $outputPath
        operationCount = $operations.Count
        slideCount = $expectedSlideCount
        sourceSha256 = $expectedHash
        written = $true
    }
    exit 0
}
catch {
    if (
        $createdOutput -and
        $null -ne $outputPath -and
        (Test-Path -LiteralPath $outputPath)
    ) {
        Remove-Item -LiteralPath $outputPath -Force -ErrorAction SilentlyContinue
    }
    Write-CompactJson @{
        error = $_.Exception.Message
        written = $false
    }
    if ($_.Exception -is [System.ArgumentException]) {
        exit 2
    }
    exit 1
}
finally {
    foreach ($deck in @($checkDeck, $workingDeck, $sourceDeck, $fragmentDeck)) {
        if ($null -ne $deck) {
            try {
                $deck.Close()
            }
            catch {
            }
        }
    }
    if ($null -ne $application) {
        try {
            $application.Quit()
        }
        catch {
        }
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
