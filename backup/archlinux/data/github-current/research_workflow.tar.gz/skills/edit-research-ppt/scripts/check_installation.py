#!/usr/bin/env python3
"""Run read-only checks for the repository-bundled research PowerPoint skill."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path


INVOCATION_SKILL_ROOT = Path(__file__).absolute().parents[1]
SKILL_ROOT = Path(__file__).resolve().parents[1]
CONTROL_ROOT = SKILL_ROOT.parents[1]
SKILL_NAME = SKILL_ROOT.name


def _absolute(value: str, label: str) -> Path:
    path = Path(value).expanduser()
    if not path.is_absolute():
        raise ValueError(f"{label} must be absolute")
    return path.resolve(strict=False)


def _default_codex_home() -> Path:
    configured = os.environ.get("CODEX_HOME")
    return _absolute(configured, "CODEX_HOME") if configured else (Path.home() / ".codex").resolve()


def _quick_validate(codex_home: Path) -> Path | None:
    candidates = [
        INVOCATION_SKILL_ROOT.parent / ".system" / "skill-creator" / "scripts" / "quick_validate.py",
        codex_home / "skills" / ".system" / "skill-creator" / "scripts" / "quick_validate.py",
    ]
    return next((path for path in candidates if path.is_file()), None)


def run_command(args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, text=True, capture_output=True, check=False)


def check_installation(codex_home: Path) -> dict[str, object]:
    checks: dict[str, dict[str, object]] = {}
    errors: list[str] = []

    def add(name: str, ok: bool, detail: str) -> None:
        checks[name] = {"ok": ok, "detail": detail}
        if not ok:
            errors.append(f"{name}: {detail}")

    required = {
        "skill": SKILL_ROOT / "SKILL.md",
        "agent_metadata": SKILL_ROOT / "agents" / "openai.yaml",
        "quality_reference": SKILL_ROOT / "references" / "ppt-style-and-qa.md",
        "contract_schema": SKILL_ROOT / "references" / "edit-contract.schema.json",
        "installer": SKILL_ROOT / "scripts" / "install.py",
        "self_check": SKILL_ROOT / "scripts" / "check_installation.py",
        "preflight": SKILL_ROOT / "scripts" / "pptx_preflight.py",
        "fragment_builder": SKILL_ROOT / "scripts" / "build_fragment.mjs",
        "math_reimport_verifier": SKILL_ROOT / "scripts" / "verify_math_reimport.mjs",
        "powerpoint_assembler": SKILL_ROOT / "scripts" / "assemble_with_powerpoint.ps1",
        "verifier": SKILL_ROOT / "scripts" / "verify_pptx.py",
    }
    for name, path in required.items():
        add(name, path.is_file(), str(path))

    add(
        "bundled_location",
        SKILL_ROOT == CONTROL_ROOT / "skills" / SKILL_NAME,
        str(SKILL_ROOT),
    )

    installed = codex_home / "skills" / SKILL_NAME
    add(
        "installed_link",
        installed.is_symlink() and installed.resolve() == SKILL_ROOT,
        f"{installed} -> {SKILL_ROOT}",
    )

    if required["skill"].is_file():
        text = required["skill"].read_text(encoding="utf-8")
        add(
            "skill_contract",
            all(
                value in text
                for value in (
                    "Edit Research PPT",
                    "presentations:Presentations",
                    "$research-workflow",
                    "edit-contract.json",
                    "assemble_with_powerpoint.ps1",
                    "verify_math_reimport.mjs",
                    "m:oMath",
                    "references/ppt-style-and-qa.md",
                )
            ),
            "bundled authority, companion skills, and QA reference",
        )

    if required["agent_metadata"].is_file():
        text = required["agent_metadata"].read_text(encoding="utf-8")
        add(
            "agent_metadata_contract",
            all(value in text for value in ("科研 PowerPoint 安全编辑", "$edit-research-ppt")),
            "current UI metadata",
        )

    if required["installer"].is_file():
        result = run_command(
            [
                sys.executable,
                "-B",
                str(required["installer"]),
                "--codex-home",
                str(codex_home),
                "--json",
            ]
        )
        try:
            payload = json.loads(result.stdout)
            add(
                "installer_preview",
                result.returncode == 0
                and payload.get("mode") == "preview"
                and payload.get("written") is False,
                payload.get("action", (result.stderr or result.stdout).strip()),
            )
        except json.JSONDecodeError:
            add("installer_preview", False, (result.stderr or result.stdout).strip())

    quick_validate = _quick_validate(codex_home)
    if quick_validate is None:
        add("skill_creator_validation", False, "quick_validate.py not found through the installed Codex home")
    else:
        result = run_command([sys.executable, "-B", str(quick_validate), str(SKILL_ROOT)])
        add(
            "skill_creator_validation",
            result.returncode == 0,
            (result.stdout or result.stderr).strip(),
        )

    return {
        "ok": not errors,
        "skill_root": str(SKILL_ROOT),
        "control_root": str(CONTROL_ROOT),
        "codex_home": str(codex_home),
        "checks": checks,
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Check the bundled research PowerPoint skill")
    parser.add_argument("--codex-home")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    try:
        codex_home = (
            _absolute(args.codex_home, "codex home")
            if args.codex_home
            else _default_codex_home()
        )
        result = check_installation(codex_home)
    except (OSError, ValueError) as exc:
        result = {"ok": False, "errors": [str(exc)], "input_error": True}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        for name, check in result.get("checks", {}).items():
            print(f"[{'OK' if check['ok'] else 'ERROR'}] {name}: {check['detail']}")
    if result.get("input_error"):
        return 2
    return 0 if result.get("ok") else 1


if __name__ == "__main__":
    raise SystemExit(main())
