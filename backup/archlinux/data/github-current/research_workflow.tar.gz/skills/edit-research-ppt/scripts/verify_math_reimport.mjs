#!/usr/bin/env node

import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";

import { InputError, verifyReimportedMath } from "./build_fragment.mjs";

function fail(message) {
  throw new InputError(message);
}

function absolute(value, label) {
  let input = value;
  if (typeof input !== "string") {
    fail(`${label} must be an absolute path`);
  }
  if (process.platform === "win32") {
    const mounted = input.match(/^\/mnt\/([A-Za-z])(?:\/(.*))?$/u);
    if (mounted) {
      input = `${mounted[1].toUpperCase()}:\\${(mounted[2] ?? "").replaceAll("/", "\\")}`;
    }
  }
  if (!path.isAbsolute(input)) fail(`${label} must be an absolute path`);
  return path.resolve(input);
}

function argumentsFrom(argv) {
  const values = {};
  for (let index = 0; index < argv.length; index += 2) {
    const key = argv[index];
    if (!["--pptx", "--contract"].includes(key) || argv[index + 1] === undefined) {
      fail("usage: verify_math_reimport.mjs --pptx ABS --contract ABS");
    }
    values[key] = argv[index + 1];
  }
  return {
    pptx: absolute(values["--pptx"], "--pptx"),
    contract: absolute(values["--contract"], "--contract"),
  };
}

function outputSlides(contract) {
  const sourceCount =
    contract.expectedSlideCount -
    contract.operations.filter((item) => item.action === "insert_slide").length;
  const tokens = Array.from({ length: sourceCount }, (_, index) => ({
    source: index + 1,
  }));
  const outputs = new Map();
  contract.operations.forEach((operation, index) => {
    const token = { operation: index };
    if (operation.action === "insert_slide") {
      tokens.splice(operation.destinationAfter, 0, token);
    } else {
      tokens.splice(operation.destinationSlide - 1, 1, token);
    }
  });
  tokens.forEach((token, index) => {
    if (token.operation !== undefined) outputs.set(token.operation, index + 1);
  });
  return outputs;
}

async function loadArtifactTool(contractPath) {
  const resolver = createRequire(
    pathToFileURL(path.join(path.dirname(contractPath), "__resolver__.cjs")),
  );
  const entryPoint = resolver.resolve("@oai/artifact-tool");
  return import(pathToFileURL(entryPoint).href);
}

async function main() {
  const options = argumentsFrom(process.argv.slice(2));
  const contract = JSON.parse(await fs.readFile(options.contract, "utf8"));
  if (
    contract.schema !== "edit-research-ppt/edit-contract" ||
    contract.schemaVersion !== 1 ||
    !Array.isArray(contract.operations) ||
    !Array.isArray(contract.equations)
  ) {
    fail("invalid edit contract");
  }
  if (absolute(contract.outputPptx, "contract.outputPptx") !== options.pptx) {
    fail("contract outputPptx does not match --pptx");
  }
  const equationById = new Map(
    contract.equations.map((equation) => [equation.id, equation]),
  );
  const mapped = [];
  const slides = outputSlides(contract);
  contract.operations.forEach((operation, index) => {
    for (const identifier of operation.equations) {
      const equation = equationById.get(identifier);
      if (equation === undefined) fail(`unknown equation id: ${identifier}`);
      mapped.push({ ...equation, outputSlide: slides.get(index) });
    }
  });
  const artifactTool = await loadArtifactTool(options.contract);
  const presentation = await artifactTool.PresentationFile.importPptx(
    await artifactTool.FileBlob.load(options.pptx),
  );
  const result = verifyReimportedMath(presentation, mapped, "outputSlide");
  process.stdout.write(
    `${JSON.stringify({ ok: true, pptx: options.pptx, ...result })}\n`,
  );
}

main().catch((error) => {
  const code = error instanceof InputError ? 2 : 1;
  process.stdout.write(
    `${JSON.stringify({ ok: false, error: String(error.message ?? error) })}\n`,
  );
  process.exitCode = code;
});
