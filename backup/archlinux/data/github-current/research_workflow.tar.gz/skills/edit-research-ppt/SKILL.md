---
name: edit-research-ppt
description: Safely edit existing research PowerPoint decks while preserving untouched slides, native objects, template styling, symbol-font bullets, and editable Office Math equations. Use for appending or replacing research slides, transferring scientific text or tables, matching reference slides, or validating a modified .pptx without whole-deck round-tripping.
---

# Edit Research PPT

Edit research decks through bounded slide fragments and PowerPoint-native assembly.

## Authority

- Resolve `CONTROL_ROOT` from `CONTROL_ROOT/skills/edit-research-ppt/SKILL.md`.
- Treat this repository directory as the skill authority.
- Read and follow `presentations:Presentations` before inspecting or editing a
  `.pptx`.
- Use `$research-workflow` only when a source or destination is under a root
  registered by `CONTROL_ROOT/workspace.toml`.
- Read [references/ppt-style-and-qa.md](references/ppt-style-and-qa.md) before
  building a fragment, creating equations, or validating delivery.

## Required workflow

1. Resolve the exact source deck, authorized slide operation, content source,
   reference slides, and distinct output path. Use 1-based slide numbers.
2. Keep notes read-only and use only an explicitly linked note section. Do not
   scan Notes, Data, Reports, or sibling roots to discover missing context.
3. Create task scratch outside user content. Run `pptx_preflight.py` and build
   a draft `edit-contract.json` with the source hash and authorized operations.
4. Inspect and render the source deck and reference slides. Use
   `assemble_with_powerpoint.ps1` in extract-fragment mode to copy only declared
   reference slides into a starter deck with PowerPoint-native formatting.
5. Normalize scientific content without inventing missing values. Preserve
   symbols, units, signs, precision, and distinctions among inputs,
   diagnostics, observations, and conclusions.
6. Point the content model at the absolute starter path and use
   `build_fragment.mjs` to edit only authorized inherited objects. Never import,
   rebuild, or export the whole source deck with artifact-tool.
7. Finalize the contract with the fragment and math-ledger SHA-256 values and
   copy the generated equation records exactly. Extra fields are forbidden.
8. Run `assemble_with_powerpoint.ps1`. It must copy the source, insert the
   hash-bound fragment with PowerPoint, delete only explicitly replaced slides,
   and refuse source overwrite or source-hash drift.
9. Run `verify_pptx.py` and `verify_math_reimport.mjs`, reopen the candidate,
   and render every slide. Deliver only when structural, content, native-math,
   re-import, and visual gates pass.

## Preservation contract

- Treat every slide not named by the contract as preserve-only.
- Preserve slide order, text, object geometry, paragraph and run formatting,
  media, relationships, layout/master/theme dependencies, and native math.
- Preserve the complete bullet tuple. A character such as `Ø` is not a safe
  bullet by itself: its `buFont` may be the Wingdings mapping that renders the
  intended arrow.
- Do not use whole-deck import/export, global restyling, or generic theme
  replacement.
- If PowerPoint COM, source mapping, native equation creation, reopening, or
  verification fails, stop without a fallback deliverable.

## Native equations

- Represent formulas as artifact-tool structured math runs using `latex` and
  `displayMode`; never type raw LaTeX or approximate it with Unicode.
- Keep block math as the only run in its paragraph. Inline math may mix with
  text. Use structured math inside table cells.
- Preflight every formula through the bundled math ledger. Unknown commands,
  parser degradation, residual command text, or wrong MathML structure must
  fail closed.
- Bind the final contract to exact fragment and math-ledger hashes. Require an
  exact object, table cell when applicable, equation ordinal, and OMML count;
  undeclared equations fail.
- Require final `m:oMath` or `m:oMathPara` in the intended object and successful
  artifact-tool re-import as an `inlineNodes.math` node.

## Completion

Report the output path, changed slides, source and reference scope, contract
result, equation result, render/reopen checks, retained scratch, and every
modified user file. Do not claim completion after any failed gate.

```text
python3 -B "<CONTROL_ROOT>/skills/edit-research-ppt/scripts/check_installation.py" --codex-home "/absolute/path/to/.codex" --json
```

Use the bundled installer preview before repeating it with `--write`.
