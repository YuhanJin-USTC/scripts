#!/usr/bin/env python3
"""Run the current Research Workflow V0 CLI."""

from pathlib import Path
import sys


SOURCE_ROOT = Path(__file__).resolve().parents[1] / "src"
sys.path.insert(0, str(SOURCE_ROOT))

from research_workflow.cli.main import main


if __name__ == "__main__":
    raise SystemExit(main())
