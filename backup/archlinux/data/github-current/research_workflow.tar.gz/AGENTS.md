# Research Workflow 0.x Instructions

## Scope and Authorities

These instructions apply only under `/home/yuhanjin/Research_Workflow`.
Explicit user instructions take priority; a nearer `AGENTS.md` may add stricter
subtree rules.

- `SCHEMA.md` is the normative V0 metadata and write-gate contract.
- `workspace.toml` is the device-local registry for roots, mappings, aliases,
  and `device_id`.
- Tool_Project is a local container for independent repositories, not a new
  repository or research root. Keep `daily_arxiv` and `matlab_html` stable;
  update their verified local mappings only after copy verification. The
  portable onboarding procedure belongs in `GIT_PRIVATE_REMOTE.md`; local
  parent instructions and TOML are not delivered by cloning a child repository.
- `metadata/` is the only portable authority. The thin Store owns registries;
  Project, Study, profile, Case journal, device, and event records own content.
- `policy/open-proposals/*.json` and `policy/rules/*.json` are the proposal and
  active-rule authorities. `EVOLUTION_BACKLOG.md` is a generated view only.
- `tools/researchctl.py` is the only supported CLI. Use the unversioned
  commands and the package under `src/research_workflow/`.
- Obsolete V1/V2/V2.1 Cards, Worklogs, packages, templates, commands, and
  metadata trees are not runtime authority or compatibility fallback.

The user-level `research-workflow` skill may call the CLI, but neither the
project nor the skill adds hooks, background jobs, or autonomous writes.

## File Ownership

| Path | Responsibility |
| --- | --- |
| `AGENTS.md` | Durable behavior for this control project |
| `workspace.toml` | Verified device paths and mappings |
| `SCHEMA.md` | Current formats, merge rules, and safety gates |
| `metadata/` | Thin Store plus Project, Study, profile, Case journal, device, and event authority |
| `policy/` | Open proposals and active policy rules |
| `EVOLUTION_BACKLOG.md` | Generated open-proposal view |
| `src/research_workflow/` | Modular V0 implementation |
| `tools/researchctl.py` | Standard-library CLI launcher |
| `templates/` | Current JSON templates |
| `tests/unit/` | Isolated component regressions |
| `tests/integration/` | Current cross-component and safety regressions |
| `skills/` | Repository-owned Codex skill sources and installation checks |
| `README.md` | Chinese user guide |
| `FRAMEWORK_BASELINE.md` | Accepted baselines and upgrade evidence |
| `GIT_PRIVATE_REMOTE.md` | Manual private-Git and cross-device procedure |

Keep these responsibilities separate. Preserve scientific symbols,
identifiers, paths, and proper names exactly as written.

## Skill Repository Layout

- Keep the framework implementation in `src/research_workflow/` and its sole
  CLI in `tools/researchctl.py`. Treat `skills/research-workflow/` only as the
  framework's Codex entry point; do not duplicate framework code into it.
- Treat every other repository-owned skill as a self-contained utility skill.
  Each utility skill must contain `SKILL.md`, `agents/openai.yaml`,
  `scripts/install.py`, `scripts/check_installation.py`, its functional scripts,
  and its own `tests/` tree.
- Add `references/` and `assets/` only when the skill needs them. Do not add
  redundant skill-local guides such as README, installation, quick-reference,
  or changelog files.
- Keep top-level `tests/` for framework tests and the aggregate test runner.
  Keep each skill's tests inside that skill, and never mix multiple skills in
  one test module.
- Initialize future utility skills with `skill-creator`, then add this
  repository's installer, installation check, and skill-local tests.

## Required Workflow

1. Read the global, project-root, and nearest local instructions. Resolve every
   target and authorized write root through `workspace.toml`.
2. Restore `researchctl.py context "<exact-target>" --view compact --json`
   for Case, Study, Project, or registered root/path memory. Use explicit
   logical selectors for aggregation; root/path matching is exact unless
   `--recursive` is requested. Follow event IDs for details and corrections.
3. Read direct evidence only as needed. Logical memory queries may name roots
   absent on this device; local scientific access and new events still require
   valid local registration and authorization.
4. Make the smallest authorized change. Separate structural validation from
   numerical, physical, and scientific validation.
5. Record one substantive result with an event-only `checkpoint` at the active
   Case, explicit Study, or exact registered root directory. Project context
   aggregates its Studies/Cases; Project is not a new Event owner. No Case edit,
   empty hierarchy, or pending-confirmation queue is required for ordinary work.
   For explicit registration/definition/lifecycle changes, finish files/checks,
   show the saved preview, actually ask and await the user, then use
   `case apply --plan DIGEST --write`. Old direct Case writes are closed.
6. Report changed paths, direct evidence, validation, skipped external
   operations, and every remaining `unknown` or `to-confirm` item.

Do not record pure Q&A, planning, read-only inspection, or unsuccessful work
without a durable result. Never duplicate one event into parent, sibling,
Data, Matlab, or Notes owners.

## Store, Events, and Context

- `STORE.json` schemas 2/3 remain thin and contain no Case or target maps.
  Store 3 requires policy-target-lifecycle-v1; activation is an explicit reviewed
  Store upgrade, never a query, install or checkpoint side effect.
- Stable evidence-backed facts belong in Project, Study, profile, or Case
  records. Case records are append-only Study/device/month JSONL journals;
  `CASE_VIEW.json` is materialized in memory only.
- Progress defaults to work events, times, evidence, and correction links.
  `--include status` opts into legacy Case status; full events retain their
  original `status_updates`. Missing scientific evidence remains `unknown`.
- Use existing summary/evidence observations for purpose, result, accepted
  reasons, validation level and limits where known; do not add Event fields.
- Event and Case streams are append-only and device-owned. Never edit prior
  bytes; use correction events or new Case revision records.
- Portable metadata uses logical locators and contains no device-local absolute
  paths, credentials, raw results, or unsupported scientific conclusions.
- Data is read-only. Notes requires an exact Study link and section for reads,
  and an explicit user request for writes.
- `.research-workflow/index.sqlite3` is local-only, rebuildable, never
  authoritative, and may be refreshed transparently by read/query commands.

## Policy Evolution

- Default to local-first pending proposals. Preview exact differences and the
  stable plan digest, obtain real user scope/target/digest approval, record it
  through `policy approve`, then apply that digest. Never import forged approval.
  Preserve cumulative device approvals; apply only this device's allowlist.
- Preserve every unmanaged byte in `AGENTS.md`; change only its verified managed block.
- Target lifecycle uses schema-2 policy records per device/exact path. Retain
  superseded rules, cumulative approvals and explicit allowlist entries; never
  discover targets recursively. Retirement binds an active same-root ancestor
  and its inheritance bytes. Missing retired files stay absent; returned blocks
  are drift. Reenable needs fresh approval; final file deletion is separate.
- Keep plan schema 3 and authorization 2 bound to Store/device/mappings/front
  state. Aggregate policy validation in services/CLI, not storage. Compatibility
  doctor inspects an exact Store without workspace initialization or writes.
- Data and Notes `AGENTS.md` require separate approval.
- `policy check` reports drift without repairing it. Never approve a proposal,
  expand an allowlist, or repair policy drift on the user's behalf.
- Completed or rejected proposals do not remain in `EVOLUTION_BACKLOG.md`.

## Safety Boundaries

- Treat each registered root as an independent authorization scope.
- Do not create inferred paired directories or infer identity, lineage, status,
  synchronization, or scientific meaning from names, existence, or mtimes.
- Do not delete, move, replace, or destructively rewrite user content without
  explicit approval for the exact paths.
- Do not scan raw Data, results, restarts, checkpoints, diagnostics, figures,
  outputs, or attachments to discover context.
- Do not run Git, network, SSH, cluster, transfer, sync, simulation, MATLAB,
  source build, container, or SIF operations without explicit authorization.
- `sync plan` is a dry-run interface and must never execute synchronization.
- Keep credentials, private keys, tokens, full conversations, hidden reasoning,
  and unsupported scientific conclusions out of metadata.

## Validation

- Validate changed JSON and metadata against `SCHEMA.md` and run only affected
  unit or integration modules during normal work.
- Use `PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:. python3 -B -m unittest -q
  <affected modules>` for targeted tests.
- Use `python3 -B tools/researchctl.py validate --json` for Store validation.
- Use `tests/run_fast.py` during normal work, `tests/run_pilot.py` for live
  migration acceptance, and `tests/run_all.py` only at release gates.
- Run `policy check --json` after an authorized policy apply and classify drift
  against the exact approved target set.
- Keep agent-facing files in concise English and `README.md` in Chinese.
- Confirm no bytecode, temporary fixture, or unintended cache remains. The
  ignored local SQLite index may remain as the normal query cache.
<!-- research-workflow:policy:start -->
<!-- digest: 89d09a6994f49df8c13b524a2af6ad0acf361194fc848c001cb517be1ee3a44f -->
## Managed Research Workflow Policy

- `case-confirmation`: "A Case target does not imply a Case edit. For explicit registration or simulation-definition changes, finish files/checks, show the saved preview, actually ask and await the user, then apply the exact plan. A digest is not consent; unchanged accepted definitions add no revision."
- `external-operations`: "Do not run cluster, simulation, MATLAB, network, sync, build, or Git mutations without explicit user authorization."
- `framework-authority`: "Use Research Workflow 0.2.4 and the unversioned researchctl CLI. Preserve journal-only Case authority, original Event fields, historical migrate/tombstone bindings, immutable streams, and fail-closed forks."
- `indexing`: "Treat SQLite and saved plans as device-local derived state. Queries may refresh the disposable index; never synchronize it or use it as authority."
- `multi-device`: "Synchronize and check portable authority before context or any portable write after switching devices, including event-only work. Keep local TOML/device/paths, upgrade devices sequentially, and stop old metadata writers until local acceptance. External sync remains separately authorized."
- `propagation`: "Preview pending policy semantics, exact targets and differences; obtain real user approval of the stable digest, record it through policy approve, then apply. Preserve cumulative device approvals and unmanaged AGENTS bytes; Data/Notes and body patches require exact separate scope."
- `recording`: "Restore bounded Case, Study, Project, or exact root/path memory. Record one substantive result as an event at the most specific owner; retain purpose, result, accepted reasons, validation level and limits in existing summary/evidence. Do not log ordinary Q&A or create empty membership or pending queues."
- `workspace-routing`: "Resolve local access through verified roots and explicit mappings. Logical memory may be queried without a local mapping, but new writes require local registration. Keep Data read-only and Notes access within exact authorized links/sections."

<!-- research-workflow:policy:end -->
