# Research Workflow 0.2.4 Architecture

## Release shape

Package 0.2.4 retains framework family `0`, thin Store schemas 2/3, journal-only
Case authority and schema-1 Events. The CLI has 29 versionless leaves. Local
implementation, protected instruction deployment, publication, and second-device
acceptance are separate states recorded in `FRAMEWORK_BASELINE.md`.

```text
workspace.toml (local roots/device)       metadata/ (portable authority)
                |                        Project/Study/profile/device
                |                        Case and Event journals
                +--------- deterministic reduction --------+
                                  |                        |
                      QueryIndex (local schema 5)     write/device gates
                                  |                        |
                      MemoryQuery / ReadSelector     authority lock
                                  |                        |
                         ContextService          result-only checkpoint
                                  |               explicit CaseChanges
                     clues -> list -> show                 |
                                              local ConfirmationPlans
                                              preview -> user -> apply
```

The thin Store registers Projects and devices only. Case head/lifecycle/lineage
is reduced through explicit parent digests. Project → Study → ordered profiles
→ Case materialization preserves accepted snapshots independently of current
scientific files. Historical migrate/tombstone bindings remain readable.

## Package boundaries

| Package | Responsibility |
| --- | --- |
| core/domain | Canonical values, identities, Case/Event/correction semantics |
| workspace | Device-local roots, explicit aliases, logical locators |
| storage | Thin Store, journals, device membership, locks, guarded writes |
| index | One disposable SQLite query projection, complete root owner paths |
| services/queries | Portable read selectors, ownership/lineage unions, filters |
| services/context | Bounded context and explicit optional link/status projection |
| services/owners | Local new-write owner resolution and access checks |
| services/checkpoint | One substantive work event, optional explicit Case changes |
| services/case_changes and plans | Definition preview, local dependency bindings and accepted replay |
| evolution | Schema-1 policy, schema-2 device/path lifecycle, digest-bound projections |
| services/store_upgrade and validation | Explicit Store capability migration and aggregate validation |
| cli | Only supported user-facing query and write interfaces |

Domain values do not write files; lower layers do not import CLI. Local new-write
restrictions do not block reading portable memory on a device without that root.

## Work and accepted definitions

A task result normally appends one evidence-backed event at the existing Case,
Study, or exact registered root directory. Parameters, accepted reasons, results,
validation levels and limits fit existing summary/evidence observations. Reads
and ordinary discussion do not log turns. No empty hierarchy or pending queue
is created. Case ownership alone never requests a Case edit.

Explicit create/revise/rename/delete and checkpoint Case changes all prepare
saved previews. Real human acceptance precedes apply; a digest is an equality
check, not evidence of consent. Exact configured input files and relevant
heads/dependencies/root mappings/device are bound locally. Unchanged definitions
are no-ops; exact successful retry is reusable, partial writes and stale plans
fail closed. One local authority lock serializes supported writers, and devices
append only their own streams. This does not coordinate remote machines.

## Useful portable reads

Case, Study, Project and root/path context use the same index. Exact owner match
is default; root recursion is explicit. Case progress associates only exact
pre-registration directories through explicit mappings, retains original owners,
follows rename lineage and deduplicates event IDs. Parent background is separate.
Corrections remain visible outside a selected time/count filter.

Logical root reads do not require local paths. `mappingAvailable` means a direct
mapping is configured, not that scientific files exist. Default progress is work
history, counts and evidence clues; legacy status is opt-in. Full event views
retain real historical status updates. Compact/deep budgets are 4096/24576 bytes;
large content is trimmed before work clues, with explicit omission and follow-up.
The index rebuilds locally on format change and never travels through Git.

## Policy and device boundaries

Pending policy plans bind semantic changes, cumulative approved scope, exact
local target diffs and relevant front-state. `policy approve` records actual
user approval of the stable digest; actor/time bookkeeping does not change it.
`policy apply` preserves unmanaged bytes. Body changes are separate reviewable
patches, and Data/Notes need separate exact approval. Old approved rules remain
readable; active drift or new targets require fresh reauthorization. Correct
blocks are reusable after approval-only synchronization.

Store 3 adds a required capability, without target or Case membership. The
storage compatibility gate has no policy/CLI dependency; aggregate validation
combines metadata, policy and compatibility in services. Compatibility-only
doctor can inspect one archived Store before constructing WorkspaceRegistry.
Only explicit digest-confirmed Store upgrade changes the format.

Target records reuse policy proposal/rule authorities. Retirement is per device
and exact path, retains approval history and removes only a verified block.
The explicit same-root parent and its inheritance bytes enter authorization 2;
policy plans use schema 3. Missing retired files stay absent. Reenable needs a
new approval. Explicit allowlists are access boundaries and remain unchanged.
Local replay receipts are completion markers, never portable authority. A
pre-completion validator rechecks outputs and unchanged dependencies. Rollback
preserves later external edits instead of forcing before-images over them.
Aggregate validation resolves actual allowlist contexts; scope queries reduce
full retained history before selecting a scope.

Each device keeps its TOML, SQLite, local plans, skill link and external AGENTS.
Shared source/skill/policy/metadata move only by authorized external sync. Stop
old metadata writers; upgrade and accept devices sequentially. Synchronize and
check authority before context and before event-only writes on a changed device.
The CLI cannot prove that external sync or another device's shutdown occurred.

Git/network, SSH, sync/transfer, cluster, simulation, MATLAB, source builds,
containers, SIF and APIs are never automatic. Notes bodies require exact link
and section selection; no raw-data discovery, embeddings or automatic ingestion
is introduced. Validation of metadata is distinct from source, numerical and
physical validation. Full installation checks may refresh the derived cache;
ordinary installation checks do not inspect live authority.

## Historical recovery

The live cutover has 207 active migrate records, 8 migrate-tombstone records,
no `metadata/cases`, and 261 unchanged Event lines across four streams. Exact
acceptance measurements belong in `FRAMEWORK_BASELINE.md`.

The previously documented external tar is currently unavailable; its actual
location is `to-confirm`. Its old expected path and digest remain historical
reference only. Recovery is destructive/overwriting and requires exact target
authorization; the archive must not be inferred or claimed verified.
