# Research Workflow V0 Baseline

## Accepted cutover status

- Framework: `0`
- Accepted package: `0.1.0`
- Schema: `1`
- Cutover state: `complete`
- `framework_version`: `"0"`
- `implementation_status`: `implemented`
- `current_phase`: `complete`
- Portable authority: `metadata/`
- CLI: `tools/researchctl.py`
- Acceptance: complete
- Final acceptance event: `20260719T110203Z-laptop-1-v0-acceptance`

## Accepted cutover authority

At cutover, the V0 Store contained 1 Project, 2 Studies, 5 profiles, 1 device,
11 Cases, and append-only device event streams. These counts are historical
acceptance evidence, not a live inventory. Current counts come only from
`validate` or `event merge`. Every Case has one digest-bound
`CASE_DELTA.json` and `CURRENT_SPEC.json` pair. Materialized views are generated
in memory only.

All 11 input identities and all 11 runner identities were verified against
live Simulation sources in Phase 4. Two referenced SIF byte identities were
verified. Scientific results, lineage not established by direct evidence, and
all Run/Data/Analysis states remain `unknown`.

## Current contracts

- Data is read-only.
- Notes requires an explicit Study link or explicit user request.
- Metadata and policy writes are preview-first and device-gated.
- Events are append-only and recorded once at the most specific owner.
- Policy promotion is local-first and requires explicit approval plus an exact
  plan digest.
- Git, network, cluster, synchronization, simulation, MATLAB, source build,
  container, and SIF operations are not automatic validation.
- The local SQLite cache is rebuildable and non-authoritative.

## Recovery

The project-external archive
`/home/yuhanjin/Research_Workflow-pre-v0-reset-20260719.tar` is the authoritative
pre-cutover recovery source with SHA-256
`988a80543beb94b23ad06e7dde04a4347d5cbb7945a0e34091fb55792b3e7ade`.
The repository retains only the approved three-file archive-backed recovery
fixture. No project-internal recovery archive is created.

## Acceptance

- Current top-level unittest discovery: 71 passed.
- Store structural validation: valid; 11 Cases.
- Context maxima: 4999 task bytes and 5005 discussion bytes.
- Approved deletion manifest: 175/175 paths absent.
- Managed policy targets: 19/19; blocking drift: 0.
- Previously deferred nested targets: 12/12 propagated under the explicit V0
  revision-2 authorization, including separate Notes approval.
- Phase 6 acceptance SHA-256:
  `4a62001935ce07e897eac0d37a22aed3401ede00afe5997b519bfd86233bfe76`.

The single root-owned final acceptance event is
`20260719T110203Z-laptop-1-v0-acceptance`. The later V0 agent-contract
migration and post-acceptance hardening are recorded separately as normal
modification events. The merged stream remains append-only.

## Control evidence

- Control prompt SHA-256:
  `8c0efb2fb8cb9746bbc7a832272bd0b33a86e36160aa915bd777d25f7c27438b`.
- Control contract SHA-256:
  `b879810fc659bfab9fbf71ce6890e0fa68345baaa8a0bec003e82128297c5f4a`.
- Approved deletion manifest SHA-256:
  `8c8c17c951e9ac1feac77132842ced936c006004f4cda0cd1c59ee0415adb8f7`.

## V0 agent contracts

All 19 discovered managed targets now carry the current V0 policy with no
drift. The 12 formerly deferred nested targets also replace active legacy
workflow instructions with V0 event ownership while retaining local safety
rules. The original nine approved target SHA-256 values are:

- control: `7e0d9e274e0b817ae2a48c2835bd12214fca3ea7dcd5357ca0878c38643a0897`
- Code_Program: `59e7a870da068b49dd8035f66b89082f1ccb6ab70be9de59f67aecbe437473a5`
- Research_Workflow: `46023faa2c8ccd4b456a7b13853028683ac669d0302b8204d6eef8a7004c9b6b`
- Simulation: `d40a54837df07acfe73a5191d52959b8ed70ac42a9f662b2c0de7fd89b4d0f5c`
- Simulation/qed_cone_pair: `0ee6a3d3d482faa159b561f3e1c02091d5d1aca4e5a4944abd12fcf9a4aa62d6`
- Source_Code: `8d3d5bfac97f65c6b6240a32addaddc1cfceba666fd9e4119158be5f70e17590`
- dot_files: `9dd6af56077f9e626641fce2c8f908c172188bfb47dc01731350d5cbb7ebdaf1`
- scripts: `c2302ac930ded3aa267b4797c13a752f5075214e0cdae9a565006e0edfb5831d`
- Matlab: `de544ce6f7fd74b2f353a199cf97565c2d8f49c30d2a0dcc5cc3bcb2991db7e5`

The root-owned governance modification event is
`20260719T111236Z-laptop-1-v0-agents-migration`.

No Git, network, cluster, simulation, MATLAB, synchronization, build,
container, or SIF operation was performed.

## Post-acceptance maintenance

This baseline remains frozen as cutover evidence. Later package releases,
Projects, Studies, Cases, and events evolve through the current preview-first
interfaces and append-only event streams. Do not copy live Store counts back
into this historical document.

## 0.2.1 accepted scalability baseline

The V0 evidence above remains frozen. Package `0.2.1` is implemented and its
bounded LBW migration pilot is accepted; it does not alter historical cutover
counts, digests, or events.

- `implementation_status`: `implemented`
- pilot acceptance: `accepted` (5 read-only tests)
- Store schema: `2`; legacy readable schema: `1`
- Case authority: device-owned monthly Case journals
- Store registry: Projects and devices only
- local projection: transparent rebuildable SQLite index
- context: compact by default, at most 4096 bytes
- task write: one structured checkpoint request and exactly one event
- knowledge integration: typed Notes locator/section metadata and explicit
  on-demand reads only; existing-authority link mutation is a reserved future
  checkpoint seam, not a 0.2.1 writer
- default validation: isolated fast tier; pilot and full are explicit

Direct pilot evidence for the 11 Cases under
`lbw_plasma_mirror/w_scanning_2d_v1`:

- migration plan digest:
  `ebb02a1a90f4f8e08fc13cab1958efbab98543ce50e43d223a2e882cf1de8276`;
- `STORE.json`: 14,714 legacy bytes to 275 thin-schema bytes;
- 22 legacy Case files, approximately 88 KiB allocated, replaced by one
  25,005-byte journal occupying 28 KiB;
- journal: 11 bound `migrate` records; every old pilot Case directory absent;
- compact context: 3,967/4,096 bytes maximum; measured cold 0.634 s and warm
  0.617 s for the acceptance target;
- four preserved events from `2026-08-20T00:00:00Z`: 8,713 exact bytes, SHA-256
  `aaf751e7d5e00202b5a3d106a6d0dc894ad1fcbb993b6d811eb6077dc6684172`;
- complete laptop-2 August stream SHA-256:
  `0ebd1a538a775963bc84df0ca4b8388c2a3b134b82bfa593dfce6443d49278c4`;
- pre-final-checkpoint validation: valid, 930 checked objects, 207 Cases, and
  258 events;
- post-acceptance-checkpoint validation: valid, 931 checked objects, 207 Cases,
  and 259 events;
- final post-hardening validation: valid, 932 checked objects, 207 Cases, and
  260 events;
- policy acceptance: 21 exact targets and zero drift.

Release validation evidence:

- fast tier: 97 framework unit tests, 37 PPT-skill tests, and 6 workflow-skill
  tests passed; one PPT test was skipped;
- pilot tier: 5/5 passed;
- full framework tier: 142/143 passed; both skill suites passed with the same
  single skip;
- the sole full-tier failure is an unrelated existing source-evidence drift:
  `qed_cone_pair/lbw_v4/20260731_lbw_baseline_v2` runner metadata records
  SHA-256 `130ac9f2f6174eb8b8391dac7faf01c174cb6a440140cc63271af52ef2f92169`,
  while the current source is
  `f89ffc181cecfb23a5d5dd800ab74cdc28f9cbf19c7b94ded0748445f78d6492`.
  This release neither infers the cause nor rewrites that out-of-pilot Case.

The single root-owned acceptance checkpoint is
`20260823T091132Z-laptop-2-v021-acceptance-b12f89db`. It adds no Case change or
scientific status and records this structural release once at the control root.
The follow-up root-owned hardening checkpoint
`20260823T092017Z-laptop-2-v021-hierarchy-hardening-ff03db3c` records the atomic
new Project/Study/first-Case bootstrap and the deliberately deferred
existing-authority knowledge-link writer seam; it likewise changes no Case or
scientific status.

## Post-acceptance benchmark_lbw migration

The 2026-08-23 extended feasibility run migrated every legacy Case under
`benchmark_lbw` without changing Case identity, scientific content, status, or
existing Event bytes.

- migration plan digest:
  `6dcf1dd16454f15be4d103d6bf8e8bc9fa74faaeff57150bcfd18a9f93fa199a`;
- fixed migration time: `2026-08-23T09:30:00Z` on `laptop-2`;
- scope: 6 Studies, 135 Cases, 270 bound legacy authority files;
- result: 6 monthly journals, 135 `migrate` records, and 135 legacy bindings;
- old authority: 190,334 logical bytes and 1,118,208 allocated bytes;
- journal authority: 249,288 logical bytes and 266,240 allocated bytes;
- allocated storage reduction: approximately 76.2%; the larger logical payload
  is the explicit migration provenance and raw-byte binding;
- every old Case and Study directory plus `metadata/cases/benchmark_lbw` is
  absent after verified empty-directory removal;
- all 135 materialized views are active and equal to their migration-bound
  legacy views;
- all 135 compact contexts fit the 4,096-byte limit: 1,782-byte minimum,
  4,029-byte maximum, 9.584 seconds total, and 70.993 ms per Case mean;
- all four pre-existing monthly Event streams and all 32 benchmark-owned Case
  Events remained byte-identical before the root checkpoint;
- Store validation after migration: valid, 932 checked objects, 207 Cases, and
  260 Events.

The run exposed one disposable-index defect: incremental journal catch-up saw
stale cached legacy rows after their authority files were migrated. An explicit
cache rebuild recovered immediately. The index refresh now removes legacy rows
that are absent from current portable authority before checking real
journal/legacy collisions; 13 focused index and journal tests pass.

The root-owned structural checkpoint is
`20260823T094314Z-laptop-2-benchmark-lbw-migration-6f54d66f`. It records no
Case change beyond the migration records and makes no scientific status claim.
Final post-checkpoint validation is valid with 933 checked objects, 207 Cases,
and 261 Events. The pre-existing 80,530-byte laptop-2 August stream remains an
exact prefix with SHA-256
`d061c26f4c5ce050d802c9c82b43182582e5a1573307357baf978fbb5bad3491`;
the single appended root event produces current stream SHA-256
`07c7a248a0f5679aab287822f097632e26df8428234a79a7d8547ee05c8ec14f`.

## 0.2.2 journal-only cutover

The 2026-08-23 final cutover removed the remaining mutable schema-1 Case
runtime and portable per-Case authority while preserving every scientific
field, identity, lifecycle state, and pre-existing Event byte.

- package version: `0.2.2`; public CLI: 23 versionless leaves;
- active migration plan:
  `ea93fead27a63f53d688954bf1117d11b88eff073d3a5c67492346a72dbb280a`;
- active migration time: `2026-08-23T18:49:00Z` on `laptop-2`;
- tombstone migration plan:
  `10b31dc5465683c1d49f53e371da888df33bf2027b17a4c538703605f52c56f1`;
- tombstone migration time: `2026-08-23T18:50:00Z` on `laptop-2`;
- cutover scope: 61 active pairs, 8 deletion receipts, and 130 exact legacy
  authority files across 8 Study journals;
- result: 207 active `migrate` heads, 8 `migrate-tombstone` deleted heads,
  215 journal records, and no `metadata/cases` tree;
- active materialization parity: 61/61; tombstones retain exact receipt
  canonical/raw bindings without constructing fake Case content;
- old remaining authority: 243,718 logical bytes and 626,688 allocated bytes;
- new 8-journal authority: 275,424 logical bytes and 294,912 allocated bytes;
- allocated storage reduction: approximately 52.9%; logical bytes increased
  approximately 13.0% because migration provenance is explicit;
- pre-checkpoint validation: valid, 933 checked objects, 207 active Cases,
  8 deletions, 261 Events, 10 deleted-Case Events, and zero unresolved orphan
  Case Events;
- representative compact context: one active Case from each of 15 Studies,
  2,129-byte minimum and 4,029-byte maximum under the 4,096-byte limit;
- direct active Case Event coverage: 92/207; evidence-backed `run`, `data`, and
  `analysis` status coverage: 0/207 for each track;
- sequential multi-device acceptance covers synchronized A-to-B revision,
  independent Cases, stale-head refusal, device ownership, journal-byte
  binding, and fail-closed sibling forks; no automatic Git/network sync or
  concurrent merge is claimed;
- final fast tier: 73 framework unit tests, 37 PPT-skill tests, and 6 workflow
  skill tests passed; one PPT test was skipped;
- policy proposal digest:
  `16ab76efd7b910b9a21f7614085a8353520c418cd1f1139275ea5842a8459721`;
- policy apply plan digest:
  `cd24f2cd2231622d2bfd42647ed760b4b05003cb78b7c51f664c47952acb746c`;
- policy acceptance: 21 exact targets, including separately approved Notes
  and Data managed blocks, with zero drift.

The four Event streams remained exact before the final root checkpoint:

- `laptop-1/2026-07.jsonl`: 84,426 bytes,
  `ef4dcbf4f1ecd8719aab14086cf467e9d7593193c8c4fca2e5431282e5e23d22`;
- `laptop-1/2026-08.jsonl`: 87,039 bytes,
  `f18ad4068c69ade1d9f89db68274fae63078892d1eaab77c9eae6cde516110ce`;
- `laptop-2/2026-07.jsonl`: 26,504 bytes,
  `a98994514924021c78ea79851051f462eda3842431d72125088888375649758d`;
- `laptop-2/2026-08.jsonl`: 82,322 bytes,
  `07c7a248a0f5679aab287822f097632e26df8428234a79a7d8547ee05c8ec14f`.

The documented pre-reset tar remains unavailable and is `to-confirm`. The
approved repository recovery fixture remains historical evidence, not a live
schema-1 reader. Structural acceptance does not establish simulation, data,
analysis, or scientific status.

## 0.2.3 accepted local upgrade and deployment boundaries

Research Workflow 0.2.3 is accepted on `laptop-2` as of 2026-09-20 UTC.
Implementation stages and independent reviews are complete. The user approved
the exact policy and body plans; protected deployment and the final independent
release gate passed. The full release run reports 200 tests: 199 passed and one
pre-existing utility skip. Detailed measurements and the consolidated change
inventory appear in the final acceptance section below.

This section retains the selected upgrade contract and measured stage handoffs;
statements marked as pre-upgrade or pre-approval are historical measurements,
not current pending local work. `SCHEMA.md`, policy JSON and scientific metadata
remain their respective authorities. The earlier release baseline prefix is
unchanged. Record one framework-root completion event after these documents
are final, not one event per stage or a scientific Case registration.

Git publication remains **unpublished**: `update_0.2.3` is the user-selected
branch, no publication command was run, and no release commit was generated.
Actual laptop-1 deployment and its later return-policy verification remain
unperformed; independent two-workspace tests do not establish remote deployment.

### Purpose and selected daily workflow

The accepted purpose is:

> 让科研工作自然地留下可信记忆。这些记忆主要供 agent 使用，使 agent 能跟上科研进展、理解正在开展的工作，并逐步支持对科研项目具体细节和进展的讨论，同时减少登记、确认和查询对科研本身的打扰。

Git carries shared research memory and framework versions; each device's own
TOML resolves local paths. Changing device must not require rebuilding the
research memory. New tasks and subagents are not new devices. The existing
device identities are `laptop-2` locally and `laptop-1` on the other device.

| Situation | Required 0.2.3 behavior |
| --- | --- |
| Parameter lookup, read-only check, ordinary Q&A | No journal and no event. |
| Post-processing, theory, scripts, or validation with a durable result | One evidence-backed work event; no required Case edit. |
| First registration or a change to the simulation definition | Finish the files and checks, show the proposed registration difference, genuinely ask the user, and wait for their answer before appending the Case journal. |
| Work completed before Case registration is accepted | Record the exact registered root/directory owner now; relate that history after explicit registration. |
| Work without Project/Study membership | Use the registered root and exact working directory; create no empty research hierarchy. |
| Case progress query | Show work events, time, evidence, and corrections; do not default to three `unknown` status tracks. |
| Device switch | Synchronize and check shared memory before restoring context or preparing any write, including event-only work; use the local identity and paths. |

Simulation definition includes `input.deck` and other inputs that actually
affect physical or numerical settings. Ordinary research discussion is not
logged turn by turn; an accepted research decision or reusable result can
produce one event. There is no cross-task pending-confirmation list, background
reminder, automatic registration, or general registration of the Matlab parent.
All historical journal/event bytes remain intact; no bulk cleanup or
normalization is part of this upgrade.

### Recording and confirmation contract

1. `checkpoint` defaults to supporting event-only work. Its target determines
   ownership and never implicitly requests a Case change. Case, Study, and
   ordinary root/path owners can each record independently. A Case mutation
   starts only from an explicit simulation-definition or other named Case
   operation, not from a broad blacklist of content field names.
2. Explicit Case requests distinguish registration, input change, metadata
   correction, and lifecycle operation. Preserve the meaning of each rather
   than treating all content as proof of a physical change. If a completed-work
   event already exists, later registration writes only the journal and does
   not duplicate that result event.
3. Every supported Case writer goes through one preview/apply gate: create,
   revise, checkpoint requests containing Case changes, rename, and delete.
   Add `case apply --plan DIGEST --write`; close old direct-write bypasses.
   Old mutation commands must provide a clear migration path or refuse writes;
   historical format compatibility does not permit old writers to bypass the
   new confirmation workflow.
4. The saved local preview binds the exact proposed content, current Case head,
   relevant Project/Study/profile dependencies, explicitly selected inputs,
   current device, and relevant local path mappings. The agent must actually
   ask and await user confirmation. A CLI digest proves content equality; it
   cannot prove that the user agreed. Preview preparation is not registration.
5. The accepted simulation definition and profile references being unchanged
   produces no revision. Changes to input bytes or dependencies invalidate an
   old preview. A fresh preview of a still-unchanged definition remains a no-op.
   Reapplying a successfully completed plan does not duplicate journals or
   events. Partial application, competing heads, changed planned bytes, and
   conflicts stop and report; they do not silently resume or choose a winner.
6. Input checking is limited to explicitly named configuration text, generated
   parameters, or input manifests. It never expands dependency trees, scans
   raw Data/large particle files, or runs a research program. Input digests
   live in the local confirmation plan and are not automatically injected into
   portable Case content. Precisely document the implemented selection API.
7. Every write entry point, including independent `event record`, checks the
   configured and registered current device. Each device appends only to its
   own streams. Preserve Case head checks, fail-closed forks, event-ID conflict
   checks, original owners, and historical correction/lineage evidence.

### Agent-facing memory and query contract

Keep the existing event schema. Use `summary` and evidence `observation` as
needed to retain the work's purpose, actual result, accepted important decisions
and reasons, validation level, and relevant limits or unresolved questions.
These are guidance, not a long mandatory form, and missing facts are never
invented. Stable background remains in Project/Study/profile content; exact
formulae, code, and parameters remain in linked evidence read on demand.
Distinguish structural checks, numerical checks, and physical judgment. User
acceptance of a setting does not establish its physical correctness.

| Interface | Required behavior |
| --- | --- |
| `context TARGET` | Case, Study, Project aggregation, and root/path memory. |
| `event list [TARGET]` | Time, count, and text filters; default 20, maximum 100; explicit truncation. |
| `event show` | Full selected event, evidence, and correction relationships. |
| `--recursive` | Explicit root/path subtree selection; otherwise exact owner match. |
| `--include status` | Optional legacy status projection; absent by default. |

Local target resolution uses explicit logical locators, longest registered
root, and existing explicit mappings. Similar names do not establish pairing.
Index owner identity includes the entire root-relative owner path. Logical
memory queries do not require local research directories or even a local
registration for the queried portable root. A device without Theory can read
`root:matlab_theory/...` history and must see that the local mapping is
unavailable. Local scientific file access, input verification, and new local
root events require a valid device-local registration and access scope.

Relate pre-registration events through exact directory ownership and explicit
mappings only. Prefer the stable Simulation logical directory when canonical
Case identity is already known. Keep the stored owner unchanged, deduplicate by
event ID, and follow rename lineage. Parent background must not appear as
Case-owned progress. Corrections must be visible so superseded assertions are
not represented as current facts. Cross-device sorting is deterministic but
neither clocks nor mtimes establish causal order.

Compact context retains recent work clues, event IDs, omitted counts, and a
follow-up query even when Case content is large. Existing compact/deep budgets
are 4096/24576 bytes; keep them unless an explicit documented implementation
need changes the contract. Budget exhaustion is reported and never returns a
plausibly complete empty progress list after silently dropping every event.

### Portable and local boundaries

| Synchronized through the repository | Maintained separately on each device |
| --- | --- |
| Source, tests, templates, skill source | Runtime `workspace.toml` |
| Portable metadata and device-owned Case/event streams | SQLite, saved confirmation plans, transaction temporary state |
| Policy, example configuration, maintenance/upgrade documentation | Skill installation location and symlink |
| Repository-owned instructions | Every external `AGENTS.md` |

`workspace.example.toml` is the shared example; `.gitignore` excludes
`workspace.toml` and `.research-workflow/`. There are no per-device TOML template
copies to introduce. Retain the other device's runtime file and update fields
against the example. Identical logical roots use identical root IDs and each
device's independently verified absolute paths. SQLite is rebuilt locally when
its format changes and never copied through Git. Local plans cannot be moved
to another device and applied there.

Upgrade devices one at a time. Old versions stop writing Research Workflow
metadata until that device passes 0.2.3 acceptance; computing, plotting, and
job submission are unaffected. A device may resume metadata recording after
its own acceptance. Remote synchronization and cessation of old writers are
operational facts the CLI cannot independently prove. Do not imply otherwise
in command output, documentation, or final reporting.

### Theory registration scope

Add only `matlab_theory`, at
`/mnt/d/document/MATLAB/Matlab/Theory`, kind `analysis`, mapping `none`, to this
device's registry and the appropriate example documentation. The two owners are
`root:matlab_theory/epoch_initial_distribution` and
`root:matlab_theory/tr_vortex_beam`. Both exact directories were observed during
stage 1. This observation is not source, numerical, or physical acceptance.
Stage 3 must inspect the implementation before describing its purpose,
including the current generator's demonstrated photon-distribution capability.
Do not broaden those descriptions beyond inspected code, invent past events,
create empty Project/Study/Case records, register the entire Matlab parent, or
add a redundant Theory `AGENTS.md`. The existing Matlab root instructions cover
Theory. The other device registers a real equivalent path only if it exists;
otherwise it creates nothing and retains logical read access to the memory.

### Exact local instruction coverage and permissions

This table is the initial `laptop-2` registry, not a portable allowlist for the
other device. `M` means preview the managed-block change. `B` means also prepare
an explicit framework-related body diff while retaining other research rules.
Data/Notes are managed-block-only; their unmanaged bytes remain untouched.

| No. | Exact local target | Role / planned scope |
| --- | --- | --- |
| 1 | `/home/yuhanjin/AGENTS.md` | control; M+B: all-owner context and recording split |
| 2 | `/home/yuhanjin/Research_Workflow/AGENTS.md` | control; M+B: query, confirmation, progress, and workflow contract |
| 3 | `/home/yuhanjin/Simulation/AGENTS.md` | simulation; M+B: event-only results and explicit definition confirmation |
| 4 | `/home/yuhanjin/Simulation/qed_cone_pair/AGENTS.md` | simulation; M+B: remove raw delta/current-spec lookup and forced metadata edits |
| 5 | `/home/yuhanjin/dot_files/AGENTS.md` | configuration; M+B: root context and transparent derived-cache use |
| 6 | `/home/yuhanjin/scripts/AGENTS.md` | scripts; M+B: root context and transparent derived-cache use |
| 7 | `/home/yuhanjin/scripts/backup/archlinux/AGENTS.md` | scripts; M, retain body |
| 8 | `/home/yuhanjin/scripts/build_containers/AGENTS.md` | scripts; M, retain body |
| 9 | `/home/yuhanjin/scripts/build_containers/pic/AGENTS.md` | scripts; M, retain body |
| 10 | `/home/yuhanjin/scripts/build_containers/post_process/AGENTS.md` | scripts; M, retain body |
| 11 | `/home/yuhanjin/scripts/clean/AGENTS.md` | scripts; M, retain body |
| 12 | `/home/yuhanjin/scripts/process/AGENTS.md` | scripts; M, retain body |
| 13 | `/home/yuhanjin/scripts/run/AGENTS.md` | scripts; M, retain body |
| 14 | `/home/yuhanjin/scripts/sync/AGENTS.md` | scripts; M, retain body |
| 15 | `/home/yuhanjin/scripts/transfer/AGENTS.md` | scripts; M, retain body |
| 16 | `/home/yuhanjin/scripts/update/AGENTS.md` | scripts; M, retain body |
| 17 | `/mnt/c/Users/17865/Desktop/Laser Plasma/Notes/AGENTS.md` | notes; M only, separate exact approval |
| 18 | `/mnt/d/document/MATLAB/Matlab/AGENTS.md` | analysis; M+B: Theory routing and event-only work |
| 19 | `/mnt/d/document/MATLAB/Data/Simulation/AGENTS.md` | data; M only, separate exact approval |
| 20 | `/home/yuhanjin/Source_Code/AGENTS.md` | source; M, retain body |
| 21 | `/home/yuhanjin/Code_Program/AGENTS.md` | build-artifact; M, retain body |
| Extra | `/mnt/b/software/Codex/Data/AGENTS.md` | actual global entry; inspect/update framework routing body without inventing a managed target |
| Extra | `/mnt/b/software/Codex/Data/skills/research-workflow` | verified symlink to this repository's skill; update source and check installation |

The actual `CODEX_HOME` is `/mnt/b/software/Codex/Data`; neither the global
instruction nor skill entry exists under `/home/yuhanjin/.codex`. No
`AGENTS.override.md` was found along the enumerated target ancestor paths.
The active config explicitly sets neither `project_doc_max_bytes` nor
`project_doc_fallback_filenames`. The local manifest preserves selected
ancestor candidates, `.git` root-marker observations, per-file bytes, and
absence checks. Its largest conservative all-ancestor chain is 25,872 bytes
for `scripts/build_containers/pic`. That inventory is not yet verification of
the host's actual loaded chain or default limit: stage 4 must establish actual
root discovery, override/fallback selection, and total loaded bytes, then
repeat after edits. Do not certify files individually and ignore the chain.

At capture, active rule `framework-v0-2-2-journal-only`, revision 2, has 21
approved absolute paths, but they are not the registry's same 21 paths. It lacks
`/mnt/d/document/MATLAB/Data/Simulation/AGENTS.md` and includes the other device's
`/mnt/c/Users/jinyuhan/Desktop/Laser Plasma/Notes/AGENTS.md`. This is a pre-existing
approval-scope discrepancy, not a new regression. Preserve all already approved
paths during reauthorization and explicitly address the missing local approval.
A successful `policy check` is distinct from authorization for a specific
`policy apply`; approval metadata changes alone must not force rewriting an
already correct managed block.

All external instruction targets are outside this task's writable repository
root and may require filesystem escalation. The accepted implementation scope
does not manufacture an as-yet-unseen policy digest authorization. First prepare
reviewable exact targets, body differences, managed-block plan, and digest;
then satisfy the existing protected approval process. Never reuse another
device's paths as local approval. Do not ask again for ordinary implementation
choices already settled by this contract. Git publication and actual remote
device execution remain separate, unperformed operations.

### Initial evidence and preserved local comparison material

The following are upgrade-before measurements, not 0.2.3 acceptance:

- Runtime/package sources report `0.2.2` in `pyproject.toml` and
  `src/research_workflow/__init__.py`. The user names delivery branch
  `update_0.2.3`; this stage ran no Git command and verified no release ref,
  commit, remote synchronization, or publication.
- Historical stream inventory: 28 Case journals, 323 lines, 793,152 bytes;
  6 event streams, 363 lines, 463,824 bytes. Every stream's exact length and
  SHA-256 is retained, including device ownership and newline termination.
- Independent pre-upgrade reviewer: `tests/run_fast.py` exits 0; 116 tests
  total (73 framework unit, 37 `edit-research-ppt` with one skip, 6 workflow
  skill). `doctor`, `validate`, and `event merge` all exit 0. Validation reports
  1,301 checked objects, 292 Cases, 8 deletions, 363 events, 2 devices,
  0 unresolved orphan events, and no diagnostics. Ten deleted-Case events and
  one migrated-orphan event are existing historical classifications.
- Independent pre-upgrade source-evidence check:
  `tests.integration.test_materialization._MaterializationTests.test_input_and_runner_digests_match_current_sources`
  fails at line 62 with `KeyError('reproducibility')`, beginning with
  `benchmark_lbw/.../20260909_mono_beams_1d_0p515_mev`. There are 65 Cases without
  `reproducibility` and 16 runner digest differences, all under
  `qed_cone_pair/lbw_v4`; the checked explicit input locators have no digest
  differences and their source files are present. Preserve historical metadata
  and source bytes. These are existing live-source validation limitations;
  "no new failures" must not be reported as "all full tests passed". Release-tier
  acceptance remains pending.
- Full skill inspection found that `context_smoke` selects from removed
  `STORE.json.cases`; a valid thin Store therefore skips it. Fix that omission
  and test that ordinary checks remain distinct from explicit `--full` checks.
- Existing index format is version 4. Rebuild derived state on an implemented
  format change; do not migrate or copy SQLite as authority.

Local derived handoff files are intentionally excluded from Git:

- `.research-workflow/upgrade-0.2.3/pre-upgrade.json`: exact history and
  portable JSON digests; 21-target/body identities; instruction-chain
  candidates; installation/config observations; all snapshot path mappings.
  Initial SHA-256:
  `8881e5c06d1930999911368fda5db7e656f0c987c37fb3f0055ee783d1180329`.
- `.research-workflow/upgrade-0.2.3/pre-upgrade-files.zip`: 126 initial
  source, tests, templates, policy, documentation, local workspace, and exact
  external instruction snapshots for local diff without Git. Size 247,352;
  SHA-256
  `58d25c76d5a53e1fa76dd25f4d7124b75eda52e6b82c0f43eab1a3c4d4d84608`.
  It contains no raw scientific data or copies of journal/event payloads.
  This local comparison archive is not the missing historical recovery tar.

For history preservation after implementation, verify each saved stream still
exists and its first saved byte count hashes to the saved SHA-256. Before the
single final upgrade checkpoint, require complete equality unless an explicitly
authorized new record has actually been added. Compare scientific authority
JSON to its saved digest; explain every intentional portable change. Never
truncate a stream to make a test pass.

### Sequential implementation and independent review

The main task first requests and waits for an independent GPT-6 Astra/xhigh
task. If that task-creation capability is unavailable, use the user-approved
fresh subagent of the same model. Each later implementation stage uses a fresh
agent with this durable contract and its immediate handoff. The host's automatic
context compression cannot be guaranteed off. Keep the complete selected
decisions here, pass concise results to the main task, and avoid raw review-log
accumulation there. Implementer and reviewer are separate; reviewers are
read-only. Exactly one implementer at a time writes shared metadata, policy,
or stage handoff records.

| Stage | Work and likely source surfaces | Review and acceptance status |
| --- | --- | --- |
| 1. Contract | Selected contract, initial snapshots, target coverage, two-device design | Independently reviewed: 21 targets match; 126 snapshot entries pass CRC/SHA; original 13,463 baseline bytes preserved; 34 streams and 38 authority JSON files unchanged. |
| 2. Recording | `services/checkpoint.py`, shared confirmation plans/owner/device gates, CLI, journal/store writes | Implemented in isolated fixtures: 72 affected tests pass; fast tier 74 + 37 (1 skip) + 6 pass. Independent frozen review passed with no remaining P1/P2; 24 independently run tests and history-byte comparison passed. See stage-2 handoff below. |
| 3. Queries and memory | `services/context.py`, `services/queries.py`, `index/query.py`, event queries, local Theory/example config | Implemented in isolated fixtures: 77 affected tests pass; final fast tier 86 + 37 (1 skip) + 6 pass. Frozen independent review passed with no remaining P1/P2; 77 independently run tests and history-byte comparison passed. See stage-3 handoff below. |
| 4. Entrypoints and replay | Policy engine and authority, all covered instructions, skill source/install checks, templates, version sources, README, architecture, schema, changelog, cross-device/skill guides, generated backlog | Accepted: affected 46 and fast 86 + 37 (1 skip) + 7 pass, full installed skill check passes; frozen independent review has no remaining P1/P2. User-approved policy and body deployment completed; 21 managed targets have zero drift and every planned final body hash matches. |
| 5. Local release acceptance | Affected modules, fast tier, full release tier, independent two-workspace fixtures, history comparison, installation and instruction-chain checks | Accepted by final independent review with no remaining P1/P2: run_all exits 0, 156 + 37 (one existing skip) + 7 tests; doctor/validate/event merge/policy/full skill pass, history and final instruction bytes verified. |
| 6. Other-device deployment | Published ref acquisition, local TOML/skill/instruction adaptation, real acceptance, authorized return of policy approvals and local result evidence | Pending: cannot be replaced with local simulation. |

Keep `EVOLUTION_BACKLOG.md` generated from proposal authority. Preserve version
history rather than replacing earlier release records. Normal implementation
uses affected modules and the fast suite; only the release gate runs the full
suite. The existing public test entrypoints are:

```text
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:. python3 -B -m unittest -q <affected modules>
python3 -B tests/run_fast.py
python3 -B tests/run_pilot.py
python3 -B tests/run_all.py
python3 -B tools/researchctl.py doctor --json
python3 -B tools/researchctl.py event merge --json
python3 -B tools/researchctl.py validate --json
python3 -B tools/researchctl.py policy check --json
python3 -B skills/research-workflow/scripts/check_installation.py --codex-home /mnt/b/software/Codex/Data --full --json
```

The installation path above is local acceptance only; the other device supplies
its own actual Codex home. `doctor` must report the running framework version.
After local upgrade completion, record one framework-root completion checkpoint
with evidence and remaining limitations. Do not record stages separately or
copy that event to the second device. A second-device event is appropriate only
after a real independent deployment or validation result.

### Required acceptance matrix

The implemented behavioral rows below passed the stage-2/3/4 fixtures and final
independent local release gate. Instruction checks passed on laptop-2 and in
isolated two-device replay; real laptop-1 deployment remains pending. Test
fixtures are isolated metadata, not live scientific authority. The last row
requires separate actual publication and remote acceptance, still unperformed.

| Area | Evidence required |
| --- | --- |
| Recording responsibility | Post-processing writes only an event; reads write neither stream; unconfirmed registration creates no Case; unchanged accepted definition/profile references create no revision. |
| Confirmation and concurrency | Every public Case writer is gated; input, head, Project/Study/profile dependency, device, and mapping changes invalidate old plans; exact successful retry adds nothing; partial application and conflicts stop. |
| Query ownership | The two Theory directory owners stay separate; default root matching is exact; recursion is explicit; exact pre-registration and explicit paired-root events associate correctly; parent/similar-name/shared-function work does not leak into a Case. |
| Research memory | A fresh agent can recover purpose, accepted decisions/reasons, verification results, and unresolved issues through query and exact evidence; large Case content cannot silently erase all recent progress. |
| History and corrections | Every historical journal/event prefix remains byte-identical and readable; corrections and rename lineage remain visible; obsolete assertions are not presented as current facts. |
| Two independent workspaces | Distinct absolute paths, device IDs, Store instances, workspace TOMLs, plans, and SQLite files; copy only portable files; verify query/result consistency and each device's own append behavior. Existing shared-Store tests alone are insufficient. |
| Missing local Theory | Device B has no Theory mapping/directory yet validates and queries synchronized Theory memory; scientific-file access, input validation, and a new local Theory event correctly refuse. |
| Device isolation and conflicts | Refuse transplanted plans, cross-device stream writes, stale synchronized heads, forks, and conflicting event IDs; exclude SQLite from the exchanged fixture set. |
| Instructions and approvals | Each device checks its own exact targets and installed skill; preserve the other's prior approval range; update managed blocks and required framework body rules; measure actual inherited instruction bytes. |
| Real deployment | Report local implementation acceptance, actual Git publication, actual second-device acceptance, and return-policy check separately; local isolated fixtures do not prove remote deployment. |

### Other-device replay and final delivery obligations

`GIT_PRIVATE_REMOTE.md` must deliver an executable upgrade procedure based on
the actual released ref, commit, version, and acceptance results. Do not default
to `origin/main`: the selected delivery branch is `update_0.2.3`. No Git release
was performed by this stage; until publication is actually completed, state
**unpublished** and give the exact remaining publication steps. Never invent a
commit, private-remote verification, or synchronized state.

The final procedure must cover these steps in order:

1. Finish and independently accept the first device; record actual branch/ref,
   commit when available, running version, and evidence. Separately identify any
   unpublished local changes and the authorized publication procedure.
2. On the second device stop old metadata writers, preserve existing local
   work, and explicitly handle unpublished changes. Fetch the actual
   published source and prefer `git merge --ff-only <published-ref>`. If
   divergent, keep all content and enter a separate integration process; never
   reset, overwrite, auto-resolve journals, or discard history.
3. Keep the second device's `workspace.toml`; compare with the new example,
   verify real roots, existing `laptop-1` identity, and exact local policy
   targets. Do not copy the first device's TOML or re-onboard an existing device.
4. Register Theory only if a real directory with the same purpose exists there.
   Otherwise leave the local mapping absent and prove logical event reads.
5. Verify actual local Codex home and the skill link; preview installation
   changes if needed. Provide replayable role-specific external AGENTS body
   changes and a local allowlist/digest plan for managed blocks. Retain other
   research rules and Data/Notes body boundaries. The portable approval record
   must accumulate the exact authorized ranges, never replace device A's
   approved paths with device B's paths.
6. Prove runtime version using `doctor`; run `event merge`, structure validation,
   `policy check`, and explicit full skill check. Query one Case and one non-Case
   owner, and verify the missing-Theory logical read case. Restart agent tasks
   that should use the upgraded instructions, then resume metadata writes only
   on that accepted device.
7. Return the independently produced portable policy authorization record only
   through the authorized sync procedure; run policy checks again on the first
   device. If approval information alone changed and checks pass, do not rewrite
   correct managed blocks again. Record second-device results only when real.

Final delivery must contain the implemented architecture, daily flow, and
agent-memory behavior; complete repository and external-instruction change
list; CLI changes/old-command migration/history compatibility; actual Theory
registration; tests, independent reviews, history evidence, two-workspace
fixtures and real-device evidence; executable second-device commands with actual
publication source, local configuration handling, instruction replay, skill
checks, and acceptance criteria. State the separate local implementation,
publication, and second-device deployment statuses, plus every unfinished or
untested item. A list of first-device changed files is not an upgrade procedure.


### Stage-2 measured recording handoff (2026-09-20 UTC)

The recording implementation passed frozen independent review with no remaining
P1/P2 findings; 24 independently run tests and history-byte comparisons passed.
This is not the 0.2.3 release or device acceptance. Package version, normative schema,
policy, skills, and external instructions remain for stage 4. No live Case,
event, authority JSON, policy, scientific file, or external instruction was
changed in stage 2. Direct SHA-256/byte-count comparison against the stage-1
manifest confirms exact equality of all 34 history streams and 38 portable JSON
files. There was no Git, network, simulation, MATLAB, or checkpoint operation.

The final write boundary uses `services/plans.py` for saved local plans and
success receipts, `services/case_changes.py` for explicit Case operations,
`services/checkpoint.py` for result events, and `services/owners.py` for local
write-owner resolution. `storage/devices.py` centralizes device membership;
`storage/locking.py` serializes supported CLI writers with a local per-authority
thread/process lock. Storage primitives remain internal implementation/test
surfaces; the sole supported CLI exposes the confirmation gate.

Public interfaces for stage-4 documentation:

- `checkpoint TARGET --request-json ... --write` defaults to event-only work.
  TARGET supplies only the event owner. Requests retain schema version 1 and
  exactly one event; `changes` defaults to `[]`. Positional Case targets need
  no `if_match`. Top-level patch/if-match/profile shorthand is rejected; explicit
  changes must each name their target, current `if_match`,
  `responsibility: "simulation-definition"`, and `reason: "input-change"` or
  `"metadata-correction"`, plus the existing patch/removal/profile fields.
  `input_configs` is an optional string array on each explicit change.
- `case create`, `case revise`, `case rename`, and `case delete` prepare saved
  previews only. Every old direct `--write` returns a migration message.
  `case revise` now requires `--reason input-change|metadata-correction`;
  rename/delete require the current source head through `--expect-digest`.
  Create and lifecycle operations have fixed `registration`/`lifecycle` reasons.
  All Case operations have simulation-definition responsibility; ordinary work
  metadata belongs in events. Explicit human confirmation remains an agent
  instruction, never something a digest can prove.
- `case apply --plan DIGEST --write` applies the exact saved preview.
  `checkpoint --apply-plan DIGEST --write` remains a replay alias. Replay cannot
  mix TARGET, request JSON, or stdin; the old hidden `--expect-digest` cannot
  silently ignore supplied request content. Case commands create no event, so
  later accepted registration/revision does not duplicate earlier result work.
- Repeated `--input-config` on create/revise, or per-change `input_configs`,
  selects exact absolute local files or `root:`/`case:` file locators. Selection
  declares configuration text, generated parameters, or an input manifest.
  Read only those files, incrementally decode UTF-8/NUL-check and hash in 64 KiB
  chunks, and check pre/post stat stability. There is no size cutoff, include
  expansion, research execution, or name-based configuration inference. Data,
  Notes, unregistered/outside paths, symlinks, and binary text violations refuse.
  Input checksums stay only in ignored local plans, never injected into Case
  content. Other text that was not explicitly selected is not read.

Plans bind proposed records/documents, source heads (including no-ops), relevant
old/new Project/Study/profile dependencies, Store/device membership, selected
inputs, and every actual local target root/alias used before canonicalization.
They also bind the local workspace/metadata paths and device, so transplanting
one into another workspace refuses. Head validation precedes equality checks;
unchanged accepted content and profile references produce no revision.
Lifecycle actions always append their actual lifecycle record.

Apply retains the preview and its success receipt. Exact successful replays
return `already-applied`. Existing planned records/events without a receipt,
conflicting IDs, stale heads/dependencies, and partial bootstrap authority refuse.
A receipt is committed last, after portable writes, fsync, and post-validation,
inside the same rollback boundary. Bootstrap replay validates required owner
files and current Store structure without requiring all later valid registry
bytes to equal the old snapshot. This is fail-closed partial detection, not a
claim of arbitrary crash-atomic multi-file storage. Supported local writers
share one lock from state reads through receipt/rollback; independent fixture
processes proved Case apply and event record preserve both events.

Case journal reduction now follows explicit `previous_digest` ancestry.
Timestamp/record-ID ordering only breaks ties between independent records;
same-second or reverse-clock valid chains work. Missing parents, cycles,
identity reuse, and actual sibling forks still refuse. Historical migrate and
migrate-tombstone readers remain intact. Rename lineage read APIs are unchanged.

Stage-3 owner/query handoff:

- `resolve_owner` is intentionally a **local new-write** resolver. Do not reuse
  its registration/existence checks to restrict portable read-only selectors.
- A `mapping=none` path preserves `root:<original-root-id>/<exact-relative-path>`;
  Theory therefore stays in its own registered root. Only explicitly canonical
  or same-relative mapped targets with a known canonical identity use
  `root:simulation/<canonical-simulation-relative-directory>` before Case
  registration. Existing active Cases own their events. Renamed/deleted Cases
  refuse new events rather than falling back to root ownership.
- The portable Event schema, correction semantics, and lineage lookup API are
  unchanged. Full query aggregation, portable unknown-local-root reads,
  pre-registration association, Theory registration, and compact progress remain
  stage-3 work. No inference from ordinary directory names was added.

Measured validation commands and scope:

```text
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:. python3 -B -m unittest -q tests.integration.test_confirmation_plans tests.integration.test_checkpoint tests.integration.test_multi_device_checkpoint tests.integration.test_case_inline_revise tests.integration.test_journal_lifecycle tests.integration.test_policy_propagation tests.integration.test_tombstone_migration tests.unit.test_case_journals tests.unit.test_storage tests.unit.test_cli tests.unit.test_cli_handlers
python3 -B tests/run_fast.py
```

The first command passes 72 isolated affected tests, including 14 new
confirmation tests. The fast runner passes 74 framework unit tests, 37 utility
skill tests (one existing skip), and six workflow skill tests. Tests retain old
semantic assertions while using real preview/apply calls for accepted writes.
New coverage includes every old CLI bypass; Case event-only work; pre-registration
work followed by journal-only acceptance; no-op/head/profile/input gates; inputs
larger than 1 MiB; device/workspace/mapping changes; partial apply; exact retry;
bootstrap concurrency; final receipt ordering; and independent writer processes.
No release `run_all.py` or pilot was run. A broad integration-discovery attempt
was interrupted rather than treated as acceptance; its live safety modules are
outside this isolated stage's validation scope. Generated edit scripts were
removed with the required cleanup marker; no bytecode or transaction temporary
files remain under source/tests.


Stage-2 changed repository paths (relative to this control root):

```text
FRAMEWORK_BASELINE.md
src/research_workflow/cli/handlers.py
src/research_workflow/cli/parser.py
src/research_workflow/domain/case_records.py
src/research_workflow/services/__init__.py
src/research_workflow/services/checkpoint.py
src/research_workflow/services/case_changes.py
src/research_workflow/services/owners.py
src/research_workflow/services/plans.py
src/research_workflow/storage/case_journals.py
src/research_workflow/storage/devices.py
src/research_workflow/storage/jsonio.py
src/research_workflow/storage/locking.py
src/research_workflow/storage/store.py
src/research_workflow/storage/streams.py
tests/integration/confirmation_helpers.py
tests/integration/test_confirmation_plans.py
tests/integration/test_case_inline_revise.py
tests/integration/test_checkpoint.py
tests/integration/test_journal_lifecycle.py
tests/integration/test_multi_device_checkpoint.py
tests/integration/test_policy_propagation.py
tests/unit/test_case_journals.py
tests/unit/test_cli.py
tests/unit/test_cli_handlers.py
```

### Stage-3 measured query handoff (2026-09-20 UTC)

The query implementation passed final frozen independent review with no
remaining P1/P2 findings; 77 independently run tests and history-byte
comparisons passed. It is not the 0.2.3 release or device acceptance.
Stage 4 still owns package versions,
normative schema, policy, skill instructions, command-list documentation,
and all external instruction changes. No live Case journal, event, portable
authority JSON, policy, scientific file, or external instruction was changed.
Direct SHA-256 and byte-count comparison against the stage-1 manifest confirms
exact equality of all 34 history streams and 38 portable JSON files. No Git,
network, simulation, MATLAB, or checkpoint operation was performed.

The read boundary is `services/queries.py`: `ReadSelector` and `MemoryQuery`
use the existing `WorkspaceRegistry` and one `QueryIndex`. This boundary does
not call `services/owners.py`, whose local new-write access, registration,
and directory checks remain unchanged. All stage-2 confirmation, device,
process-lock, and stream-ownership protections remain unchanged.

Public CLI and scope contract for stage-4 documentation:

- There are now 25 CLI leaves: the 24 stage-2 leaves plus `event list`.
  `context TARGET` accepts `case:SIM_ID`, bare canonical SIM_ID,
  `study:PROJECT_ID#STUDY_ID`, `project:PROJECT_ID`, `root:ROOT_ID[/PATH]`,
  and registered local paths. Study/Project aggregation uses the explicit
  logical selector; similar directory names never create membership.
- Logical `root:` queries parse portable identity without requiring that
  root in this device's TOML or touching scientific files. The output carries
  `selector` and `mappingAvailable`. That boolean means a direct local
  root/Case mapping is configured, not that every scientific directory or
  evidence file exists. Study/Project selectors have no direct local mapping
  and report false. Local paths still require a registered longest root.
- A local path with `mapping=none` keeps its exact root-relative owner.
  Existing or candidate Case directories mapped through `canonical` or
  `same-relative-path` use a Case selector; an unregistered candidate reports
  `registered: false` and reads exact prepared history without creating
  authority. Simulation roots themselves and strict ancestors of indexed
  Cases remain root/path selectors. A mapped ancestor uses the same canonical
  `root:simulation/<directory>` owner as the write resolver.
- Root/path selection is exact by default. `context --recursive` and
  `event list --recursive` explicitly select only that root's path subtree,
  with component boundaries; they reject non-root selectors. A local mapped
  ancestor does not union older explicit owners from another root. Its
  returned `selector` and follow-up query name the selected canonical owner;
  inspect older explicit-root history with its original
  `root:matlab_simulation/<directory>` locator. Use the explicit `study:` or
  `project:` selector for research aggregation, not a parent directory name.
- Case queries include the Case's rename lineage and exact root directories
  related by registered canonical/same-relative mappings. Explicit aliases
  are checked in both directions. `mapping=none`, similar names, descendants,
  siblings, and shared-function directories never imply pairing. Event IDs
  deduplicate the union and stored owners remain unchanged. Parent Study
  events are separate Case `parent_background`, never Case progress.
- Study aggregation includes its explicit Study events and registered member
  Case histories; Project aggregation includes its explicit Study events and
  registered Case histories. Lifecycle histories remain available. Arbitrary
  root events are not promoted to Study/Project ownership.
- `event list [TARGET]` adds `--limit N`, `--since UTC`, `--query SUBSTRING`,
  and `--recursive`. The default limit is 20, maximum 100; 0 returns counts.
  `--since` is inclusive on `occurred_at` and requires
  `YYYY-MM-DDTHH:MM:SSZ`. Text search is a Unicode-casefolded literal substring
  over summary plus evidence observations; `%` and `_` are not wildcards.
  Omitted TARGET selects all portable events. Results sort by descending
  `(occurred_at, recorded_at, event_id)`; this is deterministic display order,
  not proof of cross-device causality.
- List JSON returns `events`, returned `count`, matching `total`, `omitted`,
  `truncated`, `limit`, and `recursive`, plus `selector`/`mappingAvailable`
  when targeted. `since` and `query` appear only when supplied. Summary rows
  retain event/device IDs, both timestamps, original owner, kind, summary,
  evidence count and locator/observation clues. `scope` names the original
  owner kind. Every correction row retains its `correction`; a corrected row
  includes `corrected_by` references with exact fields/status tracks even if
  the replacement is outside the current filters or count limit.
- `event show EVENT_ID` uses the index and returns every original Event field,
  including real `status_updates`, complete evidence, and correction fields,
  plus query relationship metadata (`scope`, and `corrected_by` when present).
  These additions do not alter stored Event schema or historical bytes.
- Context default, deep, selections, and event-details do not generate the
  Run/Data/Analysis projection. `context --include status` explicitly restores
  the legacy active-Case projection. Full event details retain actual
  historical `status_updates`; they are not automatically generated unknowns.
  Root/Study/Project contexts do not synthesize status tracks.
- `context --recent` defaults to 3 and accepts 0 through 100. Context JSON
  retains `recent_events` and `progress.total`, `progress.omitted`,
  `progress.truncated`, and `progress.follow_up` (command, target, limit,
  recursion). Explicit JSON Pointer selection remains narrow and omits work
  history unless `--include event-details` is also requested. For a Case,
  pointers address its materialized spec; Study/Project pointers address
  their metadata document, and root pointers address the locator.
- Compact/deep budgets remain 4096/24576 bytes. `budget.actual_bytes`
  measures canonical JSON plus its newline. Trimming reports `omitted_paths`
  and `budget.truncated`; event omission increments the progress count.
  Large Case/background content is reduced before recent work is removed.
  If needed, evidence details and long summaries are explicitly marked as
  omitted/truncated, and at least one recent event ID and work clue remains
  when work exists and `--recent` is nonzero. Mandatory content that cannot
  fit refuses with an explicit budget error instead of a complete-looking
  empty progress list. Use `event list` and then `event show` for details.
- Explicit knowledge-link content still requires an exact Case link ID and
  linked Notes section. Generic context never reads Notes or evidence files.
  `doctor --json` now reports `framework_version` from the running package;
  it therefore still reports 0.2.2 until stage 4 changes the package version.

Index schema 5 stores complete `owner_path`, normalized searchable text, and
the correction target in addition to the original event document. An older
index is rebuilt locally from authority. Large exact-owner selections use a
temporary indexed owner table instead of an SQL expression per owner.
The local index is not transferred between devices. Corrupt/symlink refusal
remains intact; failed connection setup now closes its SQLite connection.

Theory registration is limited to this device's `matlab_theory` root at
`/mnt/d/document/MATLAB/Matlab/Theory`, kind `analysis`, mapping `none`, with
the existing exact owners `epoch_initial_distribution` and `tr_vortex_beam`.
The example TOML labels this root optional on a device without the directory.
No Project/Study/Case was created and the Matlab parent was not registered.
Read-only source inspection confirms photon-distribution generation in
`epoch_init_sample_particles_nd.m`, including weighted particle coordinates
and three photon momentum components, and colliding-beam generation in
`epoch_init_generate_colliding_beams.m`. `tr_vortex_compute.m` computes static
frequency-domain and time-domain TR vortex fields. These descriptions are
code observations, not execution, numerical, or physical acceptance.

The final affected test command passes 77 isolated tests:

```text
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:. python3 -B -m unittest -q tests.unit.test_memory_queries tests.unit.test_query_index tests.unit.test_cli tests.unit.test_cli_handlers tests.integration.test_portable_memory tests.integration.test_checkpoint tests.integration.test_multi_device_checkpoint tests.integration.test_confirmation_plans tests.integration.test_journal_lifecycle tests.integration.test_tombstone_migration
python3 -B tests/run_fast.py
```

The final fast runner passes 86 framework unit tests, 37 utility tests (one
existing skip), and six workflow skill tests. Twelve new query unit tests
cover exact/recursive ownership, explicit aliases, filters, corrected history,
status opt-in, budgets, index rebuilding, root/ancestor boundaries, more than
1000 owner selections, and CLI version reporting. Six new integration tests
use two independent Stores, absolute root layouts, device IDs, TOMLs, saved
plans, and SQLite files. Their simulated exchange copies only portable
metadata and preserves device-stream prefixes; it executes no synchronization
program. They cover absent-Theory read/write separation, own-device appends,
mapped prepared history followed by registration and rename, cache rebuild,
local plan transplant refusal, stale heads, actual sibling forks, conflicting
event IDs, and mapped ancestor checkpoint/context ownership consistency.
The initial independent review found one missing-candidate-path query bug;
the frozen fix and regression retain both explicit mapped-directory events
and canonical prepared events through local candidate-Case queries.

No release `run_all.py` or live pilot was run. No bytecode or temporary files
remain under source/tests. This isolated acceptance does not prove Git
publication, remote synchronization, or real second-device deployment.

Stage-3 changed repository paths (relative to this control root):

```text
FRAMEWORK_BASELINE.md
src/research_workflow/cli/handlers.py
src/research_workflow/cli/parser.py
src/research_workflow/index/query.py
src/research_workflow/services/context.py
src/research_workflow/services/queries.py
tests/integration/test_checkpoint.py
tests/integration/test_portable_memory.py
tests/unit/test_cli.py
tests/unit/test_cli_handlers.py
tests/unit/test_memory_queries.py
workspace.example.toml
workspace.toml
```


### Stage-4 measured entrypoint handoff (2026-09-20 UTC)

The following handoff captures the frozen **pre-approval** state. Its protected
apply and release-gate pending items were subsequently completed as recorded in
the final local acceptance section.

Implementation is prepared for independent review and exact protected approval;
this section is not a claim of policy deployment, local release acceptance,
publication or second-device installation. No live scientific Case/event JSONL,
scientific authority JSON or external AGENTS bytes were modified. The only new
portable policy state is a real **pending** proposal plus its generated backlog,
created by supported CLI preview/write. It has not been approved or applied.
The repository AGENTS body was updated within the accepted implementation scope;
its managed block still awaits policy application. No stage checkpoint was written.

Package version sources now report 0.2.3. SCHEMA, README, architecture, changelog,
example TOML, event/policy templates, skill entrypoint/UI/reference and installation
checks agree on event-only work, real definition confirmation, portable all-owner
queries, progress/corrections, and independent device boundaries. Existing Event
fields and history remain intact. The installer still previews/reuses its existing
repository symlink without mutation; no installation rewrite was necessary.

#### Policy implementation and preview contract

The CLI now has 26 leaves, adding `policy approve`. Pending schema-1 proposals
may carry cumulative `requested_targets`; old rules/proposals remain readable.
`policy plan` works before approval. Plan schema 2 exposes exact proposed file
changes and an authorization payload whose SHA-256 excludes only the candidate's
approval bookkeeping. It binds candidate semantics/evidence, cumulative targets,
full local allowlist, base rules/other proposals, normalized pending state,
backlog consistency, managed diffs and front-state, rule destinations and actual
superseded-rule removals. The displayed pending active-rule preview remains
pending; it does not fabricate actor/time or a human decision.

After real user approval, `policy approve ID --expect-digest DIGEST --actor user
--decided-at UTC --write` stores that digest and exact requested targets. CLI
propose refuses pre-approved imports. Apply checks current plan and approval;
active-rule replay only reuses unchanged files, so drift/new targets cannot bypass
fresh consent by recomputing a digest. Same-ID active reauthorization raises
revision without changing behavior. Stale approved open proposals need a new
unique ID. CLI writes share the stage-2 authority lock and registered-device gate;
policy service targets are refreshed inside dispatch from current workspace data.

The initial independent inspection found an active-rule replay bypass; it was
closed before the frozen review bundle, with explicit drift/target-expansion
regressions. Policy-only reauthorization is tested without forcing correct
managed blocks to change. These are local software tests, not cross-device deployment.

#### Exact protected review bundle

Local derived artifacts are retained under
`.research-workflow/upgrade-0.2.3/stage4_review/`:

- `pending-proposal.json`, `policy-plan.json`, `managed-policy.patch`;
- `body-candidates.json`, `body-review.patch`, `body-plan.json`,
  `body-apply.patch`, and `apply_body_plan.py`;
- `review-summary.json`, `old-active-rule.json`, `instruction-chains.json`,
  `preservation-and-body-check.json`, `validation-summary.json`, and
  `stage4-changed-paths.txt`.

Pending ID: `framework-v0-2-3-research-memory`, revision 1, superseding
`framework-v0-2-2-journal-only`. The exact policy plan digest is:

```text
1c643f638ce6bf19dcecbd4f0f4cd8fcdc3fb008f679303e9f67023d2dbc29b7
```

The independent body plan digest is:

```text
35335256e6ae1f636d4e127e0c0748d11427031ad6fb5f8273704ced570508f5
```

The managed apply set is the 21 exact laptop-2 paths in the approved contract
above. Requested approval accumulates 22 paths, retaining the existing laptop-1
Notes path and adding the missing laptop-2 Data instruction path. The foreign
Notes path is not a local target and is never read or written by propagation.
Data/Notes managed blocks and the seven external body mutations still require
exact separate user approval and filesystem authorization by the main task.

Policy apply would create
`policy/rules/framework-v0-2-3-research-memory.json`, remove the superseded
`policy/rules/framework-v0-2-2-journal-only.json`, remove the completed
`policy/open-proposals/framework-v0-2-3-research-memory.json`, and regenerate
`EVOLUTION_BACKLOG.md`. No removal has occurred. Exact old active-rule bytes are
preserved in `old-active-rule.json` and the stage-1 comparison archive; no Git
publication/history operation is claimed as performed.

All eight selected body nodes have explicit review differences. The repository
body is already applied and its execution-plan entry is `reuse`; the seven
external nodes are control-directory, actual global, Simulation, QED subtree,
configuration, scripts, and Matlab instructions. Unrelated research rules remain.
The body plan expects the exact post-managed bytes, then modifies only its
reviewed bodies. Run policy apply first, body preview second, body write last.
A changed byte in any target refuses the whole body write. An isolated helper
fixture proved preview-only behavior, all-target stale refusal without partial
writes, and exact accepted application; no external instruction was used as a test.

#### Instruction discovery and installation

The actual local Codex home remains `/mnt/b/software/Codex/Data`; the skill link
resolves to this repository. Relevant config inspection found no explicit custom
root markers, fallback filenames or document-byte override. Under the documented
[Codex instruction discovery rules](https://learn.chatgpt.com/docs/agent-configuration/agents-md),
root-to-cwd selection uses override/AGENTS/fallback precedence; no project root
means cwd only. The measured chain report records local root markers, selected
files and a separate conservative all-ancestor/reference chain. It is filesystem
and configuration inference, not unavailable host-loaded telemetry.

After the reviewed changes, the largest discovered chain is scripts/build_containers/pic:
25,108 bytes including global guidance and separators. The conservative chain,
which also includes the referenced control-directory AGENTS, is 30,561 bytes;
both fit the default 32,768-byte budget. These are projected post-deployment
measurements; repeat against real written files after main performs the protected
apply. Current files remain unchanged externally.

The ordinary installed-skill check passes, validates the skill-creator frontmatter,
reports installer `reuse`, skips live authority and preserves cache. Explicit
`--full` now discovers Cases through journal-backed `case list`, not removed
thin-Store Case maps. It passed real Case context for
`benchmark_lbw/mono_beams_collide_1d/20260807_mono_beams_1d_baseline`, Store validation
and doctor. Full queries may refresh the derived index and do not fail a false
`cache_unchanged` requirement. Zero active Cases would be explicitly reported.

#### Validation and history

Measured affected commands:

```text
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:. python3 -B -m unittest -q tests.unit.test_evolution tests.integration.test_policy_propagation tests.unit.test_cli tests.unit.test_cli_handlers skills/research-workflow/tests/unit/test_skill_bundle.py
PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=src:. python3 -B -m unittest -q tests.integration.test_materialization tests.integration.test_policy_propagation skills/research-workflow/tests/unit/test_skill_bundle.py
python3 -B tests/run_fast.py
python3 -B skills/research-workflow/scripts/check_installation.py --codex-home /mnt/b/software/Codex/Data --json
python3 -B skills/research-workflow/scripts/check_installation.py --codex-home /mnt/b/software/Codex/Data --full --json
```

The first command passes 46 tests; the second passes 26 tests, including all four
materialization checks. Fast passes 86 framework unit tests, 37 utility tests
(one existing skip), and seven workflow skill tests. Initial fast failures were
three obsolete version expectations; the expectations were updated with both
version sources and the rerun passed. No unrelated scientific test was skipped.

The obsolete live-input equality test is replaced by a temporary thin Store
with two Cases, one without reproducibility and one with an accepted historical
input locator/hash. It checks independent Project/Study/profile/Case materialization,
matching/changed/missing input states, unchanged historical hash/view, structural
validity and exact portable bytes. It never depends on live scientific paths.
Existing metadata-only live materialization checks remain. The earlier 65 missing
reproducibility fields and 16 runner differences remain historical scientific-source
diagnostics; nothing was rescanned or rewritten to hide them. Stage-2 input-plan
invalidation tests remain the separate current-input safety gate.

Direct comparison again confirms exact equality of all 34 initial history streams
and 38 scientific authority JSON files. All 21 external instruction files covered
by the initial snapshot remain byte-identical. No bytecode or transaction temporary
files remain under source/tests/this skill. Local review artifacts and the derived
SQLite index are intentionally retained.

`GIT_PRIVATE_REMOTE.md` supplies the complete sequential two-device procedure,
role-specific external body text, independent patch/managed scopes, cumulative
policy reauthorization commands, local TOML/skill/targets verification, missing-
Theory logical reads, acceptance and authorized return of approvals. The selected
branch `update_0.2.3` remains unpublished, with no fabricated commit or remote
status. Full release `run_all.py`, real protected apply, final release review,
publication and actual laptop-1 deployment remain pending; no checkpoint, Git,
SSH, cluster, simulation, MATLAB, transfer or build operation was performed.

Stage-4 changed repository paths:

```text
AGENTS.md
ARCHITECTURE.md
CHANGELOG.md
CODEX_SKILL_SYNC.md
EVOLUTION_BACKLOG.md
FRAMEWORK_BASELINE.md
GIT_PRIVATE_REMOTE.md
README.md
SCHEMA.md
pyproject.toml
workspace.example.toml
policy/open-proposals/framework-v0-2-3-research-memory.json
skills/research-workflow/SKILL.md
skills/research-workflow/agents/openai.yaml
skills/research-workflow/references/operations.md
skills/research-workflow/scripts/check_installation.py
skills/research-workflow/tests/unit/test_skill_bundle.py
src/research_workflow/__init__.py
src/research_workflow/cli/handlers.py
src/research_workflow/cli/parser.py
src/research_workflow/evolution/policy.py
src/research_workflow/evolution/propagation.py
templates/EVENT.jsonl
templates/POLICY.json
tests/integration/test_materialization.py
tests/integration/test_policy_propagation.py
tests/unit/test_cli.py
tests/unit/test_cli_handlers.py
tests/unit/test_core.py
tests/unit/test_package_entrypoint.py
```

Frozen stage-4 independent review passed with no remaining P1/P2. It rebuilt
the actual policy/body digests; checked every local managed target and body
partition; tested wrong digest, modified plan and stale intermediate bytes
against the real body helper in isolation; and exercised the actual candidate
through A supersession/apply, B same-ID revision-2 cumulative reauthorization,
and return to A without managed drift or reuse of B's digest for A mutation.
The new historical-memory materialization fixture independently passed. No live
policy approval/apply, external instruction write or remote operation was used
for these tests. Release-tier and protected deployment remain with the main task.


### 0.2.3 final local acceptance (2026-09-20 UTC)

Local status: **accepted on laptop-2**. Every implementation stage and its
independent review is complete; final reviewer `v023_release_review` reports no
remaining P1/P2. This acceptance covers the research-memory software, local
instruction deployment and stated structural/source checks. It does not certify
scientific numerical/physical correctness, publication or another device.

#### Real approval and protected deployment

The user explicitly approved both reviewed plans. The main task recorded that
approval at `2026-09-20T04:22:48Z` and applied:

- Policy authorization digest
  `1c643f638ce6bf19dcecbd4f0f4cd8fcdc3fb008f679303e9f67023d2dbc29b7`.
- Independent body digest
  `35335256e6ae1f636d4e127e0c0748d11427031ad6fb5f8273704ced570508f5`.

`policy approve`, digest-bound `policy apply`, and body-helper preview/write all
exited 0. Policy apply changed exactly 21 managed targets, created the 0.2.3
active rule, removed the authorized old active rule and completed proposal,
and regenerated the backlog. The body helper changed seven external bodies;
the already updated repository body was reused. All eight final body-node
hashes and every managed projection match the reviewed plans. Data and Notes
unmanaged bytes remain exact. The rule is
`framework-v0-2-3-research-memory`, revision 1, with 22 cumulative approved paths;
only the 21 local allowlisted targets were applied. The retained laptop-1 Notes
approval did not become a local target.

Immediate and final policy checks report valid, 21 targets and zero drift.
The final active-rule plan has 23 files and every operation is `reuse`. No
automatic drift repair or unapproved scope expansion was used.

#### Final independent release evidence

```text
python3 -B tests/run_all.py
```

The second complete release run exited 0:

| Suite | Tests | Outcome | Elapsed seconds |
| --- | --- | --- | --- |
| Framework | 156 | 156 passed | 195.834 |
| edit-research-ppt utility | 37 | 36 passed, one pre-existing skip | 1.848 |
| research-workflow skill | 7 | 7 passed | 0.482 |
| Total | 200 | 199 passed, one pre-existing skip | — |

The first release run had exactly two obsolete test-contract errors in
`tests/integration/test_safety.py`: it requested default context status and
required optional reproducibility metadata. Only these tests changed. Status
now asserts absence by default, then explicitly requests projection and checks
three unknown tracks without evidence. Source safety retains active EPOCH
begin/end checks and non-executing `sh -n`; it reports 151 EPOCH Cases as 92
complete recorded-source checks, 53 without reproducibility, and six with
incomplete input/runner metadata. All 151 are accounted for. Both affected tests
passed in 50.640 seconds before the independent complete rerun. No runtime
contract, scientific source or metadata was altered to obtain a passing gate.

Final `doctor`, `validate`, `event merge`, `policy check` and explicit full
installed-skill check all exit 0. Runtime reports package `0.2.3`, device
`laptop-2`. Before the one final completion checkpoint, structural validation
reports 1,301 checked objects, 292 active Cases, 363 events, two devices, zero
unresolved orphans and no diagnostics. These are timestamped acceptance counts,
not assertions that future event totals remain fixed. Full skill acceptance
executes journal-backed Case discovery and real bounded context; default
installation checks preserve cache while full queries may refresh derived state.

Independent inspection verified the complete sets and exact bytes of all 34
historical streams and 38 scientific metadata JSON files against stage 1 before
the completion checkpoint. The eventual single append must preserve every
historical prefix; no source hash, journal line, Event field, or old scientific
assertion was rewritten. The 65 missing reproducibility fields and 16 runner
source differences observed before the upgrade remain separate existing
scientific-source diagnostics. They were neither normalized away nor confused
with metadata validity. The isolated historical-memory test and stage-2 current-
input plan invalidation tests cover their distinct responsibilities.

Actual written instructions match the planned chain measurements: the largest
filesystem/config-derived discovery chain is 25,108 bytes, and the conservative
all-ancestor/reference chain is 30,561 bytes, both below 32,768. This verifies
complete selected file chains, not unavailable host-loaded telemetry. No
bytecode or transaction temporary files remain. The installed skill symlink
was reused and still targets this repository.

#### Consolidated actual change inventory

This inventory combines the stage-1 exact snapshots, all stage handoffs, the
approved deployment and the release-test correction. No Git tracking or branch
inspection is implied. Repository-relative paths below represent 11 added,
43 modified and one approved-deleted file; local TOML, external instruction
files and transient proposal completion are listed separately.

Added repository files:

```text
policy/rules/framework-v0-2-3-research-memory.json
src/research_workflow/services/case_changes.py
src/research_workflow/services/owners.py
src/research_workflow/services/plans.py
src/research_workflow/services/queries.py
src/research_workflow/storage/devices.py
src/research_workflow/storage/locking.py
tests/integration/confirmation_helpers.py
tests/integration/test_confirmation_plans.py
tests/integration/test_portable_memory.py
tests/unit/test_memory_queries.py
```

Modified repository files:

```text
AGENTS.md
ARCHITECTURE.md
CHANGELOG.md
CODEX_SKILL_SYNC.md
FRAMEWORK_BASELINE.md
GIT_PRIVATE_REMOTE.md
README.md
SCHEMA.md
pyproject.toml
skills/research-workflow/SKILL.md
skills/research-workflow/agents/openai.yaml
skills/research-workflow/references/operations.md
skills/research-workflow/scripts/check_installation.py
skills/research-workflow/tests/unit/test_skill_bundle.py
src/research_workflow/__init__.py
src/research_workflow/cli/handlers.py
src/research_workflow/cli/parser.py
src/research_workflow/domain/case_records.py
src/research_workflow/evolution/policy.py
src/research_workflow/evolution/propagation.py
src/research_workflow/index/query.py
src/research_workflow/services/__init__.py
src/research_workflow/services/checkpoint.py
src/research_workflow/services/context.py
src/research_workflow/storage/case_journals.py
src/research_workflow/storage/jsonio.py
src/research_workflow/storage/store.py
src/research_workflow/storage/streams.py
templates/EVENT.jsonl
templates/POLICY.json
tests/integration/test_case_inline_revise.py
tests/integration/test_checkpoint.py
tests/integration/test_journal_lifecycle.py
tests/integration/test_materialization.py
tests/integration/test_multi_device_checkpoint.py
tests/integration/test_policy_propagation.py
tests/integration/test_safety.py
tests/unit/test_case_journals.py
tests/unit/test_cli.py
tests/unit/test_cli_handlers.py
tests/unit/test_core.py
tests/unit/test_package_entrypoint.py
workspace.example.toml
```

Approved deletion of a file present in the original snapshot:

```text
policy/rules/framework-v0-2-2-journal-only.json
```

The generated
`policy/open-proposals/framework-v0-2-3-research-memory.json` was created pending,
approved through the CLI and removed by its completed apply. It was not an
original scientific file. `EVOLUTION_BACKLOG.md` was regenerated during that
workflow and its final bytes equal the stage-1 snapshot. The existing unrelated
open proposal remains intact.

The device-local `workspace.toml` changed only within the approved local registry
work and remains excluded from portable delivery. It registers only the Theory
root described above; no Matlab parent or empty Project/Study/Case was added.

External instruction files actually changed:

| Exact external file | Authorized change |
| --- | --- |
| `/home/yuhanjin/AGENTS.md` | managed+body |
| `/home/yuhanjin/Code_Program/AGENTS.md` | managed |
| `/home/yuhanjin/Simulation/AGENTS.md` | managed+body |
| `/home/yuhanjin/Simulation/qed_cone_pair/AGENTS.md` | managed+body |
| `/home/yuhanjin/Source_Code/AGENTS.md` | managed |
| `/home/yuhanjin/dot_files/AGENTS.md` | managed+body |
| `/home/yuhanjin/scripts/AGENTS.md` | managed+body |
| `/home/yuhanjin/scripts/backup/archlinux/AGENTS.md` | managed |
| `/home/yuhanjin/scripts/build_containers/AGENTS.md` | managed |
| `/home/yuhanjin/scripts/build_containers/pic/AGENTS.md` | managed |
| `/home/yuhanjin/scripts/build_containers/post_process/AGENTS.md` | managed |
| `/home/yuhanjin/scripts/clean/AGENTS.md` | managed |
| `/home/yuhanjin/scripts/process/AGENTS.md` | managed |
| `/home/yuhanjin/scripts/run/AGENTS.md` | managed |
| `/home/yuhanjin/scripts/sync/AGENTS.md` | managed |
| `/home/yuhanjin/scripts/transfer/AGENTS.md` | managed |
| `/home/yuhanjin/scripts/update/AGENTS.md` | managed |
| `/mnt/b/software/Codex/Data/AGENTS.md` | body |
| `/mnt/c/Users/17865/Desktop/Laser Plasma/Notes/AGENTS.md` | managed |
| `/mnt/d/document/MATLAB/Data/Simulation/AGENTS.md` | managed |
| `/mnt/d/document/MATLAB/Matlab/AGENTS.md` | managed+body |

There are 21 external files: 20 external managed targets plus the actual global
entry. The repository AGENTS is the remaining managed target. Seven external
bodies and the repository body account for the eight body nodes; other external
bodies, including Data/Notes, were preserved. No external scientific content was
changed. The existing symlink at
`/mnt/b/software/Codex/Data/skills/research-workflow` was verified and reused.

Local comparison/review evidence is retained, excluded from portable delivery:

- `.research-workflow/upgrade-0.2.3/pre-upgrade.json`;
- `.research-workflow/upgrade-0.2.3/pre-upgrade-files.zip`;
- `.research-workflow/upgrade-0.2.3/stage4_review/`, including exact old active-rule
  bytes, approved plans/differences, chain and preservation checks;
- `.research-workflow/upgrade-0.2.3/release-inventory.json` and its text view.

These snapshots are upgrade comparison evidence, not the missing historical
recovery tar. That archive remains unavailable and its location `to-confirm`.

#### Final recording and delivery boundary

After this public documentation is final, the main task records one event-only
checkpoint at `root:research_workflow`. Its sole stream append belongs to
`metadata/events/laptop-2/2026-09.jsonl`; the Event ID is reported at completion.
It is not a Case registration, a per-stage duplicate, or a claim of remote
deployment. The final auditor checks the one append and every preserved prefix;
the local release inventory can then note the new Event without changing these
already cited acceptance documents.

Local 0.2.3 implementation and instruction deployment are accepted. Git remains
**unpublished**, with user-selected delivery branch `update_0.2.3`, no generated
release commit and no Git/network publication operation. Actual laptop-1
installation, its acceptance and subsequent return-policy check remain
**not performed**. Follow `GIT_PRIVATE_REMOTE.md` for the exact publication and
sequential device procedure; keep each device's TOML, identity, skill location
and external instructions local. The two-independent-workspace fixtures prove
software behavior, not remote execution. No simulation, MATLAB, cluster,
transfer, sync, build, container or SIF execution was part of this acceptance.

## 0.2.4 implementation checks (2026-10-31, desktop-1)

Source implementation adds explicit Store capability upgrade, independent
archive compatibility inspection and device/path policy target lifecycle.
Case/Event/workspace/SQLite contracts and historical journals are unchanged.
This section records implementation checks, not Store activation, instruction
deployment, user approval, publication or another device's acceptance.

- Isolated fast tier: 86 framework unit tests passed; 37 PPT tests ran with one
  existing skip; seven workflow skill tests passed.
- Nine explicitly selected fixture integration modules passed 66 tests, covering
  Case confirmation/journals/tombstones, portable memory, policy propagation and
  target lifecycle. No live pilot, materialization or safety acceptance ran.
- The pre-change 0.2.3 Store validator accepted the original Store 2 document and
  rejected an in-memory Store 3 candidate. No old-writer mutation was attempted.
- Compatibility-only doctor returned package 0.2.4 with compatible Store 2 while
  the supplied workspace path did not exist; it created no workspace or cache.
- All 84 pre-task metadata/policy authority fingerprints still match. Managed
  AGENTS blocks, live Store, policy proposals/approvals and event streams were
  not written. Pending body drafts retain the original managed bytes.

The new target regression module checks unmanaged-byte preservation, retained
rule history, missing retired files, returned-block drift, real approval gates,
stale parent content, device/path conflicts, symlink/root boundaries, capability
refusal, concurrent reuse, interrupted rollback and actual completed replay.
Tests validate structure and local transactions, not remote synchronization or
scientific correctness. Live target retirement, global framework policy, exact
body edits and final file deletion await separate reviewed confirmations.

### 0.2.4 independent-review corrections

Three reproduced findings were corrected before activation: scope queries now
reduce full retained history before filtering; aggregate validation and Store
upgrade reject same-priority conflicts at actual allowlist contexts; policy
completion rechecks intended outputs and bound unchanged dependencies before
writing a receipt. Shared rollback preserves later external edits and reports
any path that could not safely be restored. No authority or AGENTS deployment
was part of these corrections.

The targeted policy/target/evolution/storage run passed 43 tests, including five
new regression methods. The affected Case confirmation/checkpoint/journal and
CLI run passed 51 tests. Seven workflow skill tests passed after the expanded
README and bounded operations reference. PPT and live pilot/materialization/
safety suites were not repeated. These are isolated structural regressions,
not scientific or remote-device acceptance.

## 0.2.4 desktop-1 local activation (2026-10-31)

After separate actual user confirmations, desktop-1 activated Store schema 3
with `policy-target-lifecycle-v1`, retired the PIC and post-processing child
targets, and deployed the 0.2.4 version policy to 20 ordinary targets plus the
separately approved exact Notes target. Store identity, creation time, Project
and device membership, old policy-rule bytes and unmanaged target bytes were
preserved. The user reported that other-device old writers were stopped.

Accepted Store plan: `acbb3dcfbe026b9e4f7976fe5508ed9b75dcd90c87fc5e8c30f309b377824612`.
PIC retirement: `04181743a801bbeb928545954032b0ddd143a98303c42a9aa47b3c94e1fe8370`.
Post-processing retirement: `6a5ab78407b3cfac9b3002e4ae83ef9bbff97ed74e49b3e0b4b689a1378ae9df`.
Global policy: `a5bd29447850cf6a8a880abbbee3dadae9f7c339fe8d95b8e985fec99fb77e3d`.

The seven independently reviewed A2 bodies were applied under digest
`9fa07c82f54464b27706e08631f081be7304be2d226ed2370af0629e1ffc6494`;
a separately approved sync-body correction permits explicitly authorized SSH
metadata while retaining Rayfile payloads. After retirement, the two redundant
child AGENTS files were separately approved and deleted under preview digest
`2579733d93e9c601aef6285055568068ac8b72ba2d1b3de7f6de7db98f23e51c`.
Their rules remain in the container parent; the scripts instruction tree has
nine files. Explicit allowlist entries and all 29 historical authorized paths
remain retained. The final policy check has no drift.

The implementation/regression evidence above remains historical. This local
activation performs no scientific run, Git publication, synchronization or
another device's acceptance. Event-only results are recorded once at their
exact owners after finalization, without Case edits or duplicated hierarchy.
