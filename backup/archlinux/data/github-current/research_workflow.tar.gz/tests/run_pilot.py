"""Run only the explicit v0.2.1 live-pilot acceptance tests."""

from __future__ import annotations

from _suite_runner import ROOT, run_suite


PILOT_ROOT = ROOT / "tests/pilot"


def main() -> int:
    tests = sorted(PILOT_ROOT.glob("test_*.py")) if PILOT_ROOT.is_dir() else []
    if not tests:
        print("[suite:pilot] pending: no explicit pilot acceptance tests", flush=True)
        return 2
    return 0 if run_suite("pilot", PILOT_ROOT) else 1


if __name__ == "__main__":
    raise SystemExit(main())
