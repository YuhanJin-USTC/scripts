"""Run isolated unit and skill tests without reading live research authority."""

from __future__ import annotations

from _suite_runner import ROOT, check_skill_layout, run_suite, skill_roots


def main() -> int:
    roots = skill_roots()
    results = [check_skill_layout(roots), run_suite("unit", ROOT / "tests/unit")]
    for root in roots:
        results.append(run_suite(root.name, root / "tests"))
    return 0 if all(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
