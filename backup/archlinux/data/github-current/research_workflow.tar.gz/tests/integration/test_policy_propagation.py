"""Test isolated policy propagation, transactions, drift, and CLI flows."""

from __future__ import annotations

import contextlib
import io
import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest import mock

from research_workflow.cli.main import main
from research_workflow.core.errors import AccessError, ConflictError, ValidationError
from research_workflow.evolution import (
    MANAGED_START,
    PolicyApplicationService,
    Proposal,
    TargetAllowlist,
    check_backlog_consistency,
    load_active_rules,
    load_open_proposals,
    render_backlog,
)
from research_workflow.workspace import WorkspaceRegistry
from research_workflow.storage import atomic_json_write


DECIDED_AT = "2026-07-19T12:00:00Z"


def _fixture(root: Path, *, device: bool = True) -> tuple[Path, PolicyApplicationService, dict[str, Path]]:
    roots = {
        "control": root / "AGENTS.md",
        "simulation": root / "Simulation" / "AGENTS.md",
        "child": root / "Simulation" / "child" / "AGENTS.md",
        "sibling": root / "Simulation" / "sibling" / "AGENTS.md",
        "analysis": root / "Matlab" / "AGENTS.md",
        "data": root / "Data" / "AGENTS.md",
        "notes": root / "Notes" / "AGENTS.md",
    }
    for name, path in roots.items():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(f"# {name}\r\n\r\nLocal bytes.\r\n".encode("utf-8"))
    device_table = '\n[device]\ndevice_id = "laptop-1"\n' if device else ""
    workspace = root / "workspace.toml"
    workspace.write_text(
        f'''schema_version = 1
workspace_id = "fixture"
verified_at = "2026-07-19T00:00:00Z"
{device_table}
[sim_id]
strategy = "simulation-relative-posix-path"
canonical_root = "simulation"
separator = "/"
case_sensitive = true
same_relative_path_default = true
allow_absolute = false
allow_dot_segments = false

[path_aliases]
policy = "explicit-and-evidence-backed-only"

[roots.simulation]
path = "{root / 'Simulation'}"
kind = "simulation"
mapping = "canonical"
default_access = "project-policy"
verification = "fixture"
verified_at = "2026-07-19T00:00:00Z"

[roots.analysis]
path = "{root / 'Matlab'}"
kind = "analysis"
mapping = "none"
default_access = "project-policy"
verification = "fixture"
verified_at = "2026-07-19T00:00:00Z"

[roots.data]
path = "{root / 'Data'}"
kind = "data"
mapping = "none"
default_access = "read-only"
verification = "fixture"
verified_at = "2026-07-19T00:00:00Z"

[roots.notes]
path = "{root / 'Notes'}"
kind = "notes"
mapping = "explicit-link-only"
default_access = "explicit-user-request"
verification = "fixture"
verified_at = "2026-07-19T00:00:00Z"
''',
        encoding="utf-8",
    )
    roles = {"control": ("control", "fixture"), "simulation": ("simulation", "simulation"),
        "child": ("simulation", "simulation"), "sibling": ("simulation", "simulation"),
        "analysis": ("analysis", "analysis"), "data": ("data", "data"), "notes": ("notes", "notes")}
    for name, path in roots.items():
        role, project = roles[name]
        with workspace.open("a", encoding="utf-8") as stream:
            stream.write(f'\n[[policy.targets]]\npath = "{path}"\nrole = "{role}"\nproject = "{project}"\nseparate_approval = {str(name in {"data", "notes"}).lower()}\n')
    if device:
        atomic_json_write(root / "metadata/STORE.json", {
            "schema": "research-workflow/store", "schema_version": 2, "framework_version": "0",
            "store_id": "policy-fixture", "created_at": DECIDED_AT, "projects": [], "devices": ["laptop-1"],
        }, write=True)
        atomic_json_write(root / "metadata/devices/laptop-1.json", {
            "schema": "research-workflow/device", "schema_version": 1, "device_id": "laptop-1",
            "name": "Laptop 1", "onboarded_at": DECIDED_AT,
        }, write=True)
    registry = WorkspaceRegistry(workspace)
    return workspace, PolicyApplicationService(root, TargetAllowlist.from_workspace(registry)), roots


def _proposal(
    proposal_id: str,
    scope: str,
    selector: str,
    *,
    approved: bool = True,
    revision: int = 1,
    authorized_targets: tuple[str, ...] = (),
    content: dict[str, object] | None = None,
) -> Proposal:
    proposal = Proposal.from_dict(
        {
            "schema": "research-workflow/policy-proposal",
            "schema_version": 1,
            "proposal_id": proposal_id,
            "status": "open",
            "scope": scope,
            "selector": selector,
            "revision": revision,
            "supersedes": [],
            "content": content or {"instruction": proposal_id},
            "evidence": ["fixture:evidence"],
            "approval": {"status": "pending"},
        }
    )
    if not approved:
        return proposal
    return proposal.approve(
        "researcher",
        DECIDED_AT,
        authorized_targets=authorized_targets,
    )


def _apply(service: PolicyApplicationService, proposal: Proposal) -> dict[str, object]:
    service.propose(proposal, device_id="laptop-1", write=True)
    plan = service.plan(proposal.proposal_id)
    return service.apply(
        proposal.proposal_id,
        expect_digest=plan.digest,
        device_id="laptop-1",
        write=True,
    )


def _run(arguments: list[str]) -> tuple[int, str, str]:
    output = io.StringIO()
    errors = io.StringIO()
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(errors):
        code = main(arguments)
    return code, output.getvalue(), errors.getvalue()


class PolicyPropagationTests(unittest.TestCase):
    """Exercise only disposable workspace, policy, and AGENTS.md fixtures."""

    def test_pending_digest_binds_front_state_and_true_approval(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            _, service, paths = _fixture(root)
            targets = tuple(sorted(str(path) for path in paths.values()))
            proposal = replace(_proposal("pending", "global", "*", approved=False), requested_targets=targets)
            service.propose(proposal, device_id="laptop-1", write=True)
            before = {path: path.read_bytes() for path in paths.values()}
            plan = service.plan("pending")
            self.assertEqual(load_open_proposals(root / "policy")[0].status, "open")
            self.assertEqual(before, {path: path.read_bytes() for path in paths.values()})
            preview = service.approve("pending", "user", DECIDED_AT,
                expect_digest=plan.digest, device_id="laptop-1")
            self.assertEqual(preview["mode"], "preview")
            self.assertEqual(load_open_proposals(root / "policy")[0].status, "open")
            service.approve("pending", "user", DECIDED_AT,
                expect_digest=plan.digest, device_id="laptop-1", write=True)
            self.assertEqual(service.plan("pending").digest, plan.digest)
            paths["analysis"].write_bytes(before[paths["analysis"]] + b"User edit.\n")
            with self.assertRaises(ConflictError):
                service.apply("pending", expect_digest=plan.digest, device_id="laptop-1", write=True)
            fresh = service.plan("pending")
            with self.assertRaises(ConflictError):
                service.apply("pending", expect_digest=fresh.digest, device_id="laptop-1", write=True)
            self.assertEqual(load_active_rules(root / "policy"), ())

    def test_pending_scope_retains_foreign_approval_without_foreign_target(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            _, service, paths = _fixture(root)
            foreign = str(root / "other-device" / "Notes" / "AGENTS.md")
            local = tuple(sorted(str(path) for path in paths.values()))
            _apply(service, _proposal("old", "global", "*", authorized_targets=local + (foreign,)))
            candidate = replace(_proposal("new", "global", "*", approved=False), supersedes=("old",), requested_targets=local)
            service.propose(candidate, device_id="laptop-1", write=True)
            with self.assertRaises(AccessError):
                service.plan("new")
            path = root / "policy/open-proposals/new.json"
            atomic_json_write(path, replace(candidate, requested_targets=local + (foreign,)).to_dict(), write=True)
            (root / "EVOLUTION_BACKLOG.md").write_text(render_backlog(load_open_proposals(root / "policy")), encoding="utf-8")
            plan = service.plan("new")
            self.assertEqual(plan.to_dict()["metrics"]["targets"], len(local))
            self.assertNotIn(foreign, [str(item.path) for item in plan.changes])
            self.assertNotIn(str(root / "policy/rules/old.json"), [str(item.path) for item in plan.changes if item.action == "delete"])
            self.assertTrue((root / "policy/rules/old.json").is_file())

    def test_cli_rejects_forged_approval_and_unregistered_writer(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, service, paths = _fixture(root)
            source = root / "candidate.json"
            source.write_text(json.dumps(_proposal("forged", "role", "simulation").to_dict()), encoding="utf-8")
            prefix = ["--workspace", str(workspace), "policy"]
            code, _, errors = _run(prefix + ["propose", "--proposal", str(source), "--write", "--json"])
            self.assertEqual(code, 2, errors)
            candidate = replace(_proposal("pending", "global", "*", approved=False), requested_targets=tuple(sorted(str(path) for path in paths.values())))
            service.propose(candidate, device_id="laptop-1", write=True)
            digest = service.plan("pending").digest
            store = root / "metadata/STORE.json"
            document = json.loads(store.read_text())
            document["devices"] = []
            atomic_json_write(store, document, write=True)
            code, _, errors = _run(prefix + ["approve", "pending", "--expect-digest", digest,
                "--actor", "user", "--decided-at", DECIDED_AT, "--write", "--json"])
            self.assertEqual(code, 2, errors)
            self.assertEqual(load_open_proposals(root / "policy")[0].status, "open")

    def test_active_rule_cannot_repair_drift_or_expand_targets(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, service, paths = _fixture(root)
            candidate = replace(_proposal("accepted", "global", "*", approved=False),
                requested_targets=tuple(sorted(str(path) for path in paths.values())))
            service.propose(candidate, device_id="laptop-1", write=True)
            digest = service.plan("accepted").digest
            service.approve("accepted", "user", DECIDED_AT, expect_digest=digest,
                device_id="laptop-1", write=True)
            service.apply("accepted", expect_digest=digest, device_id="laptop-1", write=True)
            reused = service.plan("accepted")
            self.assertEqual(service.apply("accepted", expect_digest=reused.digest,
                device_id="laptop-1", write=True)["action"], "reuse")
            paths["child"].write_bytes(paths["child"].read_bytes().replace(b'"accepted"', b'"drift"'))
            fresh = service.plan("accepted")
            with self.assertRaises(AccessError):
                service.apply("accepted", expect_digest=fresh.digest, device_id="laptop-1", write=True)
            extra = paths["simulation"].parent / "new/AGENTS.md"
            extra.parent.mkdir()
            extra.write_text("# New target\n", encoding="utf-8")
            with workspace.open("a", encoding="utf-8") as stream:
                stream.write(f'\n[[policy.targets]]\npath = "{extra}"\nrole = "simulation"\nproject = "simulation"\nseparate_approval = false\n')
            expanded = PolicyApplicationService.from_workspace(WorkspaceRegistry(workspace))
            plan = expanded.plan("accepted")
            with self.assertRaises(AccessError):
                expanded.apply("accepted", expect_digest=plan.digest, device_id="laptop-1", write=True)
            self.assertEqual(extra.read_text(), "# New target\n")

    def test_local_rule_preserves_outside_bytes_and_sibling(self) -> None:
        """Change one subtree block while retaining local and sibling bytes."""

        with tempfile.TemporaryDirectory() as temporary:
            _, service, paths = _fixture(Path(temporary))
            child_before = paths["child"].read_bytes()
            sibling_before = paths["sibling"].read_bytes()
            proposal = _proposal("local-only", "subtree", str(paths["child"].parent))
            _apply(service, proposal)
            child_after = paths["child"].read_bytes()
            self.assertTrue(child_after.startswith(child_before))
            self.assertIn(MANAGED_START.encode(), child_after)
            self.assertEqual(paths["sibling"].read_bytes(), sibling_before)

    def test_approved_role_rule_updates_every_affected_target(self) -> None:
        """Project one role rule to all and only simulation fixtures."""

        with tempfile.TemporaryDirectory() as temporary:
            _, service, paths = _fixture(Path(temporary))
            before = {name: path.read_bytes() for name, path in paths.items()}
            _apply(service, _proposal("role-all", "role", "simulation"))
            for name in ("simulation", "child", "sibling"):
                self.assertIn(MANAGED_START.encode(), paths[name].read_bytes())
            for name in ("control", "analysis", "data", "notes"):
                self.assertEqual(paths[name].read_bytes(), before[name])

    def test_global_rule_requires_then_honors_data_notes_approval(self) -> None:
        """Refuse sensitive targets until both exact AGENTS.md paths are approved."""

        with tempfile.TemporaryDirectory() as temporary:
            _, service, paths = _fixture(Path(temporary))
            proposal = _proposal("global-denied", "global", "*")
            service.propose(proposal, device_id="laptop-1", write=True)
            with self.assertRaises(AccessError):
                service.plan(proposal.proposal_id)

        with tempfile.TemporaryDirectory() as temporary:
            _, service, paths = _fixture(Path(temporary))
            authorized = (str(paths["data"]), str(paths["notes"]))
            proposal = _proposal("global-approved", "global", "*", authorized_targets=authorized)
            result = _apply(service, proposal)
            self.assertEqual(result["action"], "apply")
            for path in paths.values():
                self.assertIn(MANAGED_START.encode(), path.read_bytes())

    def test_workspace_exact_allowlist_can_include_missing_target(self) -> None:
        """Plan creation of one explicitly listed AGENTS.md without scanning."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, _, paths = _fixture(root)
            missing = root / "Source" / "AGENTS.md"
            workspace.write_text(
                workspace.read_text(encoding="utf-8").split("\n[[policy.targets]]", 1)[0]
                + f'''\n[[policy.targets]]
path = "{paths['control']}"
role = "control"
project = "fixture"
separate_approval = false

[[policy.targets]]
path = "{missing}"
role = "source"
project = "source"
separate_approval = false
''',
                encoding="utf-8",
            )
            registry = WorkspaceRegistry(workspace)
            service = PolicyApplicationService(root, TargetAllowlist.from_workspace(registry))
            proposal = _proposal(
                "explicit-targets",
                "global",
                "*",
                authorized_targets=(str(paths["control"]), str(missing)),
            )
            service.propose(proposal, device_id="laptop-1", write=True)
            plan = service.plan(proposal.proposal_id)
            agent_paths = {item.path for item in plan.changes if item.path.name == "AGENTS.md"}
            self.assertEqual(agent_paths, {paths["control"], missing})

    def test_stale_plan_digest_is_refused(self) -> None:
        """Replan from current bytes and reject an earlier approved digest."""

        with tempfile.TemporaryDirectory() as temporary:
            _, service, paths = _fixture(Path(temporary))
            proposal = _proposal("stale-plan", "role", "simulation")
            service.propose(proposal, device_id="laptop-1", write=True)
            digest = service.plan(proposal.proposal_id).digest
            paths["child"].write_bytes(paths["child"].read_bytes() + b"drift\n")
            with self.assertRaises(ConflictError):
                service.apply(
                    proposal.proposal_id,
                    expect_digest=digest,
                    device_id="laptop-1",
                    write=True,
                )

    def test_partial_write_failure_rolls_back_every_file(self) -> None:
        """Restore all original and missing states after a mid-transaction failure."""

        with tempfile.TemporaryDirectory() as temporary:
            _, service, _ = _fixture(Path(temporary))
            proposal = _proposal("rollback", "role", "simulation")
            service.propose(proposal, device_id="laptop-1", write=True)
            plan = service.plan(proposal.proposal_id)
            snapshot = {
                item.path: item.path.read_bytes() if item.path.exists() else None
                for item in plan.changes
            }
            import research_workflow.storage.jsonio as jsonio

            original_replace = jsonio.os.replace
            calls = 0

            def fail_once(source: object, target: object) -> None:
                nonlocal calls
                calls += 1
                if calls == 2:
                    raise OSError("fixture replace failure")
                original_replace(source, target)

            with mock.patch("research_workflow.storage.jsonio.os.replace", side_effect=fail_once):
                with self.assertRaises(ValidationError):
                    service.apply(
                        proposal.proposal_id,
                        expect_digest=plan.digest,
                        device_id="laptop-1",
                        write=True,
                    )
            for path, original in snapshot.items():
                current = path.read_bytes() if path.exists() else None
                self.assertEqual(current, original, path)

    def test_implemented_apply_removes_open_creates_rule_and_reuses(self) -> None:
        """Move current authority to rules and make repeated apply a no-op."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            _, service, _ = _fixture(root)
            proposal = _proposal("implemented", "role", "simulation")
            _apply(service, proposal)
            self.assertEqual(load_open_proposals(root / "policy"), ())
            self.assertEqual([item.rule_id for item in load_active_rules(root / "policy")], ["implemented"])
            repeated = service.plan(proposal.proposal_id)
            result = service.apply(
                proposal.proposal_id,
                expect_digest=repeated.digest,
                device_id="laptop-1",
                write=True,
            )
            self.assertEqual(result["action"], "reuse")
            self.assertTrue(all(item["action"] == "reuse" for item in result["operations"]))

    def test_higher_approval_only_revision_preserves_managed_bytes(self) -> None:
        """Reauthorize one active identity without changing effective policy."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            _, service, paths = _fixture(root)
            content = {"instruction": "stable"}
            _apply(service, _proposal("reauthorized", "role", "simulation", content=content))
            before = {name: paths[name].read_bytes() for name in ("simulation", "child", "sibling")}

            stale = _proposal(
                "reauthorized", "role", "simulation", revision=1, content=content
            )
            with self.assertRaises(ConflictError):
                service.propose(stale, device_id="laptop-1", write=True)

            changed = _proposal(
                "reauthorized", "role", "simulation", revision=2,
                content={"instruction": "changed"},
            )
            with self.assertRaises(ConflictError):
                service.propose(changed, device_id="laptop-1", write=True)

            revised = _proposal(
                "reauthorized", "role", "simulation", revision=2, content=content
            )
            service.propose(revised, device_id="laptop-1", write=True)
            plan = service.plan(revised.proposal_id)
            result = service.apply(
                revised.proposal_id,
                expect_digest=plan.digest,
                device_id="laptop-1",
                write=True,
            )
            rule = load_active_rules(root / "policy")[0]
            self.assertEqual(rule.revision, 2)
            self.assertEqual({name: paths[name].read_bytes() for name in before}, before)
            managed_paths = {str(paths[name]) for name in before}
            managed = [item for item in result["operations"] if item["path"] in managed_paths]
            self.assertTrue(all(item["action"] == "reuse" for item in managed))

    def test_rejected_proposal_leaves_open_set_and_backlog(self) -> None:
        """Remove rejected current authority without adding completed history."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            _, service, _ = _fixture(root)
            proposal = _proposal("rejected", "role", "simulation", approved=False)
            service.propose(proposal, device_id="laptop-1", write=True)
            service.reject("rejected", "researcher", DECIDED_AT, device_id="laptop-1", write=True)
            self.assertEqual(load_open_proposals(root / "policy"), ())
            backlog = (root / "EVOLUTION_BACKLOG.md").read_text(encoding="utf-8")
            self.assertIn("No open proposals.", backlog)
            self.assertNotIn("rejected", backlog)
            self.assertTrue(check_backlog_consistency(backlog, ()))

    def test_check_reports_managed_block_drift_without_repair(self) -> None:
        """Detect changed projection bytes and leave the fixture untouched."""

        with tempfile.TemporaryDirectory() as temporary:
            _, service, paths = _fixture(Path(temporary))
            _apply(service, _proposal("drift-check", "role", "simulation"))
            self.assertTrue(service.check()["valid"])
            changed = paths["child"].read_bytes().replace(b"drift-check", b"changed-value")
            paths["child"].write_bytes(changed)
            report = service.check()
            self.assertFalse(report["valid"])
            self.assertEqual(paths["child"].read_bytes(), changed)

    def test_policy_cli_flows_and_exit_codes(self) -> None:
        """Connect every accepted policy leaf with stable success and gate codes."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, _, paths = _fixture(root)
            targets = tuple(str(paths[name]) for name in ("simulation", "child", "sibling"))
            proposal = replace(_proposal("cli-flow", "role", "simulation", approved=False), requested_targets=targets)
            proposal_path = root / "proposal.json"
            proposal_path.write_text(json.dumps(proposal.to_dict()), encoding="utf-8")
            prefix = ["--workspace", str(workspace), "policy"]

            code, _, errors = _run(prefix + ["propose", "--proposal", str(proposal_path), "--write", "--json"])
            self.assertEqual(code, 0, errors)
            code, output, errors = _run(prefix + ["list", "--status", "open", "--json"])
            self.assertEqual(code, 0, errors)
            self.assertEqual(json.loads(output)["count"], 1)
            code, output, errors = _run(prefix + ["plan", "cli-flow", "--json"])
            self.assertEqual(code, 0, errors)
            digest = json.loads(output)["digest"]
            code, _, errors = _run(prefix + ["apply", "cli-flow", "--expect-digest", digest, "--write", "--json"])
            self.assertEqual(code, 2, errors)
            code, _, errors = _run(prefix + ["approve", "cli-flow", "--expect-digest", digest,
                "--actor", "user", "--decided-at", DECIDED_AT, "--write", "--json"])
            self.assertEqual(code, 0, errors)
            code, output, errors = _run(prefix + ["plan", "cli-flow", "--json"])
            self.assertEqual(code, 0, errors)
            self.assertEqual(json.loads(output)["digest"], digest)
            code, _, errors = _run(prefix + ["apply", "cli-flow", "--expect-digest", "0" * 64, "--write", "--json"])
            self.assertEqual(code, 4, errors)
            code, _, errors = _run(prefix + ["apply", "cli-flow", "--expect-digest", digest, "--write", "--json"])
            self.assertEqual(code, 0, errors)
            code, output, errors = _run(prefix + ["check", "--json"])
            self.assertEqual(code, 0, errors)
            self.assertTrue(json.loads(output)["valid"])
            code, output, errors = _run(prefix + ["effective", "--scope", "role:simulation", "--json"])
            self.assertEqual(code, 0, errors)
            self.assertEqual(json.loads(output)["count"], 1)

            pending = replace(_proposal("cli-pending", "project", "simulation", approved=False), requested_targets=targets)
            pending_path = root / "pending.json"
            pending_path.write_text(json.dumps(pending.to_dict()), encoding="utf-8")
            code, _, errors = _run(prefix + ["propose", "--proposal", str(pending_path), "--write", "--json"])
            self.assertEqual(code, 0, errors)
            code, _, errors = _run(prefix + ["plan", "cli-pending", "--json"])
            self.assertEqual(code, 0, errors)

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, _, _ = _fixture(root, device=False)
            proposal = _proposal("missing-device", "role", "simulation", approved=False)
            proposal_path = root / "proposal.json"
            proposal_path.write_text(json.dumps(proposal.to_dict()), encoding="utf-8")
            code, _, errors = _run(
                ["--workspace", str(workspace), "policy", "propose", "--proposal", str(proposal_path), "--json"]
            )
            self.assertEqual(code, 2, errors)
            self.assertIn("device_id", errors)


if __name__ == "__main__":
    unittest.main()
