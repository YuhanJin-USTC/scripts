"""Exercise the no-document inline Case revision boundary end to end."""

from __future__ import annotations

import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from research_workflow.cli.main import main
from research_workflow.domain import CaseDelta, CaseRecord, ProfileReference
from research_workflow.storage import Store, atomic_json_write


SIM_ID = "project/study/case"


def _run(arguments: list[str]) -> tuple[int, dict[str, object] | None, str]:
    output = io.StringIO()
    errors = io.StringIO()
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(errors):
        code = main(arguments)
    return code, json.loads(output.getvalue()) if output.getvalue() else None, errors.getvalue()


def _fixture(root: Path) -> tuple[Path, Store, dict[Path, bytes]]:
    external_roots = {
        "simulation": root / "Simulation",
        "data_simulation": root / "Data",
        "matlab_simulation": root / "Matlab",
        "notes": root / "Notes",
    }
    sentinels: dict[Path, bytes] = {}
    for name, path in external_roots.items():
        path.mkdir()
        sentinel = path / f"{name}.sentinel"
        sentinel.write_bytes(f"unchanged:{name}\n".encode())
        sentinels[sentinel] = sentinel.read_bytes()
    workspace = root / "workspace.toml"
    workspace.write_text(
        f'''schema_version = 1
workspace_id = "fixture"
verified_at = "2026-08-01T00:00:00Z"

[device]
device_id = "laptop-1"

[sim_id]
strategy = "simulation-relative-posix-path"
canonical_root = "simulation"
separator = "/"
case_sensitive = true
same_relative_path_default = true
allow_absolute = false
allow_dot_segments = false

[path_aliases]
policy = "explicit-and-evidence-backed-only"

[roots.simulation]
path = "{external_roots['simulation']}"
kind = "simulation"
mapping = "canonical"
default_access = "project-policy"
verification = "fixture"
verified_at = "2026-08-01T00:00:00Z"

[roots.data_simulation]
path = "{external_roots['data_simulation']}"
kind = "data"
mapping = "same-relative-path"
default_access = "read-only"
verification = "fixture"
verified_at = "2026-08-01T00:00:00Z"

[roots.matlab_simulation]
path = "{external_roots['matlab_simulation']}"
kind = "analysis"
mapping = "same-relative-path"
default_access = "project-policy"
verification = "fixture"
verified_at = "2026-08-01T00:00:00Z"

[roots.notes]
path = "{external_roots['notes']}"
kind = "notes"
mapping = "explicit-link-only"
default_access = "explicit-user-request"
verification = "fixture"
verified_at = "2026-08-01T00:00:00Z"
''',
        encoding="utf-8",
    )
    store = Store(root / "metadata")
    atomic_json_write(
        store.store_path,
        {
            "schema": "research-workflow/store",
            "schema_version": 2,
            "framework_version": "0",
            "store_id": "fixture",
            "created_at": "2026-08-01T00:00:00Z",
            "projects": ["project"],
            "devices": ["laptop-1"],
        },
        write=True,
    )
    atomic_json_write(
        store.project_path("project"),
        {
            "schema": "research-workflow/project",
            "schema_version": 2,
            "project_id": "project",
            "name": "Project",
            "profiles": [],
            "content": {},
            "knowledge_links": [],
        },
        write=True,
    )
    atomic_json_write(
        store.study_path("project", "study"),
        {
            "schema": "research-workflow/study",
            "schema_version": 2,
            "project_id": "project",
            "study_id": "study",
            "name": "Study",
            "sim_prefix": "project/study",
            "profiles": [],
            "content": {},
            "knowledge_links": [],
        },
        write=True,
    )
    for profile_id in ("old", "new"):
        reference = ProfileReference("case", profile_id)
        atomic_json_write(
            store.profile_path(reference),
            {
                "schema": "research-workflow/profile",
                "schema_version": 1,
                "profile_id": profile_id,
                "scope": "case",
                "name": profile_id,
                "content": {f"{profile_id}_profile": True},
            },
            write=True,
        )
    delta = CaseDelta.from_dict(
        {
            "schema": "research-workflow/case-delta",
            "schema_version": 1,
            "sim_id": SIM_ID,
            "project_id": "project",
            "study_id": "study",
            "revision": 1,
            "profiles": [{"scope": "case", "profile_id": "old"}],
            "content": {
                "geometry": {"shape": "box", "obsolete": "remove", "nested": {"keep": 1, "change": "old"}},
                "source": {"digests": ["a"]},
                "numerics": {"cells": 10},
                "type_change": {"old": 1},
                "scalar": "old",
            },
        }
    )
    atomic_json_write(
        store.device_path("laptop-1"),
        {
            "schema": "research-workflow/device",
            "schema_version": 1,
            "device_id": "laptop-1",
            "name": "Laptop 1",
            "onboarded_at": "2026-08-01T00:00:00Z",
        },
        write=True,
    )
    store.append_case_record(
        CaseRecord.build_create(
            delta,
            record_id="20260801T000001Z-laptop-1-create",
            device_id="laptop-1",
            recorded_at="2026-08-01T00:00:01Z",
        ),
        current_device="laptop-1",
        write=True,
    )
    return workspace, store, sentinels


def _digest(store: Store) -> str:
    return store.load_case_delta(SIM_ID).digest


class InlineCaseReviseTests(unittest.TestCase):
    def test_nested_patch_remove_preview_write_and_external_zero_touch(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, store, sentinels = _fixture(root)
            journal_path = store.case_record_paths()[0]
            before_journal = journal_path.read_bytes()
            arguments = [
                "--workspace", str(workspace), "case", "revise", SIM_ID, "--reason", "input-change",
                "--revision", "2",
                "--content-patch-json",
                '{"geometry":{"nested":{"change":"new"}},"source":{"digests":["b","c"]},"numerics":"explicit","type_change":["array"],"scalar":{"now":true}}',
                "--remove-content-path", "/content/geometry/obsolete",
                "--expect-digest", _digest(store), "--json",
            ]
            code, preview, errors = _run(arguments)
            self.assertEqual(code, 0, errors)
            assert preview is not None
            self.assertEqual((preview["input_mode"], preview["revision"]), ("inline-patch", 2))
            self.assertEqual(journal_path.read_bytes(), before_journal)
            operation_paths = {Path(item["path"]) for item in preview["operations"]}
            self.assertEqual(len(operation_paths), 1)
            planned_journal = next(iter(operation_paths))
            self.assertEqual(planned_journal.parent, journal_path.parent)

            code, result, errors = _run(["--workspace", str(workspace), "case", "apply", "--plan", preview["plan_digest"], "--write", "--json"])
            self.assertEqual(code, 0, errors)
            assert result is not None
            revised = store.load_case_delta(SIM_ID)
            self.assertEqual(revised.profiles, (ProfileReference("case", "old"),))
            self.assertEqual(
                revised.content,
                {
                    "geometry": {"shape": "box", "nested": {"keep": 1, "change": "new"}},
                    "source": {"digests": ["b", "c"]},
                    "numerics": "explicit",
                    "type_change": ["array"],
                    "scalar": {"now": True},
                },
            )
            self.assertTrue(journal_path.read_bytes().startswith(before_journal))
            self.assertEqual(len(store.read_case_records()), 2)
            self.assertEqual({Path(item["path"]) for item in result["operations"]}, {planned_journal})
            for path, expected in sentinels.items():
                self.assertEqual(path.read_bytes(), expected)
            self.assertTrue((root / ".research-workflow" / "plans").is_dir())
            self.assertFalse((root / ".research-workflow" / "index.sqlite3").exists())
            residuals = [path for path in root.rglob("*") if ".txn-" in path.name or ".tmp-" in path.name or path.name.startswith(".tmp_")]
            self.assertEqual(residuals, [])

    def test_profiles_replace_clear_and_stale_digest(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, store, _ = _fixture(root)
            cache_path = root / ".research-workflow" / "index.sqlite3"
            cache_path.parent.mkdir()
            cache_path.write_bytes(b"explicit-cache-sentinel\n")
            cache_before = cache_path.read_bytes()
            first_digest = _digest(store)
            preview_args = [
                "--workspace", str(workspace), "case", "revise", SIM_ID, "--reason", "input-change",
                "--revision", "3", "--content-patch-json", '{"future":true}',
                "--expect-digest", first_digest, "--json",
            ]
            code, preview, errors = _run(preview_args)
            self.assertEqual(code, 0, errors)

            replace_args = [
                "--workspace", str(workspace), "case", "revise", SIM_ID, "--reason", "input-change",
                "--revision", "2", "--content-patch-json", "{}",
                "--profiles-json", '[{"scope":"case","profile_id":"new"}]',
                "--expect-digest", first_digest, "--json",
            ]
            code, prepared, errors = _run(replace_args)
            self.assertEqual(code, 0, errors)
            code, _, errors = _run(["--workspace", str(workspace), "case", "apply", "--plan", prepared["plan_digest"], "--write", "--json"])
            self.assertEqual(code, 0, errors)
            self.assertEqual(store.load_case_delta(SIM_ID).profiles, (ProfileReference("case", "new"),))
            code, _, errors = _run(["--workspace", str(workspace), "case", "apply", "--plan", preview["plan_digest"], "--write", "--json"])
            self.assertEqual(code, 4)
            self.assertIn("head changed", errors)

            clear_args = [
                "--workspace", str(workspace), "case", "revise", SIM_ID, "--reason", "input-change",
                "--revision", "3", "--content-patch-json", "{}", "--profiles-json", "[]",
                "--expect-digest", _digest(store), "--json",
            ]
            code, prepared, errors = _run(clear_args)
            self.assertEqual(code, 0, errors)
            code, _, errors = _run(["--workspace", str(workspace), "case", "apply", "--plan", prepared["plan_digest"], "--write", "--json"])
            self.assertEqual(code, 0, errors)
            self.assertEqual(store.load_case_delta(SIM_ID).profiles, ())
            self.assertEqual(cache_path.read_bytes(), cache_before)

    def test_inline_inputs_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, store, _ = _fixture(root)
            prefix = ["--workspace", str(workspace), "case", "revise", SIM_ID, "--reason", "input-change"]
            suffix = ["--expect-digest", _digest(store), "--json"]
            checks = (
                (["--content-patch-json", "{}"], "requires --revision", 2),
                (["--revision", "2"], "requires --content-patch-json", 2),
                (["--revision", "1", "--content-patch-json", "{}"], "must increase", 4),
                (["--revision", "0", "--content-patch-json", "{}"], "positive integer", 2),
                (["--revision", "-1", "--content-patch-json", "{}"], "positive integer", 2),
                (["--revision", "2", "--remove-content-path", ""], "absolute JSON Pointer", 2),
                (["--revision", "2", "--remove-content-path", "/"], "only /content", 2),
                (["--revision", "2", "--remove-content-path", "/sim_id"], "only /content", 2),
                (["--revision", "2", "--remove-content-path", "/content"], "only /content", 2),
                (["--revision", "2", "--remove-content-path", "/content/missing"], "target is missing", 2),
                (["--revision", "2", "--remove-content-path", "/content/a~2b"], "invalid JSON Pointer", 2),
                (["--revision", "2", "--remove-content-path", "/content/scalar", "--remove-content-path", "/content/scalar"], "duplicate", 2),
                (["--revision", "2", "--content-patch-json", '{"geometry":1}', "--remove-content-path", "/content/geometry/shape"], "overlap", 2),
                (["--revision", "2", "--remove-content-path", "/content/geometry", "--remove-content-path", "/content/geometry/shape"], "overlapping", 2),
            )
            for arguments, message, expected_code in checks:
                with self.subTest(arguments=arguments):
                    code, _, errors = _run(prefix + arguments + suffix)
                    self.assertEqual(code, expected_code)
                    self.assertIn(message, errors)

            for value in ("{", "[]", '{"x":1,"x":2}', '{"x":1.5}', '{"x":null}'):
                with self.subTest(json=value):
                    code, _, errors = _run(prefix + ["--revision", "2", "--content-patch-json", value] + suffix)
                    self.assertEqual(code, 2)
                    self.assertTrue(any(fragment in errors for fragment in ("JSON", "object", "forbidden")))

if __name__ == "__main__":
    unittest.main()
