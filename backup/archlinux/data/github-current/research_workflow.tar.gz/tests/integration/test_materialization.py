"""Validate portable materialization without requiring live scientific files."""

from __future__ import annotations

import hashlib
import tempfile
import unittest
from pathlib import Path

from research_workflow.domain import CaseDelta, CaseRecord
from research_workflow.storage import Store, atomic_json_write, materialized_case_document, read_json
from tests.unit.test_case_journals import _thin_store, _delta, _record_id


ROOT = Path(__file__).resolve().parents[2]
SIM_IDS = Store(ROOT / "metadata").list_case_ids()


def _selected(document: dict[str, object], dotted: str) -> object:
    value: object = document
    for part in dotted.split("."):
        if not isinstance(value, dict):
            raise AssertionError(f"non-object before {part}: {dotted}")
        value = value[part]
    return value


class _MaterializationTests(unittest.TestCase):
    """Check portable identity, historical snapshots, profiles, and recovery."""

    @classmethod
    def setUpClass(cls) -> None:
        cls.store = Store(ROOT / "metadata")

    def test_store_identity_and_counts(self) -> None:
        """Require the live registries and derived counts to agree."""

        document = self.store.load_store()
        self.assertEqual(document["schema_version"], 2)
        self.assertNotIn("cases", document)
        self.assertEqual(self.store.list_case_ids(), SIM_IDS)
        report = self.store.validate()
        self.assertTrue(report.valid, report.errors)
        self.assertEqual(report.details["projects"], len(document["projects"]))
        self.assertEqual(report.details["cases"], len(SIM_IDS))
        self.assertEqual(
            report.details["studies"],
            len(list((ROOT / "metadata/studies").rglob("STUDY.json"))),
        )
        self.assertEqual(
            report.details["profiles"],
            len(list((ROOT / "metadata/profiles").rglob("PROFILE.json"))),
        )
        self.assertEqual(report.details["devices"], len(document["devices"]))
        self.assertEqual(report.details["events"], len(self.store.read_events()))

    def test_historical_materialization_is_independent_of_current_input(self) -> None:
        """Keep accepted memory valid when local input changes or is absent."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            source = root / "input.deck"
            source.write_bytes(b"accepted input\n")
            digest = hashlib.sha256(source.read_bytes()).hexdigest()
            project = read_json(store.project_path("project"))
            project["content"]["purpose"] = "fixture research"
            atomic_json_write(store.project_path("project"), project, write=True)
            study = read_json(store.study_path("project", "study"))
            study["content"]["study_purpose"] = "fixture comparison"
            atomic_json_write(store.study_path("project", "study"), study, write=True)
            profile_path = store.root / "profiles/study/numerics/PROFILE.json"
            atomic_json_write(profile_path, {
                "schema": "research-workflow/profile", "schema_version": 1,
                "scope": "study", "profile_id": "numerics", "name": "Numerics",
                "content": {"grid": "accepted", "shared": "profile"},
            }, write=True)
            targets = ("project/study/no-source", "project/study/historical-source")
            for number, target in enumerate(targets, start=1):
                value = _delta(target, 1, "accepted").to_dict()
                value["profiles"] = [{"scope": "study", "profile_id": "numerics"}]
                if number == 2:
                    value["content"]["reproducibility"] = {"input": {
                        "locator": {"kind": "case", "sim_id": target, "path": "input.deck"},
                        "sha256": digest,
                    }}
                record = CaseRecord.build_create(CaseDelta.from_dict(value),
                    record_id=_record_id(number, "materialize"), device_id="laptop-2",
                    recorded_at=f"2026-08-23T01:00:{number:02d}Z")
                store.append_case_record(record, current_device="laptop-2", write=True)
            expected = {target: materialized_case_document(store, target) for target in targets}
            portable = {path: path.read_bytes() for path in store.root.rglob("*") if path.is_file()}
            self.assertNotIn("reproducibility", expected[targets[0]]["content"])
            for state in ("matching", "changed", "missing"):
                if state == "changed":
                    source.write_bytes(b"new local definition\n")
                elif state == "missing":
                    source.rename(root / "unavailable-input.deck")
                with self.subTest(state=state):
                    for target in targets:
                        actual = materialized_case_document(store, target)
                        self.assertEqual(actual, expected[target])
                        self.assertEqual(actual["content"]["purpose"], "fixture research")
                        self.assertEqual(actual["content"]["study_purpose"], "fixture comparison")
                        self.assertEqual(actual["content"]["parameter"], "accepted")
                        self.assertEqual(actual["content"]["grid"], "accepted")
                        self.assertEqual(actual["content"]["shared"], "profile")
                    self.assertEqual(expected[targets[1]]["content"]["reproducibility"]["input"]["sha256"], digest)
                    report = store.validate()
                    self.assertTrue(report.valid, report.errors)
                    self.assertEqual({path: path.read_bytes() for path in store.root.rglob("*") if path.is_file()}, portable)

    def test_materialization_for_all_cases(self) -> None:
        """Resolve every profile and Case source once."""

        for sim_id in SIM_IDS:
            view = materialized_case_document(self.store, sim_id)
            self.assertEqual(view["sim_id"], sim_id)
            self.assertEqual(view["schema"], "research-workflow/case-view")

    def test_recovery_selected_fields_and_source_digests(self) -> None:
        """Match five stable fields and verify the two exact legacy source digests."""

        fixture = read_json(ROOT / "tests/fixtures/recovery/archive-backed/expected.json")
        view = materialized_case_document(self.store, str(fixture["sim_id"]))
        for dotted, expected in fixture["selected_fields"].items():
            self.assertEqual(_selected(view["content"], dotted), expected)
        self.assertFalse(fixture["status_imported"])
        self.assertIn("without a production legacy reader", fixture["fixture_purpose"])
        fixture_root = ROOT / "tests/fixtures/recovery/archive-backed"
        for source in fixture["sources"]:
            path = fixture_root / source["locator"]["path"]
            text = path.read_text(encoding="utf-8")
            self.assertIn(f"Source SHA-256: `{source['sha256']}`", text)


if __name__ == "__main__":
    unittest.main()
