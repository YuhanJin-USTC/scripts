"""Replay portable memory between independent device workspaces."""

from __future__ import annotations

import shutil
import tempfile
import unittest
from pathlib import Path

from research_workflow.core.canonical import canonical_json_bytes
from research_workflow.core.errors import AccessError, ConflictError, DeviceIdentityError, ValidationError
from research_workflow.domain import Event
from research_workflow.index import QueryIndex
from research_workflow.services import CheckpointRequest, CheckpointService, ContextOptions, ContextService
from research_workflow.services.case_changes import CaseChanges
from research_workflow.services.plans import input_binding
from research_workflow.services.queries import MemoryQuery
from research_workflow.storage import Store, append_event
from research_workflow.workspace import WorkspaceRegistry, parse_locator
from tests.integration.test_multi_device_checkpoint import DEVICE_A, DEVICE_B, _delta, _store, _workspace


TARGET = "project/study/case"


def exchange(source: Store, destination: Store):
    """Copy only portable fixture authority, never TOML, plans, or SQLite."""

    for path in source.root.rglob("*"):
        if path.is_file():
            target = destination.root / path.relative_to(source.root)
            target.parent.mkdir(parents=True, exist_ok=True)
            if path.suffix == ".jsonl" and target.exists():
                incoming, existing = path.read_bytes(), target.read_bytes()
                if existing.startswith(incoming):
                    continue
                if not incoming.startswith(existing):
                    raise ConflictError("fixture exchange found divergent device-stream bytes")
            shutil.copyfile(path, target)


def add_root(workspace, root_id, path, *, mapping="none"):
    path.mkdir(parents=True, exist_ok=True)
    text = workspace.config_path.read_text() + f'''
[roots.{root_id}]
path = "{path}"
kind = "analysis"
mapping = "{mapping}"
default_access = "project-policy"
verified_at = "2026-08-23T00:00:00Z"
'''
    workspace.config_path.write_text(text)
    return WorkspaceRegistry(workspace.config_path)


def work(workspace, store, target, request_id, *, summary="Validated result; physical interpretation remains open"):
    request = CheckpointRequest.from_dict({
        "schema": "research-workflow/checkpoint-request", "schema_version": 1,
        "request_id": request_id,
        "event": {"kind": "validation", "summary": summary},
    }, default_target=target)
    return CheckpointService(workspace, store).execute(request, write=True)


class PortableMemoryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.a, self.b = self.root / "device-a", self.root / "device-b"
        self.a.mkdir()
        self.b.mkdir()
        self.wa, self.wb = _workspace(self.a, DEVICE_A), _workspace(self.b, DEVICE_B)
        self.sa = _store(self.a)
        self.sb = Store(self.b / "metadata")
        exchange(self.sa, self.sb)

    def register(self, target=TARGET):
        service = CaseChanges(self.wa, self.sa)
        plan = service.plan("create", _delta(target, 1, "initial"))
        service.confirmation.apply_saved(plan["plan_digest"], write=True)
        return plan

    def test_theory_memory_without_local_theory_and_device_owned_append(self):
        self.wa = add_root(self.wa, "matlab_theory", self.a / "Matlab/Theory")
        first = self.a / "Matlab/Theory/epoch_initial_distribution"
        second = self.a / "Matlab/Theory/tr_vortex_beam"
        first.mkdir()
        second.mkdir()
        work(self.wa, self.sa, str(first), "generator", summary="Photon distribution generator: structural checks passed; physical validation remains open")
        work(self.wa, self.sa, str(second), "vortex", summary="TR vortex field computation: reviewed formula; convergence remains open")
        original = {path: path.read_bytes() for path in self.sa.event_paths()}
        ContextService(self.wa, self.sa).build("root:matlab_theory/epoch_initial_distribution")
        exchange(self.sa, self.sb)
        self.assertFalse(self.wb.cache_path.exists())
        self.assertFalse((self.b / ".research-workflow/plans").exists())
        self.assertNotIn("matlab_theory", self.wb.roots)
        self.assertTrue(self.sb.validate().valid)
        service = ContextService(self.wb, self.sb)
        for path in ("epoch_initial_distribution", "tr_vortex_beam"):
            context = service.build("root:matlab_theory/" + path)
            self.assertFalse(context["mappingAvailable"])
            self.assertEqual(context["progress"]["total"], 1)
            self.assertEqual(context["recent_events"][0]["owner"]["path"], path)
        self.assertEqual(service.build("root:matlab_theory")["progress"]["total"], 0)
        self.assertEqual(service.build("root:matlab_theory", ContextOptions(recursive=True))["progress"]["total"], 2)
        with self.assertRaises((AccessError, ValidationError)):
            parse_locator("root:matlab_theory/epoch_initial_distribution/input.m").resolve_local(self.wb)
        with self.assertRaises((AccessError, ValidationError)):
            input_binding("root:matlab_theory/epoch_initial_distribution/input.m", self.wb)
        with self.assertRaises((AccessError, ValidationError)):
            work(self.wb, self.sb, "root:matlab_theory/epoch_initial_distribution", "refused")
        work(self.wb, self.sb, "root:research_workflow", "device-b-review")
        self.assertEqual(original, {path: path.read_bytes() for path in original})
        b_events = self.sb.read_events(DEVICE_B)
        self.assertEqual(len(b_events), 1)
        with self.assertRaises(DeviceIdentityError):
            append_event(self.sb.root, self.sb.read_events(DEVICE_A)[0], current_device=DEVICE_B, write=True)
        exchange(self.sb, self.sa)
        qa, qb = MemoryQuery(self.wa, self.sa), MemoryQuery(self.wb, self.sb)
        self.assertEqual(qa.events()["events"], qb.events()["events"])
        self.assertNotEqual(self.wa.cache_path, self.wb.cache_path)
        self.assertFalse((self.b / "Matlab").exists())

    def test_prepared_mapping_registration_rename_and_cache_rebuild(self):
        self.wa = add_root(self.wa, "matlab_simulation", self.a / "Matlab/Simulation", mapping="same-relative-path")
        directory = self.a / "Matlab/Simulation" / TARGET
        directory.mkdir(parents=True)
        (self.wa.simulation_root / TARGET).mkdir(parents=True)
        completed = work(self.wa, self.sa, str(directory), "prepared")
        self.assertEqual(completed["event"]["owner"], {"kind": "root", "root_id": "simulation", "path": TARGET})
        explicit = work(self.wa, self.sa, "root:matlab_simulation/" + TARGET, "explicit-mapped")
        memory = MemoryQuery(self.wa, self.sa)
        prepared = ContextService(self.wa, self.sa).build(str(directory))
        self.assertFalse(prepared["registered"])
        self.assertEqual(prepared["progress"]["total"], 2)
        self.assertEqual(memory.events(memory.selector(str(directory)))["total"], 2)
        self.assertEqual(memory.events(memory.selector("root:matlab_simulation/" + TARGET))["total"], 1)
        self.assertEqual(memory.events(memory.selector("root:simulation/" + TARGET))["total"], 1)
        self.wb = add_root(self.wb, "matlab_simulation", self.b / "Analysis", mapping="same-relative-path")
        before = {path: path.read_bytes() for path in self.sa.event_paths()}
        self.register()
        self.assertEqual(before, {path: path.read_bytes() for path in before})
        exchange(self.sa, self.sb)
        initial = ContextService(self.wb, self.sb).build("case:" + TARGET)
        self.assertEqual(initial["progress"]["total"], 2)
        head = self.sb.case_head(TARGET)
        changes = CaseChanges(self.wb, self.sb)
        renamed = "project/study/renamed"
        plan = changes.plan("rename", source=TARGET, destination=renamed, if_match=head.delta_digest)
        changes.confirmation.apply_saved(plan["plan_digest"], write=True)
        work(self.wb, self.sb, renamed, "after-rename")
        exchange(self.sb, self.sa)
        qa, qb = MemoryQuery(self.wa, self.sa), MemoryQuery(self.wb, self.sb)
        left = qa.events(qa.selector("case:" + renamed))
        right = qb.events(qb.selector("case:" + renamed))
        self.assertEqual(left, right)
        self.assertEqual(left["total"], 3)
        self.assertIn(completed["event"]["event_id"], {item["event_id"] for item in left["events"]})
        self.assertIn(explicit["event"]["event_id"], {item["event_id"] for item in left["events"]})
        self.assertTrue(ContextService(self.wb, self.sb).build(TARGET)["redirected"])
        QueryIndex(self.wb.cache_path).rebuild(self.sb)
        self.assertEqual(right, qb.events(qb.selector("case:" + renamed)))
        self.assertEqual(before, {path: path.read_bytes() for path in before})
        self.assertEqual(self.sa.validate().valid, self.sb.validate().valid)
        self.assertTrue(self.sa.validate().valid)

    def test_local_plan_transplant_and_stale_synced_head_refuse(self):
        self.register()
        exchange(self.sa, self.sb)
        a_changes, b_changes = CaseChanges(self.wa, self.sa), CaseChanges(self.wb, self.sb)
        digest = self.sa.case_head(TARGET).delta_digest
        a_plan = a_changes.plan("revise", _delta(TARGET, 2, "from-a"), if_match=digest, reason="input-change")
        b_plan = b_changes.plan("revise", _delta(TARGET, 2, "from-b"), if_match=digest, reason="input-change")
        path = a_changes.confirmation.plans.root / (a_plan["plan_digest"] + ".json")
        destination = b_changes.confirmation.plans.root / path.name
        shutil.copyfile(path, destination)
        with self.assertRaises((ConflictError, DeviceIdentityError)):
            b_changes.confirmation.apply_saved(a_plan["plan_digest"], write=True)
        a_changes.confirmation.apply_saved(a_plan["plan_digest"], write=True)
        exchange(self.sa, self.sb)
        with self.assertRaises(ConflictError):
            b_changes.confirmation.apply_saved(b_plan["plan_digest"], write=True)
        self.assertEqual(self.sb.case_head(TARGET).delta.content, {"value": "from-a"})

    def test_mapped_case_ancestor_checkpoint_and_context_use_same_root_owner(self):
        self.register()
        self.wa = add_root(self.wa, "matlab_simulation", self.a / "Matlab/Simulation", mapping="same-relative-path")
        parent = "project/study"
        mapped = self.a / "Matlab/Simulation" / parent
        mapped.mkdir(parents=True)
        (self.wa.simulation_root / parent).mkdir(parents=True)
        completed = work(self.wa, self.sa, str(mapped), "parent-result")
        context = ContextService(self.wa, self.sa).build(str(mapped))
        self.assertEqual(context["selector"], completed["event"]["owner"])
        self.assertEqual(context["selector"], {"kind": "root", "root_id": "simulation", "path": parent})
        self.assertEqual(context["progress"]["total"], 1)
        self.assertNotIn("case", context)
        self.assertEqual(self.sa.load_study("project", "study").sim_prefix, parent)
        self.assertEqual(ContextService(self.wa, self.sa).build("study:project#study")["progress"]["total"], 0)

    def test_real_fork_between_independent_stores_fails_closed(self):
        self.register()
        exchange(self.sa, self.sb)
        for workspace, store, value in ((self.wa, self.sa, "a"), (self.wb, self.sb, "b")):
            service = CaseChanges(workspace, store)
            plan = service.plan("revise", _delta(TARGET, 2, value), if_match=store.case_head(TARGET).delta_digest, reason="input-change")
            service.confirmation.apply_saved(plan["plan_digest"], write=True)
        exchange(self.sb, self.sa)
        with self.assertRaises(ConflictError):
            ContextService(self.wa, self.sa).build(TARGET)

    def test_conflicting_event_id_after_portable_exchange_refuses(self):
        work(self.wa, self.sa, "root:research_workflow", "one")
        exchange(self.sa, self.sb)
        event = self.sb.read_events()[0]
        conflicting = Event.from_dict({**event.to_dict(), "summary": "Conflicting bytes"})
        path = self.sb.root / "events" / DEVICE_A / "2026-01.jsonl"
        path.write_bytes(canonical_json_bytes(conflicting.to_dict()) + b"\n")
        with self.assertRaises(ConflictError):
            MemoryQuery(self.wb, self.sb).events()


if __name__ == "__main__":
    unittest.main()
