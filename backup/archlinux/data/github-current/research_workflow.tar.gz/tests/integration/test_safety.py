"""Validate Phase 4 source parsing and protected-scope safety gates."""

from __future__ import annotations

import re
import subprocess
import unittest
from pathlib import Path

from research_workflow.services import ContextOptions, ContextService
from research_workflow.storage import Store, materialized_case_document, read_json
from research_workflow.workspace import WorkspaceRegistry


ROOT = Path(__file__).resolve().parents[2]
SIM_IDS = Store(ROOT / "metadata").list_case_ids()
QED_NUMERICAL_HEATING_IDS = [
    "qed_cone_pair/numerical_heating_v2/20260715_nh_200_nc",
    "qed_cone_pair/numerical_heating_v2/20260715_nh_400_nc",
    "qed_cone_pair/numerical_heating_v2/20260715_nh_600_nc",
    "qed_cone_pair/numerical_heating_v2/20260715_nh_800_nc",
]


def _portable_strings(value: object) -> list[str]:
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [text for item in value for text in _portable_strings(item)]
    if isinstance(value, dict):
        return [text for item in value.values() for text in _portable_strings(item)]
    return []


def _active_lines(path: Path) -> list[str]:
    return [
        line.strip()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]


class _SafetyTests(unittest.TestCase):
    """Check portable bytes, unknown status, active parsing, and absent products."""

    @classmethod
    def setUpClass(cls) -> None:
        cls.store = Store(ROOT / "metadata")
        cls.workspace = WorkspaceRegistry(ROOT / "workspace.toml")

    def test_portable_metadata_has_no_absolute_paths(self) -> None:
        """Reject POSIX or drive-absolute strings in the live portable documents."""

        documents = [self.store.load_store()]
        for pattern in (
            "metadata/projects/**/PROJECT.json",
            "metadata/studies/**/STUDY.json",
            "metadata/profiles/**/PROFILE.json",
        ):
            documents.extend(read_json(path) for path in sorted(ROOT.glob(pattern)))
        for sim_id in SIM_IDS:
            documents.append(self.store.load_case_delta(sim_id).to_dict())
        for document in documents:
            for text in _portable_strings(document):
                self.assertFalse(text.startswith("/"), text)
                self.assertIsNone(re.match(r"^[A-Za-z]:[\\/]", text), text)

    def test_status_stays_unknown_without_events(self) -> None:
        """Project unknown tracks only when explicitly requested without evidence."""

        sim_id = "lbw_plasma_mirror/w_scanning_2d_v1/20260814_baseline_v1"
        target = self.workspace.local_case_path("matlab_simulation", sim_id)
        context = ContextService(self.workspace, self.store).build(
            str(target), ContextOptions(view="compact", recent=3)
        )
        self.assertNotIn("status", context)
        context = ContextService(self.workspace, self.store).build(
            str(target), ContextOptions(view="compact", recent=3, include=("status",))
        )
        status = context["status"]
        self.assertEqual(
            {track: status[track]["state"] for track in status},
            {"run": "unknown", "data": "unknown", "analysis": "unknown"},
        )

    def test_active_epoch_blocks_and_runners_are_structural(self) -> None:
        """Check recorded live sources and account for absent optional metadata."""

        epoch_cases = checked = not_recorded = incomplete = 0
        for sim_id in SIM_IDS:
            view = materialized_case_document(self.store, sim_id)
            if not str(view["content"].get("identity", {}).get("simulation_code", "")).startswith("EPOCH"):
                continue
            epoch_cases += 1
            if "reproducibility" not in view["content"]:
                not_recorded += 1
                continue
            sources = view["content"]["reproducibility"]
            self.assertIsInstance(sources, dict, sim_id)
            if "input" not in sources or "runner" not in sources:
                incomplete += 1
                continue
            case_path = self.workspace.local_case_path("simulation", sim_id)
            input_path = case_path / sources["input"]["locator"]["path"]
            runner_path = case_path / sources["runner"]["locator"]["path"]
            stack: list[str] = []
            for line in _active_lines(input_path):
                begin = re.fullmatch(r"begin:([A-Za-z0-9_]+)", line)
                end = re.fullmatch(r"end:([A-Za-z0-9_]+)", line)
                if begin:
                    stack.append(begin.group(1))
                elif end:
                    self.assertTrue(stack, sim_id)
                    self.assertEqual(stack.pop(), end.group(1), sim_id)
            self.assertEqual(stack, [], sim_id)
            result = subprocess.run(
                ["sh", "-n", str(runner_path)],
                check=False,
                capture_output=True,
                text=True,
            )
            self.assertEqual(result.returncode, 0, f"{sim_id}: {result.stderr}")
            checked += 1
        self.assertGreater(checked, 0, "no recorded EPOCH sources were checked")
        self.assertEqual(epoch_cases, checked + not_recorded + incomplete)
        print(
            f"[source-structure] EPOCH={epoch_cases} checked={checked} "
            f"not-recorded={not_recorded} incomplete={incomplete}"
        )

    def test_numerical_heating_scan_is_mechanically_equal_except_density(self) -> None:
        """Confirm one active input variable and one active runner-name delta."""

        selected = QED_NUMERICAL_HEATING_IDS
        normalized_inputs: list[str] = []
        normalized_runners: list[str] = []
        values: list[str] = []
        for sim_id in selected:
            case_path = self.workspace.local_case_path("simulation", sim_id)
            active = _active_lines(case_path / "input.deck")
            density = [line for line in active if line.startswith("reflector_density_r =")]
            self.assertEqual(len(density), 1)
            values.append(density[0].split("=", 1)[1].strip())
            normalized_inputs.append("\n".join("reflector_density_r = <scan>" if line.startswith("reflector_density_r =") else line for line in active))
            runner = (case_path / "epoch_jobsub.sh").read_text(encoding="utf-8").splitlines()
            normalized_runners.append("\n".join("#SBATCH -J <case>" if line.startswith("#SBATCH -J ") else line for line in runner))
        self.assertEqual(values, ["200.0 * n_c", "400.0 * n_c", "600.0 * n_c", "800.0 * n_c"])
        self.assertEqual(len(set(normalized_inputs)), 1)
        self.assertEqual(len(set(normalized_runners)), 1)

    def test_forbidden_products_and_legacy_runtime_are_absent(self) -> None:
        """Keep materialized Cards, cache, and legacy runtime absent."""

        for path in (ROOT / "metadata/materialized", ROOT / "metadata/policies"):
            self.assertFalse(path.exists(), path)
        self.assertNotIn(".research-workflow", {path.name for path in (ROOT / "metadata").iterdir()})
        self.assertIn(".research-workflow/", (ROOT / ".gitignore").read_text(encoding="utf-8"))
        self.assertFalse((ROOT / "metadata/cases").exists())
        source_names = {path.name.lower() for path in (ROOT / "src/research_workflow").rglob("*.py")}
        self.assertFalse(any("legacy" in name or "v21" in name or name.startswith("v2") for name in source_names))


if __name__ == "__main__":
    unittest.main()
