"""Test sequential multi-device checkpoint safety without Git or network."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest import mock

from research_workflow.core.errors import ConflictError, DeviceIdentityError, ValidationError
from research_workflow.domain import CaseDelta, CaseRecord, reduce_case_records
from research_workflow.services import CheckpointRequest, CheckpointService
from tests.integration.confirmation_helpers import apply_request
from research_workflow.storage import Store, atomic_json_write
from research_workflow.workspace import WorkspaceRegistry


DEVICE_A = "laptop-a"
DEVICE_B = "laptop-b"


def _workspace(root: Path, device_id: str) -> WorkspaceRegistry:
    simulation = root / "Simulation"
    data = root / "Data"
    notes = root / "Notes"
    for path in (simulation, data, notes):
        path.mkdir(exist_ok=True)
    config = root / f"workspace-{device_id}.toml"
    config.write_text(
        f'''schema_version = 1
workspace_id = "fixture"
verified_at = "2026-08-23T00:00:00Z"

[device]
device_id = "{device_id}"

[sim_id]
strategy = "simulation-relative-posix-path"
canonical_root = "simulation"
separator = "/"
case_sensitive = true
same_relative_path_default = true
allow_absolute = false
allow_dot_segments = false

[path_aliases]
policy = "explicit-and-evidence-backed-only"

[roots.simulation]
path = "{simulation}"
kind = "simulation"
mapping = "canonical"
default_access = "project-policy"
verification = "fixture"
verified_at = "2026-08-23T00:00:00Z"

[roots.data_simulation]
path = "{data}"
kind = "data"
mapping = "same-relative-path"
default_access = "read-only"
verification = "fixture"
verified_at = "2026-08-23T00:00:00Z"

[roots.notes]
path = "{notes}"
kind = "notes"
mapping = "explicit-link-only"
default_access = "explicit-user-request"
verification = "fixture"
verified_at = "2026-08-23T00:00:00Z"
''',
        encoding="utf-8",
    )
    return WorkspaceRegistry(config)


def _store(root: Path) -> Store:
    metadata = root / "metadata"
    atomic_json_write(
        metadata / "STORE.json",
        {
            "schema": "research-workflow/store",
            "schema_version": 2,
            "framework_version": "0",
            "store_id": "multi-device-fixture",
            "created_at": "2026-08-23T00:00:00Z",
            "projects": ["project"],
            "devices": [DEVICE_A, DEVICE_B],
        },
        write=True,
    )
    atomic_json_write(
        metadata / "projects/project/PROJECT.json",
        {
            "schema": "research-workflow/project",
            "schema_version": 1,
            "project_id": "project",
            "name": "Project",
            "profiles": [],
            "content": {},
        },
        write=True,
    )
    atomic_json_write(
        metadata / "studies/project/study/STUDY.json",
        {
            "schema": "research-workflow/study",
            "schema_version": 1,
            "project_id": "project",
            "study_id": "study",
            "name": "Study",
            "sim_prefix": "project/study",
            "profiles": [],
            "content": {},
        },
        write=True,
    )
    for device_id in (DEVICE_A, DEVICE_B):
        atomic_json_write(
            metadata / f"devices/{device_id}.json",
            {
                "schema": "research-workflow/device",
                "schema_version": 1,
                "device_id": device_id,
                "name": device_id,
                "onboarded_at": "2026-08-23T00:00:00Z",
            },
            write=True,
        )
    return Store(metadata)


def _delta(sim_id: str, revision: int, value: str) -> CaseDelta:
    return CaseDelta.from_dict(
        {
            "schema": "research-workflow/case-delta",
            "schema_version": 1,
            "sim_id": sim_id,
            "project_id": "project",
            "study_id": "study",
            "revision": revision,
            "profiles": [],
            "content": {"value": value},
        }
    )


def _create(store: Store, sim_id: str, *, second: int) -> CaseDelta:
    delta = _delta(sim_id, 1, "initial")
    recorded_at = f"2026-08-23T00:00:{second:02d}Z"
    store.append_case_record(
        CaseRecord.build_create(
            delta,
            record_id=f"20260823T0000{second:02d}Z-{DEVICE_A}-create-{second}",
            device_id=DEVICE_A,
            recorded_at=recorded_at,
        ),
        current_device=DEVICE_A,
        write=True,
    )
    return delta


def _request(sim_id: str, digest: str, request_id: str) -> CheckpointRequest:
    return CheckpointRequest.from_dict(
        {
            "schema": "research-workflow/checkpoint-request",
            "schema_version": 1,
            "request_id": request_id,
            "changes": [
                {
                    "target": sim_id,
                    "if_match": digest,
                    "reason": "input-change", "responsibility": "simulation-definition",
                    "content_patch": {"checkpoint": request_id},
                }
            ],
            "event": {
                "owner": {"kind": "case", "sim_id": sim_id},
                "kind": "modification",
                "summary": f"Applied {request_id}",
            },
        }
    )


class MultiDeviceCheckpointTests(unittest.TestCase):
    def test_case_changes_require_explicit_if_match(self) -> None:
        with self.assertRaisesRegex(ValidationError, "requires explicit if_match"):
            CheckpointRequest.from_dict(
                {
                    "schema": "research-workflow/checkpoint-request",
                    "schema_version": 1,
                    "changes": [{"target": "project/study/case", "content_patch": {"x": 1}}],
                    "event": {"kind": "modification", "summary": "Missing digest"},
                }
            )
        with self.assertRaisesRegex(ValidationError, "cannot be not-specified"):
            _request("project/study/case", "not-specified", "placeholder")
        event_only = CheckpointRequest.from_dict(
            {
                "schema": "research-workflow/checkpoint-request",
                "schema_version": 1,
                "changes": [],
                "event": {
                    "owner": {"kind": "root", "root_id": "research_workflow"},
                    "kind": "modification",
                    "summary": "Event only",
                },
            }
        )
        self.assertEqual(event_only.changes, ())

    def test_a_then_b_sequentially_revise_the_same_case(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _store(root)
            workspace_a = _workspace(root, DEVICE_A)
            workspace_b = _workspace(root, DEVICE_B)
            initial = _create(store, "project/study/shared", second=1)
            with mock.patch(
                "research_workflow.services.checkpoint.utc_now",
                side_effect=("2026-08-23T01:00:00Z", "2026-08-23T01:01:00Z"),
            ):
                apply_request(CheckpointService(workspace_a, store), _request(initial.sim_id, initial.digest, "device-a"))
                after_a = store.case_head(initial.sim_id)
                assert after_a is not None
                apply_request(CheckpointService(workspace_b, store), _request(initial.sim_id, after_a.delta_digest, "device-b"))
            final = store.case_head(initial.sim_id)
            assert final is not None
            self.assertEqual(final.revision, 3)
            self.assertEqual(final.content["checkpoint"], "device-b")
            self.assertEqual({record.device_id for record in store.read_case_records("project", "study")}, {DEVICE_A, DEVICE_B})

    def test_devices_revise_different_cases_and_event_streams_merge(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _store(root)
            workspace_a = _workspace(root, DEVICE_A)
            workspace_b = _workspace(root, DEVICE_B)
            left = _create(store, "project/study/left", second=1)
            right = _create(store, "project/study/right", second=2)
            with mock.patch(
                "research_workflow.services.checkpoint.utc_now",
                side_effect=("2026-08-23T02:00:00Z", "2026-08-23T02:01:00Z"),
            ):
                apply_request(CheckpointService(workspace_a, store), _request(left.sim_id, left.digest, "left-a"))
                apply_request(CheckpointService(workspace_b, store), _request(right.sim_id, right.digest, "right-b"))
            self.assertEqual(store.case_head(left.sim_id).revision, 2)  # type: ignore[union-attr]
            self.assertEqual(store.case_head(right.sim_id).revision, 2)  # type: ignore[union-attr]
            events = store.read_events()
            self.assertEqual(len(events), 2)
            self.assertEqual({event.device_id for event in events}, {DEVICE_A, DEVICE_B})
            self.assertEqual(len({event.event_id for event in events}), 2)

    def test_stale_device_b_digest_is_rejected_after_device_a_write(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _store(root)
            workspace_a = _workspace(root, DEVICE_A)
            workspace_b = _workspace(root, DEVICE_B)
            initial = _create(store, "project/study/stale", second=1)
            stale_b = _request(initial.sim_id, initial.digest, "stale-b")
            with mock.patch(
                "research_workflow.services.checkpoint.utc_now",
                return_value="2026-08-23T03:00:00Z",
            ):
                apply_request(CheckpointService(workspace_a, store), _request(initial.sim_id, initial.digest, "fresh-a"))
            with self.assertRaisesRegex(ConflictError, "if_match is stale"):
                CheckpointService(workspace_b, store).plan(stale_b)

    def test_apply_rejects_changed_journal_bytes_and_device_identity(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _store(root)
            workspace_a = _workspace(root, DEVICE_A)
            workspace_b = _workspace(root, DEVICE_B)
            initial = _create(store, "project/study/bound", second=1)
            service_a = CheckpointService(workspace_a, store)
            with mock.patch(
                "research_workflow.services.checkpoint.utc_now",
                return_value="2026-08-23T04:00:00Z",
            ):
                plan = service_a.plan(_request(initial.sim_id, initial.digest, "bound-a"))
            with self.assertRaisesRegex(DeviceIdentityError, "plan device_id differs"):
                CheckpointService(workspace_b, store).apply(plan, write=True)
            unrelated = _delta("project/study/unrelated", 1, "new")
            store.append_case_record(
                CaseRecord.build_create(
                    unrelated,
                    record_id="20260823T040100Z-laptop-a-unrelated",
                    device_id=DEVICE_A,
                    recorded_at="2026-08-23T04:01:00Z",
                ),
                current_device=DEVICE_A,
                write=True,
            )
            with self.assertRaisesRegex(ConflictError, "dependency bytes changed"):
                service_a.apply(plan, write=True)

    def test_unonboarded_device_cannot_plan_case_write(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _store(root)
            initial = _create(store, "project/study/onboard", second=1)
            workspace = _workspace(root, "laptop-c")
            with self.assertRaisesRegex(DeviceIdentityError, "not registered"):
                CheckpointService(workspace, store).plan(
                    _request(initial.sim_id, initial.digest, "device-c")
                )

    def test_reducer_rejects_sibling_fork_and_conflicting_record_id(self) -> None:
        initial = _delta("project/study/fork", 1, "initial")
        created = CaseRecord.build_create(
            initial,
            record_id="20260823T050000Z-laptop-a-create",
            device_id=DEVICE_A,
            recorded_at="2026-08-23T05:00:00Z",
        )
        branch_a = CaseRecord.build_revise(
            _delta(initial.sim_id, 2, "a"),
            previous_digest=initial.digest,
            record_id="20260823T050100Z-laptop-a-revise",
            device_id=DEVICE_A,
            recorded_at="2026-08-23T05:01:00Z",
        )
        branch_b = CaseRecord.build_revise(
            _delta(initial.sim_id, 2, "b"),
            previous_digest=initial.digest,
            record_id="20260823T050200Z-laptop-b-revise",
            device_id=DEVICE_B,
            recorded_at="2026-08-23T05:02:00Z",
        )
        with self.assertRaisesRegex(ConflictError, "fork or stale"):
            reduce_case_records((created, branch_a, branch_b))
        duplicate_id = CaseRecord.build_revise(
            _delta(initial.sim_id, 2, "different"),
            previous_digest=initial.digest,
            record_id=branch_a.record_id,
            device_id=DEVICE_A,
            recorded_at=branch_a.recorded_at,
        )
        with self.assertRaisesRegex(ConflictError, "conflicting duplicate Case record ID"):
            reduce_case_records((created, branch_a, duplicate_id))


if __name__ == "__main__":
    unittest.main()
