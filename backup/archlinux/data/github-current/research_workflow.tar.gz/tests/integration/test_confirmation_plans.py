"""Exercise explicit Case confirmation and independent work recording."""

from __future__ import annotations

import contextlib
import io
import json
import multiprocessing
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from research_workflow.cli.main import main
from research_workflow.core.errors import AccessError, ConflictError, DeviceIdentityError, ValidationError
from research_workflow.domain import CaseDelta, CaseRecord, Project, Study
from research_workflow.services import CheckpointRequest, CheckpointService
from research_workflow.services.case_changes import CaseChanges
from research_workflow.services.plans import ConfirmationPlans
from research_workflow.storage import atomic_json_write, read_json, case_journal_path
from research_workflow.core.canonical import canonical_json_bytes
from research_workflow.storage.locking import authority_lock
from research_workflow.workspace import WorkspaceRegistry

from tests.integration.test_checkpoint import _append_case, _workspace
from tests.unit.test_case_journals import _delta, _thin_store


TARGET = "project/study/case"


def cli(workspace, *arguments):
    output, errors = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(errors):
        code = main(["--workspace", str(workspace.config_path), *arguments, "--json"])
    return code, json.loads(output.getvalue()) if output.getvalue() else {}, errors.getvalue()


def request(*, target=None, changes=(), request_id="result"):
    return CheckpointRequest.from_dict({
        "schema": "research-workflow/checkpoint-request", "schema_version": 1,
        "request_id": request_id, "changes": list(changes),
        "event": {"kind": "validation", "summary": "Numerical convergence checked; physical interpretation remains open."},
    }, default_target=target)


def change(delta, *, value="new"):
    return {"target": delta.sim_id, "if_match": delta.digest,
            "reason": "input-change", "responsibility": "simulation-definition",
            "content_patch": {"parameter": value}}


def _process_cli(workspace_path, arguments, connection):
    connection.send("ready")
    workspace = WorkspaceRegistry(workspace_path)
    connection.send(cli(workspace, *arguments))
    connection.close()


class ConfirmationPlanTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.store = _thin_store(self.root)
        self.workspace = _workspace(self.root, "laptop-2")
        self.initial = _delta(TARGET, 1, "initial")
        _append_case(self.store, self.initial, second=1)
        self.service = CaseChanges(self.workspace, self.store)
        self.plans = self.service.confirmation

    def authority(self):
        return {str(path.relative_to(self.store.root)): path.read_bytes() for path in self.store.root.rglob("*") if path.is_file()}

    def revise(self, value="new", **kwargs):
        head = self.store.case_head(TARGET)
        proposed = _delta(TARGET, head.revision + 1, value)
        return self.service.plan("revise", proposed, if_match=head.delta_digest, reason="input-change", **kwargs)

    def test_case_event_only_needs_no_if_match_or_revision(self):
        service = CheckpointService(self.workspace, self.store)
        prepared = service.plan(request(target=TARGET))
        self.assertEqual(prepared["heads"], {})
        self.assertEqual(prepared["records"], [])
        self.assertFalse(prepared["confirmation_required"])
        other = self.revise()
        self.plans.apply(other, write=True)
        service.apply(prepared, write=True)
        self.assertEqual(self.store.case_head(TARGET).revision, 2)
        self.assertEqual(len(self.store.read_events()), 1)
        self.assertEqual(self.store.read_events()[0].owner.identity, TARGET)

    def test_work_before_registration_preserves_owner_and_event_bytes(self):
        target = "project/study/new"
        directory = self.workspace.simulation_root / target
        directory.mkdir(parents=True)
        service = CheckpointService(self.workspace, self.store)
        result = service.execute(request(target=str(directory)), write=True)
        self.assertEqual(result["event"]["owner"], {"kind": "root", "root_id": "simulation", "path": target})
        before = {path: path.read_bytes() for path in self.store.event_paths()}
        registration = self.service.plan("create", _delta(target, 1, "registered"))
        self.assertEqual(self.store.case_state(target)["state"], "missing")
        self.plans.apply_saved(registration["plan_digest"], write=True)
        self.assertEqual(before, {path: path.read_bytes() for path in self.store.event_paths()})
        self.assertEqual(self.store.case_state(target)["state"], "active")

    def test_every_old_case_cli_write_and_checkpoint_shorthand_is_closed(self):
        before = self.authority()
        commands = [
            ("case", "create", "project/study/new", "--project-id", "project", "--study-id", "study"),
            ("case", "revise", TARGET, "--revision", "2", "--reason", "input-change", "--content-patch-json", '{"parameter":"new"}', "--expect-digest", self.initial.digest),
            ("case", "rename", TARGET, "project/study/renamed", "--expect-digest", self.initial.digest),
            ("case", "delete", TARGET, "--expect-digest", self.initial.digest),
        ]
        for command in commands:
            with self.subTest(command=command):
                code, _, error = cli(self.workspace, *command, "--write")
                self.assertEqual(code, 2)
                self.assertIn("case apply", error)
                self.assertEqual(self.authority(), before)
        body = {"schema": "research-workflow/checkpoint-request", "schema_version": 1,
                "changes": [change(self.initial)], "event": {"kind": "validation", "summary": "Checked"}}
        code, _, error = cli(self.workspace, "checkpoint", TARGET, "--request-json", json.dumps(body), "--write")
        self.assertEqual(code, 2)
        self.assertIn("confirmation", error)
        body.pop("changes")
        body["content_patch"] = {"parameter": "new"}
        body["if_match"] = self.initial.digest
        code, _, error = cli(self.workspace, "checkpoint", TARGET, "--request-json", json.dumps(body))
        self.assertEqual(code, 2)
        self.assertIn("unsupported fields", error)
        self.assertEqual(self.authority(), before)

    def test_saved_checkpoint_alias_refuses_ignored_request_and_target(self):
        service = CheckpointService(self.workspace, self.store)
        prepared = service.plan(request(target=TARGET))
        body = {"schema": "research-workflow/checkpoint-request", "schema_version": 1,
                "event": {"kind": "validation", "summary": "Different work"}}
        before = self.authority()
        code, _, error = cli(self.workspace, "checkpoint", TARGET, "--request-json", json.dumps(body), "--expect-digest", prepared["plan_digest"], "--write")
        self.assertEqual(code, 2)
        self.assertIn("cannot be combined", error)
        self.assertEqual(self.authority(), before)

    def test_noop_checks_head_first_and_profiles_remain_part_of_definition(self):
        prepared = self.revise("initial")
        self.assertEqual(prepared["records"], [])
        self.assertEqual(prepared["cases"][0]["action"], "no-op")
        before = self.authority()
        self.plans.apply(prepared, write=True)
        self.assertEqual(self.authority(), before)
        self.assertEqual(self.plans.apply(prepared, write=True)["status"], "already-applied")
        self.plans.apply(self.revise(), write=True)
        with self.assertRaisesRegex(ConflictError, "expect_digest"):
            self.service.plan("revise", _delta(TARGET, 3, "new"), if_match=self.initial.digest, reason="metadata-correction")
        profile_path = self.store.root / "profiles/case/p/PROFILE.json"
        atomic_json_write(profile_path, {"schema": "research-workflow/profile", "schema_version": 1,
                          "scope": "case", "profile_id": "p", "name": "p", "content": {}}, write=True)
        current = self.store.case_head(TARGET)
        proposed = CaseDelta.from_dict({**current.delta.to_dict(), "revision": 3, "profiles": [{"scope": "case", "profile_id": "p"}]})
        plan = self.service.plan("revise", proposed, if_match=current.delta_digest, reason="metadata-correction")
        self.assertEqual(len(plan["records"]), 1)
        document = read_json(profile_path)
        document["name"] = "changed dependency"
        atomic_json_write(profile_path, document, write=True)
        with self.assertRaisesRegex(ConflictError, "dependency bytes changed"):
            self.plans.apply(plan, write=True)

    def test_project_study_and_input_changes_invalidate_saved_preview(self):
        for path in [self.store.project_path("project"), self.store.study_path("project", "study")]:
            with self.subTest(path=path):
                plan = self.revise()
                document = read_json(path)
                document["name"] += " changed"
                atomic_json_write(path, document, write=True)
                with self.assertRaisesRegex(ConflictError, "dependency bytes changed"):
                    self.plans.apply(plan, write=True)
        directory = self.workspace.simulation_root / TARGET
        directory.mkdir(parents=True)
        configuration = directory / "input.deck"
        configuration.write_text("include = missing.deck\n" + "# text\n" * 160000)
        plan = self.revise("initial", input_configs=[str(configuration)])
        self.assertGreater(plan["inputs"][str(configuration)]["bytes"], 1024 * 1024)
        self.assertEqual(plan["records"], [])
        configuration.write_text("include = other-missing.deck\n")
        with self.assertRaisesRegex(ConflictError, "input configuration changed"):
            self.plans.apply(plan, write=True)
        fresh = self.revise("initial", input_configs=[str(configuration)])
        self.plans.apply(fresh, write=True)
        self.assertEqual(self.store.case_head(TARGET).revision, 1)
        self.assertNotIn("sha256", json.dumps(self.store.load_case_delta(TARGET).to_dict()))

    def test_input_selection_rejects_data_binary_and_outside_scope(self):
        data = self.workspace.roots["data_simulation"].path / "parameters.txt"
        data.write_text("n=1\n")
        binary = self.workspace.simulation_root / "binary"
        binary.write_bytes(b"abc\x00")
        outside = self.root / "outside.txt"
        outside.write_text("n=1\n")
        for selection in [str(data), str(binary), str(outside)]:
            with self.subTest(selection=selection):
                with self.assertRaises((AccessError, ValidationError)):
                    self.revise(input_configs=[selection])

    def test_exact_retry_receipt_partial_application_and_lifecycle(self):
        plan = self.revise()
        self.plans.apply(plan, write=True)
        before = self.authority()
        self.assertTrue(self.plans.plans.receipt(plan["plan_digest"]).is_file())
        self.assertEqual(self.plans.apply_saved(plan["plan_digest"], write=True)["status"], "already-applied")
        self.assertEqual(before, self.authority())
        second = self.revise("third")
        self.store.append_case_record(CaseRecord.from_dict(second["records"][0]), current_device="laptop-2", write=True)
        with self.assertRaisesRegex(ConflictError, "partial application"):
            self.plans.apply(second, write=True)
        head = self.store.case_head(TARGET)
        rename = self.service.plan("rename", source=TARGET, destination="project/study/renamed", if_match=head.delta_digest)
        self.assertEqual(rename["records"][0]["action"], "rename")
        self.plans.apply(rename, write=True)
        renamed = self.store.case_head("project/study/renamed")
        deletion = self.service.plan("delete", source=renamed.sim_id, if_match=renamed.delta_digest)
        self.assertEqual(deletion["records"][0]["action"], "delete")
        self.plans.apply(deletion, write=True)
        for target in [TARGET, renamed.sim_id]:
            with self.assertRaisesRegex(ValidationError, "must be active"):
                CheckpointService(self.workspace, self.store).execute(request(target=target), write=True)

    def test_event_writer_requires_membership_and_matching_document(self):
        document = self.store.load_store()
        document["devices"] = []
        atomic_json_write(self.store.store_path, document, write=True)
        code, _, error = cli(self.workspace, "event", "record", "root:research_workflow", "--kind", "validation", "--summary", "Unregistered writer", "--write")
        self.assertEqual(code, 2)
        self.assertIn("not registered", error)
        self.assertEqual(self.store.read_events(), [])
        with self.assertRaises(DeviceIdentityError):
            self.revise()

    def test_actual_matlab_target_and_workspace_identity_are_bound(self):
        matlab = self.root / "Matlab"
        matlab.mkdir()
        text = self.workspace.config_path.read_text() + f'''\n[roots.matlab_simulation]
path = "{matlab}"
kind = "analysis"
mapping = "same-relative-path"
default_access = "project-policy"
verified_at = "2026-08-23T00:00:00Z"
'''
        self.workspace.config_path.write_text(text)
        workspace = WorkspaceRegistry(self.workspace.config_path)
        arguments = ("case", "revise", str(matlab / TARGET), "--reason", "input-change", "--revision", "2", "--content-patch-json", '{"parameter":"changed"}', "--expect-digest", self.initial.digest)
        code, prepared, error = cli(workspace, *arguments)
        self.assertEqual(code, 0, error)
        service = CheckpointService(workspace, self.store)
        raw_change = change(self.initial)
        raw_change["target"] = str(matlab / TARGET)
        checkpoint = service.plan(request(target=TARGET, changes=[raw_change]))
        self.workspace.config_path.write_text(text.replace(str(matlab), str(self.root / "MovedMatlab")))
        for digest in [prepared["plan_digest"], checkpoint["plan_digest"]]:
            code, _, error = cli(workspace, "case", "apply", "--plan", digest, "--write")
            self.assertEqual(code, 4)
            self.assertIn("mappings", error)
        self.assertEqual(self.store.case_head(TARGET).revision, 1)

    def test_bootstrap_refuses_dependency_change_during_transaction_preparation(self):
        delta = CaseDelta.from_dict({**_delta("new/study/case", 1, "new").to_dict(), "project_id": "new"})
        project = Project.from_dict({"schema": "research-workflow/project", "schema_version": 2, "project_id": "new", "name": "new", "profiles": [], "content": {}})
        study = Study.from_dict({"schema": "research-workflow/study", "schema_version": 2, "project_id": "new", "study_id": "study", "name": "study", "sim_prefix": "new/study", "profiles": [], "content": {}})
        plan = self.service.plan("create", delta, project=project, study=study)
        original_read = self.store._safe_raw_bytes
        injected = False
        def change_before_read(path):
            nonlocal injected
            if path == self.store.store_path and not injected:
                injected = True
                document = self.store.load_store()
                document["store_id"] = "concurrent-change"
                atomic_json_write(path, document, write=True)
            return original_read(path)
        with mock.patch.object(self.store, "_safe_raw_bytes", side_effect=change_before_read):
            with self.assertRaisesRegex(ConflictError, "preparing transaction"):
                self.plans.apply(plan, write=True)
        self.assertEqual(self.store.load_store()["store_id"], "concurrent-change")
        self.assertFalse(self.store.project_path("new").exists())
        self.assertFalse(self.plans.plans.receipt(plan["plan_digest"]).exists())

    def test_process_writers_share_authority_lock_and_preserve_both_events(self):
        context = multiprocessing.get_context("spawn")
        service = CheckpointService(self.workspace, self.store)
        plan = service.plan(request(target=TARGET, request_id="parallel-apply"))
        commands = [
            ("case", "apply", "--plan", plan["plan_digest"], "--write"),
            ("event", "record", "root:research_workflow", "--event-id", "20260920T010001Z-laptop-2-parallel-event", "--kind", "validation", "--summary", "Independent event", "--write"),
        ]
        jobs = []
        with authority_lock(self.store.root):
            for arguments in commands:
                parent, child = context.Pipe()
                process = context.Process(target=_process_cli, args=(str(self.workspace.config_path), arguments, child))
                process.start()
                child.close()
                jobs.append((process, parent))
            for process, connection in jobs:
                self.assertTrue(connection.poll(10))
                self.assertEqual(connection.recv(), "ready")
                self.assertFalse(connection.poll(0.15), "public writer bypassed the held process lock")
        for process, connection in jobs:
            self.assertTrue(connection.poll(10))
            code, _, error = connection.recv()
            self.assertEqual(code, 0, error)
            process.join(10)
            self.assertEqual(process.exitcode, 0)
            connection.close()
        events = self.store.read_events()
        self.assertEqual(len(events), 2)
        self.assertEqual({event.summary for event in events}, {"Independent event", "Numerical convergence checked; physical interpretation remains open."})
        self.assertEqual(self.plans.apply_saved(plan["plan_digest"], write=True)["status"], "already-applied")

    def test_completion_marker_is_last_and_partial_bootstrap_never_replays(self):
        delta = CaseDelta.from_dict({**_delta("new/study/case", 1, "new").to_dict(), "project_id": "new"})
        project = Project.from_dict({"schema": "research-workflow/project", "schema_version": 2, "project_id": "new", "name": "new", "profiles": [], "content": {}})
        study = Study.from_dict({"schema": "research-workflow/study", "schema_version": 2, "project_id": "new", "study_id": "study", "name": "study", "sim_prefix": "new/study", "profiles": [], "content": {}})
        plan = self.service.plan("create", delta, project=project, study=study)
        receipt_path = self.plans.plans.receipt(plan["plan_digest"])
        original_validate = self.store.validate
        def validate_before_receipt():
            self.assertFalse(receipt_path.exists())
            return original_validate()
        with mock.patch.object(self.store, "validate", side_effect=validate_before_receipt):
            self.plans.apply(plan, write=True)
        self.assertTrue(receipt_path.exists())
        other = self.root / "partial"
        other.mkdir()
        partial_store = _thin_store(other)
        partial_workspace = _workspace(other, "laptop-2")
        partial_changes = CaseChanges(partial_workspace, partial_store)
        partial = partial_changes.plan("create", delta, project=project, study=study)
        atomic_json_write(partial_store.store_path, partial["documents"]["STORE.json"], write=True)
        record = CaseRecord.from_dict(partial["records"][0])
        journal = case_journal_path(partial_store.root, record.project_id, record.study_id, record.device_id, record.recorded_at[:7])
        journal.parent.mkdir(parents=True)
        journal.write_bytes(canonical_json_bytes(record.to_dict()) + b"\n")
        atomic_json_write(partial_changes.confirmation.plans.receipt(partial["plan_digest"]), {
            "schema": "research-workflow/apply-receipt", "schema_version": 1,
            "plan_digest": partial["plan_digest"], "device_id": "laptop-2",
        }, write=True)
        with self.assertRaises((ConflictError, ValidationError)):
            partial_changes.confirmation.apply_saved(partial["plan_digest"], write=True)
        self.assertFalse(partial_store.project_path("new").exists())
        self.assertFalse(partial_store.study_path("new", "study").exists())

    def test_transplanted_plan_refuses_independent_workspace(self):
        plan = self.revise()
        other = self.root / "other"
        other.mkdir()
        other_store = _thin_store(other)
        other_workspace = _workspace(other, "laptop-2")
        other_plans = ConfirmationPlans(other_workspace, other_store)
        other_plans.plans.save(plan)
        with self.assertRaisesRegex(ConflictError, "workspace changed"):
            other_plans.apply_saved(plan["plan_digest"], write=True)


if __name__ == "__main__":
    unittest.main()
