"""Test atomic structured checkpoints against journal-only Case authority."""

from __future__ import annotations

import os
import contextlib
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from research_workflow.core.errors import ValidationError
from research_workflow.cli.main import main
from research_workflow.domain import CaseDelta, CaseRecord
from research_workflow.index import QueryIndex
from research_workflow.services import CheckpointRequest, CheckpointService, ContextService
from research_workflow.storage import Store
from research_workflow.workspace import WorkspaceRegistry

from tests.integration.confirmation_helpers import apply_request, preview_and_apply
from tests.unit.test_case_journals import _delta, _record_id, _thin_store


def _workspace(root: Path, device_id: str) -> WorkspaceRegistry:
    simulation = root / "Simulation"
    data = root / "Data"
    notes = root / "Notes"
    for path in (simulation, data, notes):
        path.mkdir(exist_ok=True)
    path = root / "workspace.toml"
    path.write_text(
        f'''schema_version = 1
workspace_id = "fixture"
verified_at = "2026-08-23T00:00:00Z"

[device]
device_id = "{device_id}"

[sim_id]
strategy = "simulation-relative-posix-path"
canonical_root = "simulation"
separator = "/"
case_sensitive = true
same_relative_path_default = true
allow_absolute = false
allow_dot_segments = false

[path_aliases]
policy = "explicit-and-evidence-backed-only"

[roots.simulation]
path = "{simulation}"
kind = "simulation"
mapping = "canonical"
default_access = "project-policy"
verification = "fixture"
verified_at = "2026-08-23T00:00:00Z"

[roots.data_simulation]
path = "{data}"
kind = "data"
mapping = "same-relative-path"
default_access = "read-only"
verification = "fixture"
verified_at = "2026-08-23T00:00:00Z"

[roots.notes]
path = "{notes}"
kind = "notes"
mapping = "explicit-link-only"
default_access = "explicit-user-request"
verification = "fixture"
verified_at = "2026-08-23T00:00:00Z"
''',
        encoding="utf-8",
    )
    return WorkspaceRegistry(path)


def _append_case(store: Store, delta: CaseDelta, *, second: int) -> None:
    store.append_case_record(
        CaseRecord.build_create(
            delta,
            record_id=_record_id(second, f"checkpoint-{second}"),
            device_id="laptop-2",
            recorded_at=f"2026-08-23T01:00:{second:02d}Z",
        ),
        current_device="laptop-2",
        write=True,
    )


def _request(
    store: Store,
    targets: list[str],
    *,
    owner: dict[str, object],
    request_id: str,
) -> CheckpointRequest:
    changes: list[dict[str, object]] = []
    for target in targets:
        head = store.case_head(target)
        assert head is not None and head.state == "active"
        changes.append(
            {
                "target": target,
                "if_match": head.delta_digest,
                "reason": "input-change", "responsibility": "simulation-definition",
                "content_patch": {"checkpoint": request_id},
            }
        )
    return CheckpointRequest.from_dict(
        {
            "schema": "research-workflow/checkpoint-request",
            "schema_version": 1,
            "request_id": request_id,
            "changes": changes,
            "event": {
                "owner": owner,
                "kind": "modification",
                "summary": f"Applied {request_id}",
            },
        }
    )


class CheckpointIntegrationTests(unittest.TestCase):
    def test_cli_accepts_inline_and_stdin_requests(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            workspace = _workspace(root, "laptop-2")
            target = "project/study/case"
            first = _delta(target, 1, "initial")
            _append_case(store, first, second=1)
            request = {
                "schema": "research-workflow/checkpoint-request", "schema_version": 1,
                "request_id": "stdin-checkpoint",
                "event": {"kind": "validation", "summary": "Validated post-processing"},
            }
            preview_output = io.StringIO()
            with contextlib.redirect_stdout(preview_output):
                code = main(
                    [
                        "--workspace",
                        str(workspace.config_path),
                        "checkpoint",
                        target,
                        "--request-json",
                        json.dumps(request),
                        "--json",
                    ]
                )
            self.assertEqual(code, 0)
            self.assertEqual(json.loads(preview_output.getvalue())["mode"], "preview")
            output = io.StringIO()
            with mock.patch.object(sys, "stdin", io.StringIO(json.dumps(request))):
                with contextlib.redirect_stdout(output):
                    code = main(
                        [
                            "--workspace",
                            str(workspace.config_path),
                            "checkpoint",
                            target,
                            "--stdin",
                            "--write",
                            "--json",
                        ]
                    )
            self.assertEqual(code, 0)
            self.assertEqual(json.loads(output.getvalue())["mode"], "write")
            self.assertEqual(store.load_case_delta(target).to_dict(), first.to_dict())
            self.assertEqual(len(store.read_events()), 1)

    def test_batch_journal_checkpoint_is_one_atomic_transaction(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            workspace = _workspace(root, "laptop-2")
            targets = ["project/study/case-a", "project/study/case-b"]
            for second, target in enumerate(targets, start=1):
                _append_case(store, _delta(target, 1, "initial"), second=second)
            request = _request(
                store,
                targets,
                owner={"kind": "study", "project_id": "project", "study_id": "study"},
                request_id="journal-batch",
            )
            result = apply_request(CheckpointService(workspace, store), request)
            self.assertEqual(result["mode"], "write")
            self.assertEqual([store.load_case_delta(target).revision for target in targets], [2, 2])
            events = store.read_events()
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0].owner.to_dict(), {"kind": "study", "project_id": "project", "study_id": "study"})
            context = ContextService(workspace, store).build(targets[0])
            self.assertEqual(context["recent_events"], [])
            recent = context["parent_background"]["recent_events"]
            self.assertEqual(recent[0]["scope"], "study")

    def test_event_replace_failure_rolls_back_case_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            workspace = _workspace(root, "laptop-2")
            target = "project/study/case"
            _append_case(store, _delta(target, 1, "initial"), second=1)
            service = CheckpointService(workspace, store)
            plan = service.plan(
                _request(
                    store,
                    [target],
                    owner={"kind": "case", "sim_id": target},
                    request_id="rollback",
                )
            )
            before = {path: path.read_bytes() for path in store.case_record_paths()}
            real_replace = os.replace

            def fail_event(source: object, destination: object) -> None:
                if "/events/" in str(destination):
                    raise OSError("fixture event failure")
                real_replace(source, destination)

            with mock.patch("research_workflow.storage.jsonio.os.replace", side_effect=fail_event):
                with self.assertRaises(ValidationError):
                    service.apply(plan, write=True)
            self.assertEqual(before, {path: path.read_bytes() for path in before})
            self.assertEqual(store.event_paths(), [])

    def test_journal_only_checkpoint_and_index(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            workspace = _workspace(root, "laptop-2")
            first = _delta("project/study/case-a", 1, "a")
            store.append_case_record(
                CaseRecord.build_create(
                    first,
                    record_id=_record_id(1, "create-checkpoint"),
                    device_id="laptop-2",
                    recorded_at="2026-08-23T01:00:01Z",
                ),
                current_device="laptop-2",
                write=True,
            )
            self.assertEqual(ContextService(workspace, store).build(first.sim_id)["case"]["revision"], 1)
            snapshot_path = root / "journal-cache.sqlite3"
            self.assertEqual(QueryIndex(snapshot_path).rebuild(store)["counts"]["cases"], 1)
            request = _request(
                store,
                [first.sim_id],
                owner={"kind": "case", "sim_id": first.sim_id},
                request_id="journal-checkpoint",
            )
            apply_request(CheckpointService(workspace, store), request)
            head = store.case_head(first.sim_id)
            assert head is not None
            self.assertEqual(head.revision, 2)
            self.assertEqual(head.content["checkpoint"], "journal-checkpoint")
            self.assertFalse((store.root / "cases").exists())
            self.assertEqual(len(store.read_events()), 1)

    def test_case_cli_uses_journal_create_and_revise(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            workspace = _workspace(root, "laptop-2")
            target = "project/study/case-cli"
            with contextlib.redirect_stdout(io.StringIO()):
                code = preview_and_apply(
                    [
                        "--workspace",
                        str(workspace.config_path),
                        "case",
                        "create",
                        target,
                        "--project-id",
                        "project",
                        "--study-id",
                        "study",
                        "--content-json",
                        '{"parameter":"one"}',
                        "--json",
                    ]
                )
            self.assertEqual(code, 0)
            head = store.case_head(target)
            assert head is not None
            self.assertEqual(head.revision, 1)
            with contextlib.redirect_stdout(io.StringIO()):
                code = preview_and_apply(
                    [
                        "--workspace",
                        str(workspace.config_path),
                        "case",
                        "revise",
                        target,
                        "--reason", "input-change",
                        "--revision",
                        "2",
                        "--content-patch-json",
                        '{"parameter":"two"}',
                        "--expect-digest",
                        head.delta_digest,
                        "--json",
                    ]
                )
            self.assertEqual(code, 0)
            revised = store.case_head(target)
            assert revised is not None
            self.assertEqual(revised.revision, 2)
            self.assertEqual(revised.content["parameter"], "two")
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                code = main(
                    ["--workspace", str(workspace.config_path), "case", "list", "--json"]
                )
            self.assertEqual(code, 0)
            listed = json.loads(output.getvalue())["cases"][0]
            self.assertEqual(listed["current_spec_digest"], revised.delta_digest)

    def test_event_only_root_checkpoint(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            workspace = _workspace(root, "laptop-2")
            request = CheckpointRequest.from_dict(
                {
                    "schema": "research-workflow/checkpoint-request",
                    "schema_version": 1,
                    "request_id": "root-only",
                    "changes": [],
                    "event": {
                        "owner": {"kind": "root", "root_id": "research_workflow"},
                        "kind": "modification",
                        "summary": "Updated framework fixture",
                    },
                }
            )
            result = apply_request(CheckpointService(workspace, store), request)
            self.assertEqual(result["cases"], [])
            self.assertEqual(store.read_events()[0].owner.kind, "root")

    def test_high_risk_removal_requires_saved_plan(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            workspace = _workspace(root, "laptop-2")
            target = "project/study/case"
            first = CaseDelta.from_dict(
                {
                    "schema": "research-workflow/case-delta",
                    "schema_version": 1,
                    "sim_id": target,
                    "project_id": "project",
                    "study_id": "study",
                    "revision": 1,
                    "profiles": [],
                    "content": {"obsolete": True},
                }
            )
            _append_case(store, first, second=1)
            request = CheckpointRequest.from_dict(
                {
                    "schema": "research-workflow/checkpoint-request",
                    "schema_version": 1,
                    "request_id": "remove-field",
                    "changes": [
                        {
                            "target": target,
                            "if_match": first.digest,
                            "reason": "metadata-correction", "responsibility": "simulation-definition",
                            "remove_content_paths": ["/content/obsolete"],
                        }
                    ],
                    "event": {
                        "owner": {"kind": "case", "sim_id": target},
                        "kind": "modification",
                        "summary": "Removed obsolete field",
                    },
                }
            )
            service = CheckpointService(workspace, store)
            plan = service.plan(request)
            self.assertTrue(plan["confirmation_required"])
            self.assertEqual(store.load_case_delta(target).revision, 1)
            service.apply_saved(plan["plan_digest"], write=True)
            revised = store.load_case_delta(target)
            self.assertEqual(revised.revision, 2)
            self.assertNotIn("obsolete", revised.content)


if __name__ == "__main__":
    unittest.main()
