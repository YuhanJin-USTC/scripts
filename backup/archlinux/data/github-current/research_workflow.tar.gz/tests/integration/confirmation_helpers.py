"""Exercise saved previews through the public apply command in fixtures."""

import contextlib
import io
import json

from research_workflow.cli.main import main


def preview_and_apply(arguments):
    """Test-only consent stand-in; run both real CLI steps."""
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        code = main(arguments)
    if code:
        return code
    plan = json.loads(output.getvalue())
    workspace = arguments[arguments.index("--workspace") + 1]
    return main(["--workspace", workspace, "case", "apply", "--plan", plan["plan_digest"], "--write", "--json"])


def apply_request(service, request):
    preview = service.execute(request)
    return service.apply_saved(preview["plan_digest"], write=True)
