"""Test permanent reading of historical journal tombstones."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from research_workflow.core.canonical import canonical_json_bytes
from research_workflow.domain import Event
from research_workflow.services import ContextService
from research_workflow.storage import append_event, case_journal_path

from tests.integration.test_checkpoint import _workspace
from tests.unit.test_case_journals import _historical_tombstone, _thin_store


class TombstoneReaderIntegrationTests(unittest.TestCase):
    def test_historical_tombstone_preserves_deleted_event_lineage(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            workspace = _workspace(root, "laptop-2")
            record = _historical_tombstone()
            journal = case_journal_path(store.root, "project", "study", "laptop-2", "2026-08")
            journal.parent.mkdir(parents=True)
            journal.write_bytes(canonical_json_bytes(record.to_dict()) + b"\n")
            for index in range(10):
                append_event(
                    store.root,
                    Event.from_dict(
                        {
                            "schema": "research-workflow/event",
                            "schema_version": 1,
                            "event_id": f"20260823T000100Z-laptop-2-deleted-{index:02d}",
                            "device_id": "laptop-2",
                            "recorded_at": "2026-08-23T00:01:00Z",
                            "occurred_at": "2026-08-23T00:01:00Z",
                            "owner": {"kind": "case", "sim_id": record.sim_id},
                            "kind": "validation",
                            "summary": f"Preserved deleted event {index}",
                            "evidence": [],
                            "status_updates": [],
                        }
                    ),
                    current_device="laptop-2",
                    write=True,
                )
            head = store.case_head(record.sim_id)
            assert head is not None
            self.assertEqual((head.state, head.delta), ("deleted", None))
            context = ContextService(workspace, store).build(record.sim_id)
            self.assertFalse(context["registered"])
            self.assertTrue(context["deleted"])
            report = store.validate()
            self.assertTrue(report.valid, report.errors)
            self.assertEqual(report.details["deleted_case_events"], 10)


if __name__ == "__main__":
    unittest.main()
