"""Test schema-2 Case lifecycle through the compatibility CLI."""

from __future__ import annotations

import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from research_workflow.cli.main import main
from research_workflow.core.errors import ValidationError
from research_workflow.core.models import ValidationReport
from research_workflow.domain import CaseRecord, Project, Study
from research_workflow.storage import Store, atomic_json_write, read_json

from tests.integration.test_checkpoint import _workspace
from tests.integration.confirmation_helpers import preview_and_apply
from tests.unit.test_case_journals import _delta, _thin_store


class JournalLifecycleIntegrationTests(unittest.TestCase):
    def _empty_thin_store(self, root: Path) -> Store:
        metadata = root / "metadata"
        atomic_json_write(
            metadata / "STORE.json",
            {
                "schema": "research-workflow/store",
                "schema_version": 2,
                "framework_version": "0",
                "store_id": "test-store",
                "created_at": "2026-08-23T00:00:00Z",
                "projects": [],
                "devices": ["laptop-2"],
            },
            write=True,
        )
        atomic_json_write(
            metadata / "devices/laptop-2.json",
            {
                "schema": "research-workflow/device",
                "schema_version": 1,
                "device_id": "laptop-2",
                "name": "Laptop 2",
                "onboarded_at": "2026-08-23T00:00:00Z",
            },
            write=True,
        )
        return Store(metadata)

    def test_cli_atomically_bootstraps_project_study_and_case(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = self._empty_thin_store(root)
            workspace = _workspace(root, "laptop-2")
            command = [
                "--workspace", str(workspace.config_path), "case", "create",
                "new-project/new-study/case-a",
                "--project-id", "new-project",
                "--study-id", "new-study",
                "--project-name", "New Project",
                "--study-name", "New Study",
                "--study-prefix", "new-project/new-study",
                "--json",
            ]
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(main(command), 0)
            self.assertEqual(store.load_store()["projects"], [])
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                self.assertEqual(preview_and_apply(command), 0)
            result = json.loads(output.getvalue())
            self.assertEqual(len(result["operations"]), 4)
            self.assertEqual(store.load_store()["projects"], ["new-project"])
            self.assertEqual(read_json(store.project_path("new-project"))["schema_version"], 2)
            self.assertEqual(read_json(store.study_path("new-project", "new-study"))["schema_version"], 2)
            self.assertEqual(store.case_state("new-project/new-study/case-a")["authority"], "journal")
            self.assertTrue(store.validate().valid, store.validate().errors)

            second_study = [
                "--workspace", str(workspace.config_path), "case", "create",
                "new-project/second-study/case-b",
                "--project-id", "new-project",
                "--study-id", "second-study",
                "--study-name", "Second Study",
                "--study-prefix", "new-project/second-study",
                "--json",
            ]
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(preview_and_apply(second_study), 0)
            self.assertEqual(read_json(store.study_path("new-project", "second-study"))["schema_version"], 2)
            self.assertEqual(store.load_store()["projects"], ["new-project"])

    def test_bootstrap_post_validation_failure_rolls_back_every_path(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = self._empty_thin_store(root)
            before = store.store_path.read_bytes()
            delta = _delta("project/study/case", 1, "a")
            project = Project.from_dict(
                {
                    "schema": "research-workflow/project",
                    "schema_version": 2,
                    "project_id": "project",
                    "name": "Project",
                    "profiles": [],
                    "content": {},
                }
            )
            study = Study.from_dict(
                {
                    "schema": "research-workflow/study",
                    "schema_version": 2,
                    "project_id": "project",
                    "study_id": "study",
                    "name": "Study",
                    "sim_prefix": "project/study",
                    "profiles": [],
                    "content": {},
                }
            )
            record = CaseRecord.build_create(
                delta,
                record_id="20260823T010001Z-laptop-2-create",
                device_id="laptop-2",
                recorded_at="2026-08-23T01:00:01Z",
            )
            failure = ValidationReport(False, 1, ("forced failure",), {})
            with mock.patch.object(store, "validate", return_value=failure):
                with self.assertRaisesRegex(ValidationError, "post-bootstrap"):
                    store.bootstrap_case_record(
                        record,
                        current_device="laptop-2",
                        project=project,
                        study=study,
                        write=True,
                    )
            self.assertEqual(store.store_path.read_bytes(), before)
            self.assertFalse(store.project_path("project").exists())
            self.assertFalse(store.study_path("project", "study").exists())
            self.assertFalse(store.case_record_paths())

    def test_cli_rename_delete_append_only_to_journal(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            workspace = _workspace(root, "laptop-2")
            source = _delta("project/study/source", 1, "a")
            store.append_case_record(
                CaseRecord.build_create(
                    source,
                    record_id="20260823T010001Z-laptop-2-create",
                    device_id="laptop-2",
                    recorded_at="2026-08-23T01:00:01Z",
                ),
                current_device="laptop-2",
                write=True,
            )
            target = "project/study/target"
            with contextlib.redirect_stdout(io.StringIO()):
                code = preview_and_apply([
                    "--workspace", str(workspace.config_path), "case", "rename",
                    source.sim_id, target, "--expect-digest", source.digest,
                    "--recorded-at", "2026-08-23T01:00:02Z", "--json",
                ])
            self.assertEqual(code, 0)
            self.assertEqual(store.case_state(source.sim_id)["state"], "renamed")
            self.assertEqual(store.case_state(target)["state"], "active")

            with contextlib.redirect_stdout(io.StringIO()):
                code = preview_and_apply([
                    "--workspace", str(workspace.config_path), "case", "delete", target,
                    "--expect-digest", store.case_head(target).delta_digest,
                    "--recorded-at", "2026-08-23T01:00:03Z", "--json",
                ])
            self.assertEqual(code, 0)
            self.assertEqual(store.case_state(target)["state"], "deleted")
            self.assertEqual(
                [record.action for record in store.read_case_records()],
                ["create", "rename", "delete"],
            )
            self.assertFalse((store.root / "cases").exists())


if __name__ == "__main__":
    unittest.main()
