"""Exercise Store compatibility and exact policy target transitions in fixtures."""

import contextlib
import io
import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from pathlib import Path
from unittest import mock

from research_workflow.cli.main import main
from research_workflow.core.errors import AccessError, ConflictError, UnsupportedOperationError, ValidationError
from research_workflow.evolution import PolicyApplicationService, Proposal, Rule, load_active_rules
from research_workflow.evolution.targets import current_target_rules, target_state
from research_workflow.services.store_upgrade import StoreUpgradeService
from research_workflow.services.validation import validate_workspace
from research_workflow.storage import Store, atomic_json_write
from research_workflow.storage.compatibility import TARGET_CAPABILITY, inspect_store
from research_workflow.storage.devices import require_registered_device
from research_workflow.workspace import WorkspaceRegistry
from tests.integration.test_policy_propagation import _fixture, _proposal, _apply, DECIDED_AT


class TargetLifecycleTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.config, self.legacy, self.paths = _fixture(self.root)
        _apply(self.legacy, _proposal("base", "role", "simulation"))
        self.workspace = WorkspaceRegistry(self.config)
        self.store = Store(self.workspace.metadata_root)
        self.upgrade = StoreUpgradeService(self.workspace, self.store)
        plan = self.upgrade.execute()["plan"]
        self.upgrade.execute(expect_digest=plan["digest"], write=True)
        self.service = PolicyApplicationService.from_workspace(self.workspace)

    def proposal(self, action="retire", identity="retire-child", path=None, replacement=None):
        return self.service.propose_target(str(path or self.paths["child"]), action=action,
            replacement=str(replacement or self.paths["simulation"]) if action == "retire" else "",
            proposal_id=identity, evidence=["fixture:verified-parent"], write=True)

    def approve_apply(self, identity="retire-child"):
        plan = self.service.plan(identity)
        self.service.approve(identity, "fixture-user", DECIDED_AT, device_id="laptop-1", expect_digest=plan.digest, write=True)
        self.service.apply(identity, device_id="laptop-1", expect_digest=plan.digest, write=True)
        return plan.digest

    def test_scope_queries_reduce_cross_scope_supersession_before_filtering(self):
        cases = (
            ("global", "*", "role", "simulation", ("global", "project:simulation"), "role:simulation"),
            ("role", "simulation", "project", "simulation", ("role:simulation", "global"), "project:simulation"),
            ("project", "simulation", "subtree", str(self.paths["child"].parent), ("project:simulation", "global"), str(self.paths["child"])),
        )
        for index, (old_scope, old_selector, new_scope, new_selector, absent, present) in enumerate(cases):
            with self.subTest(old_scope=old_scope, new_scope=new_scope):
                old = Rule.from_proposal(_proposal(f"old-{index}", old_scope, old_selector,
                    content={f"old-key-{index}": "old"}))
                new = Rule.from_proposal(replace(_proposal(f"new-{index}", new_scope, new_selector,
                    content={f"new-key-{index}": "new"}), supersedes=(old.rule_id,)))
                for rule in (old, new):
                    atomic_json_write(self.root / "policy/rules" / f"{rule.rule_id}.json", rule.to_dict(), write=True)
                for query in (*absent, present):
                    content = self.service.effective(query)["entries"][0]["effective"]["content"]
                    self.assertNotIn(f"old-key-{index}", content)
                self.assertIn(f"new-key-{index}", self.service.effective(present)["entries"][0]["effective"]["content"])
                self.assertEqual(len([rule for rule in load_active_rules(self.root / "policy")
                    if rule.rule_id in {old.rule_id, new.rule_id}]), 2)

    def test_validation_and_upgrade_refuse_overlapping_subtree_conflicts(self):
        document = self.store.load_store()
        document.pop("required_capabilities"); document["schema_version"] = 2
        atomic_json_write(self.store.store_path, document, write=True)
        digest = self.upgrade.execute()["plan"]["digest"]
        for identity, selector in (("outer", self.paths["simulation"].parent), ("inner", self.paths["child"].parent)):
            rule = Rule.from_proposal(_proposal(identity, "subtree", str(selector), content={"overlap": identity}))
            atomic_json_write(self.root / "policy/rules" / f"{identity}.json", rule.to_dict(), write=True)
        before = {path: path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        self.assertFalse(validate_workspace(self.workspace, self.store)["valid"])
        with self.assertRaises(ConflictError):
            self.service.check()
        for write in (False, True):
            with self.subTest(write=write), self.assertRaisesRegex(ValidationError, "same-scope policy conflict"):
                self.upgrade.execute(expect_digest=digest, write=write)
        self.assertEqual(before, {path: path.read_bytes() for path in self.root.rglob("*") if path.is_file()})
        self.assertEqual(self.store.load_store()["schema_version"], 2)

    def test_validation_reports_conflicts_without_treating_projection_drift_as_repair(self):
        original = self.paths["child"].read_bytes()
        self.paths["child"].write_bytes(original + b"Unmanaged addition.\n")
        self.assertTrue(validate_workspace(self.workspace, self.store)["valid"])
        self.paths["child"].write_bytes(original.replace(b'"base"', b'"external-drift"'))
        changed = self.paths["child"].read_bytes()
        self.assertTrue(validate_workspace(self.workspace, self.store)["valid"])
        self.assertFalse(self.service.check()["valid"])
        self.assertEqual(self.paths["child"].read_bytes(), changed)

    def test_completion_rechecks_dependencies_and_preserves_external_edits(self):
        self.proposal()
        digest = self.service.plan("retire-child").digest
        self.service.approve("retire-child", "fixture-user", DECIDED_AT,
            device_id="laptop-1", expect_digest=digest, write=True)
        before = {path: path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        parent = self.paths["simulation"]
        sibling = self.paths["sibling"]
        external = {parent: before[parent] + b"External parent edit.\n",
            sibling: before[sibling] + b"External sibling edit.\n"}
        import research_workflow.storage.jsonio as jsonio
        original_replace = jsonio.os.replace
        injected = False

        def replace_then_edit(source, target):
            nonlocal injected
            result = original_replace(source, target)
            if Path(target) == self.paths["child"] and not injected:
                injected = True
                for path, payload in external.items():
                    path.write_bytes(payload)
            return result

        with mock.patch.object(jsonio.os, "replace", side_effect=replace_then_edit):
            with self.assertRaisesRegex(ConflictError, "changed before completion"):
                self.service.apply("retire-child", device_id="laptop-1", expect_digest=digest, write=True)
        self.assertTrue(injected)
        for path, payload in before.items():
            self.assertEqual(path.read_bytes(), external.get(path, payload))
        self.assertFalse((self.root / "policy/rules/retire-child.json").exists())
        self.assertFalse((self.root / ".research-workflow/policy-plans" / f"{digest}.json").exists())
        self.assertTrue((self.root / "policy/open-proposals/retire-child.json").exists())

    def test_retire_reenable_and_history_preserve_unmanaged_bytes(self):
        original = self.paths["child"].read_bytes().split(b"<!-- research-workflow:policy:start -->")[0]
        old_rule = (self.root / "policy/rules/base.json").read_bytes()
        self.proposal()
        plan = self.service.plan("retire-child").to_dict()
        self.assertEqual((plan["schema_version"], plan["authorization"]["schema_version"]), (3, 2))
        self.assertEqual(plan["authorization"]["replacement"]["content"].encode(), self.paths["simulation"].read_bytes())
        digest = self.approve_apply()
        self.assertEqual(self.paths["child"].read_bytes(), original)
        self.assertTrue(self.service.check()["valid"])
        self.assertEqual(self.service.apply("retire-child", device_id="laptop-1", expect_digest=digest, write=True)["action"], "reuse")
        retired_rule = (self.root / "policy/rules/retire-child.json").read_bytes()
        self.paths["child"].write_bytes(original + b"New local content.\n")
        self.proposal("reenable", "reenable-child")
        self.approve_apply("reenable-child")
        self.assertTrue(self.paths["child"].read_bytes().startswith(original + b"New local content.\n"))
        self.assertEqual((self.root / "policy/rules/base.json").read_bytes(), old_rule)
        self.assertEqual((self.root / "policy/rules/retire-child.json").read_bytes(), retired_rule)
        self.assertEqual(len(current_target_rules(load_active_rules(self.root / "policy"))), 1)

    def test_missing_retired_file_is_not_recreated_and_returned_block_is_drift(self):
        self.proposal(); self.approve_apply()
        retired = self.paths["child"]
        retired.unlink()
        self.assertTrue(self.service.check()["valid"])
        self.assertFalse(retired.exists())
        retired.write_bytes(self.paths["simulation"].read_bytes())
        self.assertFalse(self.service.check()["valid"])

    def test_parent_changed_invalidates_approval(self):
        self.proposal()
        digest = self.service.plan("retire-child").digest
        self.service.approve("retire-child", "fixture-user", DECIDED_AT, device_id="laptop-1", expect_digest=digest, write=True)
        self.paths["simulation"].write_bytes(self.paths["simulation"].read_bytes() + b"Changed parent.\n")
        with self.assertRaises(ConflictError):
            self.service.apply("retire-child", device_id="laptop-1", expect_digest=digest, write=True)
        self.assertIn(b"research-workflow:policy:start", self.paths["child"].read_bytes())

    def test_apply_requires_approval_and_replay_checks_real_state(self):
        self.proposal()
        digest = self.service.plan("retire-child").digest
        with self.assertRaises(AccessError):
            self.service.apply("retire-child", device_id="laptop-1", expect_digest=digest, write=True)
        self.approve_apply()
        self.paths["child"].write_bytes(b"changed\n")
        with self.assertRaises(ConflictError):
            self.service.apply("retire-child", device_id="laptop-1", expect_digest=digest, write=True)

    def test_exact_device_path_forks_and_cross_device_are_distinct(self):
        self.proposal(); self.approve_apply()
        rules = load_active_rules(self.root / "policy")
        retired = target_state(rules, "laptop-1", self.paths["child"])
        self.assertIsNone(target_state(rules, "desktop-1", self.paths["child"]))
        fork = replace(retired, rule_id="fork", proposal_id="fork")
        with self.assertRaises(ConflictError):
            current_target_rules((*rules, fork))
        foreign = replace(retired, rule_id="foreign", proposal_id="foreign", target=replace(retired.target, device_id="desktop-1"))
        self.assertEqual(len(current_target_rules((*rules, foreign))), 2)
        wrong_parent = replace(foreign, supersedes=(retired.rule_id,), revision=2)
        with self.assertRaises(ConflictError):
            current_target_rules((*rules, wrong_parent))

    def test_parent_root_policy_and_symlink_guards(self):
        with self.assertRaises(ValidationError):
            self.proposal(replacement=self.paths["sibling"])
        with self.assertRaises(AccessError):
            self.proposal(replacement=self.paths["control"])
        child = self.paths["child"]
        child.unlink(); child.symlink_to(self.paths["sibling"])
        with self.assertRaises(ConflictError):
            PolicyApplicationService.from_workspace(self.workspace)

    def test_concurrent_apply_reuses_and_atomic_failure_rolls_back(self):
        self.proposal()
        digest = self.service.plan("retire-child").digest
        self.service.approve("retire-child", "fixture-user", DECIDED_AT, device_id="laptop-1", expect_digest=digest, write=True)
        snapshots = {path: path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        import research_workflow.storage.jsonio as jsonio
        original = jsonio.os.replace
        count = 0
        def fail_once(source, target):
            nonlocal count
            count += 1
            if count == 3:
                raise OSError("fixture interruption")
            return original(source, target)
        with mock.patch.object(jsonio.os, "replace", side_effect=fail_once):
            with self.assertRaises(ValidationError):
                self.service.apply("retire-child", device_id="laptop-1", expect_digest=digest, write=True)
        for path, payload in snapshots.items():
            self.assertEqual(path.read_bytes(), payload)
        with ThreadPoolExecutor(max_workers=2) as executor:
            results = list(executor.map(lambda _: self.service.apply("retire-child", device_id="laptop-1", expect_digest=digest, write=True), range(2)))
        self.assertEqual(sorted(item["action"] for item in results), ["apply", "reuse"])

    def test_no_allowlist_discovery_and_store_gate(self):
        config = self.config.read_text()
        self.config.write_text(config.split("\n[[policy.targets]]", 1)[0])
        with self.assertRaises(AccessError):
            PolicyApplicationService.from_workspace(WorkspaceRegistry(self.config))
        self.config.write_text(config)
        document = self.store.load_store()
        document["required_capabilities"].append("unknown-future")
        atomic_json_write(self.store.store_path, document, write=True)
        with self.assertRaises(UnsupportedOperationError):
            require_registered_device(self.store.root, "laptop-1")
        self.assertFalse(validate_workspace(self.workspace, self.store)["valid"])
        self.assertFalse(inspect_store(self.store.store_path)["compatibility"]["compatible"])

    def test_store_preview_stale_idempotent_and_independent_compatibility(self):
        self.assertEqual(self.upgrade.execute()["action"], "already-current")
        self.assertFalse(self.upgrade.execute(expect_digest="0" * 64, write=True)["written"])
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = main(["--workspace", str(self.root / "absent.toml"), "doctor", "--compatibility-only", "--store", str(self.store.store_path), "--json"])
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(output.getvalue())["framework_version"], "0.2.4")
        document = self.store.load_store()
        document.pop("required_capabilities"); document["schema_version"] = 2
        atomic_json_write(self.store.store_path, document, write=True)
        before = {path: path.read_bytes() for path in self.store.root.rglob("*") if path.is_file()}
        plan = self.upgrade.execute()["plan"]
        self.assertEqual(before, {path: path.read_bytes() for path in self.store.root.rglob("*") if path.is_file()})
        with self.assertRaises(ConflictError):
            self.upgrade.execute(expect_digest="0" * 64, write=True)
        self.upgrade.execute(expect_digest=plan["digest"], write=True)
        for path, payload in before.items():
            if path != self.store.store_path:
                self.assertEqual(path.read_bytes(), payload)

    def test_legacy_schema_digest_roundtrip_and_target_cli_preview(self):
        legacy = _proposal("old", "global", "*", approved=False)
        self.assertEqual(Proposal.from_dict(legacy.to_dict()).digest, legacy.digest)
        output = io.StringIO()
        before = list((self.root / "policy/open-proposals").glob("*.json"))
        with contextlib.redirect_stdout(output):
            code = main(["--workspace", str(self.config), "policy", "target", "retire", str(self.paths["child"]), "--replacement", str(self.paths["simulation"]), "--proposal-id", "cli-retire", "--evidence", "fixture:evidence", "--json"])
        self.assertEqual(code, 0)
        self.assertEqual(json.loads(output.getvalue())["proposal"]["approval"]["status"], "pending")
        self.assertEqual(before, list((self.root / "policy/open-proposals").glob("*.json")))


if __name__ == "__main__":
    unittest.main()
