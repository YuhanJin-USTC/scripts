"""Run the explicit full framework and bundled-skill regression tier."""

from __future__ import annotations

from _suite_runner import ROOT, check_skill_layout, run_suite, skill_roots


def main() -> int:
    roots = skill_roots()
    results = [check_skill_layout(roots), run_suite("framework-full", ROOT / "tests")]
    for root in roots:
        tests_root = root / "tests"
        if tests_root.exists():
            results.append(run_suite(root.name, tests_root))
    return 0 if all(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
