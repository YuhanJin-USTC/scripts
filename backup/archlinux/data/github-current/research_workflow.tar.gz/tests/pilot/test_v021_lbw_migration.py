"""Accept the bounded LBW schema-2 migration without scanning unrelated Cases."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tomllib
import unittest
from pathlib import Path

from research_workflow.domain import CaseRecord
from research_workflow.storage.store import validate_store_document


ROOT = Path(__file__).resolve().parents[2]
METADATA = ROOT / "metadata"
PROJECT_ID = "lbw_plasma_mirror"
STUDY_ID = "w_scanning_2d_v1"
SIM_PREFIX = f"{PROJECT_ID}/{STUDY_ID}"
JOURNAL = METADATA / "case-journals" / PROJECT_ID / STUDY_ID / "laptop-2/2026-08.jsonl"
WORKSPACE = tomllib.loads((ROOT / "workspace.toml").read_text(encoding="utf-8"))
SIMULATION = Path(WORKSPACE["roots"]["simulation"]["path"])
SIM_IDS = (
    f"{SIM_PREFIX}/20260814_baseline_v1",
    f"{SIM_PREFIX}/20260814_v1_10_nc_w_10",
    f"{SIM_PREFIX}/20260814_v1_10_nc_w_15",
    f"{SIM_PREFIX}/20260814_v1_10_nc_w_5",
    f"{SIM_PREFIX}/20260814_v1_2_nc_w_10",
    f"{SIM_PREFIX}/20260814_v1_2_nc_w_15",
    f"{SIM_PREFIX}/20260814_v1_2_nc_w_5",
    f"{SIM_PREFIX}/20260814_v1_w_11",
    f"{SIM_PREFIX}/20260814_v1_w_14",
    f"{SIM_PREFIX}/20260814_v1_w_17",
    f"{SIM_PREFIX}/20260814_v1_w_8",
)
PRESERVED_EVENTS = {
    "20260820T030931Z-laptop-2-lbw-pm-postprocess": (1319, "d39f06e9447df65c51ca2bb0a76c3bf62062119e107b852dbf4c619478a98f73"),
    "20260822T203638Z-laptop-2-photon-summary-v4": (2615, "14b0f807ec9c29bc8c126b108143e438bda30b20613df45fbca77fa56bd54b0c"),
    "20260823T011148Z-laptop-2-final-statistics-output": (2410, "3eefb843d0b16d9eac8a600acc11e14a0323cbce74ae529d38f199e28a5f2890"),
    "20260823T014350Z-laptop-2-postprocess-runtime-fixes": (2369, "7ff985db4ccd4e19d75477b37294683914fcff3dd07c94d20040c3eef7e272c9"),
}


class V021LbwMigrationPilotTests(unittest.TestCase):
    """Check only the approved 11 Cases and preserved post-cutoff events."""

    def test_store_is_thin_schema_two(self) -> None:
        store = validate_store_document(json.loads((METADATA / "STORE.json").read_text(encoding="utf-8")))
        self.assertEqual(store["schema_version"], 2)
        self.assertFalse({"cases", "case_redirects", "case_deletions"} & set(store))

    def test_journal_has_one_bound_migration_for_each_pilot_case(self) -> None:
        records = [CaseRecord.from_dict(json.loads(line)) for line in JOURNAL.read_text(encoding="utf-8").splitlines()]
        migrations = {record.sim_id: record for record in records if record.action == "migrate"}
        self.assertEqual(set(migrations), set(SIM_IDS))
        for sim_id, record in migrations.items():
            self.assertEqual(record.previous_digest, "not-applicable")
            self.assertEqual(record.delta.sim_id, sim_id)
            self.assertEqual((record.delta.project_id, record.delta.study_id), (PROJECT_ID, STUDY_ID))
            self.assertIsNotNone(record.legacy_binding)

    def test_legacy_case_directories_are_absent(self) -> None:
        for sim_id in SIM_IDS:
            self.assertFalse((METADATA / "cases" / sim_id).exists(), sim_id)
        self.assertFalse((METADATA / "cases" / SIM_PREFIX).exists())

    def test_post_cutoff_event_bytes_are_preserved(self) -> None:
        found: dict[str, tuple[int, str]] = {}
        for path in sorted((METADATA / "events").glob("*/*.jsonl")):
            for line in path.read_bytes().splitlines(keepends=True):
                event_id = json.loads(line)["event_id"]
                if event_id in PRESERVED_EVENTS:
                    self.assertNotIn(event_id, found)
                    found[event_id] = (len(line), hashlib.sha256(line).hexdigest())
        self.assertEqual(found, PRESERVED_EVENTS)
        self.assertEqual(sum(size for size, _digest in found.values()), 8713)

    def test_all_pilot_cases_have_bounded_compact_context(self) -> None:
        environment = os.environ.copy()
        environment["PYTHONDONTWRITEBYTECODE"] = "1"
        environment["PYTHONPATH"] = os.pathsep.join((str(ROOT / "src"), str(ROOT)))
        for sim_id in SIM_IDS:
            with self.subTest(sim_id=sim_id):
                result = subprocess.run(
                    [
                        sys.executable,
                        "-B",
                        str(ROOT / "tools/researchctl.py"),
                        "context",
                        str(SIMULATION / sim_id),
                        "--view",
                        "compact",
                        "--json",
                    ],
                    cwd=ROOT,
                    env=environment,
                    text=True,
                    capture_output=True,
                    check=False,
                )
                self.assertEqual(result.returncode, 0, result.stderr)
                context = json.loads(result.stdout)
                self.assertEqual(context["view"], "compact")
                self.assertEqual(context["case"]["state"], "active")
                self.assertEqual(context["case"]["sim_id"], sim_id)
                self.assertEqual(context["study"]["member_count"], 11)
                self.assertEqual(context["budget"]["limit_bytes"], 4096)
                self.assertLessEqual(context["budget"]["actual_bytes"], 4096)
                self.assertEqual(len(result.stdout.encode("utf-8")), context["budget"]["actual_bytes"])


if __name__ == "__main__":
    unittest.main()
