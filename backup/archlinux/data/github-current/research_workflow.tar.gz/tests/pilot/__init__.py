"""Live read-only acceptance tests for the approved v0.2.1 pilot."""
