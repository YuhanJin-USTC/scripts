"""Share isolated unittest discovery across explicit test tiers."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SKILLS_ROOT = ROOT / "skills"
REQUIRED_SKILL_PATHS = (
    Path("agents/openai.yaml"),
    Path("scripts/install.py"),
    Path("scripts/check_installation.py"),
    Path("tests"),
)


def environment() -> dict[str, str]:
    result = os.environ.copy()
    result["PYTHONDONTWRITEBYTECODE"] = "1"
    required = (str(ROOT / "src"), str(ROOT))
    existing = result.get("PYTHONPATH")
    result["PYTHONPATH"] = os.pathsep.join((*required, existing) if existing else required)
    return result


def skill_roots() -> list[Path]:
    return sorted(
        path
        for path in SKILLS_ROOT.iterdir()
        if path.is_dir() and (path / "SKILL.md").is_file()
    )


def check_skill_layout(roots: list[Path]) -> bool:
    ok = True
    for root in roots:
        missing = [str(relative) for relative in REQUIRED_SKILL_PATHS if not (root / relative).exists()]
        if missing:
            ok = False
            print(f"[layout:{root.name}] missing: {', '.join(missing)}", flush=True)
        else:
            print(f"[layout:{root.name}] ok", flush=True)
    return ok


def run_suite(label: str, start_directory: Path) -> bool:
    print(f"[suite:{label}] start", flush=True)
    result = subprocess.run(
        [
            sys.executable,
            "-B",
            "-m",
            "unittest",
            "discover",
            "-s",
            str(start_directory),
            "-q",
        ],
        cwd=ROOT,
        env=environment(),
        check=False,
    )
    status = "passed" if result.returncode == 0 else "failed"
    print(f"[suite:{label}] {status}", flush=True)
    return result.returncode == 0
