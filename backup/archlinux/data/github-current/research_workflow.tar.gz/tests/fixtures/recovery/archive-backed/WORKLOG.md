# Minimal legacy Worklog recovery excerpt

- Source: `case:qed_cone_pair/lbw_v2/20260715_lbw_cfl_50_id/WORKLOG.md`
- Source SHA-256: `4c575adf9390831e4635e5f5e7c5d00e8f9e92a237d39566e2b7ef2383d946bc`
- Fixture purpose: verify digest-indexed recovery evidence without importing history or status.
- runner_sha256: `e8417077dbcd0df45f1fee5eed2eee76fbfb29ab7eb6d2438d5732a7c419a775`
- artifact_sha256: `4dcb1910ef411f12300cf969c1b73af505661bf468cefb1a9f38c09961a62f34`
- status_updates: `none`
