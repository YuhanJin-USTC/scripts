# Minimal legacy Sim Card recovery excerpt

- Source: `case:qed_cone_pair/lbw_v2/20260715_lbw_cfl_50_id/SIM_CARD.md`
- Source SHA-256: `a536efc24336dc8645d90058b3804375e86aaead350033a285fb4198b181247d`
- Fixture purpose: verify selected stable legacy facts against the V0 in-memory Case view.
- sim_id: `qed_cone_pair/lbw_v2/20260715_lbw_cfl_50_id`
- laser_a0: `150.0`
- CFL_constant: `0.50`
- input_sha256: `a88d3655cf1f7e507b4e731451f25994e586780a1ab5d461dc22fa251c4a0b1d`
