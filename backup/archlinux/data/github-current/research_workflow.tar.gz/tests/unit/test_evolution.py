"""Test current policy models, precedence, transitions, and backlog view."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from research_workflow.core.errors import ConflictError
from research_workflow.evolution import (
    PolicyContext,
    Proposal,
    Rule,
    backlog_record_set,
    check_backlog_consistency,
    effective_policy,
    open_proposal_records,
    render_backlog,
)


DECIDED_AT = "2026-07-19T12:00:00Z"


def _proposal(
    proposal_id: str,
    scope: str,
    selector: str,
    content: dict[str, object],
    *,
    approved: bool = True,
) -> Proposal:
    value: dict[str, object] = {
        "schema": "research-workflow/policy-proposal",
        "schema_version": 1,
        "proposal_id": proposal_id,
        "status": "open",
        "scope": scope,
        "selector": selector,
        "revision": 1,
        "supersedes": [],
        "content": content,
        "evidence": ["fixture:evidence"],
        "approval": {"status": "pending"},
    }
    proposal = Proposal.from_dict(value)
    return proposal.approve("researcher", DECIDED_AT) if approved else proposal


class EvolutionModelTests(unittest.TestCase):
    """Check deterministic model behavior without live policy paths."""

    def test_global_role_project_subtree_precedence(self) -> None:
        """Apply the four accepted scope ranks in increasing priority."""

        path = Path("/fixture/Simulation/project/case/AGENTS.md")
        context = PolicyContext(path, "simulation", "project-a")
        proposals = (
            _proposal("global-rule", "global", "*", {"mode": "global", "g": 1}),
            _proposal("role-rule", "role", "simulation", {"mode": "role", "r": 2}),
            _proposal("project-rule", "project", "project-a", {"mode": "project", "p": 3}),
            _proposal("subtree-rule", "subtree", "/fixture/Simulation/project", {"mode": "subtree", "s": 4}),
        )
        effective = effective_policy((Rule.from_proposal(item) for item in proposals), context)
        self.assertEqual(effective.content, {"mode": "subtree", "g": 1, "r": 2, "p": 3, "s": 4})
        self.assertEqual(effective.rule_ids, ("global-rule", "role-rule", "project-rule", "subtree-rule"))

    def test_subtree_rule_does_not_propagate_to_sibling(self) -> None:
        """Keep a local-only rule outside a sibling context."""

        rule = Rule.from_proposal(_proposal("local-rule", "subtree", "/fixture/a", {"local": True}))
        selected = effective_policy((rule,), PolicyContext(Path("/fixture/a/AGENTS.md"), "simulation", "a"))
        sibling = effective_policy((rule,), PolicyContext(Path("/fixture/b/AGENTS.md"), "simulation", "b"))
        self.assertEqual(selected.content, {"local": True})
        self.assertEqual(sibling.content, {})

    def test_same_scope_same_key_conflict_is_refused(self) -> None:
        """Refuse equal-priority key ownership instead of choosing by time."""

        rules = (
            Rule.from_proposal(_proposal("role-a", "role", "simulation", {"key": "a"})),
            Rule.from_proposal(_proposal("role-b", "role", "simulation", {"key": "b"})),
        )
        with self.assertRaises(ConflictError):
            effective_policy(rules, PolicyContext(Path("/fixture/AGENTS.md"), "simulation", "project"))

    def test_open_approval_implemented_and_rejected_transitions(self) -> None:
        """Require approval before implementation and close terminal states."""

        proposal = _proposal("transition", "global", "*", {"gate": True}, approved=False)
        with self.assertRaises(ConflictError):
            proposal.implemented()
        approved = proposal.approve("researcher", DECIDED_AT)
        self.assertEqual(approved.status, "approved")
        self.assertFalse(approved.implemented().is_open)
        self.assertFalse(proposal.reject("researcher", DECIDED_AT).is_open)
        self.assertEqual(Rule.from_proposal(approved).approval.actor, "researcher")

    def test_proposal_digest_round_trip_and_tamper_refusal(self) -> None:
        """Serialize the computed digest and reject changed canonical content."""

        proposal = _proposal("round-trip", "global", "*", {"gate": "on"}, approved=False)
        self.assertEqual(Proposal.from_dict(proposal.to_dict()), proposal)
        changed = proposal.to_dict()
        changed["content"] = {"gate": "off"}
        with self.assertRaises(ConflictError):
            Proposal.from_dict(changed)

    def test_backlog_matches_open_json_fields_and_excludes_history(self) -> None:
        """Project only current open and approved proposal comparison fields."""

        open_item = _proposal("open-item", "role", "simulation", {"a": 1}, approved=False)
        approved = _proposal("approved-item", "project", "project-a", {"b": 2})
        implemented = approved.implemented()
        rejected = open_item.reject("researcher", DECIDED_AT)
        markdown = render_backlog((open_item, approved, implemented, rejected))
        self.assertTrue(check_backlog_consistency(markdown, (open_item, approved)))
        self.assertEqual(backlog_record_set(markdown), open_proposal_records((open_item, approved)))
        self.assertNotIn("implemented", markdown)
        self.assertNotIn("rejected", markdown)

    def test_empty_backlog_has_exact_marker(self) -> None:
        """Render the required empty-state sentence once."""

        markdown = render_backlog(())
        self.assertIn("No open proposals.\n", markdown)
        self.assertEqual(markdown.count("No open proposals."), 1)
        self.assertTrue(check_backlog_consistency(markdown, ()))

    def test_models_create_no_files(self) -> None:
        """Keep pure model and renderer calls side-effect free."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            proposal = _proposal("pure-model", "subtree", str(root), {"pure": True})
            render_backlog((proposal,))
            self.assertEqual(list(root.iterdir()), [])


if __name__ == "__main__":
    unittest.main()
