"""Validate the public schema-2 and Case-journal templates."""

from __future__ import annotations

import json
import unittest
from pathlib import Path

from research_workflow.domain import CaseRecord, KnowledgeLink, Project, Study
from research_workflow.storage.store import validate_store_document


ROOT = Path(__file__).resolve().parents[2]
TEMPLATES = ROOT / "templates"


def _document(name: str) -> dict[str, object]:
    return json.loads((TEMPLATES / name).read_text(encoding="utf-8"))


class V021TemplateTests(unittest.TestCase):
    """Keep release templates aligned with implemented public models."""

    def test_thin_store_template_uses_schema_two(self) -> None:
        document = validate_store_document(_document("STORE.json"))
        self.assertEqual(document["schema_version"], 3)
        self.assertFalse({"cases", "case_redirects", "case_deletions"} & set(document))

    def test_project_and_study_templates_accept_knowledge_links(self) -> None:
        project = Project.from_dict(_document("PROJECT.json"))
        study = Study.from_dict(_document("STUDY.json"))
        self.assertEqual((project.schema_version, study.schema_version), (2, 2))
        self.assertEqual((project.knowledge_links, study.knowledge_links), ((), ()))

    def test_case_record_template_is_a_valid_create(self) -> None:
        record = CaseRecord.from_dict(_document("CASE_RECORD.json"))
        self.assertEqual(record.action, "create")
        self.assertEqual(record.delta.sim_id, record.sim_id)

    def test_knowledge_link_template_is_explicit_notes_only(self) -> None:
        link = KnowledgeLink.from_dict(_document("KNOWLEDGE_LINK.json"))
        self.assertEqual(link.role, "theory")
        self.assertEqual(link.locator.identity, "notes")


if __name__ == "__main__":
    unittest.main()
