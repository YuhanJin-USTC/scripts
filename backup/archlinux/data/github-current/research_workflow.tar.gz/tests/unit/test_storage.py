"""Test the journal-only Store boundary."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from research_workflow.core.errors import ConflictError, DeviceIdentityError, ValidationError
from research_workflow.domain import CaseRecord, Event
from research_workflow.index import QueryIndex
from research_workflow.storage import append_event, atomic_multi_write, materialized_case_document

from tests.unit.test_case_journals import _delta, _record_id, _thin_store


class StorageTests(unittest.TestCase):
    def test_transaction_rollback_preserves_later_external_writes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            changed, sibling, dependency = (root / name for name in ("changed", "sibling", "dependency"))
            original = {changed: b"old changed", sibling: b"old sibling", dependency: b"old dependency"}
            for path, payload in original.items():
                path.write_bytes(payload)
            payloads = {changed: b"new changed", sibling: b"new sibling", dependency: original[dependency]}
            def validate():
                changed.write_bytes(b"external changed")
                dependency.write_bytes(b"external dependency")
                raise ConflictError("fixture dependency race")
            with self.assertRaisesRegex(ValidationError, "externally changed after apply; left untouched"):
                atomic_multi_write(payloads, expected=original, write=True, post_apply_validator=validate)
            self.assertEqual(changed.read_bytes(), b"external changed")
            self.assertEqual(dependency.read_bytes(), b"external dependency")
            self.assertEqual(sibling.read_bytes(), original[sibling])
            self.assertFalse(any(".txn-" in path.name for path in root.iterdir()))

    def test_case_write_requires_device(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = _thin_store(Path(temporary))
            delta = _delta("project/study/case", 1, "a")
            record = CaseRecord.build_create(delta, record_id=_record_id(1, "create"), device_id="laptop-2", recorded_at="2026-08-23T01:00:01Z")
            with self.assertRaises(DeviceIdentityError):
                store.append_case_record(record, current_device=None)

    def test_materialized_view_is_not_persisted(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = _thin_store(Path(temporary))
            delta = _delta("project/study/case", 1, "a")
            store.append_case_record(
                CaseRecord.build_create(delta, record_id=_record_id(1, "create"), device_id="laptop-2", recorded_at="2026-08-23T01:00:01Z"),
                current_device="laptop-2",
                write=True,
            )
            view = materialized_case_document(store, delta.sim_id)
            self.assertEqual(view["sim_id"], delta.sim_id)
            self.assertFalse(any(path.name == "CASE_VIEW.json" for path in store.root.rglob("CASE_VIEW.json")))

    def test_query_index_is_explicit_and_rebuildable(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            delta = _delta("project/study/case", 1, "a")
            store.append_case_record(
                CaseRecord.build_create(delta, record_id=_record_id(1, "create"), device_id="laptop-2", recorded_at="2026-08-23T01:00:01Z"),
                current_device="laptop-2",
                write=True,
            )
            path = root / "index.sqlite3"
            self.assertFalse(path.exists())
            result = QueryIndex(path).rebuild(store)
            self.assertFalse(result["authority"])
            self.assertEqual(result["counts"]["cases"], 1)

    def test_event_identity_reuses_equal_and_refuses_conflict(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = _thin_store(Path(temporary))
            document = {
                "schema": "research-workflow/event",
                "schema_version": 1,
                "event_id": "20260823T020000Z-laptop-2-event",
                "device_id": "laptop-2",
                "recorded_at": "2026-08-23T02:00:00Z",
                "occurred_at": "2026-08-23T02:00:00Z",
                "owner": {"kind": "root", "root_id": "research_workflow"},
                "kind": "validation",
                "summary": "Validated fixture",
                "evidence": [],
                "status_updates": [],
            }
            event = Event.from_dict(document)
            append_event(store.root, event, current_device="laptop-2", write=True)
            self.assertEqual(append_event(store.root, event, current_device="laptop-2", write=True).action, "reuse")
            with self.assertRaises(ConflictError):
                append_event(store.root, Event.from_dict({**document, "summary": "Conflict"}), current_device="laptop-2", write=True)

    def test_store_validation_reports_historical_orphan_diagnostic(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = _thin_store(Path(temporary))
            event = Event.from_dict(
                {
                    "schema": "research-workflow/event",
                    "schema_version": 1,
                    "event_id": "20260823T020000Z-laptop-2-orphan",
                    "device_id": "laptop-2",
                    "recorded_at": "2026-08-23T02:00:00Z",
                    "occurred_at": "2026-08-23T02:00:00Z",
                    "owner": {"kind": "case", "sim_id": "project/study/missing"},
                    "kind": "validation",
                    "summary": "Historical orphan",
                    "evidence": [],
                    "status_updates": [],
                }
            )
            append_event(store.root, event, current_device="laptop-2", write=True)
            report = store.validate()
            self.assertTrue(report.valid, report.errors)
            self.assertEqual(report.details["orphan_case_events"], 1)


if __name__ == "__main__":
    unittest.main()
