"""Test current core primitives in isolation."""

from __future__ import annotations

import unittest
from pathlib import Path

import research_workflow
from research_workflow.core import (
    FRAMEWORK_VERSION,
    SCHEMA_VERSION,
    ValidationError,
    WriteResult,
    canonical_digest,
    canonical_json_bytes,
    canonical_json_text,
    decode_json,
    recorded_month,
    validate_device_id,
    validate_digest,
    validate_event_id,
    validate_sim_id,
    validate_utc,
)


class _CoreTests(unittest.TestCase):
    """Check canonical values, identifiers, versions, and typed results."""

    def test_versions_are_current(self) -> None:
        """Expose the accepted framework, schema, and package versions."""

        self.assertEqual(FRAMEWORK_VERSION, "0")
        self.assertEqual(SCHEMA_VERSION, 1)
        self.assertEqual(research_workflow.__version__, "0.2.4")
        root = Path(__file__).resolve().parents[2]
        self.assertIn('version = "0.2.4"', (root / "pyproject.toml").read_text(encoding="utf-8"))
        for name in ("SCHEMA.md", "ARCHITECTURE.md", "README.md", "CHANGELOG.md"):
            self.assertIn("0.2.4", (root / name).read_text(encoding="utf-8"), name)

    def test_canonical_codec_is_stable(self) -> None:
        """Sort keys, preserve Unicode, and provide a stable digest."""

        value = {"b": 1, "a": "é"}
        self.assertEqual(canonical_json_bytes(value), b'{"a":"\xc3\xa9","b":1}')
        self.assertEqual(canonical_json_text(value), '{"a":"é","b":1}\n')
        self.assertEqual(len(canonical_digest(value)), 64)
        self.assertEqual(decode_json(canonical_json_bytes(value), require_canonical=True), value)

    def test_codec_rejects_ambiguous_values(self) -> None:
        """Reject duplicate keys, null, floats, and noncanonical bytes."""

        for raw in (b'{"a":1,"a":2}', b'{"a":null}', b'{"a":1.5}', b'{"b":1, "a":2}'):
            with self.assertRaises(ValidationError):
                decode_json(raw, require_canonical=True)

    def test_identifiers_and_time_are_strict(self) -> None:
        """Accept portable identities and refuse dot segments or malformed UTC."""

        self.assertEqual(validate_sim_id("project/study/case"), "project/study/case")
        self.assertEqual(validate_device_id("laptop-1"), "laptop-1")
        self.assertEqual(validate_event_id("20260718T120000Z-laptop-1"), "20260718T120000Z-laptop-1")
        self.assertEqual(recorded_month("2026-07-18T12:00:00Z"), "2026-07")
        self.assertEqual(validate_digest("a" * 64), "a" * 64)
        with self.assertRaises(ValidationError):
            validate_sim_id("project/../case")
        with self.assertRaises(ValidationError):
            validate_utc("2026-02-30T00:00:00Z")

    def test_write_result_is_portable(self) -> None:
        """Serialize a typed write result without mutating its target."""

        result = WriteResult("create", Path("/tmp/example"), "a" * 64, 10)
        self.assertEqual(result.to_dict()["written"], False)
        self.assertEqual(result.to_dict()["bytes"], 10)


if __name__ == "__main__":
    unittest.main()
