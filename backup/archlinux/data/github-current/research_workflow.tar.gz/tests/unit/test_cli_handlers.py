"""Test current CLI handler routing without version adapters."""

from __future__ import annotations

import argparse
import unittest

from research_workflow.cli.handlers import PolicyService, UnavailablePolicyService
from research_workflow.cli.parser import build_parser


def _leaves(parser: argparse.ArgumentParser) -> set[str]:
    action = next(
        (item for item in parser._actions if isinstance(item, argparse._SubParsersAction)),
        None,
    )
    if action is None:
        return {str(parser.prog)}
    result: set[str] = set()
    for child in action.choices.values():
        result.update(_leaves(child))
    return result


class CliHandlerTests(unittest.TestCase):
    def test_parser_has_twenty_nine_current_leaves(self) -> None:
        parser = build_parser()
        commands = parser._subparsers._group_actions[0].choices
        self.assertEqual(
            set(commands),
            {"context", "checkpoint", "case", "event", "validate", "cache", "device", "doctor", "policy", "sync", "store"},
        )
        self.assertEqual(len(_leaves(parser)), 29)

    def test_parser_selects_string_handler(self) -> None:
        args = build_parser().parse_args(["context", "project/study/case", "--json"])
        self.assertEqual(args.handler, "context")
        self.assertEqual(args.view, "compact")
        self.assertNotIn("func", vars(args))

        context_args = build_parser().parse_args(
            [
                "context",
                "project/study/case",
                "--view",
                "deep",
                "--select",
                "/content",
                "--include",
                "knowledge-links",
                "--include-link",
                "theory-main",
            ]
        )
        self.assertEqual(context_args.view, "deep")
        self.assertEqual(context_args.select, ["/content"])
        self.assertEqual(context_args.include_link, ["theory-main"])
        self.assertEqual(context_args.include, ["knowledge-links"])

        checkpoint_args = build_parser().parse_args(
            ["checkpoint", "project/study/case", "--stdin", "--write"]
        )
        self.assertEqual(checkpoint_args.handler, "checkpoint")
        self.assertTrue(checkpoint_args.stdin)

    def test_policy_service_seam_is_explicit(self) -> None:
        service = UnavailablePolicyService()
        self.assertIsInstance(service, PolicyService)


if __name__ == "__main__":
    unittest.main()
