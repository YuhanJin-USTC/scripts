"""Test transparent indexed context from isolated authority."""

from __future__ import annotations

import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from research_workflow.core import ValidationError
from research_workflow.core.canonical import canonical_digest, canonical_json_bytes
from research_workflow.domain import CaseDelta, CaseRecord, Event
from research_workflow.index import QueryIndex
from research_workflow.services import ContextOptions, ContextService
from research_workflow.storage import Store, append_event, atomic_json_write, case_journal_path
from research_workflow.workspace import WorkspaceRegistry

from tests.unit.test_case_journals import _delta, _historical_migration, _thin_store


def _workspace(root: Path) -> WorkspaceRegistry:
    simulation = root / "Simulation"
    data = root / "Data"
    notes = root / "Notes"
    for path in (simulation, data, notes):
        path.mkdir()
    config = root / "workspace.toml"
    config.write_text(
        f'''schema_version = 1
workspace_id = "fixture"
verified_at = "2026-07-18T00:00:00Z"

[device]
device_id = "laptop-1"

[sim_id]
strategy = "simulation-relative-posix-path"
canonical_root = "simulation"
separator = "/"
case_sensitive = true
same_relative_path_default = true
allow_absolute = false
allow_dot_segments = false

[path_aliases]
policy = "explicit-and-evidence-backed-only"

[roots.simulation]
path = "{simulation}"
kind = "simulation"
mapping = "canonical"
default_access = "project-policy"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"

[roots.data_simulation]
path = "{data}"
kind = "data"
mapping = "same-relative-path"
default_access = "read-only"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"

[roots.notes]
path = "{notes}"
kind = "notes"
mapping = "explicit-link-only"
default_access = "explicit-user-request"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"
''',
        encoding="utf-8",
    )
    return WorkspaceRegistry(config)


def _store(root: Path, *, linked: bool, large: bool = False) -> Store:
    store = Store(root / "metadata")
    atomic_json_write(
        store.store_path,
        {
            "schema": "research-workflow/store",
            "schema_version": 2,
            "framework_version": "0",
            "store_id": "fixture",
            "created_at": "2026-07-18T00:00:00Z",
            "projects": ["project"],
            "devices": ["laptop-1"],
        },
        write=True,
    )
    atomic_json_write(
        store.project_path("project"),
        {
            "schema": "research-workflow/project",
            "schema_version": 2,
            "project_id": "project",
            "name": "Project",
            "profiles": [],
            "content": {},
            "knowledge_links": [],
        },
        write=True,
    )
    study: dict[str, object] = {
        "schema": "research-workflow/study",
        "schema_version": 2,
        "project_id": "project",
        "study_id": "study",
        "name": "Study",
        "sim_prefix": "project/study",
        "profiles": [],
        "content": {},
        "knowledge_links": [],
    }
    if linked:
        study["knowledge_links"] = [{
            "link_id": "study-notes",
            "role": "theory",
            "locator": {"kind": "root", "root_id": "notes", "path": "study.md"},
            "section": "Discussion",
        }]
    atomic_json_write(store.study_path("project", "study"), study, write=True)
    atomic_json_write(
        store.device_path("laptop-1"),
        {
            "schema": "research-workflow/device",
            "schema_version": 1,
            "device_id": "laptop-1",
            "name": "Laptop 1",
            "onboarded_at": "2026-07-18T00:00:00Z",
        },
        write=True,
    )
    content = {"payload": "x" * 30000} if large else {"purpose": "fixture"}
    delta = CaseDelta.from_dict(
        {
            "schema": "research-workflow/case-delta",
            "schema_version": 1,
            "sim_id": "project/study/case",
            "project_id": "project",
            "study_id": "study",
            "revision": 1,
            "profiles": [],
            "content": content,
        }
    )
    store.append_case_record(
        CaseRecord.build_create(
            delta,
            record_id="20260718T000001Z-laptop-1-create",
            device_id="laptop-1",
            recorded_at="2026-07-18T00:00:01Z",
        ),
        current_device="laptop-1",
        write=True,
    )
    return store


class QueryIndexTests(unittest.TestCase):
    def test_symlinked_index_path_is_refused(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            target = root / "target.sqlite3"
            QueryIndex(target).stats()
            linked = root / "linked.sqlite3"
            linked.symlink_to(target)
            with self.assertRaises(ValidationError):
                QueryIndex(linked).stats()

    def test_corrupt_index_is_refused_without_replacing_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "index.sqlite3"
            original = b"not-a-sqlite-database"
            path.write_bytes(original)
            with self.assertRaises((ValidationError, sqlite3.DatabaseError)):
                QueryIndex(path).stats()
            self.assertEqual(path.read_bytes(), original)

    def test_historical_migration_record_is_indexed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            store = _thin_store(root)
            delta = _delta("project/study/historical", 1, "historical")
            record = _historical_migration(delta)
            path = case_journal_path(store.root, "project", "study", "laptop-2", "2026-08")
            path.parent.mkdir(parents=True)
            path.write_bytes(canonical_json_bytes(record.to_dict()) + b"\n")
            index = QueryIndex(root / "index.sqlite3")
            self.assertEqual(index.case(store, delta.sim_id).revision, 1)

    def test_warm_compact_context_avoids_full_case_and_event_reduction(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace = _workspace(root)
            store = _store(root, linked=False)
            service = ContextService(workspace, store)
            service.build("project/study/case")
            with mock.patch.object(
                store,
                "journal_case_heads",
                side_effect=AssertionError("full journal reduction"),
            ), mock.patch.object(
                store,
                "read_events",
                side_effect=AssertionError("full event read"),
            ):
                document = service.build("project/study/case")
            self.assertLessEqual(document["budget"]["actual_bytes"], 4096)

    def test_large_case_delta_is_deterministically_omitted(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace = _workspace(root)
            store = _store(root, linked=False, large=True)
            document = ContextService(workspace, store).build("project/study/case")
            self.assertLessEqual(document["budget"]["actual_bytes"], 4096)
            self.assertIn("/case_delta/content/payload", document["omitted_paths"])

    def test_deep_notes_content_is_deterministically_bounded(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace = _workspace(root)
            store = _store(root, linked=True)
            (root / "Notes/study.md").write_text(
                "# Study\n## Discussion\n" + "x" * 100000 + "\n## Other\nExcluded\n",
                encoding="utf-8",
            )
            document = ContextService(workspace, store).build(
                "project/study/case",
                ContextOptions(view="deep", include_links=("study-notes",)),
            )
            self.assertLessEqual(document["budget"]["actual_bytes"], 24 * 1024)
            self.assertTrue(document["links"][0]["truncated"])
            self.assertNotIn("Excluded", document["links"][0]["content"])

    def test_schema_one_notes_reads_only_exact_section(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace = _workspace(root)
            store = _store(root, linked=True)
            (root / "Notes/study.md").write_text(
                "# Study\n## Discussion\nSelected text\n### Detail\nIncluded detail\n## Other\nExcluded text\n",
                encoding="utf-8",
            )
            document = ContextService(workspace, store).build(
                "project/study/case",
                ContextOptions(view="deep", include_links=("study-notes",)),
            )
            self.assertEqual(
                document["links"][0]["content"],
                "Selected text\n### Detail\nIncluded detail",
            )
            self.assertNotIn("Excluded", document["links"][0]["content"])

    def test_notes_symlink_and_missing_section_are_refused(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace = _workspace(root)
            store = _store(root, linked=True)
            target = root / "notes-target.md"
            target.write_text("## Discussion\nUnsafe\n", encoding="utf-8")
            linked = root / "Notes/study.md"
            linked.symlink_to(target)
            with self.assertRaisesRegex(ValidationError, "missing or unsafe"):
                ContextService(workspace, store).build(
                    "project/study/case",
                    ContextOptions(view="deep", include_links=("study-notes",)),
                )
            linked.unlink()
            linked.write_text("## Other\nMissing\n", encoding="utf-8")
            with self.assertRaisesRegex(ValidationError, "section is missing"):
                ContextService(workspace, store).build(
                    "project/study/case",
                    ContextOptions(view="deep", include_links=("study-notes",)),
                )

    def test_compact_context_builds_disposable_index(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace = _workspace(root)
            store = _store(root, linked=False)
            authority_before = {
                path: path.read_bytes()
                for path in store.root.rglob("*")
                if path.is_file()
            }
            document = ContextService(workspace, store).build("project/study/case")
            self.assertLessEqual(document["budget"]["actual_bytes"], 4096)
            self.assertEqual(document["view"], "compact")
            self.assertEqual(document["case_delta"]["content"], {"purpose": "fixture"})
            self.assertEqual(document["case"]["spec_digest"], store.load_case_delta("project/study/case").digest)
            self.assertTrue(workspace.cache_path.is_file())
            self.assertEqual(
                authority_before,
                {path: path.read_bytes() for path in authority_before},
            )

    def test_event_append_and_case_revision_refresh_incrementally(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace = _workspace(root)
            store = _store(root, linked=False)
            index = QueryIndex(workspace.cache_path)
            service = ContextService(workspace, store, index=index)
            self.assertEqual(service.build("project/study/case")["recent_events"], [])
            event = Event.from_dict(
                {
                    "schema": "research-workflow/event",
                    "schema_version": 1,
                    "event_id": "20260718T120000Z-laptop-1-index",
                    "device_id": "laptop-1",
                    "recorded_at": "2026-07-18T12:00:00Z",
                    "occurred_at": "2026-07-18T12:00:00Z",
                    "owner": {"kind": "case", "sim_id": "project/study/case"},
                    "kind": "validation",
                    "summary": "Indexed event",
                    "evidence": [],
                    "status_updates": [],
                }
            )
            append_event(store.root, event, current_device="laptop-1", write=True)
            refreshed = service.build("project/study/case")
            self.assertEqual(refreshed["recent_events"][0]["event_id"], event.event_id)
            self.assertEqual(index.event_location(event.event_id)["offset"], 0)

            previous = store.load_case_delta("project/study/case")
            revised = CaseDelta.from_dict(
                {**previous.to_dict(), "revision": 2, "content": {"purpose": "revised"}}
            )
            store.append_case_record(
                CaseRecord.build_revise(
                    revised,
                    previous_digest=previous.digest,
                    record_id="20260718T120001Z-laptop-1-revise",
                    device_id="laptop-1",
                    recorded_at="2026-07-18T12:00:01Z",
                ),
                current_device="laptop-1",
                write=True,
            )
            self.assertEqual(service.build("project/study/case")["case"]["revision"], 2)

    def test_deep_select_members_and_explicit_knowledge_link(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace = _workspace(root)
            store = _store(root, linked=False)
            atomic_json_write(
                store.study_path("project", "study"),
                {
                    "schema": "research-workflow/study",
                    "schema_version": 2,
                    "project_id": "project",
                    "study_id": "study",
                    "name": "Study",
                    "sim_prefix": "project/study",
                    "profiles": [],
                    "content": {},
                    "knowledge_links": [
                        {
                            "link_id": "theory-main",
                            "role": "theory",
                            "locator": {"kind": "root", "root_id": "notes", "path": "study.md"},
                            "section": "Theory",
                        }
                    ],
                },
                write=True,
            )
            compact = ContextService(workspace, store).build("project/study/case")
            self.assertEqual(compact["knowledge_links"][0]["link_id"], "theory-main")
            self.assertNotIn("links", compact)
            (root / "Notes/study.md").write_text(
                "# Study\n## Theory\nSelected theory\n## Other\nExcluded\n",
                encoding="utf-8",
            )
            document = ContextService(workspace, store).build(
                "project/study/case",
                ContextOptions(
                    view="deep",
                    select=("/content/purpose",),
                    include=("study-members", "knowledge-links"),
                    include_links=("theory-main",),
                ),
            )
            self.assertEqual(document["selection"]["/content/purpose"], "fixture")
            self.assertNotIn("spec", document)
            self.assertNotIn("status", document)
            self.assertNotIn("recent_events", document)
            self.assertEqual(document["study"]["members"][0]["sim_id"], "project/study/case")
            self.assertEqual(document["knowledge_links"][0]["link_id"], "theory-main")
            self.assertEqual(document["links"][0]["content"], "Selected theory")
            self.assertNotIn("Excluded", document["links"][0]["content"])


if __name__ == "__main__":
    unittest.main()
