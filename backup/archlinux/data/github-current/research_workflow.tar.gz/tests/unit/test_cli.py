"""Test the exact CLI surface and isolated fixture behavior."""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import tempfile
import unittest
from pathlib import Path

from research_workflow.cli.main import main
from research_workflow.cli.parser import build_parser
from research_workflow.domain import CaseDelta, CaseRecord, Event, ProfileReference
from research_workflow.storage import Store, append_event, atomic_json_write
from research_workflow.workspace import WorkspaceRegistry


EXPECTED = {
    "context",
    "checkpoint",
    "case list",
    "case show",
    "case create",
    "case apply",
    "case revise",
    "case rename",
    "case delete",
    "event record",
    "event list",
    "event show",
    "event merge",
    "validate",
    "cache rebuild",
    "cache update",
    "device onboard",
    "doctor",
    "store upgrade",
    "policy target retire",
    "policy target reenable",
    "policy effective",
    "policy propose",
    "policy list",
    "policy plan",
    "policy approve",
    "policy apply",
    "policy check",
    "sync plan",
}


def _leaf_commands(parser: argparse.ArgumentParser, prefix: tuple[str, ...] = ()) -> set[str]:
    action = next(
        (item for item in parser._actions if isinstance(item, argparse._SubParsersAction)),
        None,
    )
    if action is None:
        return {" ".join(prefix)}
    result: set[str] = set()
    for name, child in action.choices.items():
        result.update(_leaf_commands(child, prefix + (name,)))
    return result


def _fixture(root: Path, *, device: bool = True) -> tuple[Path, Store]:
    simulation = root / "Simulation"
    data = root / "Data"
    notes = root / "Notes"
    for path in (simulation, data, notes):
        path.mkdir()
    device_text = '\n[device]\ndevice_id = "laptop-1"\n' if device else ""
    workspace = root / "workspace.toml"
    workspace.write_text(
        f'''schema_version = 1
workspace_id = "fixture"
verified_at = "2026-07-18T00:00:00Z"
{device_text}
[sim_id]
strategy = "simulation-relative-posix-path"
canonical_root = "simulation"
separator = "/"
case_sensitive = true
same_relative_path_default = true
allow_absolute = false
allow_dot_segments = false

[path_aliases]
policy = "explicit-and-evidence-backed-only"

[roots.simulation]
path = "{simulation}"
kind = "simulation"
mapping = "canonical"
default_access = "project-policy"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"

[roots.data_simulation]
path = "{data}"
kind = "data"
mapping = "same-relative-path"
default_access = "read-only"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"

[roots.notes]
path = "{notes}"
kind = "notes"
mapping = "explicit-link-only"
default_access = "explicit-user-request"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"
''',
        encoding="utf-8",
    )
    store = Store(root / "metadata")
    atomic_json_write(
        store.store_path,
        {
            "schema": "research-workflow/store",
            "schema_version": 2,
            "framework_version": "0",
            "store_id": "fixture",
            "created_at": "2026-07-18T00:00:00Z",
            "projects": ["project"],
            "devices": ["laptop-1"] if device else [],
        },
        write=True,
    )
    atomic_json_write(
        store.project_path("project"),
        {
            "schema": "research-workflow/project",
            "schema_version": 2,
            "project_id": "project",
            "name": "Project",
            "profiles": [],
            "content": {},
            "knowledge_links": [],
        },
        write=True,
    )
    atomic_json_write(
        store.study_path("project", "study"),
        {
            "schema": "research-workflow/study",
            "schema_version": 2,
            "project_id": "project",
            "study_id": "study",
            "name": "Study",
            "sim_prefix": "project/study",
            "profiles": [],
            "content": {},
            "knowledge_links": [],
        },
        write=True,
    )
    if device:
        atomic_json_write(
            store.device_path("laptop-1"),
            {
                "schema": "research-workflow/device",
                "schema_version": 1,
                "device_id": "laptop-1",
                "name": "Laptop 1",
                "onboarded_at": "2026-07-18T00:00:00Z",
            },
            write=True,
        )
    return workspace, store


def _run(arguments: list[str]) -> tuple[int, str, str]:
    output = io.StringIO()
    errors = io.StringIO()
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(errors):
        code = main(arguments)
    return code, output.getvalue(), errors.getvalue()


def _confirmed(arguments):
    from tests.integration.confirmation_helpers import preview_and_apply
    output, errors = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(errors):
        code = preview_and_apply(arguments)
    return code, output.getvalue(), errors.getvalue()


class _CliTests(unittest.TestCase):
    """Check command count, dry-run gates, exit codes, and service seam."""

    def test_parser_has_exact_current_leaf_commands(self) -> None:
        """Expose only the accepted grouped versionless command set."""

        leaves = _leaf_commands(build_parser())
        self.assertEqual(leaves, EXPECTED)
        help_text = build_parser().format_help()
        for forbidden in ("context-v2", "record-v2", "sync-plan", "cache status"):
            self.assertNotIn(forbidden, help_text)
        retired = (
            ["store", "upgrade"],
            ["case", "migrate", "project/study/case"],
            ["context", "project/study/case", "--mode", "task"],
            ["case", "revise", "project/study/case", "--delta", "delta.json", "--expect-digest", "0" * 64],
            ["event", "record", "root:simulation", "--kind", "correction", "--summary", "x", "--correct-owner"],
            ["case", "create", "project/study/case", "--project-id", "project", "--study-id", "study", "--study-notes-section", "Theory"],
        )
        for arguments in retired:
            with self.subTest(arguments=arguments), contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
                build_parser().parse_args(arguments)

    def test_case_preview_and_write_are_isolated(self) -> None:
        """Keep preview side-effect free and write only the fixture Store."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, store = _fixture(root)
            delta = root / "delta.json"
            delta.write_text(
                json.dumps(
                    {
                        "schema": "research-workflow/case-delta",
                        "schema_version": 1,
                        "sim_id": "project/study/case",
                        "project_id": "project",
                        "study_id": "study",
                        "revision": 1,
                        "profiles": [],
                        "content": {"purpose": "fixture"},
                    }
                ),
                encoding="utf-8",
            )
            base = ["--workspace", str(workspace), "case", "create", "project/study/case", "--delta", str(delta), "--json"]
            code, output, _ = _run(base)
            self.assertEqual(code, 0, output)
            self.assertEqual(json.loads(output)["input_mode"], "document")
            self.assertFalse((store.root / "cases").exists())
            code, _, errors = _confirmed(base)
            self.assertEqual(code, 0, errors)
            code, output, _ = _run(["--workspace", str(workspace), "case", "show", "project/study/case", "--json"])
            self.assertEqual(code, 0)
            self.assertEqual(json.loads(output)["sim_id"], "project/study/case")

    def test_case_create_bootstraps_new_project_and_round_trips_parameters(self) -> None:
        """Create the first Case through the public CLI in one transaction."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, store = _fixture(root)
            existing_project = store.project_path("project").read_bytes()
            project = root / "project.json"
            study = root / "study.json"
            delta = root / "delta.json"
            project.write_text(
                json.dumps(
                    {
                        "schema": "research-workflow/project",
                        "schema_version": 2,
                        "project_id": "numerical_heating",
                        "name": "Numerical Heating",
                        "profiles": [],
                        "content": {"code": "EPOCH"},
                        "knowledge_links": [],
                    }
                ),
                encoding="utf-8",
            )
            study.write_text(
                json.dumps(
                    {
                        "schema": "research-workflow/study",
                        "schema_version": 2,
                        "project_id": "numerical_heating",
                        "study_id": "baseline",
                        "name": "Baseline",
                        "sim_prefix": "test_sim/test_epoch/numerical_heating",
                        "profiles": [],
                        "content": {},
                        "knowledge_links": [],
                    }
                ),
                encoding="utf-8",
            )
            sim_id = "test_sim/test_epoch/numerical_heating/20260722_nh_baseline_v1"
            parameters = {
                "grid": {"nx": 400, "ny": 400},
                "cfl": "0.95",
                "density": "800 n_c",
                "runtime": "100 fs",
            }
            delta.write_text(
                json.dumps(
                    {
                        "schema": "research-workflow/case-delta",
                        "schema_version": 1,
                        "sim_id": sim_id,
                        "project_id": "numerical_heating",
                        "study_id": "baseline",
                        "revision": 1,
                        "profiles": [],
                        "content": {"parameters": parameters},
                    }
                ),
                encoding="utf-8",
            )
            arguments = [
                "--workspace",
                str(workspace),
                "case",
                "create",
                sim_id,
                "--delta",
                str(delta),
                "--project",
                str(project),
                "--study",
                str(study),
                "--json",
            ]

            code, output, errors = _run(arguments)
            self.assertEqual(code, 0, errors)
            self.assertEqual(len(json.loads(output)["operations"]), 4)
            self.assertFalse(store.project_path("numerical_heating").exists())

            code, _, errors = _confirmed(arguments)
            self.assertEqual(code, 0, errors)
            code, output, errors = _run(
                ["--workspace", str(workspace), "case", "show", sim_id, "--json"]
            )
            self.assertEqual(code, 0, errors)
            self.assertEqual(json.loads(output)["content"]["parameters"], parameters)
            self.assertEqual(store.project_path("project").read_bytes(), existing_project)

    def test_case_create_inline_bootstraps_canonical_documents_without_files(self) -> None:
        """Build the first Project, Study, and Case from explicit inline inputs."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, store = _fixture(root)
            for scope, profile_id, content in (
                ("project-layer", "base", {"project_profile": True}),
                ("study-layer", "base", {"study_profile": True}),
                ("case-layer", "base", {"case_profile": True}),
            ):
                reference = ProfileReference(scope, profile_id)
                atomic_json_write(
                    store.profile_path(reference),
                    {
                        "schema": "research-workflow/profile",
                        "schema_version": 1,
                        "profile_id": profile_id,
                        "scope": scope,
                        "name": f"{scope} profile",
                        "content": content,
                    },
                    write=True,
                )
            sim_id = "explicit/location/case"
            arguments = [
                "--workspace",
                str(workspace),
                "case",
                "create",
                sim_id,
                "--project-id",
                "inline-project",
                "--study-id",
                "inline-study",
                "--content-json",
                '{"case_value":3}',
                "--case-profile",
                "case-layer:base",
                "--project-name",
                "Inline Project",
                "--project-content-json",
                '{"project_value":1}',
                "--project-profile",
                "project-layer:base",
                "--study-name",
                "Inline Study",
                "--study-prefix",
                "explicit/location",
                "--study-content-json",
                '{"study_value":2}',
                "--study-profile",
                "study-layer:base",
                "--json",
            ]

            code, output, errors = _run(arguments)
            self.assertEqual(code, 0, errors)
            preview = json.loads(output)
            self.assertEqual(preview["input_mode"], "inline")
            self.assertEqual(preview["registration"]["revision"], 1)
            self.assertEqual(len(preview["operations"]), 4)
            self.assertFalse(store.project_path("inline-project").exists())

            code, _, errors = _confirmed(arguments)
            self.assertEqual(code, 0, errors)
            delta = store.load_case_delta(sim_id)
            self.assertEqual((delta.project_id, delta.study_id), ("inline-project", "inline-study"))
            project = store.load_project("inline-project")
            study = store.load_study("inline-project", "inline-study")
            self.assertEqual(project.content, {"project_value": 1})
            self.assertEqual(study.content, {"study_value": 2})
            self.assertIsNone(study.notes)
            code, output, errors = _run(
                ["--workspace", str(workspace), "case", "show", sim_id, "--json"]
            )
            self.assertEqual(code, 0, errors)
            content = json.loads(output)["content"]
            self.assertEqual(
                content,
                {
                    "case_profile": True,
                    "case_value": 3,
                    "project_profile": True,
                    "project_value": 1,
                    "study_profile": True,
                    "study_value": 2,
                },
            )

    def test_case_create_inline_uses_existing_hierarchy_and_rejects_bootstrap_flags(self) -> None:
        """Keep bootstrap-only options explicit and refuse silently ignored inputs."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, store = _fixture(root)
            base = [
                "--workspace",
                str(workspace),
                "case",
                "create",
                "project/study/inline",
                "--project-id",
                "project",
                "--study-id",
                "study",
                "--revision",
                "3",
                "--content-json",
                '{"purpose":"inline"}',
            ]
            code, output, errors = _confirmed(base + ["--json"])
            self.assertEqual(code, 0, errors)
            result = json.loads(output)
            self.assertEqual(result["input_mode"], "inline")
            self.assertEqual(len(result["operations"]), 1)
            self.assertEqual(store.load_case_delta("project/study/inline").revision, 3)

            for option, value, message in (
                ("--project-name", "Ignored", "existing Project"),
                ("--project-content-json", "{}", "existing Project"),
                ("--study-name", "Ignored", "existing Study"),
                ("--study-prefix", "project/study", "existing Study"),
            ):
                with self.subTest(option=option):
                    changed = base.copy()
                    changed[4] = f"project/study/reject-{option[2:]}"
                    code, _, errors = _run(changed + [option, value, "--json"])
                    self.assertEqual(code, 2)
                    self.assertIn(message, errors)

    def test_case_create_rejects_inline_document_mixing_and_incomplete_bootstrap(self) -> None:
        """Require one complete, unambiguous registration input mode."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, _ = _fixture(root)
            delta = root / "delta.json"
            delta.write_text("{}", encoding="utf-8")
            prefix = ["--workspace", str(workspace), "case", "create", "project/study/case"]
            checks = (
                (["--delta", str(delta), "--project-id", "project"], "cannot be combined"),
                (["--project", str(delta)], "require --delta"),
                ([], "requires --project-id and --study-id"),
                (["--project-id", "new", "--study-id", "new"], "requires --project-name"),
                (
                    [
                        "--project-id",
                        "project",
                        "--study-id",
                        "new",
                        "--study-name",
                        "New Study",
                    ],
                    "requires --study-name and --study-prefix",
                ),
            )
            for arguments, message in checks:
                with self.subTest(message=message):
                    code, _, errors = _run(prefix + arguments + ["--json"])
                    self.assertEqual(code, 2)
                    self.assertIn(message, errors)

    def test_case_create_inline_rejects_invalid_json_profiles_and_notes_pair(self) -> None:
        """Apply canonical JSON, profile, and explicit Notes-link validation gates."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, _ = _fixture(root)
            base = [
                "--workspace",
                str(workspace),
                "case",
                "create",
                "project/study/case",
                "--project-id",
                "project",
                "--study-id",
                "study",
            ]
            invalid_json = ("{", "[]", '{"x":1,"x":2}', '{"x":1.5}', '{"x":null}')
            for value in invalid_json:
                with self.subTest(json=value):
                    code, _, errors = _run(base + ["--content-json", value, "--json"])
                    self.assertEqual(code, 2)
                    self.assertTrue("JSON" in errors or "object" in errors or "forbidden" in errors)

            checks = (
                (["--case-profile", "missing-colon"], "SCOPE:PROFILE_ID"),
                (["--case-profile", "scope:missing"], "profiles/scope/missing"),
            )
            for arguments, message in checks:
                with self.subTest(message=message):
                    code, _, errors = _run(base + arguments + ["--json"])
                    self.assertEqual(code, 2)
                    self.assertIn(message, errors)

    def test_missing_device_refuses_case_preview(self) -> None:
        """Expose device identity refusal at the service boundary."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, _ = _fixture(root, device=False)
            delta = root / "delta.json"
            delta.write_text(
                json.dumps(
                    {
                        "schema": "research-workflow/case-delta",
                        "schema_version": 1,
                        "sim_id": "project/study/case",
                        "project_id": "project",
                        "study_id": "study",
                        "revision": 1,
                        "profiles": [],
                        "content": {},
                    }
                ),
                encoding="utf-8",
            )
            code, _, errors = _run(["--workspace", str(workspace), "case", "create", "project/study/case", "--delta", str(delta)])
            self.assertEqual(code, 2)
            self.assertIn("device_id", errors)

    def test_policy_seam_refuses_without_side_effects(self) -> None:
        """Return the reserved-service exit code and create no policy tree."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, _ = _fixture(root)
            code, _, errors = _run(["--workspace", str(workspace), "policy", "effective"])
            self.assertEqual(code, 2)
            self.assertIn("explicit policy.targets", errors)
            self.assertFalse((root / "policy").exists())

    def test_event_record_preview_then_append(self) -> None:
        """Preview exact event identity and append only after explicit write."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, store = _fixture(root)
            delta = CaseDelta.from_dict(
                {
                    "schema": "research-workflow/case-delta",
                    "schema_version": 1,
                    "sim_id": "project/study/case",
                    "project_id": "project",
                    "study_id": "study",
                    "revision": 1,
                    "profiles": [],
                    "content": {},
                }
            )
            store.append_case_record(
                CaseRecord.build_create(
                    delta,
                    record_id="20260718T110000Z-laptop-1-create",
                    device_id="laptop-1",
                    recorded_at="2026-07-18T11:00:00Z",
                ),
                current_device="laptop-1",
                write=True,
            )
            arguments = [
                "--workspace",
                str(workspace),
                "event",
                "record",
                "project/study/case",
                "--kind",
                "validation",
                "--summary",
                "Validated fixture",
                "--evidence",
                "case:project/study/case",
                "--event-id",
                "20260718T120000Z-laptop-1",
                "--occurred-at",
                "2026-07-18T12:00:00Z",
                "--json",
            ]
            code, _, errors = _run(arguments)
            self.assertEqual(code, 0, errors)
            self.assertEqual(store.event_paths(), [])
            code, _, errors = _run(arguments[:-1] + ["--write", "--json"])
            self.assertEqual(code, 0, errors)
            self.assertEqual(len(store.read_events()), 1)

    def test_event_record_rejects_unknown_case_but_allows_root_owner(self) -> None:
        """Gate new orphan events without narrowing root-owned records."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, store = _fixture(root)
            unknown = [
                "--workspace",
                str(workspace),
                "event",
                "record",
                "project/study/missing",
                "--kind",
                "validation",
                "--summary",
                "Unknown Case",
                "--event-id",
                "20260718T120000Z-laptop-1-unknown",
                "--occurred-at",
                "2026-07-18T12:00:00Z",
                "--json",
            ]
            code, _, errors = _run(unknown)
            self.assertEqual(code, 2)
            self.assertIn("existing exact directory", errors)
            self.assertEqual(store.event_paths(), [])

            root_event = [
                "--workspace",
                str(workspace),
                "event",
                "record",
                "root:simulation",
                "--kind",
                "validation",
                "--summary",
                "Validated root fixture",
                "--event-id",
                "20260718T120100Z-laptop-1-root",
                "--occurred-at",
                "2026-07-18T12:01:00Z",
                "--write",
                "--json",
            ]
            code, _, errors = _run(root_event)
            self.assertEqual(code, 0, errors)
            events = store.read_events()
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0].owner.kind, "root")
            self.assertEqual(events[0].owner.identity, "simulation")

    def test_device_onboard_preview_then_write(self) -> None:
        """Establish device identity only through the explicit onboarding write."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace, store = _fixture(root, device=False)
            arguments = ["--workspace", str(workspace), "device", "onboard", "--device-id", "desktop-1", "--json"]
            code, _, errors = _run(arguments)
            self.assertEqual(code, 0, errors)
            self.assertFalse(store.device_path("desktop-1").exists())
            code, _, errors = _run(arguments[:-1] + ["--write", "--json"])
            self.assertEqual(code, 0, errors)
            self.assertEqual(WorkspaceRegistry(workspace).device_id, "desktop-1")
            self.assertIn("desktop-1", store.load_store()["devices"])

    def test_parser_validates_expect_digest(self) -> None:
        """Reject malformed optimistic-write digests during argument parsing."""

        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            build_parser().parse_args(["case", "revise", "a/b/c", "--revision", "2", "--content-patch-json", "{}", "--expect-digest", "bad"])


if __name__ == "__main__":
    unittest.main()
