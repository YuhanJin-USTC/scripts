"""Test bounded portable work queries and exact ownership."""

from __future__ import annotations

import json
import sqlite3
import tempfile
import unittest
from pathlib import Path

from research_workflow import __version__
from research_workflow.core.errors import ValidationError
from research_workflow.domain import Event
from research_workflow.index import QueryIndex
from research_workflow.services import ContextOptions, ContextService
from research_workflow.services.queries import MemoryQuery
from research_workflow.storage import append_event
from research_workflow.workspace import WorkspaceRegistry
from tests.unit.test_cli import _run
from tests.unit.test_query_index import _store, _workspace


TARGET = "project/study/case"


def event(store, owner, number, *, summary="Validated work", evidence=(), correction=None, status=()):
    stamp = f"2026-07-18T12:{number // 60:02d}:{number % 60:02d}Z"
    document = {
        "schema": "research-workflow/event", "schema_version": 1,
        "event_id": stamp.replace("-", "").replace(":", "") + "-laptop-1-query",
        "device_id": "laptop-1", "recorded_at": stamp, "occurred_at": stamp,
        "owner": owner, "kind": "correction" if correction else "validation",
        "summary": summary, "evidence": list(evidence), "status_updates": list(status),
    }
    if correction:
        document["correction"] = correction
    value = Event.from_dict(document)
    append_event(store.root, value, current_device="laptop-1", write=True)
    return value


class MemoryQueryTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.workspace = _workspace(self.root)
        self.store = _store(self.root, linked=False)
        self.memory = MemoryQuery(self.workspace, self.store)

    def test_logical_root_read_does_not_require_local_registration(self):
        owner = {"kind": "root", "root_id": "matlab_theory", "path": "epoch_initial_distribution"}
        item = event(self.store, owner, 1)
        context = ContextService(self.workspace, self.store).build("root:matlab_theory/epoch_initial_distribution")
        self.assertFalse(context["mappingAvailable"])
        self.assertEqual(context["recent_events"][0]["event_id"], item.event_id)
        self.assertNotIn("status", context)
        with self.assertRaises(ValidationError):
            self.memory.selector(str(self.root / "unknown-local-root"))

    def test_local_root_and_known_case_ancestors_are_not_missing_cases(self):
        for path in (self.workspace.simulation_root, self.workspace.simulation_root / "project",
                     self.workspace.simulation_root / "project/study"):
            with self.subTest(path=path):
                selected = self.memory.selector(str(path))
                self.assertEqual(selected.kind, "root")
                context = ContextService(self.workspace, self.store).build(str(path))
                self.assertNotIn("case", context)
                self.assertNotIn("next_action", context)
        self.assertEqual(self.memory.selector("study:project#study").kind, "study")
        self.assertEqual(self.memory.selector("project:project").kind, "project")

    def test_root_exact_and_explicit_recursive_do_not_merge_siblings(self):
        for number, path in enumerate((None, "beam", "beam/sub", "beam-other", "beam/sub/deep"), 1):
            owner = {"kind": "root", "root_id": "matlab_theory"}
            if path:
                owner["path"] = path
            event(self.store, owner, number)
        selector = self.memory.selector("root:matlab_theory/beam")
        exact = self.memory.events(selector)
        recursive = self.memory.events(selector, recursive=True)
        self.assertEqual(exact["total"], 1)
        self.assertEqual(recursive["total"], 3)
        root = self.memory.selector("root:matlab_theory")
        self.assertEqual(self.memory.events(root)["total"], 1)
        self.assertEqual(self.memory.events(root, recursive=True)["total"], 5)
        with self.assertRaisesRegex(ValidationError, "root/path"):
            self.memory.events(self.memory.selector(TARGET), recursive=True)

    def test_count_time_and_literal_unicode_substring_filters(self):
        for number in range(25):
            event(self.store, {"kind": "case", "sim_id": TARGET}, number, summary=f"Straße photon 50%_ {number}")
        selected = self.memory.selector(TARGET)
        limited = self.memory.events(selected)
        self.assertEqual((limited["count"], limited["total"], limited["omitted"]), (20, 25, 5))
        self.assertTrue(limited["truncated"])
        filtered = self.memory.events(selected, since="2026-07-18T12:00:23Z", query="STRASSE photon 50%_")
        self.assertEqual(filtered["count"], 2)
        self.assertEqual(self.memory.events(selected, query="50__")["count"], 0)
        self.assertEqual(self.memory.events(selected, limit=0)["omitted"], 25)
        for limit in (-1, 101, True):
            with self.assertRaises(ValidationError):
                self.memory.events(selected, limit=limit)
        with self.assertRaises(ValidationError):
            self.memory.events(selected, since="yesterday")

    def test_case_joins_only_exact_prepared_directory_and_parent_is_separate(self):
        prepared = event(self.store, {"kind": "root", "root_id": "simulation", "path": TARGET}, 1)
        owned = event(self.store, {"kind": "case", "sim_id": TARGET}, 2)
        event(self.store, {"kind": "root", "root_id": "simulation", "path": TARGET + "-other"}, 3)
        parent = event(self.store, {"kind": "study", "project_id": "project", "study_id": "study"}, 4)
        context = ContextService(self.workspace, self.store).build(TARGET)
        self.assertEqual({item["event_id"] for item in context["recent_events"]}, {prepared.event_id, owned.event_id})
        self.assertEqual(context["parent_background"]["recent_events"][0]["event_id"], parent.event_id)
        self.assertEqual(context["recent_events"][1]["owner"], prepared.owner.to_dict())
        for target in ("study:project#study", "project:project"):
            aggregate = ContextService(self.workspace, self.store).build(target)
            self.assertEqual(aggregate["progress"]["total"], 3)
            self.assertNotIn("status", aggregate)

    def test_corrections_remain_visible_when_filters_omit_replacement(self):
        owner = {"kind": "case", "sim_id": TARGET}
        first = event(self.store, owner, 1, summary="Initial interpretation")
        replacement = event(self.store, owner, 2, summary="Corrected interpretation", evidence=[{
            "id": "E1", "kind": "validation", "locator": owner,
            "observation": "Rechecked interpretation", "observed_at": "2026-07-18T12:00:02Z",
        }], correction={
            "corrects": first.event_id, "fields": ["/summary"], "status_tracks": [],
        })
        result = self.memory.events(self.memory.selector(TARGET), query="Initial")
        self.assertEqual(result["count"], 1)
        self.assertEqual(result["events"][0]["corrected_by"][0]["event_id"], replacement.event_id)
        shown = self.memory.index.show_event(self.store, first.event_id)
        self.assertEqual({key: shown[key] for key in first.to_dict()}, first.to_dict())
        self.assertEqual(shown["corrected_by"][0]["fields"], ["/summary"])
        self.assertEqual(self.memory.index.show_event(self.store, replacement.event_id)["correction"]["corrects"], first.event_id)

    def test_real_event_status_is_preserved_and_projection_is_opt_in(self):
        evidence = [{"id": "E1", "kind": "validation", "locator": {"kind": "case", "sim_id": TARGET},
                     "observation": "Numerical check completed", "observed_at": "2026-07-18T12:00:01Z"}]
        item = event(self.store, {"kind": "case", "sim_id": TARGET}, 1, evidence=evidence,
                     status=[{"track": "analysis", "state": "completed", "evidence_ids": ["E1"]}])
        service = ContextService(self.workspace, self.store)
        for options in (ContextOptions(), ContextOptions(view="deep"), ContextOptions(include=("event-details",))):
            self.assertNotIn("status", service.build(TARGET, options))
        self.assertEqual(service.build(TARGET, ContextOptions(include=("status",)))["status"]["analysis"]["state"], "completed")
        self.assertEqual(self.memory.index.show_event(self.store, item.event_id)["status_updates"], item.to_dict()["status_updates"])
        self.assertEqual(self.memory.events(self.memory.selector(TARGET), query="Numerical")["count"], 1)

    def test_large_case_retains_recent_ids_and_explicit_follow_up(self):
        large_root = self.root / "large"
        large_root.mkdir()
        workspace = _workspace(large_root)
        store = _store(large_root, linked=False, large=True)
        ids = [event(store, {"kind": "case", "sim_id": TARGET}, number, summary="Result " + "x" * 10000).event_id for number in range(6)]
        context = ContextService(workspace, store).build(TARGET, ContextOptions(recent=6))
        self.assertLessEqual(context["budget"]["actual_bytes"], 4096)
        self.assertTrue(context["recent_events"])
        self.assertEqual(context["recent_events"][0]["event_id"], ids[-1])
        self.assertEqual(context["progress"]["omitted"], 6 - len(context["recent_events"]))
        self.assertEqual(context["progress"]["follow_up"]["target"], "case:" + TARGET)
        self.assertIn("/case_delta/content/payload", context["omitted_paths"])
        self.assertTrue(context["budget"]["truncated"])

    def test_index_schema_change_rebuilds_owner_paths_from_authority(self):
        owner = {"kind": "root", "root_id": "matlab_theory", "path": "beam"}
        item = event(self.store, owner, 1)
        before = {path: path.read_bytes() for path in self.store.event_paths()}
        selected = self.memory.selector("root:matlab_theory/beam")
        first = self.memory.events(selected)
        with sqlite3.connect(self.workspace.cache_path) as connection:
            connection.execute("PRAGMA user_version=4")
        connection.close()
        second = self.memory.events(selected)
        self.assertEqual(first, second)
        self.assertEqual(second["events"][0]["event_id"], item.event_id)
        self.assertEqual(before, {path: path.read_bytes() for path in before})

    def test_explicit_aliases_associate_only_matching_canonical_directory(self):
        config = self.workspace.config_path
        config.write_text(config.read_text() + f'''
[[path_aliases.entries]]
root = "data_simulation"
source_prefix = "analysis"
canonical_prefix = "{TARGET}"
evidence = "fixture mapping"
verified_at = "2026-07-18T00:00:00Z"

[[path_aliases.entries]]
root = "data_simulation"
source_prefix = "{TARGET}"
canonical_prefix = "other/study/case"
evidence = "fixture mapping"
verified_at = "2026-07-18T00:00:00Z"
''')
        workspace = WorkspaceRegistry(config)
        matched = event(self.store, {"kind": "root", "root_id": "data_simulation", "path": "analysis"}, 1)
        event(self.store, {"kind": "root", "root_id": "data_simulation", "path": TARGET}, 2)
        event(self.store, {"kind": "root", "root_id": "matlab_theory", "path": TARGET}, 3)
        memory = MemoryQuery(workspace, self.store)
        result = memory.events(memory.selector(TARGET))
        self.assertEqual([item["event_id"] for item in result["events"]], [matched.event_id])

    def test_many_exact_owners_do_not_exceed_sql_expression_depth(self):
        item = event(self.store, {"kind": "case", "sim_id": TARGET}, 1)
        owners = {("case", f"project/study/case-{number}", "") for number in range(1200)}
        owners.add(("case", TARGET, ""))
        result = self.memory.index.list_events(self.store, owners)
        self.assertEqual(result["events"][0]["event_id"], item.event_id)

    def test_cli_read_surface_and_runtime_version(self):
        event(self.store, {"kind": "root", "root_id": "matlab_theory", "path": "beam"}, 1)
        prefix = ["--workspace", str(self.workspace.config_path)]
        code, output, errors = _run(prefix + ["event", "list", "root:matlab_theory", "--recursive", "--limit", "1", "--json"])
        self.assertEqual((code, errors), (0, ""))
        self.assertEqual(json.loads(output)["count"], 1)
        code, output, errors = _run(prefix + ["doctor", "--json"])
        self.assertEqual((code, errors), (0, ""))
        self.assertEqual(json.loads(output)["framework_version"], __version__)


if __name__ == "__main__":
    unittest.main()
