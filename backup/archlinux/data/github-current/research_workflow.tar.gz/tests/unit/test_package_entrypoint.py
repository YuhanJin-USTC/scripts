"""Test direct src package import and python -m fixture execution."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import research_workflow
from research_workflow.cli.main import main


PROJECT_ROOT = Path(__file__).resolve().parents[2]
SOURCE_ROOT = PROJECT_ROOT / "src"


def _workspace(root: Path) -> Path:
    simulation = root / "Simulation"
    data = root / "Data"
    notes = root / "Notes"
    for path in (simulation, data, notes):
        path.mkdir()
    path = root / "workspace.toml"
    path.write_text(
        f'''schema_version = 1
workspace_id = "entrypoint-fixture"
verified_at = "2026-07-18T00:00:00Z"

[device]
device_id = "laptop-1"

[sim_id]
strategy = "simulation-relative-posix-path"
canonical_root = "simulation"
separator = "/"
case_sensitive = true
same_relative_path_default = true
allow_absolute = false
allow_dot_segments = false

[path_aliases]
policy = "explicit-and-evidence-backed-only"

[roots.simulation]
path = "{simulation}"
kind = "simulation"
mapping = "canonical"
default_access = "project-policy"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"

[roots.data_simulation]
path = "{data}"
kind = "data"
mapping = "same-relative-path"
default_access = "read-only"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"

[roots.notes]
path = "{notes}"
kind = "notes"
mapping = "explicit-link-only"
default_access = "explicit-user-request"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"
''',
        encoding="utf-8",
    )
    return path


def _environment() -> dict[str, str]:
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["PYTHONPATH"] = str(SOURCE_ROOT)
    return environment


class _PackageEntrypointTests(unittest.TestCase):
    """Check package versions, direct import, module help, and isolated CLI smoke."""

    def test_public_package_exports_current_identity(self) -> None:
        """Expose only the current package identity and callable entry point."""

        self.assertEqual(research_workflow.__version__, "0.2.4")
        self.assertEqual(research_workflow.FRAMEWORK_VERSION, "0")
        self.assertTrue(callable(main))

    def test_direct_import_uses_src_package(self) -> None:
        """Import the standard src package from an isolated working directory."""

        with tempfile.TemporaryDirectory() as temporary:
            result = subprocess.run(
                [sys.executable, "-P", "-B", "-c", "import research_workflow; print(research_workflow.__version__)"],
                cwd=temporary,
                env=_environment(),
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout.strip(), "0.2.4")

    def test_module_help_exposes_versionless_groups(self) -> None:
        """Run module help without invoking the unchanged live wrapper."""

        with tempfile.TemporaryDirectory() as temporary:
            result = subprocess.run(
                [sys.executable, "-P", "-B", "-m", "research_workflow", "--help"],
                cwd=temporary,
                env=_environment(),
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("Research Workflow 0.x metadata control", result.stdout)
            self.assertNotIn("context-v2", result.stdout)

    def test_module_fixture_smoke_has_no_external_execution(self) -> None:
        """Run sync plan against a temp workspace and verify no execution action."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workspace = _workspace(root)
            result = subprocess.run(
                [
                    sys.executable,
                    "-P",
                    "-B",
                    "-m",
                    "research_workflow",
                    "--workspace",
                    str(workspace),
                    "sync",
                    "plan",
                    "--json",
                ],
                cwd=temporary,
                env=_environment(),
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertFalse(json.loads(result.stdout)["execution"])
            self.assertFalse(any(root.rglob("__pycache__")))


if __name__ == "__main__":
    unittest.main()
