"""Test thin Store Case journals and historical migration records."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from research_workflow.core.canonical import canonical_json_bytes
from research_workflow.core.errors import ConflictError, ValidationError
from research_workflow.domain import CaseDelta, CaseRecord, reduce_case_records
from research_workflow.storage import Store, append_case_records, atomic_json_write, case_journal_path, validate_store_document


def _delta(sim_id: str, revision: int, value: str) -> CaseDelta:
    return CaseDelta.from_dict(
        {
            "schema": "research-workflow/case-delta",
            "schema_version": 1,
            "sim_id": sim_id,
            "project_id": "project",
            "study_id": "study",
            "revision": revision,
            "profiles": [],
            "content": {"parameter": value},
        }
    )


def _record_id(second: int, slug: str) -> str:
    return f"20260823T0100{second:02d}Z-laptop-2-{slug}"


def _write_authority(path: Path, document: dict[str, object]) -> None:
    atomic_json_write(path, document, write=True)


def _thin_store(root: Path) -> Store:
    metadata = root / "metadata"
    _write_authority(
        metadata / "STORE.json",
        {
            "schema": "research-workflow/store",
            "schema_version": 2,
            "framework_version": "0",
            "store_id": "test-store",
            "created_at": "2026-08-23T00:00:00Z",
            "projects": ["project"],
            "devices": ["laptop-2"],
        },
    )
    _write_authority(
        metadata / "projects/project/PROJECT.json",
        {
            "schema": "research-workflow/project",
            "schema_version": 2,
            "project_id": "project",
            "name": "Project",
            "profiles": [],
            "content": {"shared": "project"},
            "knowledge_links": [],
        },
    )
    _write_authority(
        metadata / "studies/project/study/STUDY.json",
        {
            "schema": "research-workflow/study",
            "schema_version": 2,
            "project_id": "project",
            "study_id": "study",
            "name": "Study",
            "sim_prefix": "project/study",
            "profiles": [],
            "content": {"shared": "study"},
            "knowledge_links": [],
        },
    )
    _write_authority(
        metadata / "devices/laptop-2.json",
        {
            "schema": "research-workflow/device",
            "schema_version": 1,
            "device_id": "laptop-2",
            "name": "Laptop 2",
            "onboarded_at": "2026-08-23T00:00:00Z",
        },
    )
    return Store(metadata)


def _historical_migration(delta: CaseDelta) -> CaseRecord:
    return CaseRecord.from_dict(
        {
            "schema": "research-workflow/case-record",
            "schema_version": 1,
            "record_id": _record_id(6, "migrate"),
            "device_id": "laptop-2",
            "recorded_at": "2026-08-23T01:00:06Z",
            "action": "migrate",
            "sim_id": delta.sim_id,
            "previous_digest": "not-applicable",
            "delta": delta.to_dict(),
            "legacy_binding": {
                "delta_digest": delta.digest,
                "current_spec_digest": "1" * 64,
                "delta_raw_sha256": "2" * 64,
                "delta_raw_bytes": 1,
                "current_spec_raw_sha256": "3" * 64,
                "current_spec_raw_bytes": 1,
            },
        }
    )


def _historical_tombstone(sim_id: str = "project/study/deleted") -> CaseRecord:
    return CaseRecord.from_dict(
        {
            "schema": "research-workflow/case-record",
            "schema_version": 1,
            "record_id": _record_id(7, "migrate-tombstone"),
            "device_id": "laptop-2",
            "recorded_at": "2026-08-23T01:00:07Z",
            "action": "migrate-tombstone",
            "sim_id": sim_id,
            "previous_digest": "not-applicable",
            "legacy_deletion_binding": {
                "sim_id": sim_id,
                "project_id": "project",
                "study_id": "study",
                "revision": 1,
                "source_delta_digest": "4" * 64,
                "source_current_spec_digest": "5" * 64,
                "source_delta_raw_sha256": "6" * 64,
                "source_delta_raw_bytes": 1,
                "source_current_spec_raw_sha256": "7" * 64,
                "source_current_spec_raw_bytes": 1,
                "receipt_digest": "8" * 64,
                "receipt_raw_sha256": "9" * 64,
                "receipt_raw_bytes": 1,
            },
        }
    )


class CaseJournalTests(unittest.TestCase):
    def test_store_requires_thin_schema_without_case_registries(self) -> None:
        document = {
            "schema": "research-workflow/store",
            "schema_version": 2,
            "framework_version": "0",
            "store_id": "test-store",
            "created_at": "2026-08-23T00:00:00Z",
            "projects": [],
            "devices": [],
            "cases": [],
        }
        with self.assertRaisesRegex(ValidationError, "unsupported fields"):
            validate_store_document(document)
        document.pop("cases")
        document["schema_version"] = 1
        with self.assertRaisesRegex(ValidationError, "schema version 2"):
            validate_store_document(document)
        left = case_journal_path("/tmp/metadata", "a/b", "c", "laptop-2", "2026-08")
        right = case_journal_path("/tmp/metadata", "a", "b/c", "laptop-2", "2026-08")
        self.assertNotEqual(left, right)

    def test_reduce_rejects_forks_and_preserves_lifecycle(self) -> None:
        first = _delta("project/study/case-a", 1, "a")
        second = _delta(first.sim_id, 2, "b")
        created = CaseRecord.build_create(first, record_id=_record_id(1, "create"), device_id="laptop-2", recorded_at="2026-08-23T01:00:01Z")
        revised = CaseRecord.build_revise(second, previous_digest=first.digest, record_id=_record_id(2, "revise"), device_id="laptop-2", recorded_at="2026-08-23T01:00:02Z")
        stale = CaseRecord.build_revise(_delta(first.sim_id, 3, "fork"), previous_digest=first.digest, record_id=_record_id(3, "fork"), device_id="laptop-2", recorded_at="2026-08-23T01:00:03Z")
        with self.assertRaisesRegex(ConflictError, "fork or stale"):
            reduce_case_records((created, revised, stale))
        target = _delta("project/study/case-b", 2, "b")
        renamed = CaseRecord.build_rename(first.sim_id, target, previous_digest=second.digest, record_id=_record_id(4, "rename"), device_id="laptop-2", recorded_at="2026-08-23T01:00:04Z")
        deleted = CaseRecord.build_delete(target, previous_digest=target.digest, record_id=_record_id(5, "delete"), device_id="laptop-2", recorded_at="2026-08-23T01:00:05Z")
        heads = reduce_case_records((created, revised, renamed, deleted))
        self.assertEqual(heads[first.sim_id].state, "renamed")
        self.assertEqual(heads[target.sim_id].state, "deleted")

    def test_historical_migration_records_are_readable_but_not_writable(self) -> None:
        migrated = _historical_migration(_delta("project/study/migrated", 3, "historical"))
        tombstone = _historical_tombstone()
        heads = reduce_case_records((migrated, tombstone))
        self.assertEqual(heads[migrated.sim_id].state, "active")
        self.assertEqual((heads[tombstone.sim_id].state, heads[tombstone.sim_id].delta), ("deleted", None))
        with tempfile.TemporaryDirectory() as temporary:
            with self.assertRaisesRegex(ValidationError, "read-only"):
                append_case_records(Path(temporary), (migrated,), current_device="laptop-2")

    def test_store_appends_revises_renames_and_deletes_without_case_tree(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            store = _thin_store(Path(temporary))
            first = _delta("project/study/case-a", 1, "a")
            created = CaseRecord.build_create(first, record_id=_record_id(1, "create"), device_id="laptop-2", recorded_at="2026-08-23T01:00:01Z")
            store.append_case_record(created, current_device="laptop-2", write=True)
            second = _delta(first.sim_id, 2, "b")
            revised = CaseRecord.build_revise(second, previous_digest=first.digest, record_id=_record_id(2, "revise"), device_id="laptop-2", recorded_at="2026-08-23T01:00:02Z")
            store.append_case_record(revised, current_device="laptop-2", write=True)
            target = _delta("project/study/case-b", 2, "b")
            renamed = CaseRecord.build_rename(first.sim_id, target, previous_digest=second.digest, record_id=_record_id(3, "rename"), device_id="laptop-2", recorded_at="2026-08-23T01:00:03Z")
            store.append_case_record(renamed, current_device="laptop-2", write=True)
            deleted = CaseRecord.build_delete(target, previous_digest=target.digest, record_id=_record_id(4, "delete"), device_id="laptop-2", recorded_at="2026-08-23T01:00:04Z")
            store.append_case_record(deleted, current_device="laptop-2", write=True)
            self.assertFalse((store.root / "cases").exists())
            report = store.validate()
            self.assertTrue(report.valid, report.errors)
            self.assertEqual((report.details["case_redirects"], report.details["case_deletions"]), (1, 1))


class CausalOrderingTests(unittest.TestCase):
    def test_digest_ancestry_orders_same_second_and_reversed_clocks(self):
        first = _delta("project/study/causal", 1, "first")
        second = _delta(first.sim_id, 2, "second")
        third = _delta(first.sim_id, 3, "third")
        created = CaseRecord.build_create(first, record_id="20260823T010003Z-laptop-2-z", device_id="laptop-2", recorded_at="2026-08-23T01:00:03Z")
        revised = CaseRecord.build_revise(second, previous_digest=first.digest, record_id="20260823T010003Z-laptop-2-a", device_id="laptop-2", recorded_at="2026-08-23T01:00:03Z")
        last = CaseRecord.build_revise(third, previous_digest=second.digest, record_id="20260823T010001Z-laptop-2-first-clock", device_id="laptop-2", recorded_at="2026-08-23T01:00:01Z")
        from research_workflow.domain import reduce_case_records
        for records in [(created, revised, last), (last, revised, created)]:
            self.assertEqual(reduce_case_records(records)[first.sim_id].revision, 3)


if __name__ == "__main__":
    unittest.main()
