"""Test current Project, Study, profile, Case, event, and status semantics."""

from __future__ import annotations

import unittest

from research_workflow.core import ConflictError, ValidationError
from research_workflow.domain import (
    CaseDelta,
    Correction,
    Evidence,
    Profile,
    ProfileReference,
    Project,
    StatusUpdate,
    Study,
    build_revised_case_delta,
    build_event,
    derive_case_status,
    materialize_case,
    validate_revision,
)
from research_workflow.workspace import LogicalLocator
from research_workflow.domain.knowledge import KnowledgeLink


def _profile(profile_id: str, content: dict[str, object]) -> Profile:
    return Profile.from_dict(
        {
            "schema": "research-workflow/profile",
            "schema_version": 1,
            "profile_id": profile_id,
            "scope": "shared",
            "name": profile_id,
            "content": content,
        }
    )


def _project() -> Project:
    return Project.from_dict(
        {
            "schema": "research-workflow/project",
            "schema_version": 1,
            "project_id": "project",
            "name": "Project",
            "profiles": [{"scope": "shared", "profile_id": "base"}],
            "content": {"physics": {"species": "electron", "density": "unknown"}},
        }
    )


def _study() -> Study:
    return Study.from_dict(
        {
            "schema": "research-workflow/study",
            "schema_version": 1,
            "project_id": "project",
            "study_id": "study",
            "name": "Study",
            "sim_prefix": "project/study",
            "profiles": [{"scope": "shared", "profile_id": "numerics"}],
            "content": {"physics": {"density": "study"}},
        }
    )


def _delta(revision: int = 1) -> CaseDelta:
    return CaseDelta.from_dict(
        {
            "schema": "research-workflow/case-delta",
            "schema_version": 1,
            "sim_id": "project/study/case",
            "project_id": "project",
            "study_id": "study",
            "revision": revision,
            "profiles": [{"scope": "shared", "profile_id": "case"}],
            "content": {"physics": {"density": "case"}},
        }
    )


def _evidence(time: str) -> Evidence:
    return Evidence.from_dict(
        {
            "id": "E1",
            "kind": "validation",
            "locator": {"kind": "case", "sim_id": "project/study/case", "path": "input.deck"},
            "observation": "Fixture validation",
            "observed_at": time,
        }
    )


class _DomainTests(unittest.TestCase):
    """Check materialization order, identity conflicts, and append-only status."""

    def test_ordered_profiles_and_delta_materialize_once(self) -> None:
        """Apply Project, Study, ordered profiles, then Case delta in memory."""

        profiles = {
            ("shared", "base"): _profile("base", {"physics": {"density": "base"}}),
            ("shared", "numerics"): _profile("numerics", {"numerics": {"cells": 10}}),
            ("shared", "case"): _profile("case", {"physics": {"density": "profile"}}),
        }
        view = materialize_case(_project(), _study(), profiles, _delta())
        self.assertEqual(view.content["physics"]["density"], "case")
        self.assertEqual(view.content["numerics"]["cells"], 10)
        self.assertEqual([item.profile_id for item in view.profiles], ["base", "numerics", "case"])
        self.assertEqual(view.to_dict()["schema"], "research-workflow/case-view")

    def test_revision_preserves_immutable_identity(self) -> None:
        """Accept increasing revisions and refuse identity mutation."""

        validate_revision(_delta(1), _delta(2))
        changed = _delta(2).to_dict()
        changed["study_id"] = "other"
        with self.assertRaises(ConflictError):
            validate_revision(_delta(1), CaseDelta.from_dict(changed))

    def test_inline_revision_builder_merges_replaces_removes_and_preserves_identity(self) -> None:
        """Apply deterministic content operations without exposing envelope mutation."""

        previous_data = _delta().to_dict()
        previous_data["content"] = {
            "nested": {"keep": 1, "change": "old", "remove": True},
            "array": [1, 2],
            "type": {"old": True},
        }
        previous = CaseDelta.from_dict(previous_data)
        revised = build_revised_case_delta(
            previous,
            revision=2,
            content_patch={"nested": {"change": "new"}, "array": [3], "type": "scalar"},
            remove_content_paths=("/content/nested/remove",),
        )
        self.assertEqual(
            (revised.sim_id, revised.project_id, revised.study_id, revised.revision),
            (previous.sim_id, previous.project_id, previous.study_id, 2),
        )
        self.assertEqual(revised.profiles, previous.profiles)
        self.assertEqual(
            revised.content,
            {"nested": {"keep": 1, "change": "new"}, "array": [3], "type": "scalar"},
        )
        self.assertEqual(previous.content["nested"]["change"], "old")

    def test_inline_revision_builder_rejects_removal_conflicts(self) -> None:
        """Fail closed for missing, reserved, duplicate, and set/remove paths."""

        checks = (
            ({"content_patch": {}, "remove_content_paths": ("/sim_id",)}, "only /content"),
            ({"content_patch": {}, "remove_content_paths": ("/content/missing",)}, "missing"),
            (
                {"content_patch": {}, "remove_content_paths": ("/content/physics", "/content/physics/density")},
                "overlapping",
            ),
            (
                {"content_patch": {"physics": {"density": "new"}}, "remove_content_paths": ("/content/physics",)},
                "overlap",
            ),
        )
        for arguments, message in checks:
            with self.subTest(arguments=arguments):
                with self.assertRaisesRegex(ValidationError, message):
                    build_revised_case_delta(_delta(), revision=2, **arguments)

    def test_non_unknown_status_requires_evidence(self) -> None:
        """Reject evidence-free non-unknown Run, Data, or Analysis state."""

        with self.assertRaises(ValidationError):
            StatusUpdate.from_dict({"track": "run", "state": "completed", "evidence_ids": []})

    def test_study_event_is_typed_and_cannot_broadcast_status(self) -> None:
        """Allow shared Study history while keeping status Case-specific."""

        owner = LogicalLocator.from_dict(
            {"kind": "study", "project_id": "project", "study_id": "study"}
        )
        event = build_event(
            event_id="20260718T120000Z-laptop-1-study",
            device_id="laptop-1",
            recorded_at="2026-07-18T12:00:00Z",
            occurred_at="2026-07-18T12:00:00Z",
            owner=owner,
            kind="modification",
            summary="Updated shared scan inputs",
            evidence=(),
            status_updates=(),
        )
        self.assertEqual(
            event.to_dict()["owner"],
            {"kind": "study", "project_id": "project", "study_id": "study"},
        )
        evidence = (_evidence("2026-07-18T12:00:00Z"),)
        with self.assertRaises(ValidationError):
            build_event(
                event_id="20260718T120000Z-laptop-1-study-status",
                device_id="laptop-1",
                recorded_at="2026-07-18T12:00:00Z",
                occurred_at="2026-07-18T12:00:00Z",
                owner=owner,
                kind="status-change",
                summary="Invalid shared status",
                evidence=evidence,
                status_updates=(StatusUpdate("run", "running", ("E1",)),),
            )

    def test_correction_replaces_exact_status_track(self) -> None:
        """Derive corrected Run status without editing the superseded event."""

        owner = LogicalLocator("case", "project/study/case")
        first_time = "2026-07-18T12:00:00Z"
        second_time = "2026-07-18T13:00:00Z"
        first = build_event(
            event_id="20260718T120000Z-laptop-1",
            device_id="laptop-1",
            recorded_at=first_time,
            occurred_at=first_time,
            owner=owner,
            kind="status-change",
            summary="Initial status",
            evidence=(_evidence(first_time),),
            status_updates=(StatusUpdate("run", "completed", ("E1",)),),
        )
        correction = build_event(
            event_id="20260718T130000Z-laptop-1",
            device_id="laptop-1",
            recorded_at=second_time,
            occurred_at=first_time,
            owner=owner,
            kind="correction",
            summary="Correct Run status",
            evidence=(_evidence(second_time),),
            status_updates=(StatusUpdate("run", "failed", ("E1",)),),
            correction=Correction(first.event_id, (), ("run",)),
        )
        status = derive_case_status([first, correction], "project/study/case")
        self.assertEqual(status["run"]["state"], "failed")
        self.assertEqual(status["data"]["state"], "unknown")

    def test_duplicate_ordered_profile_refuses_materialization(self) -> None:
        """Refuse repeated profile identities rather than silently reapplying them."""

        project = _project()
        study_data = _study().to_dict()
        study_data["profiles"] = [{"scope": "shared", "profile_id": "base"}]
        profiles = {("shared", "base"): _profile("base", {})}
        with self.assertRaises(ConflictError):
            materialize_case(project, Study.from_dict(study_data), profiles, _delta())

    def test_profile_reference_round_trip(self) -> None:
        """Keep ordered profile identities compact and portable."""

        reference = ProfileReference.from_dict({"scope": "shared", "profile_id": "base"})
        self.assertEqual(reference.to_dict(), {"scope": "shared", "profile_id": "base"})

    def test_schema_two_knowledge_links_are_exact_and_opt_in(self) -> None:
        """Keep Theory or Literature links typed without reading Notes."""

        link = {
            "link_id": "lbw-theory",
            "role": "theory",
            "locator": {"kind": "root", "root_id": "notes", "path": "Theories/lbw.md"},
            "section": "Threshold",
            "external_ref": {"kind": "zotero", "value": "ABCD1234"},
        }
        project_data = _project().to_dict()
        project_data["schema_version"] = 2
        project_data["knowledge_links"] = [link]
        project = Project.from_dict(project_data)
        self.assertEqual(project.knowledge_links[0], KnowledgeLink.from_dict(link))
        self.assertEqual(project.to_dict()["knowledge_links"], [link])

        study_data = _study().to_dict()
        study_data["schema_version"] = 2
        study_data["knowledge_links"] = [link]
        study = Study.from_dict(study_data)
        self.assertIsNone(study.notes)
        self.assertEqual(study.knowledge_links[0].locator.identity, "notes")

    def test_schema_one_refuses_new_knowledge_links(self) -> None:
        """Require an explicit schema transition before adding typed links."""

        document = _study().to_dict()
        document["knowledge_links"] = []
        with self.assertRaises(ValidationError):
            Study.from_dict(document)


if __name__ == "__main__":
    unittest.main()
