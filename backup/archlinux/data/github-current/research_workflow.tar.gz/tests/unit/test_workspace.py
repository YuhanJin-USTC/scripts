"""Test registered-root resolution and access boundaries."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from research_workflow.core import AccessError, DeviceIdentityError, ValidationError
from research_workflow.workspace import LogicalLocator, WorkspaceRegistry, parse_locator


def _workspace(root: Path, *, device: bool = True) -> Path:
    simulation = root / "Simulation"
    data = root / "Data"
    notes = root / "Notes"
    for path in (simulation, data, notes):
        path.mkdir()
    device_text = '\n[device]\ndevice_id = "laptop-1"\n' if device else ""
    config = root / "workspace.toml"
    config.write_text(
        f'''schema_version = 1
workspace_id = "fixture"
verified_at = "2026-07-18T00:00:00Z"
{device_text}
[sim_id]
strategy = "simulation-relative-posix-path"
canonical_root = "simulation"
separator = "/"
case_sensitive = true
same_relative_path_default = true
allow_absolute = false
allow_dot_segments = false

[path_aliases]
policy = "explicit-and-evidence-backed-only"

[roots.simulation]
path = "{simulation}"
kind = "simulation"
mapping = "canonical"
default_access = "project-policy"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"

[roots.data_simulation]
path = "{data}"
kind = "data"
mapping = "same-relative-path"
default_access = "read-only"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"

[roots.notes]
path = "{notes}"
kind = "notes"
mapping = "explicit-link-only"
default_access = "explicit-user-request"
verification = "fixture"
verified_at = "2026-07-18T00:00:00Z"
''',
        encoding="utf-8",
    )
    return config


class _WorkspaceTests(unittest.TestCase):
    """Check canonical mapping, logical locators, and Data or Notes gates."""

    def test_registered_path_resolves_to_sim_id(self) -> None:
        """Resolve an existing Simulation path without alias inference."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            registry = WorkspaceRegistry(_workspace(root))
            case = registry.simulation_root / "project" / "study" / "case"
            case.mkdir(parents=True)
            self.assertEqual(registry.resolve_sim_id(case), "project/study/case")
            self.assertEqual(registry.local_case_path("data_simulation", "project/study/case"), root / "Data/project/study/case")

    def test_data_and_notes_write_gates(self) -> None:
        """Keep Data read-only and Notes restricted to linked reads."""

        with tempfile.TemporaryDirectory() as temporary:
            registry = WorkspaceRegistry(_workspace(Path(temporary)))
            registry.authorize("data_simulation")
            with self.assertRaises(AccessError):
                registry.authorize("data_simulation", write=True)
            with self.assertRaises(AccessError):
                registry.authorize("notes")
            registry.authorize("notes", linked_notes=True)
            with self.assertRaises(AccessError):
                registry.authorize("notes", write=True, linked_notes=True)

    def test_locator_is_git_portable(self) -> None:
        """Validate relative paths and resolve only registered local locators."""

        with tempfile.TemporaryDirectory() as temporary:
            registry = WorkspaceRegistry(_workspace(Path(temporary)))
            locator = LogicalLocator.from_dict(
                {"kind": "root", "root_id": "notes", "path": "study.md"},
                registry,
            )
            self.assertEqual(locator.resolve_local(registry, linked_notes=True), Path(temporary) / "Notes/study.md")
            self.assertEqual(parse_locator("case:project/study/case").identity, "project/study/case")
            study = parse_locator("study:test_sim/test_epoch#numerical_heating")
            self.assertEqual(
                study.to_dict(),
                {
                    "kind": "study",
                    "project_id": "test_sim/test_epoch",
                    "study_id": "numerical_heating",
                },
            )
            with self.assertRaises(ValidationError):
                LogicalLocator.from_dict({"kind": "case", "sim_id": "../case"})

    def test_missing_device_refuses_gate(self) -> None:
        """Refuse gated writes when current device identity is absent."""

        with tempfile.TemporaryDirectory() as temporary:
            registry = WorkspaceRegistry(_workspace(Path(temporary), device=False))
            with self.assertRaises(DeviceIdentityError):
                registry.require_device()

    def test_exact_policy_targets_disable_discovery(self) -> None:
        """Load explicit existing or missing AGENTS targets as one allowlist."""

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            config = _workspace(root)
            text = config.read_text(encoding="utf-8")
            config.write_text(
                text
                + f'''\n[[policy.targets]]
path = "{root / 'AGENTS.md'}"
role = "control"
project = "fixture"
separate_approval = false

[[policy.targets]]
path = "{root / 'Data' / 'AGENTS.md'}"
role = "data"
project = "data"
separate_approval = true
''',
                encoding="utf-8",
            )
            registry = WorkspaceRegistry(config)
            self.assertEqual(len(registry.policy_targets), 2)
            self.assertEqual(registry.policy_targets[0]["path"], str(root / "AGENTS.md"))
            self.assertTrue(registry.policy_targets[1]["separate_approval"])


if __name__ == "__main__":
    unittest.main()
